# -*- coding: utf-8 -*-
"""
DreamMachine Auto-Start Service
Starts the addon automatically when Kodi launches (if setting is enabled)
"""

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ICON = ADDON.getAddonInfo('icon')

def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_NAME}] {msg}", level=level)


def show_notification(title, message, time_ms=4000):
    xbmcgui.Dialog().notification(
        title,
        message,
        icon=ICON,
        time=time_ms,
        sound=False
    )


def auto_start():
    if not ADDON.getSettingBool("autostart"):
        log("Auto-start is disabled in settings")
        return

    log("Auto-start is enabled → launching DreamMachine")

    # Configurable delay with safe fallback
    delay_sec = 0
    try:
        delay_sec = ADDON.getSettingInt("autostart_delay")
    except:
        pass
    if delay_sec > 0:
        xbmc.sleep(delay_sec * 1000)
        log(f"Applied startup delay of {delay_sec} seconds")
    else:
        log("No startup delay configured")

    mode = ADDON.getSettingInt("autostart_mode")
    last_used_server_str = ADDON.getSetting("last_used_server").strip()

    try:
        if mode == 0:
            log("Auto-start mode 0 → opening addon root")
            xbmc.executebuiltin(f'RunAddon("{ADDON_ID}")')
            msg = "Opening main menu..."

        elif mode == 1:  # Auto-load last used Xtream server (smart)
            if not last_used_server_str:
                log("Mode 1 → no last_used_server saved → fallback to server list")
                xbmc.executebuiltin(f'ActivateWindow(Videos,plugin://{ADDON_ID}/?action=select_xtream_server,return)')
                msg = "No saved server → selecting Xtream server..."
            else:
                import json
                try:
                    server_data = json.loads(last_used_server_str)
                    base_url = server_data.get("base_url", "").strip()
                    username = server_data.get("username", "").strip()
                    password = server_data.get("password", "").strip()

                    if not base_url:
                        raise ValueError("base_url missing")

                    log(f"Mode 1 → loading saved server: {base_url} (user={username})")

                    query = f"action=xtreamocodespastebin_categories&page={base_url}"
                    if username:
                        query += f"&extra={username}"
                    if password:
                        query += f"&episode={password}"

                    xbmc.executebuiltin(
                        f'ActivateWindow(Videos,plugin://{ADDON_ID}/?{query},return)'
                    )
                    msg = "Loading last used server..."

                except (json.JSONDecodeError, ValueError) as e:
                    log(f"Cannot load saved server: {repr(e)} → fallback to list")
                    xbmc.executebuiltin(f'ActivateWindow(Videos,plugin://{ADDON_ID}/?action=select_xtream_server,return)')
                    msg = "Saved server invalid → selecting Xtream server..."

        elif mode == 2:  # Always show the Xtream server list
            log("Mode 2 → always showing Xtream server selector")
            xbmc.executebuiltin(f'ActivateWindow(Videos,plugin://{ADDON_ID}/?action=select_xtream_server,return)')
            msg = "Selecting Xtream server..."

        elif mode == 3:
            log("Mode 3 → opening Xtream search selector")
            xbmc.executebuiltin(f'ActivateWindow(Videos,plugin://{ADDON_ID}/?action=xtream_search_selector,return)')
            msg = "Opening search selector..."

        elif mode == 4:
            log("Mode 4 → opening favorites")
            xbmc.executebuiltin(f'ActivateWindow(Videos,plugin://{ADDON_ID}/?action=show_favorite_searches,return)')
            msg = "Opening favorites..."

        else:
            log(f"Invalid autostart_mode ({mode}) → fallback to root")
            xbmc.executebuiltin(f'RunAddon("{ADDON_ID}")')
            msg = "Opening main menu (fallback)"

        show_notification(
            "[COLOR blue]D[COLOR salmon]r[COLOR violet]e[COLOR yellow]a[COLOR orange]m[COLOR lime]M[COLOR red]a[COLOR blue]c[COLOR salmon]h[COLOR violet]i[COLOR yellow]n[COLOR orange]e[/COLOR]",
            f"Auto-starting... {msg}",
            3500
        )

    except Exception as ex:
        log(f"Auto-start failed: {repr(ex)}", xbmc.LOGERROR)
        show_notification(
            "[COLOR blue]D[COLOR salmon]r[COLOR violet]e[COLOR yellow]a[COLOR orange]m[COLOR lime]M[COLOR red]a[COLOR blue]c[COLOR salmon]h[COLOR violet]i[COLOR yellow]n[COLOR orange]e[/COLOR]",
            "Auto-start failed – check log",
            6000
        )


if __name__ == '__main__':
    log("DreamMachine service started")

    monitor = xbmc.Monitor()

    while not monitor.abortRequested():
        if xbmc.getCondVisibility("Window.IsActive(10000)"):  # Home window
            auto_start()
            break

        if monitor.waitForAbort(0.5):
            break

    log("DreamMachine service stopped")