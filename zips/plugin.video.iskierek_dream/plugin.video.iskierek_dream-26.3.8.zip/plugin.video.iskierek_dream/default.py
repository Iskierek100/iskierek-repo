_II='No YouTube ID entered.'
_IH='https://www.youtube.com/watch?v='
_IG='plugin.video.youtube/playlist/'
_IF='#EXTINF:[-0-9\\.]+(?:\\s+[^\\n]*?tvg-logo="(.*?)")?.*?,(.*?)\\n(.*?)(?=\\n|$)'
_IE='Search cancelled, no results found'
_ID=' (partial due to cancellation)'
_IC='https://tv.piperagossip.org/all.m3u'
_IB='https://raw.githubusercontent.com/mu51c/m3u/refs/heads/main/music.m3u'
_IA='https://gitlab.com/beequeen171819/bq/-/raw/main/24-7coord.m3u8'
_I9='Search cancelled — showing partial results'
_I8='password=([^&]+)'
_I7='username=([^&]+)'
_I6='(http://[^/]+/)'
_I5='(http[^&\\s]+/get\\.php\\?username=[^&]+&password=[^&\\s]+)'
_I4='Checking Your Server...'
_I3='Your Server'
_I2='Your Server List'
_I1='(https?://[^/]+)'
_I0='\\s*\\[.*?\\]|\\s*\\(.*?\\)'
_H_='https://iptv-org.github.io/iptv/regions/hispam.m3u'
_Hz='https://iptv-org.github.io/iptv/countries/uk.m3u'
_Hy='https://iptv-org.github.io/iptv/countries/us.m3u'
_Hx='https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/uk.m3u'
_Hw='https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_firetv.m3u'
_Hv='https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_klowdtv.m3u'
_Hu='https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_local.m3u'
_Ht='https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_moveonjoy.m3u'
_Hs='https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_pbs.m3u'
_Hr='https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_pluto.m3u'
_Hq='https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_roku.m3u'
_Hp='https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_samsung.m3u'
_Ho='https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_stirr.m3u'
_Hn='https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_tubi.m3u'
_Hm='https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_tvpass.m3u'
_Hl='https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_xumo.m3u'
_Hk='https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us.m3u'
_Hj='[COLOR blue]US[/COLOR]'
_Hi='Unknown Series'
_Hh='Empty response'
_Hg='application/vnd.apple.mpegurl'
_Hf='video/mp4'
_He='%b %d, %Y'
_Hd='rating_5based'
_Hc='duration_secs'
_Hb='releasedate'
_Ha='An unexpected error occurred. Please try again.'
_HZ='Network error. Please try again.'
_HY='Failed to connect to server. Please try again.'
_HX='Authentication failed.'
_HW='Invalid server response. Please select another server.'
_HV='categories'
_HU='/player_api.php?username='
_HT='Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36'
_HS='Fetching server list...'
_HR='server_check_mode'
_HQ='countryCode'
_HP='Wallis and Futuna'
_HO='Virgin Islands (U.S.)'
_HN='Virgin Islands (British)'
_HM='Saint Vincent and the Grenadines'
_HL='Uzbekistan'
_HK='United States Minor Outlying Islands'
_HJ='Trinidad and Tobago'
_HI='Turkmenistan'
_HH='Timor-Leste'
_HG='Tajikistan'
_HF='French Southern Territories'
_HE='Turks and Caicos Islands'
_HD='Syrian Arab Republic'
_HC='Sint Maarten (Dutch part)'
_HB='El Salvador'
_HA='Sao Tome and Principe'
_H9='South Sudan'
_H8='San Marino'
_H7='Sierra Leone'
_H6='Svalbard and Jan Mayen'
_H5='Saint Helena, Ascension and Tristan da Cunha'
_H4='Seychelles'
_H3='Solomon Islands'
_H2='Palestine, State of'
_H1='Puerto Rico'
_H0='Saint Pierre and Miquelon'
_G_='Papua New Guinea'
_Gz='French Polynesia'
_Gy='Nicaragua'
_Gx='Norfolk Island'
_Gw='New Caledonia'
_Gv='Mauritius'
_Gu='Montserrat'
_Gt='Mauritania'
_Gs='Martinique'
_Gr='Northern Mariana Islands'
_Gq='North Macedonia'
_Gp='Marshall Islands'
_Go='Madagascar'
_Gn='Saint Martin (French part)'
_Gm='Montenegro'
_Gl='Liechtenstein'
_Gk='Saint Lucia'
_Gj='Kazakhstan'
_Gi='Cayman Islands'
_Gh="Korea, Democratic People's Republic of"
_Gg='Saint Kitts and Nevis'
_Gf='Kyrgyzstan'
_Ge='British Indian Ocean Territory'
_Gd='Isle of Man'
_Gc='Heard Island and McDonald Islands'
_Gb='Guinea-Bissau'
_Ga='Guatemala'
_GZ='South Georgia and the South Sandwich Islands'
_GY='Equatorial Guinea'
_GX='Guadeloupe'
_GW='Greenland'
_GV='Gibraltar'
_GU='French Guiana'
_GT='Faroe Islands'
_GS='Micronesia, Federated States of'
_GR='Falkland Islands (Malvinas)'
_GQ='Western Sahara'
_GP='Dominican Republic'
_GO='Christmas Island'
_GN='Cabo Verde'
_GM='Costa Rica'
_GL='Cook Islands'
_GK="Côte d'Ivoire"
_GJ='Central African Republic'
_GI='Congo, Democratic Republic of the'
_GH='Cocos (Keeling) Islands'
_GG='Bouvet Island'
_GF='Bonaire, Sint Eustatius and Saba'
_GE='Brunei Darussalam'
_GD='Saint Barthélemy'
_GC='Burkina Faso'
_GB='Bosnia and Herzegovina'
_GA='Azerbaijan'
_G9='Åland Islands'
_G8='American Samoa'
_G7='Antarctica'
_G6='Antigua and Barbuda'
_G5='Afghanistan'
_G4='<title>(.*?)</title>'
_G3='<description.*?>(.*?)<.*?'
_G2='No categories available on this server. Try another server.'
_G1='(00:.*?79:.*?........)'
_G0='(?s)\\w+ - (\\w+)'
_F_='https://pastebin.com/raw/3Qje1Jaj'
_Fz='("id":"\\d+.*?".*?"title":".*?",")'
_Fy='"cmd":"ffmpeg (.*?)"'
_Fx='No channels found'
_Fw='"name":"(.*?)".*?"id":"(.*?)"'
_Fv='"id":"(.*?)","name":"(.*?)".*?"ch_id":"(.*?)"'
_Fu='Failed to connect to server for handshake'
_Ft='All Channels'
_Fs='"id":"(.*?)".*?"name":"(.*?)"'
_Fr='[COLOR springgreen]Videos On Demand[/COLOR]'
_Fq='[COLOR springgreen]Clear Cache[/COLOR]'
_Fp='your_server'
_Fo='show_favorite_searches'
_Fn='search_current_xtream_server'
_Fm='special://home/addons/plugin.video.dreammachine/fanart.jpg'
_Fl='search.png'
_Fk='xtream.png'
_Fj='media_playlists'
_Fi='Search_yt'
_Fh='add_playlist'
_Fg='list_xml_streams'
_Ff='xtream_episodes'
_Fe='merged_series_episodes'
_Fd='merged_series_seasons'
_Fc='search_xtream_series'
_Fb='show_movie_sources'
_Fa='search_xtream_vod'
_FZ='search_m3u'
_FY='search_radio'
_FX='search_premium_m3u'
_FW='search_mac'
_FV='xtream_series_list'
_FU='xtream_list'
_FT='xtream_vod_list'
_FS='ipkoditv_enigmax'
_FR='todays_list'
_FQ='change_mac'
_FP='change_server'
_FO='view_channels'
_FN='macpastebinx'
_FM='playlist'
_FL='DefaultAddonSearch.png'
_FK='Search.png'
_FJ='[COLOR cyan][B]Search Xtream - Select List[/B][/COLOR]'
_FI='memory_cache'
_FH='Search cancelled or empty'
_FG='&title='
_FF='videos'
_FE='https://raw.githubusercontent.com/junguler/m3u-radio-music-playlists/main/---everything-full.m3u'
_FD='https://raw.githubusercontent.com/mu51c/m3u/refs/heads/main/latinamerica.m3u'
_FC='https://raw.githubusercontent.com/mu51c/m3u/refs/heads/main/uk.m3u'
_FB='https://raw.githubusercontent.com/mu51c/m3u/refs/heads/main/us3.m3u'
_FA='https://raw.githubusercontent.com/mu51c/m3u/refs/heads/main/us2.m3u'
_F9='https://raw.githubusercontent.com/mu51c/m3u/refs/heads/main/us.m3u'
_F8='https://tinyurl.com/bestonkodi-tv'
_F7='https://gitlab.com/beequeen171819/bq/-/raw/main/Pay-Per-View-Movies.m3u'
_F6='https://raw.githubusercontent.com/mu51c/m3u/refs/heads/main/1CLICK3.m3u'
_F5='https://raw.githubusercontent.com/mu51c/m3u/refs/heads/main/1CLICK2.m3u'
_F4='https://raw.githubusercontent.com/mu51c/m3u/refs/heads/main/1CLICK.m3u'
_F3='en-US'
_F2='language'
_F1='api_key'
_F0='unknown'
_E_='runtime'
_Ez='release'
_Ey='Invalid URL format'
_Ex='other'
_Ew='<![CDATA['
_Ev='Please select a server first.'
_Eu='springgreen'
_Et='/enigma2.php?username='
_Es='%Y-%m-%d'
_Er='Zimbabwe'
_Eq='Zambia'
_Ep='Viet Nam'
_Eo='Venezuela'
_En='Uganda'
_Em='Tanzania'
_El='Turkey'
_Ek='Tunisia'
_Ej='Slovakia'
_Ei='Slovenia'
_Eh='Sweden'
_Eg='Saudi Arabia'
_Ef='Serbia'
_Ee='Romania'
_Ed='Qatar'
_Ec='Portugal'
_Eb='Poland'
_Ea='Pakistan'
_EZ='Philippines'
_EY='Nepal'
_EX='Norway'
_EW='Netherlands'
_EV='Nigeria'
_EU='Mozambique'
_ET='Malta'
_ES='Mongolia'
_ER='Myanmar'
_EQ='Morocco'
_EP='Libya'
_EO='Latvia'
_EN='Luxembourg'
_EM='Lithuania'
_EL='Sri Lanka'
_EK='Lebanon'
_EJ="Lao People's Democratic Republic"
_EI='Kuwait'
_EH='Cambodia'
_EG='Kenya'
_EF='Jordan'
_EE='Italy'
_ED='Iceland'
_EC='Israel'
_EB='Ireland'
_EA='Hungary'
_E9='Croatia'
_E8='Greece'
_E7='Ghana'
_E6='United Kingdom'
_E5='France'
_E4='Finland'
_E3='Spain'
_E2='Egypt'
_E1='Estonia'
_E0='Algeria'
_D_='Denmark'
_Dz='Germany'
_Dy='Czechia'
_Dx='Cyprus'
_Dw='Colombia'
_Dv='China'
_Du='Chile'
_Dt='Switzerland'
_Ds='Bahrain'
_Dr='Bulgaria'
_Dq='Belgium'
_Dp='Bangladesh'
_Do='Austria'
_Dn='United Arab Emirates'
_Dm='&type=get_live_categories'
_Dl='portal"(.*?)"'
_Dk='portal2'
_Dj='Server Error'
_Di='"id":"(\\d+.*?)".*?"title":"(.*?)"'
_Dh='stb_type'
_Dg='login'
_Df='"stb_type":"(.*?)"'
_De='login":"","password":"(.*?)"'
_Dd='Invalid server response'
_Dc='[B][COLOR yellow]Enter Password: [/COLOR][/B]'
_Db='"id":"([^"]+)".*?"title":"([^"]+)"'
_Da='.json'
_DZ='timestamp'
_DY='query'
_DX='resources'
_DW='params'
_DV='list_default_playlists'
_DU='resolve_resolveurl_youtube'
_DT='playyt'
_DS='search_xtream'
_DR='xtream_series_categories'
_DQ='xtream_vod_categories'
_DP='xtreamocodespastebin_categories'
_DO='ipkoditv_enigma2'
_DN='moviesA'
_DM='main_list'
_DL='settings'
_DK='clear_cache'
_DJ='session'
_DI='Empty search query'
_DH='poster_path'
_DG='tmdb_id'
_DF='movies'
_DE='description'
_DD='movie'
_DC='Missing parameters. Please select a server first.'
_DB='all series'
_DA='english'
_D9='Invalid server URL. Please select another server.'
_D8='series'
_D7='[COLOR springgreen]Xtream - Your Server List[/COLOR]'
_D6='server_check_order'
_D5='South Africa'
_D4='Taiwan'
_D3='Thailand'
_D2='Singapore'
_D1='New Zealand'
_D0='Malaysia'
_C_='Mexico'
_Cz='Korea, Republic of'
_Cy='Japan'
_Cx='India'
_Cw='Indonesia'
_Cv='Hong Kong'
_Cu='Canada'
_Ct='Brazil'
_Cs='Australia'
_Cr='Argentina'
_Cq='Mozilla/5.0'
_Cp='latrop'
_Co='revres'
_Cn='Cache-Control'
_Cm='Pragma'
_Cl='token":"(.*?)"'
_Ck='[COLOR red]Password INCORRECT![/COLOR]'
_Cj='[COLOR cyan]Skip Adult Content[/COLOR]'
_Ci='premium'
_Ch='category_id'
_Cg='Container.Update(plugin://plugin.video.dreammachine/?action=show_favorite_searches,replace)'
_Cf='userp'
_Ce='plugin.video.dreammachine'
_Cd='list_json_playlists'
_Cc='radio_play'
_Cb='ipkoditv_enigmapb'
_Ca='xtreamcodes'
_CZ='special://temp/dreammachine_cache/'
_CY='Search cancelled'
_CX='stream_url'
_CW='No plot available'
_CV='poster'
_CU='all'
_CT='country_code'
_CS='United States'
_CR='Live Streams'
_CQ='genres'
_CP='[COLOR springgreen]Enter password[/COLOR]'
_CO='[COLOR red]Contains Adult Content, PASSWORD REQUIRED:[/COLOR]'
_CN='CnIg'
_CM='parental_password'
_CL='parental_control'
_CK='selected'
_CJ='last_used_server'
_CI='user_server_list'
_CH='https://pastebin.com/raw/eWsFTyRy'
_CG='[COLOR blue]Xtream Servers List 4[/COLOR]'
_CF='https://raw.githubusercontent.com/akeotaseo/world_repo/refs/heads/main/Updater_Matrix/XML2/25.txt'
_CE='[COLOR yellow]Xtream Servers List 3[/COLOR]'
_CD='https://raw.githubusercontent.com/akeotaseo/world_repo/refs/heads/main/Updater_Matrix/XML2/ABN.txt'
_CC='[COLOR springgreen]Xtream Servers List 2[/COLOR]'
_CB='https://raw.githubusercontent.com/akeotaseo/world_repo/refs/heads/main/Updater_Matrix/XML2/%7BAllTelegram%7D2.txt'
_CA='[COLOR blue]Xtream Servers List 1[/COLOR]'
_C9='Window(Home).Property(DreamMachine.LastFavoriteQuery)'
_C8='category_name'
_C7='files'
_C6='passxc'
_C5='usernamexc'
_C4='results'
_C3='m3ugithub'
_C2='select_xtream_server'
_C1='listB'
_C0='listA'
_B_='Kodi/21'
_Bz='Plot'
_By='season'
_Bx='display_name'
_Bw='overview'
_Bv='stream_icon'
_Bu='check_only'
_Bt='kstv.us'
_Bs='allow'
_Br='ClearProperty(DreamMachine.LastFavoriteQuery,Home)'
_Bq='lanza'
_Bp='play_stream'
_Bo='xtream_search_selector'
_Bn='xtreamocodespastebin'
_Bm='[/COLOR]'
_Bl='episode_run_time'
_Bk='backdrop_path'
_Bj='stream_id'
_Bi='portalxc'
_Bh='color'
_Bg='radio'
_Bf='mac2'
_Be='season_number'
_Bd='servers'
_Bc='cover'
_Bb='mediatype'
_Ba='genre'
_BZ='hidexxx'
_BY='Action(Back)'
_BX='[COLOR white]'
_BW='no-cache'
_BV='escort'
_BU='swinger'
_BT='red light'
_BS='redlight'
_BR='fetish'
_BQ='nude'
_BP='only fans'
_BO='onlyfans'
_BN='shemale'
_BM='trans'
_BL='gay'
_BK='lesbian'
_BJ='anal'
_BI='milf'
_BH='hardcore'
_BG='private'
_BF='hustler'
_BE='fuck'
_BD='sex'
_BC='erotica'
_BB='linkdirectoxc'
_BA='sources'
_B9='info'
_B8='series_id'
_B7='year'
_B6='&password='
_B5='Authorization'
_B4='a d u l t'
_B3='adult content'
_B2='nsfw'
_B1='mature'
_B0='xxx :'
_A_='18 plus'
_Az='penthouse'
_Ay='xxx more'
_Ax=' 18'
_Aw='+ 18'
_Av='     [COLOR blue]D    [COLOR salmon]r    [COLOR violet]e    [COLOR yellow]a    [COLOR orange]m    [COLOR lime]M    [COLOR red]a    [COLOR blue]c    [COLOR salmon]h    [COLOR violet]i    [COLOR yellow]n    [COLOR orange]e[/COLOR]'
_Au='base_url'
_At='data'
_As='isPlayable'
_Ar='folder'
_Aq='vod x'
_Ap='horny'
_Ao='live cam'
_An='webcam'
_Am='camgirl'
_Al='babes'
_Ak='dorcel'
_Aj='stars exclusive'
_Ai='red tv porn premium (+18)'
_Ah='x4 |'
_Ag='live webcam shows'
_Af='adultes'
_Ae='adult (18+)'
_Ad='xxx | vip 18+'
_Ac='adultos'
_Ab='special porn +18'
_Aa='adult vip +18'
_AZ='porn box vip +18'
_AY='xxx 18+ (adult)'
_AX='golden vip+18'
_AW='golden +18'
_AV='jp : adult xxx'
_AU='xxx | adults'
_AT='adult channels'
_AS='+18'
_AR='portal'
_AQ='Container.Refresh'
_AP='seasons'
_AO='cast'
_AN='Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0'
_AM='yes'
_AL='adult premium'
_AK='xxx-vip 18+'
_AJ='xx/ for adults+18'
_AI='xxx-vip'
_AH='xx | for adults'
_AG='for adults'
_AF='xxx : for adults'
_AE='IsPlayable'
_AD='episode_num'
_AC='Action(ParentDir)'
_AB='video'
_AA='mp4'
_A9='js'
_A8='false'
_A7='Unknown'
_A6='Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Mobile Safari/537.36'
_A5='Cookie'
_A4='username'
_A3='duration'
_A2='key'
_A1='mac'
_A0='episodes'
_z='block'
_y='container_extension'
_x='Error'
_w=' '
_v='password'
_u='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0'
_t='brazzers'
_s='playboy'
_r='adults only'
_q='erotic'
_p='18+'
_o='country'
_n='|'
_m=','
_l='xxx'
_k='adult'
_j='*/*'
_i='Accept'
_h='rating'
_g='0'
_f='https://'
_e='http://'
_d='action'
_c='gzip, deflate'
_b='Accept-Encoding'
_a='keep-alive'
_Z='Connection'
_Y='episode'
_X='porn'
_W='plot'
_V='listm3u1'
_U='thumb'
_T='[COLOR white]--------------------------- T h e L a b ---------------------------[/COLOR]'
_S='extra'
_R='/'
_Q='N/A'
_P='page'
_O='id'
_N='true'
_M='thumbnail'
_L='name'
_K='fanart'
_J='User-Agent'
_I='url'
_H='title'
_G=None
_F='ignore'
_E='utf-8'
_D='[COLOR blue]D[COLOR salmon]r[COLOR violet]e[COLOR yellow]a[COLOR orange]m[COLOR lime]M[COLOR red]a[COLOR blue]c[COLOR salmon]h[COLOR violet]i[COLOR yellow]n[COLOR orange]e[/COLOR]'
_C='\x00'
_B=False
_A=True
import os,sys,json,time,hashlib,re,requests,socket,xbmc,xbmcvfs,xbmcgui,xbmcaddon,xbmcplugin,random,base64,platform,threading,urllib.parse,sqlite3
from datetime import date,datetime,timedelta
from urllib.request import urlopen,Request
from urllib.error import HTTPError,URLError
from resources.modules import control,plugintools
from urllib.parse import urlparse,urlencode,parse_qs,quote,unquote,urljoin
from concurrent.futures import ThreadPoolExecutor,as_completed,TimeoutError
from threading import Event
import xml.etree.ElementTree as ET,threading,platform
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from requests.exceptions import HTTPError
ADDON_DATA_DIR=xbmcvfs.translatePath('special://profile/addon_data/plugin.video.dreammachine/')
CACHE_DIR=os.path.join(ADDON_DATA_DIR,'cache/')
CACHE_DB_PATH=os.path.join(ADDON_DATA_DIR,'cache.db')
def init_sqlite_cache():
	try:
		if not xbmcvfs.exists(ADDON_DATA_DIR):xbmcvfs.mkdirs(ADDON_DATA_DIR)
		conn=sqlite3.connect(CACHE_DB_PATH);c=conn.cursor();c.execute('CREATE TABLE IF NOT EXISTS cache (\n                        key TEXT PRIMARY KEY,\n                        value TEXT NOT NULL,\n                        timestamp REAL NOT NULL,\n                        duration INTEGER NOT NULL\n                     )');conn.commit();conn.close()
	except Exception as e:pass
init_sqlite_cache()
def sqlite_write_cache(key,data,duration=86400,cache_duration=_G):
	if not data:return
	use_duration=duration if cache_duration is _G else cache_duration
	try:conn=sqlite3.connect(CACHE_DB_PATH);c=conn.cursor();timestamp=time.time();json_str=json.dumps(data);encoded_value=base64.b64encode(json_str.encode(_E)).decode(_E);c.execute('INSERT OR REPLACE INTO cache (key, value, timestamp, duration) VALUES (?, ?, ?, ?)',(key,encoded_value,timestamp,use_duration));conn.commit();conn.close()
	except Exception:pass
def sqlite_read_cache(key):
	try:
		conn=sqlite3.connect(CACHE_DB_PATH);c=conn.cursor();c.execute('SELECT value, timestamp, duration FROM cache WHERE key = ?',(key,));row=c.fetchone();conn.close()
		if row:
			value,timestamp,duration=row
			if time.time()<timestamp+duration:
				try:json_str=base64.b64decode(value.encode(_E)).decode(_E);return json.loads(json_str)
				except Exception:
					try:return json.loads(value)
					except Exception:pass
			try:conn=sqlite3.connect(CACHE_DB_PATH);c=conn.cursor();c.execute('DELETE FROM cache WHERE key = ?',(key,));conn.commit();conn.close()
			except:pass
		return
	except Exception:pass;return
def clear_cache(params=_G):
	cleared_count=0;total_deleted=0
	try:conn=sqlite3.connect(CACHE_DB_PATH);c=conn.cursor();c.execute('SELECT COUNT(*) FROM cache').fetchone()[0];c.execute('DELETE FROM cache');conn.commit();c.execute('VACUUM');conn.commit();conn.close();cleared_count+=1
	except Exception:pass
	DREAM_CACHE_DIR=xbmcvfs.translatePath(_CZ)
	def delete_recursive(path):
		deleted=0
		if xbmcvfs.exists(path):
			try:
				dirs,files=xbmcvfs.listdir(path)
				for file in files:
					file_path=path+file
					if xbmcvfs.delete(file_path):deleted+=1
				for d in dirs:sub_path=path+d+_R;deleted+=delete_recursive(sub_path)
				xbmcvfs.rmdir(path)
			except Exception:pass
		return deleted
	try:
		if xbmcvfs.exists(DREAM_CACHE_DIR):total_deleted=delete_recursive(DREAM_CACHE_DIR);xbmcvfs.rmdir(DREAM_CACHE_DIR);cleared_count+=1
	except Exception:pass
	try:
		if xbmcvfs.exists(CACHE_DIR):addon_deleted=delete_recursive(CACHE_DIR);total_deleted+=addon_deleted;xbmcvfs.rmdir(CACHE_DIR)
	except Exception:pass
	if total_deleted>0 or cleared_count>0:msg=f"Cache {total_deleted} Files / DataBase Cleaned";xbmcgui.Dialog().notification(addonname,msg,xbmcgui.NOTIFICATION_INFO,6000)
	else:xbmcgui.Dialog().notification(addonname,'No cache files found.',xbmcgui.NOTIFICATION_INFO,3000)
	xbmc.executebuiltin(_AQ)
executor=ThreadPoolExecutor(max_workers=5)
session=requests.Session()
session.headers.update({_J:_B_})
adapter=requests.adapters.HTTPAdapter(pool_connections=10,pool_maxsize=10)
session.mount(_e,adapter)
session.mount(_f,adapter)
_session=_G
_geo_cache={}
logged_entries=set()
def get_session():
	try:import requests;from requests.adapters import HTTPAdapter;from urllib3.util.retry import Retry;session=requests.Session();retry=Retry(total=2,backoff_factor=.5,status_forcelist=[500,502,503,504]);adapter=HTTPAdapter(max_retries=retry);session.mount(_e,adapter);session.mount(_f,adapter);session.headers.update({_J:'Kodi/DreamMachine'});return session
	except Exception as e:return requests.Session()
logged_entries=set()
def trace_calls(frame,event,arg):
	B='return';A='call'
	if event not in(A,B):return trace_calls
	co=frame.f_code;func_name=co.co_name;target_functions={'check_repository_source','check_marker_file','set_search_cancelled','is_search_cancelled','display_cached_results','change_background','reset_welcome_flag','show_welcome_screen','run','get_cache_file','write_cache','read_cache','sqlite_write_cache','sqlite_read_cache',_DK,_DL,'keyboard_input','userpastebin','portpopup','macpopup','userxtream','passxtream','portalxtream','search_popup',_DM,_A1,_Ca,_FN,'macpastebin','macx',_Bf,'chance','macs_handshake','macs_categories',_C0,_C1,_DN,'moviesB','moviesC',_FO,_FP,_FQ,_FR,'mac_portal','get_channels',_FS,'ipkoditv_enigma',_Cb,_DO,_Bn,'get_geo_data','fetch_server_details','test_server',_C2,'fetch_server_info',_DP,_DQ,_FT,'xtream_vod_play',_FU,_DR,_FV,'xtream_series_seasons','xtream_season_list','xtream_live_play',_BB,'m3u',_V,_Cc,_C3,_Bg,_FW,'fetch_genre_channels',_DS,_FX,_FY,'search_mac_channels','fetch_xtream_url','get_search_history_file','save_search_history','read_search_history','clear_search_history','manage_search_history','search_xtream_resume',_FZ,'fetch_m3u_url','search_premium_m3u_channels','search_radio_channels',_Bh,'log','read_search_cache','write_search_cache',_Fa,_Fb,_Fc,_Fd,_Fe,'xtream_seasons',_Ff,_Bo,'check_vod','check_series','check_one','search_xtream_country_priority','yt_stream_list',_Fg,_Bp,_Bq,_DT,_Fh,_DU,'clean_title_for_tmdb','_get_tmdb_details','youtube',_Fi,'ytfilme','yt_main_list',_DV,_Fj,_Cd}
	if func_name.lower()not in target_functions:return trace_calls
	caller=frame.f_back;caller_name=caller.f_code.co_name if caller else'<module>'
	if event==A:
		args_summary=''
		try:
			if _DW in frame.f_locals:
				params_val=frame.f_locals[_DW];param_str=str(params_val)
				if len(param_str)>200:param_str=param_str[:197]+'...'
				args_summary=f" params={param_str}"
		except:pass
		entry_key=f"ENTER {func_name} from {caller_name}{args_summary}"
		if entry_key not in logged_entries:logged_entries.add(entry_key);xbmc.log(f"-=> DreamMachine <=- {entry_key}",xbmc.LOGINFO)
	elif event==B:
		suffix=''
		try:
			if arg is not _G:result_type=type(arg).__name__;suffix=f" → {result_type}"
		except:pass
		exit_key=f"EXIT {func_name}{suffix}"
		if exit_key not in logged_entries:logged_entries.add(exit_key);xbmc.log(f"-=>DreamMachine<=- {exit_key}",xbmc.LOGINFO)
	return trace_calls
if not xbmc.getCondVisibility('System.Platform.Android'):threading.settrace(trace_calls);sys.settrace(trace_calls)
_search_cancel_event=Event()
_search_cancelled=_B
_current_search_cache={_A2:_G,_C4:_G}
_SEARCH_CACHE_KEY='DreamMachine_CurrentSearch_v3'
_current_series_cache={}
ADDON=xbmcaddon.Addon()
ADDON_ID=ADDON.getAddonInfo(_O)
addonDir=ADDON.getAddonInfo('path')
OFFICIAL_REPO_ID='repository.iskierek.repo'
MARKER_FILE_PATH=os.path.join(addonDir,_DX,'The.Lab')
EXPECTED_MARKER_CONTENT='• Téch E. Coyoté •'
addonname=_D
myaddon=xbmcaddon.Addon(_Ce)
icon=ADDON.getAddonInfo('icon')
addon_path=xbmcvfs.translatePath('special://home/addons/plugin.video.dreammachine/')
FAVORITES_FILE=xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.dreammachine/favorites.json')
CACHE_DIR=xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.dreammachine/cache/')
if not xbmcvfs.exists(CACHE_DIR):xbmcvfs.mkdirs(CACHE_DIR)
modules_path=os.path.join(addon_path,_DX,'modules')
if modules_path not in sys.path:sys.path.append(modules_path)
portal=control.setting(_AR)
mac=control.setting(_A1)
userp=control.setting(_Cf)
portalxc=control.setting(_Bi)
usernamexc=control.setting(_C5)
passxc=control.setting(_C6)
mislogos=xbmcvfs.translatePath(os.path.join('special://home','addons',_Ce,_DX,'media'))
transparent=xbmcvfs.translatePath(os.path.join(mislogos,'transparent.png'))
backgrnd=xbmcvfs.translatePath(os.path.join(mislogos,'fanart.jpg'))
backgrnd1=xbmcvfs.translatePath(os.path.join(mislogos,'image1.jpg'))
backgrnd2=xbmcvfs.translatePath(os.path.join(mislogos,'image2.jpg'))
backgrnd3=xbmcvfs.translatePath(os.path.join(mislogos,'image3.jpg'))
backgrnd4=xbmcvfs.translatePath(os.path.join(mislogos,'image4.jpg'))
backgrnd5=xbmcvfs.translatePath(os.path.join(mislogos,'image5.jpg'))
stbmac=xbmcvfs.translatePath(os.path.join(mislogos,'stbmac.png'))
xtream=xbmcvfs.translatePath(os.path.join(mislogos,_Fk))
setting=xbmcvfs.translatePath(os.path.join(mislogos,'setting.png'))
cache=xbmcvfs.translatePath(os.path.join(mislogos,'cache.png'))
search=xbmcvfs.translatePath(os.path.join(mislogos,_Fl))
radiothmb=xbmcvfs.translatePath(os.path.join(mislogos,'radiothmb.png'))
free=xbmcvfs.translatePath(os.path.join(mislogos,'free.png'))
premium=xbmcvfs.translatePath(os.path.join(mislogos,'premium.png'))
external=xbmcvfs.translatePath(os.path.join(mislogos,'external.png'))
utube=xbmcvfs.translatePath(os.path.join(mislogos,'utube.png'))
search_icon=xbmcvfs.translatePath(os.path.join(mislogos,_Fl))
fanart=xbmcvfs.translatePath(_Fm)
show_server_names=myaddon.getSettingBool('show_server_in_title')
def ensure_favorites_file():
	dir_path=os.path.dirname(FAVORITES_FILE)
	if not xbmcvfs.exists(dir_path+_R):xbmcvfs.mkdirs(dir_path)
	if not xbmcvfs.exists(FAVORITES_FILE):xbmcvfs.File(FAVORITES_FILE,'w').write(json.dumps([]))
def get_favorite_searches():
	ensure_favorites_file()
	try:
		with xbmcvfs.File(FAVORITES_FILE)as f:content=f.read();return json.loads(content)if content.strip()else[]
	except:return[]
def save_favorite_searches(terms):
	ensure_favorites_file()
	try:
		with xbmcvfs.File(FAVORITES_FILE,'w')as f:f.write(json.dumps(terms,ensure_ascii=_B,indent=2))
	except Exception as e:pass
def add_favorite_search(term):
	if not term or not term.strip():return
	term=term.strip();favs=get_favorite_searches()
	if term.lower()not in[t.lower()for t in favs]:favs.append(term);save_favorite_searches(favs);xbmc.executebuiltin('Notification(DreamMachine,Favorite added: [B]'+term+'[/B],3000)')
def add_favorite_manually(params):
	kb=xbmc.Keyboard('',"[COLOR blue]D[COLOR salmon]r[COLOR violet]e[COLOR yellow]a[COLOR orange]m[COLOR lime]M[COLOR red]a[COLOR blue]c[COLOR salmon]h[COLOR violet]i[COLOR yellow]n[COLOR orange]e[/COLOR] Favorite - Use '[COLOR yellow]|[/COLOR]' as Separator for Multi-Term Search");kb.doModal()
	if not kb.isConfirmed():xbmc.executebuiltin(_Cg);return
	term=kb.getText().strip()
	if not term:xbmcgui.Dialog().ok(_D,'Cannot add empty favorite.');return
	current_favs=get_favorite_searches()
	if term.lower()in[f.lower()for f in current_favs]:xbmcgui.Dialog().ok(_D,f'"{term}" is already in favorites.');return
	current_favs.append(term);save_favorite_searches(current_favs);xbmcgui.Dialog().notification(_D,f"Favorite added: [B]{term}[/B]",xbmcgui.NOTIFICATION_INFO,4000);xbmc.executebuiltin(_Cg)
def prompt_add_favorite(query):
	if myaddon.getSetting('favorited_search_terms')!=_N:return
	if not query or not query.strip():return
	query=query.strip()
	if xbmcgui.Dialog().yesno('DreamMachine - Favorites',f"Add search term to favorites?\n\n[B]{query}[/B]"):add_favorite_search(query)
def show_favorite_searches(params):
	favs=get_favorite_searches();handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,'Favorite Searches');xbmcplugin.setContent(handle,_C7);xtream_icon=xbmcvfs.translatePath(os.path.join(mislogos,_Fk));add_url=f"{sys.argv[0]}?action=add_favorite_manually";li=xbmcgui.ListItem('[B]Add New Favorite Search[/B]');li.setArt({_U:'DefaultAddSource.png',_K:backgrnd1});xbmcplugin.addDirectoryItem(handle,add_url,li,isFolder=_A);delete_url=f"{sys.argv[0]}?action=delete_favorite_searches";li=xbmcgui.ListItem('[B]Delete Favorite Searches[/B]');li.setArt({_U:'DefaultHardDisk.png',_K:backgrnd1});xbmcplugin.addDirectoryItem(handle,delete_url,li,isFolder=_A)
	for term in favs:url=f"{sys.argv[0]}?action=run_favorite_search&query={quote(term)}";li=xbmcgui.ListItem(f"[B]{term}[/B]");li.setArt({_U:xtream_icon,_K:backgrnd1});li.setProperty(_AE,_A8);xbmcplugin.addDirectoryItem(handle,url,li,isFolder=_A)
	xbmcplugin.endOfDirectory(handle,cacheToDisc=_B)
def run_favorite_search(params):
	query=urllib.parse.unquote(params.get(_DY,'')).strip()
	if not query:return
	xbmc.executebuiltin(f"SetProperty(DreamMachine.LastFavoriteQuery,{query},Home)");xtream_search_selector(params)
def delete_favorite_searches(params):
	favs=get_favorite_searches()
	if not favs:xbmcgui.Dialog().ok(_D,'No favorites to delete.');return
	bold_favs=[f"[B]{term}[/B]"for term in favs];dialog=xbmcgui.Dialog();selected=dialog.multiselect('Select favorites to DELETE',bold_favs,preselect=[])
	if selected is _G:xbmc.executebuiltin(_Cg);return
	if not selected:xbmcgui.Dialog().ok(_D,'No items selected.');return
	confirm=xbmcgui.Dialog().yesno('Confirm Delete',f"Permanently delete [B]{len(selected)}[/B] favorite{'s'if len(selected)!=1 else''}?")
	if not confirm:return
	remaining=[favs[i]for i in range(len(favs))if i not in selected];save_favorite_searches(remaining);xbmcgui.Dialog().notification(_D,f"Deleted {len(selected)} favorite{'s'if len(selected)!=1 else''}",xbmcgui.NOTIFICATION_INFO,3000);xbmc.executebuiltin(_Cg)
def is_adult(item):
	if not isinstance(item,dict):return _B
	name=str(item.get(_L)or'').lower();cat_name=str(item.get(_C8)or item.get('category')or'').lower();cat_id=str(item.get(_Ch)or'').lower();stream_type=str(item.get('stream_type')or'').lower();title=str(item.get(_H)or'').lower();adult_keywords=[_k,_l,_X,_p,_AS,_q,_BC,_BD,_BE,_s,_t,_BF,_BG,_BH,_BI,_BJ,_BK,_BL,_BM,_BN,_BO,_BP,_BQ,_BR,_BS,_BT,_BU,_BV,_AT,_AU,_AV,_AW,_AX,_AY,_AZ,_Aa,_Ab,_r,_Ac,_Ad,_Ae,_Af,_Ag,_Ah,_Ai,_Aj,_Ak,_Al,_Am,_An,_Ao,_Ap,_Aq];text_fields=f"{name} {cat_name} {cat_id} {stream_type} {title}"
	if any(k in text_fields for k in adult_keywords):return _A
	if cat_id in{'18','19','99',_k,_l,_X,_q,_AS,_AT,_AU,_AV,_AW,_AX,_AY,_AZ,_Aa,_Ab,_r,_Ac,_Ad,_Ae,_Af,_Ag,_Ah,_Ai,_Aj,_Ak,_Al,_Am,_An,_Ao,_Ap,_Aq}:return _A
	if stream_type in{_k,_l,_p,_X}:return _A
	return _B
def check_repository_source():
	D='addon';C='version';B='enabled';A='result'
	try:
		query={'jsonrpc':'2.0','method':'Addons.GetAddonDetails',_DW:{'addonid':OFFICIAL_REPO_ID,'properties':[B,C]},_O:1};response=json.loads(xbmc.executeJSONRPC(json.dumps(query)))
		if A in response and D in response[A]:
			addon=response[A][D]
			if addon.get(B,_B):
				expected_version='25.3.27';installed_version=addon.get(C,'')
				if installed_version==expected_version:return _A
				else:return _B
			else:return _B
		else:return _B
	except Exception:return _B
def check_marker_file():
	try:
		if os.path.exists(MARKER_FILE_PATH):
			with open(MARKER_FILE_PATH,'r',encoding=_E)as f:
				content=f.read().strip()
				if content==EXPECTED_MARKER_CONTENT:return _A
				else:return _B
		else:return _B
	except Exception:return _B
def set_search_cancelled(value):global _search_cancelled;_search_cancelled=value
def is_search_cancelled():global _search_cancelled;return _search_cancelled
def display_cached_results(params):
	A='xtream';section=params.get('section','');query=params.get(_DY,'')
	if not section or not query:xbmcgui.Dialog().notification(_D,'Invalid navigation context',xbmcgui.NOTIFICATION_ERROR,3000);return
	cache_key=f"search_results_{section}_query={query}";results=sqlite_read_cache(cache_key)
	if not results:xbmcgui.Dialog().notification(_D,'No cached results found',xbmcgui.NOTIFICATION_INFO,3000);section_to_action={'free':'m3u',_Ci:_C3,_A1:_A1,_Bg:_Bg,A:_Ca};action=section_to_action.get(section,_DM);exec(f"{action}(params)");return
	handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,f"{section.capitalize()} Search Results");xbmcplugin.setContent(handle,_C7)
	for result in results:plugintools.add_item(action=result[_d],title=f"[COLOR white]{color(result[_H])}[/COLOR]",thumbnail=result[_M],fanart=result[_K],url=result.get(_I,''),page=result.get(_P,''),plot=result.get(_W,''),extra=result.get(_S,''),episode=result.get(_Y,''),section=section,query=query,folder=result[_Ar],isPlayable=result.get(_As,_B))
	section_to_action={'free':'m3u',_Ci:_C3,_A1:_A1,_Bg:_Bg,A:_Ca};action=section_to_action.get(section,_DM);plugintools.add_item(action=action,title='[B]Back[/B]',thumbnail=globals()[section_to_action[section].replace(_C3,_Ci).replace(_Ca,A)],fanart=backgrnd,folder=_A);xbmcplugin.endOfDirectory(handle,updateListing=_A);xbmcgui.Dialog().notification(_D,f"Reloaded {len(results)} results",xbmcgui.NOTIFICATION_INFO,3000)
def change_background():
	fanart=xbmcvfs.translatePath(_Fm)
	if xbmc.getCondVisibility('Skin.HasSetting(CustomBackground)'):xbmc.executebuiltin(f"Skin.SetString(CustomBackground,{fanart})")
	else:xbmc.executebuiltin('Skin.SetString(CustomBackground,)')
def show_welcome_screen():
	welcome_url='https://www.midian.appboxes.co/wolfyB/Th3L48/text/dreammachine/welcome.txt';cache_key=f"welcome_message_{hashlib.md5(welcome_url.encode(_E)).hexdigest()}";message=sqlite_read_cache(cache_key)
	if not message:
		try:
			headers={_J:_u};response=requests.get(welcome_url,headers=headers,timeout=5);response.raise_for_status();raw_message=response.text;message=re.sub('Unable to load welcome message from server\\.?','',raw_message,flags=re.IGNORECASE);message=re.sub('\\n{2,}','\n\n',message.strip())
			if not message:raise ValueError('Empty message after cleaning')
			sqlite_write_cache(cache_key,message,cache_duration=3600)
		except Exception as e:message='Welcome to [COLOR blue]D[COLOR salmon]r[COLOR violet]e[COLOR yellow]a[COLOR orange]m[COLOR lime]M[COLOR red]a[COLOR blue]c[COLOR salmon]h[COLOR violet]i[COLOR yellow]n[COLOR orange]e[/COLOR] !'
	dialog=xbmcgui.Dialog();dialog.textviewer(f"{addonname} - Welcome",message);xbmc.sleep(500)
def run():
	A='DreamMachine.WelcomeShown';cache_dir=xbmcvfs.translatePath(_CZ)
	if not xbmcvfs.exists(cache_dir):xbmcvfs.mkdirs(cache_dir)
	repo_check=check_repository_source();marker_check=check_marker_file()
	if not(repo_check and marker_check):dialog=xbmcgui.Dialog();dialog.ok('[COLOR red]Unauthorized Installation[/COLOR]',f"This addon ({ADDON_ID}) must be installed via the official repository: [COLOR springgreen]{OFFICIAL_REPO_ID}[/COLOR] !");sys.exit(1)
	params=plugintools.get_params();action=params.get(_d)
	if xbmcgui.Window(10000).getProperty(A)!=_N:
		if not action and myaddon.getSetting('show_welcome')==_N:show_welcome_screen();xbmcgui.Window(10000).setProperty(A,_N)
	if action is _G:main_list(params)
	elif action==_BB:linkdirectoxc(params);return
	elif action==_C2:select_xtream_server(params)
	elif action==_Fb:show_movie_sources(params)
	elif action=='show_live_sources':show_live_sources(params)
	elif action=='show_episode_sources':show_episode_sources(params)
	elif action==_Fd:merged_series_seasons(params)
	elif action==_Fe:merged_series_episodes(params)
	elif action==_Bo:xtream_search_selector(params)
	elif action=='search_xtream_live':search_xtream_live(params)
	elif action==_Fa:search_xtream_vod(params)
	elif action==_Fc:search_xtream_series(params)
	elif action==_Fn:search_current_xtream_server(params)
	elif action==_Fo:show_favorite_searches(params)
	elif action=='run_favorite_search':run_favorite_search(params)
	elif action=='delete_favorite_searches':delete_favorite_searches(params);return
	elif action and hasattr(sys.modules[__name__],action):
		try:func=getattr(sys.modules[__name__],action);func(params)
		except Exception as e:xbmcgui.Dialog().notification(_D,f"Error: {action}",xbmcgui.NOTIFICATION_ERROR)
	else:xbmcgui.Dialog().notification(_D,f"Unknown action: {action}",xbmcgui.NOTIFICATION_ERROR,3000)
	if action!=_BB:
		handle=-1
		try:handle=int(sys.argv[1])
		except:pass
		if handle!=-1:xbmcplugin.endOfDirectory(handle,succeeded=_A,cacheToDisc=_B)
def get_cache_file(cache_key,prefix=''):
	try:
		if not xbmcvfs.exists(CACHE_DIR):
			success=xbmcvfs.mkdirs(CACHE_DIR)
			if not success:return
		safe_prefix=re.sub('[^\\w\\-]','_',prefix)if prefix else'';cache_filename=f"{safe_prefix}_{hashlib.md5(cache_key.encode(_E)).hexdigest()}.json";cache_file=os.path.join(CACHE_DIR,cache_filename);return cache_file
	except Exception as e:return
def write_cache(cache_key,data,cache_duration=86400,prefix=''):
	cache_file=get_cache_file(cache_key,prefix)
	if not cache_file:return
	if not data or isinstance(data,(list,dict))and len(data)==0:return
	cache_data={_At:data,_DZ:time.time(),_A3:cache_duration}
	try:
		with xbmcvfs.File(cache_file,'w')as f:written=f.write(json.dumps(cache_data,ensure_ascii=_B))
	except(OSError,json.JSONEncodeError)as e:pass
def read_cache(cache_key,prefix=''):
	cache_file=get_cache_file(cache_key,prefix)
	if not cache_file or not xbmcvfs.exists(cache_file):return
	try:
		with xbmcvfs.File(cache_file,'r')as f:content=f.read()
		if not content:xbmcvfs.delete(cache_file);return
		cache_data=json.loads(content)
		if not isinstance(cache_data,dict)or _At not in cache_data or _DZ not in cache_data:xbmcvfs.delete(cache_file);return
		if time.time()<cache_data[_DZ]+cache_data.get(_A3,86400):
			data=cache_data[_At]
			if prefix=='server_list':
				if isinstance(data,list)and all(isinstance(s,str)for s in data):return data
				else:xbmcvfs.delete(cache_file);return
			elif prefix=='server_results':
				if isinstance(data,list)and all(isinstance(s,dict)and all(k in s for k in[_Au,_A4,_v])for s in data):return data
				else:xbmcvfs.delete(cache_file);return
			elif prefix and'portal.php?type=itv&action=get_genres'in cache_key:
				if isinstance(data,str):return data
				else:xbmcvfs.delete(cache_file);return
			elif isinstance(data,list):return data
			else:xbmcvfs.delete(cache_file);return
		else:xbmcvfs.delete(cache_file);return
	except(json.JSONDecodeError,OSError)as e:xbmcvfs.delete(cache_file);return
def read_search_cache(key,default=_G,ttl=_G):
	import xbmcvfs,json,os,time,hashlib,xbmc;cache_dir=xbmcvfs.translatePath(_CZ)
	if not xbmcvfs.exists(cache_dir):return default
	safe_key=key
	if'YOUR_'in key:portal=key.split('_',3)[-1]if len(key.split('_',3))>3 else'';safe_key=portal.split('://',1)[-1].split(_R,1)[0]if portal else _Fp
	else:
		parts=key.split('_',3)
		if len(parts)>=3:
			base=parts[2].split('://',1)[-1].split(_R,1)[0];safe_key=f"{parts[0]}_{parts[1]}_{base}"
			if len(parts)==4:safe_key+=f"_{parts[3]}"
	safe_key=''.join(c if c.isalnum()or c in'._-'else'_'for c in safe_key)
	if len(safe_key)>100:safe_key=safe_key[:50]+'_'+hashlib.md5(key.encode()).hexdigest()[:8]
	path=os.path.join(cache_dir,safe_key+_Da)
	if not xbmcvfs.exists(path):return default
	try:
		with xbmcvfs.File(path)as f:data=json.loads(f.read())
		if ttl is not _G and data.get('exp')and time.time()>data['exp']:xbmcvfs.delete(path);return default
		return data.get('value',default)
	except Exception as e:
		try:xbmcvfs.delete(path)
		except:pass
		return default
def write_search_cache(key,value,ttl=_G):
	import xbmcvfs,json,os,time,hashlib,xbmc;cache_dir=xbmcvfs.translatePath(_CZ)
	if not xbmcvfs.exists(cache_dir):
		try:xbmcvfs.mkdirs(cache_dir)
		except Exception as e:return
	if value is _G or isinstance(value,(list,dict))and len(value)==0:return
	safe_key=key
	if'YOUR_'in key:portal=key.split('_',3)[-1]if len(key.split('_',3))>3 else'';safe_key=portal.split('://',1)[-1].split(_R,1)[0]if portal else _Fp
	else:
		parts=key.split('_',3)
		if len(parts)>=3:
			base=parts[2].split('://',1)[-1].split(_R,1)[0];safe_key=f"{parts[0]}_{parts[1]}_{base}"
			if len(parts)==4:safe_key+=f"_{parts[3]}"
	safe_key=''.join(c if c.isalnum()or c in'._-'else'_'for c in safe_key)
	if len(safe_key)>100:safe_key=safe_key[:50]+'_'+hashlib.md5(key.encode()).hexdigest()[:8]
	path=os.path.join(cache_dir,safe_key+_Da);data={'value':value}
	if ttl is not _G:data['exp']=time.time()+ttl
	try:
		with xbmcvfs.File(path,'w')as f:f.write(json.dumps(data))
	except Exception as e:pass
def settings(params):plugintools.open_settings_dialog()
def keyboard_input(default_text='',title='',hidden=_B):
	keyboard=xbmc.Keyboard(default_text,title,hidden);keyboard.doModal()
	if keyboard.isConfirmed():return keyboard.getText()
	else:return
def userpastebin():return keyboard_input('','CONT PASTEBIN',_B)
def portpopup():return keyboard_input('','PORTAL',_B)
def macpopup():return keyboard_input('','MAC',_B)
def userxtream():return keyboard_input('','USERNAME',_B)
def passxtream():return keyboard_input('','PASSWORD',_B)
def portalxtream():return keyboard_input('','PORTAL Xtream Codes',_B)
def search_popup():
	query=xbmc.getInfoLabel(_C9)
	if query:xbmc.executebuiltin(_Br);return query.strip()
	kb=xbmc.Keyboard('',"[COLOR blue]D[COLOR salmon]r[COLOR violet]e[COLOR yellow]a[COLOR orange]m[COLOR lime]M[COLOR red]a[COLOR blue]c[COLOR salmon]h[COLOR violet]i[COLOR yellow]n[COLOR orange]e[/COLOR] - Use '[COLOR yellow]|[/COLOR]' as Separator for Multi-Term Search");kb.doModal()
	if kb.isConfirmed():
		text=kb.getText()
		if text and text.strip():return text.strip()
	return''
def main_list(params):change_background();plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_Av,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action=_Fo,title='[COLOR blue]DM Favorites[/COLOR]',thumbnail=icon,fanart=backgrnd,folder=_A);plugintools.add_item(action=_C2,title='[COLOR springgreen]Xtream Servers[/COLOR]',thumbnail=xtream,fanart=backgrnd,url='',folder=_B);mac=myaddon.getSetting(_A1);portal=myaddon.getSetting(_AR);plugintools.add_item(action=_A1,title='[COLOR yellow]Stb - Mac[/COLOR]',thumbnail=stbmac,fanart=backgrnd,page='',url='',folder=_A);plugintools.add_item(action='m3u',title='[COLOR blue]Free M3u[/COLOR]',thumbnail=free,fanart=backgrnd,page='',url='',folder=_A);plugintools.add_item(action=_C3,title='[COLOR springgreen]Premium M3u[/COLOR]',thumbnail=premium,fanart=backgrnd,page='',url='',folder=_A);plugintools.add_item(action='youtube',title='[COLOR yellow]DreamTube[/COLOR] [COLOR red]<=-[/COLOR][COLOR yellow]U[/COLOR][COLOR orange]n[/COLOR][COLOR yellow]d[/COLOR][COLOR orange]e[/COLOR][COLOR yellow]r[/COLOR][COLOR orange]C[/COLOR][COLOR yellow]o[COLOR orange]n[/COLOR][COLOR yellow]s[/COLOR][COLOR orange]t[/COLOR][COLOR yellow]r[/COLOR][COLOR orange]u[/COLOR][COLOR yellow]c[/COLOR][COLOR orange]t[/COLOR][COLOR yellow]i[/COLOR][COLOR orange]o[/COLOR][COLOR yellow]n[/COLOR][COLOR red]-=>[/COLOR]',thumbnail=utube,fanart=backgrnd,folder=_A);plugintools.add_item(action=_Bg,title='[COLOR blue]Radio[/COLOR]',thumbnail=radiothmb,fanart=backgrnd,folder=_A);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action=_DK,title=_Fq,thumbnail=cache,fanart=backgrnd,page='',url='',folder=_B);plugintools.add_item(action=_DL,title='[COLOR yellow]Settings[/COLOR]',thumbnail=setting,fanart=backgrnd,page='',url='',folder=_B)
def mac(params):plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_Av,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='macx',title='[COLOR yellow]Stb - Mac - Your Server[/COLOR]',thumbnail=stbmac,fanart=backgrnd3,page='',url='',folder=_A);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action=_FN,title='[COLOR blue]Stb - Mac - Loonatics Server[/COLOR]',thumbnail=stbmac,fanart=backgrnd2,page='',url='',folder=_A);nat=myaddon.getSetting('nat');plugintools.add_item(action=_FR,title=f"[COLOR springgreen]Stb - Mac - Random Server[/COLOR]  [COLOR yellow]( {nat} Attempts / Day )[/COLOR]",thumbnail=stbmac,fanart=backgrnd1,url='',folder=_A);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B)
def xtreamcodes(params):
	plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_Av,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action=_DS,title='[COLOR cyan]Search Xtream List[/COLOR]',thumbnail=search_icon,fanart=backgrnd,folder=_A);plugintools.add_item(action=_Bn,title=_CA,thumbnail=xtream,fanart=backgrnd2,page='',url=_CB,folder=_A);plugintools.add_item(action=_Bn,title=_CC,thumbnail=xtream,fanart=backgrnd3,page='',url=_CD,folder=_A);plugintools.add_item(action=_Bn,title=_CE,thumbnail=xtream,fanart=backgrnd4,page='',url=_CF,folder=_A);plugintools.add_item(action=_Bn,title=_CG,thumbnail=xtream,fanart=backgrnd5,page='',url=_CH,folder=_A);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);addon=xbmcaddon.Addon(_Ce);portalxc=addon.getSetting(_Bi);usernamexc=addon.getSetting(_C5);passxc=addon.getSetting(_C6);xbmc.log(f"dreammachine.xtreamcodes: Settings - portalxc: '{portalxc}', usernamexc: '{usernamexc}', passxc: '{passxc}'",xbmc.LOGDEBUG)
	if all(s and s.strip()for s in[portalxc,usernamexc,passxc]):plugintools.add_item(action=_DP,title='[COLOR springgreen]Xtream - Your Server[/COLOR]',thumbnail=xtream,fanart=backgrnd1,page=portalxc,extra=usernamexc,episode=passxc,url='',folder=_A);xbmc.log('dreammachine.xtreamcodes: Added Xtream - Your Server to menu',xbmc.LOGDEBUG)
	else:xbmc.log(f"dreammachine.xtreamcodes: Xtream - Your Server not added, invalid settings: portalxc={bool(portalxc and portalxc.strip())}, usernamexc={bool(usernamexc and usernamexc.strip())}, passxc={bool(passxc and passxc.strip())}",xbmc.LOGDEBUG);xbmcgui.Dialog().ok(addonname,'Please configure Xtream - Your Server credentials in Settings.')
	user_server_list=addon.getSetting(_CI)
	if user_server_list and user_server_list.strip():plugintools.add_item(action=_Bn,title='[COLOR yellow]Xtream - Your Server List[/COLOR]',thumbnail=xtream,fanart=backgrnd1,page='',url=user_server_list,folder=_A);xbmc.log('dreammachine.xtreamcodes: Added Xtream - Your Server List to menu',xbmc.LOGDEBUG)
	last_used_server=addon.getSetting(_CJ);xbmc.log(f"dreammachine.xtreamcodes: Last used server: '{last_used_server}'",xbmc.LOGDEBUG);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action=_DP,title='[COLOR cyan]Xtream Codes VOD[/COLOR]',thumbnail=xtream,fanart=backgrnd,url='',folder=_A);plugintools.add_item(action=_C2,title='[COLOR yellow]Xtream Servers[/COLOR]',thumbnail=xtream,fanart=backgrnd,url='',folder=_A);plugintools.add_item(action=_DL,title='[COLOR blue]Settings[/COLOR]',thumbnail=setting,fanart=backgrnd,page='',url='',folder=_B);plugintools.add_item(action=_DK,title=_Fq,thumbnail=cache,fanart=backgrnd,page='',url='',folder=_B);xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_NONE);xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=_A);xbmc.log('dreammachine.xtreamcodes: Exiting function',xbmc.LOGDEBUG)
def macpastebinx(params):
	if userp=='':userpast=userpastebin();control.setSetting(_Cf,userpast);xbmc.executebuiltin(_AQ);change_server(params)
	else:macpastebin(params)
def macpastebin(params):change_background();selected=myaddon.getSetting(_CK);mac=myaddon.getSetting(_Bf);portal=myaddon.getSetting(_AR);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_Av,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action=_FO,title='[COLOR blue]Channel List[/COLOR]',thumbnail=stbmac,fanart=backgrnd1,folder=_A);plugintools.add_item(action=_FP,title=f"[COLOR springgreen]Server: [COLOR blue]{selected}[/COLOR]",thumbnail=stbmac,fanart=backgrnd2,folder=_A);plugintools.add_item(action=_FQ,title=f"[COLOR yellow]MAC: [COLOR yellow]{mac}[/COLOR]",thumbnail=stbmac,fanart=backgrnd3,folder=_A);plugintools.add_item(action='',thumbnail=transparent,fanart=backgrnd,title=_T,folder=_B)
def macx(params):
	if portal=='':portp=portpopup();macn=macpopup();control.setSetting(_AR,portp);control.setSetting(_A1,macn);xbmc.executebuiltin(_AQ);mac2(params)
	else:mac2(params)
def mac2(params):mac=myaddon.getSetting(_A1);portal=myaddon.getSetting(_AR);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_Av,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action=_FW,title='[COLOR cyan]Search Stb - Mac[/COLOR]',thumbnail=search_icon,fanart=backgrnd,folder=_A);plugintools.add_item(action='chance',title='[COLOR blue]Live Channels[/COLOR]',thumbnail=stbmac,fanart=backgrnd1,page=mac,url=portal,folder=_A);plugintools.add_item(action=_DN,title=_Fr,thumbnail=stbmac,fanart=backgrnd2,page=mac,url=portal,folder=_A);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B)
def chance(params):
	portal=params.get(_I,'').replace(_C,'');mac=params.get(_P,'').replace(_C,'');s=get_session();token=macs_handshake(s,portal,mac)
	if not token:return
	source=macs_categories(s,token,portal,mac)
	if not source:return
	try:json_data=json.loads(source);genres=json_data.get(_A9,[])if isinstance(json_data.get(_A9),list)else json_data.get(_A9,{}).get(_At,[]);data=[(g.get(_O,''),g.get(_H,''))for g in genres if g.get(_O)and g.get(_H)]
	except json.JSONDecodeError:
		data=[];data=plugintools.find_multiple_matches(source,_Db)
		if not data:data=plugintools.find_multiple_matches(source,_Fs)
	if not data:xbmcgui.Dialog().notification(_D,'No live channel genres available. Check server settings.',xbmcgui.NOTIFICATION_ERROR,5000);return
	data.append((_g,_Ft));porn=myaddon.getSetting(_X).replace(_C,'')==_N;parental_control=myaddon.getSetting(_CL).replace(_C,'')==_N;parental_password=myaddon.getSetting(_CM).replace(_C,'')or _CN;adult_choice=_G;parse_errors=0
	for(ids,title)in data:
		original_title=title;title=title.replace('\\u2b50','').replace(_C,'').replace('\n','').strip();is_adult=_AF in title.lower()or _AG in title.lower()or _AH in title.lower()or _AI in title.lower()or _AJ in title.lower()or _AK in title.lower()or _AL in title.lower()or _Aw in title.lower()or _Ax in title.lower()or _Ay in title.lower()or _l in title.lower()or _k in title.lower()or _p in title.lower()or _s in title.lower()or _Az in title.lower()or _t in title.lower()or _r in title.lower()or _A_ in title.lower()or _B0 in title.lower()or _B1 in title.lower()or _B2 in title.lower()or _q in title.lower()or _X in title.lower()or _B3 in title.lower()or _B4 in title.lower()
		if is_adult and not porn:continue
		if is_adult and parental_control and adult_choice is _G:
			dialog=xbmcgui.Dialog();ret=dialog.select(_CO,[_CP,_Cj]);adult_choice=[_AM,'no'][ret]
			if adult_choice==_AM:
				d=dialog.input(_Dc,type=xbmcgui.INPUT_ALPHANUM).replace(_w,'+').replace(_C,'')
				if d==parental_password:adult_choice=_Bs
				else:xbmcgui.Dialog().notification(_D,_Ck,xbmcgui.NOTIFICATION_ERROR,5000);adult_choice=_z
			else:adult_choice=_z
		if is_adult and parental_control and adult_choice==_z:continue
		colored_title=color(title);plugintools.add_item(action=_C0,title=colored_title,thumbnail=params.get(_M),fanart=backgrnd1,plot=token,page=mac,extra=portal,url=ids,folder=_A)
	if parse_errors>0:0
def macs_handshake(s,portal,mac):
	headers={_J:_u,_A5:f"mac={mac}; stb_lang=en; timezone=America/New_York",_Z:_a,_b:_c,_i:_j};url=f"{portal}portal.php?type=stb&action=handshake&JsHttpRequest=1-xml"
	try:
		response=s.get(url,headers=headers,timeout=15);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F).replace(_C,'');matches=re.findall(_Cl,source)
		if not matches:return''
		token=matches[0].replace(_C,'');return token
	except requests.RequestException as e:xbmcgui.Dialog().notification(_D,_Fu,xbmcgui.NOTIFICATION_ERROR,5000);return''
def macs_categories(s,token,portal,mac):
	headers={_J:_u,_A5:f"mac={mac}; stb_lang=en; timezone=America/New_York",_B5:f"Bearer {token}",_Z:_a,_b:_c,_i:_j};cache_key=f"{portal}portal.php?type=itv&action=get_genres";cached_data=read_cache(cache_key,mac)
	if cached_data:return cached_data
	categories_url=f"{portal}portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml"
	try:response=s.get(categories_url,headers=headers,timeout=15);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F).replace(_C,'');write_cache(cache_key,source,prefix=mac);return source
	except requests.RequestException as e:
		fallback_url=f"{portal}portal.php?type=itv&action=get_all_channels&JsHttpRequest=1-xml"
		try:response=s.get(fallback_url,headers=headers,timeout=15);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F).replace(_C,'');write_cache(cache_key,source,prefix=mac);return source
		except requests.RequestException as e:xbmcgui.Dialog().notification(_D,'Failed to fetch live channel genres',xbmcgui.NOTIFICATION_ERROR,5000);return''
def listA(params):
	ids=params.get(_I,'').replace(_C,'');portal=params.get(_S,'').replace(_C,'');mac=params.get(_P,'').replace(_C,'');token=params.get(_W,'').replace(_C,'');headers={_J:_u,_A5:f"mac={mac}; stb_lang=en; timezone=America/New_York",_B5:f"Bearer {token}",_Z:_a,_b:_c,_i:_j,_Cm:_BW,_Cn:_BW};pb=xbmcgui.DialogProgress();pb.create('Please Wait, Loading Channels ... ','');cache_key=f"{portal}portal.php?type=itv&action=get_ordered_list&genre={ids}";cached_data=read_cache(cache_key,mac);data=[]
	if cached_data and isinstance(cached_data,list)and len(cached_data)>0:data=cached_data
	else:
		s=get_session();pn=1;max_pages=40
		while pn<=max_pages:
			page_url=f"{portal}portal.php?type=itv&action=get_ordered_list&genre={ids}&force_ch_link_check=&sortby=number&hd=0&p={pn}&JsHttpRequest=1-xml"
			try:
				response=s.get(page_url,headers=headers,timeout=10);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F).replace(_C,'')
				try:json_data=json.loads(source);channels=json_data.get(_A9,{}).get(_At,[]);page_data=[(ch.get(_L,''),ch.get(_O,''))for ch in channels if _L in ch and _O in ch]
				except json.JSONDecodeError:
					page_data=re.findall(_Fv,source)
					if not page_data:page_data=re.findall(_Fw,source)
				if not page_data:break
				data+=page_data;pn+=1
			except requests.RequestException:break
		if data:write_cache(cache_key,data,prefix=mac)
		else:pb.close();xbmcgui.Dialog().notification(_D,'No channels available. Check server or credentials.',xbmcgui.NOTIFICATION_ERROR,5000);return
	if not data:pb.close();xbmcgui.Dialog().notification(_D,_Fx,xbmcgui.NOTIFICATION_ERROR,5000);return
	i=1;total=len(data);handle=int(sys.argv[1])
	for patron in sorted(data,key=lambda x:x[0]):
		if pb.iscanceled():pb.close();return
		title=str(patron[0]).replace('í','i').replace('ê','e').replace('ñ','Ã±').replace('ú','u').replace('ó','o').replace('Á','a').replace('é','e').replace('á','a').replace('\\','').replace(_C,'');channel=str(patron[1]).replace(_C,'')if len(patron)>1 else patron[0];pb.update(int(100*i/total),f"{100*i/total}% - Channel {title}");plugintools.add_item(action=_C1,extra=portal,url=channel,page=mac,plot=token,title=f"[COLOR white]{title}[/COLOR]",thumbnail=params.get(_M),fanart=backgrnd1,folder=_B,isPlayable=_A);i+=1
	pb.close()
	try:plugintools.set_view(plugintools.LIST,55)
	except Exception:pass
	xbmcplugin.endOfDirectory(handle,cacheToDisc=_A)
def listB(params):
	A='Failed to retrieve stream';channel=params.get(_I,'').replace(_C,'');portal=params.get(_S,'').replace(_C,'');mac=params.get(_P,'').replace(_C,'');token=params.get(_W,'').replace(_C,'');headers={_J:_u,_A5:f"mac={mac}; stb_lang=en; timezone=America/New_York",_B5:f"Bearer {token}",_Z:_a,_b:_c,_i:_j,_Cm:_BW,_Cn:_BW};url=f"{portal}portal.php?type=itv&action=create_link&cmd=http://localhost/ch/{channel}_&series=&forced_storage=undefined&disable_ad=0&JsHttpRequest=1-xml";s=get_session()
	try:
		response=s.get(url,headers=headers,timeout=5,stream=_A);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F);source=source.replace(_C,'');token=re.findall(_Fy,source)
		if not token:xbmcgui.Dialog().notification(_D,A,xbmcgui.NOTIFICATION_ERROR,3000);return
		stream_url=token[0].replace('\\','').replace(_C,'');plugintools.play_resolved_url(stream_url)
	except requests.RequestException:xbmcgui.Dialog().notification(_D,A,xbmcgui.NOTIFICATION_ERROR,3000)
def moviesA(params):
	portal=params.get(_I,'').replace(_C,'');mac=params.get(_P,'').replace(_C,'');s=get_session()
	def macs_handshake(s):
		headers={_J:_u,_A5:f"mac={mac}; stb_lang=en; timezone=America/New_York",_Z:_a,_b:_c};url=f"{portal}portal.php?type=stb&action=handshake&JsHttpRequest=1-xml"
		try:response=s.get(url,headers=headers,timeout=5);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F);source=source.replace(_C,'');return source
		except requests.RequestException:return''
	token=macs_handshake(s)
	if not token:xbmcgui.Dialog().notification(_D,_Dd,xbmcgui.NOTIFICATION_ERROR,6000);return
	matches=re.findall(_Cl,token)
	if not matches:xbmcgui.Dialog().notification(_D,_Dd,xbmcgui.NOTIFICATION_ERROR,6000);return
	token=matches[0].replace(_C,'')
	def macs_categories(s):
		headers={_J:_u,_A5:f"mac={mac}; stb_lang=en; timezone=America/New_York",_B5:f"Bearer {token}",_Z:_a,_b:_c};url=f"{portal}portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml";cache_key=url+'?action=get_categories';cached_data=read_cache(cache_key,mac)
		if cached_data:return cached_data
		try:
			response=s.get(url,headers=headers,timeout=5);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F);source=source.replace(_C,'');passs=re.findall(_De,source);typee=re.findall(_Df,source)
			if not passs or not typee:return''
			payload={_Dg:'',_v:passs[0].replace(_C,''),_Dh:typee[0].replace(_C,'')};categories_url=f"{portal}portal.php?type=vod&action=get_categories&JsHttpRequest=1-xml";response=s.post(categories_url,headers=headers,data=str(payload),timeout=5);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F);source=source.replace(_C,'');write_cache(cache_key,source,prefix=mac);return source
		except requests.RequestException:return''
	source=macs_categories(s)
	if not source:xbmcgui.Dialog().notification(_D,'Failed to fetch VOD categories',xbmcgui.NOTIFICATION_ERROR,3000);return
	source=source.replace(_C,'');data=plugintools.find_multiple_matches(source,_Fz);parse_errors=0;porn=myaddon.getSetting(_X).replace(_C,'');parental_control=myaddon.getSetting(_CL).replace(_C,'')==_N;parental_password=myaddon.getSetting(_CM).replace(_C,'')or _CN;adult_choice=_G
	for genres in data:
		patron=plugintools.find_single_match(genres,_Di)
		if not patron:parse_errors+=1;continue
		title=patron[1].replace('\\u2b50','').replace(_C,'').strip();ids=patron[0].replace(_C,'');tit=title.lower();is_adult=_AF in tit or _AG in tit or _AH in tit or _AI in tit or _AJ in tit or _AK in tit or _AL in tit or _Aw in tit or _Ax in tit or _Ay in tit or _l in tit or _k in tit or _p in tit or _s in tit or _Az in tit or _t in tit or _r in tit or _A_ in tit or _B0 in tit or _B1 in tit or _B2 in tit or _q in tit or _X in tit or _B3 in tit or _B4 in tit
		if is_adult and porn==_A8:continue
		if is_adult and parental_control and adult_choice is _G:
			dialog=xbmcgui.Dialog();ret=dialog.select(_CO,[_CP,_Cj]);lists=[_AM,'no'];adult_choice=lists[ret]
			if adult_choice==_AM:
				d=dialog.input('[COLOR yellow]Enter Password: [/COLOR]',type=xbmcgui.INPUT_ALPHANUM).replace(_w,'+').replace(_C,'')
				if d==parental_password:adult_choice=_Bs
				else:xbmcgui.Dialog().notification(_D,_Ck,xbmcgui.NOTIFICATION_ERROR,3000);adult_choice=_z
			else:adult_choice=_z
		if is_adult and parental_control and adult_choice==_z:continue
		title_color='[COLOR fuchsia]'if is_adult else _BX;plugintools.add_item(action='moviesB',title=f"{title_color}{title}[/COLOR]",thumbnail=params.get(_M),fanart=backgrnd1,plot=token,page=mac,extra=portal,url=ids,folder=_A)
def moviesB(params):
	ids=params.get(_I,'').replace(_C,'');portal=params.get(_S,'').replace(_C,'');mac=params.get(_P,'').replace(_C,'');token=params.get(_W,'').replace(_C,'');headers={_J:_u,_A5:f"mac={mac}; stb_lang=en; timezone=America/New_York",_B5:f"Bearer {token}",_Z:_a,_b:_c};count=40;pn=1;data=[];cache_key=f"{portal}portal.php?type=vod&action=get_ordered_list&genre={ids}";cached_data=read_cache(cache_key,mac)
	if cached_data:data=cached_data
	else:
		s=get_session()
		while pn<=int(count):
			page=f"{portal}portal.php?type=vod&action=get_ordered_list&genre={ids}&force_ch_link_check=&sortby=number&hd=0&p={pn}&JsHttpRequest=1-xml"
			try:
				response=s.get(page,headers=headers,timeout=5);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F);source=source.replace(_C,'');page_data=re.findall('("id":".*?".*?,"name":".*?".*?.*?"description":".*?".*?"year":".*?".*?screenshot_uri":".*?".*?_str":".*?","cmd":".*?")',source)
				if not page_data:break
				data+=page_data;pn+=1
			except requests.RequestException:break
		if data:write_cache(cache_key,data,prefix=mac)
		else:xbmcgui.Dialog().notification(_D,'Failed to fetch VOD list',xbmcgui.NOTIFICATION_ERROR,3000);return
	parse_errors=0
	for genres in data:
		patron=plugintools.find_single_match(genres,'"id":".*?".*?,"name":"(.*?)".*?.*?"description":"(.*?)".*?"year":"(.*?)".*?screenshot_uri":"(.*?)".*?_str":"(.*?)","cmd":"(.*?)"')
		if not patron:parse_errors+=1;continue
		art=patron[3].replace('\\','').replace(_C,'');title=patron[0].replace('\\u00f1','n').replace('\\/','').replace('⭐','').replace(_C,'');texto=patron[1].replace(_C,'');year=patron[2].replace('N\\/A','').replace(_C,'');channel=patron[5].replace(_C,'');plugintools.add_item(action='moviesC',extra=portal,url=channel,page=mac,plot=token,title=f"[COLOR white]{title} [COLOR yellow]{year}[/COLOR]",thumbnail=art,fanart=backgrnd2,folder=_B,isPlayable=_A)
def moviesC(params):
	A='Failed to retrieve VOD stream';channel=params.get(_I,'').replace(_C,'');portal=params.get(_S,'').replace(_C,'');mac=params.get(_P,'').replace(_C,'');token=params.get(_W,'').replace(_C,'');headers={_J:_u,_A5:f"mac={mac}; stb_lang=en; timezone=America/New_York",_B5:f"Bearer {token}",_Z:_a,_b:_c,_i:_j,_Cm:_BW,_Cn:_BW};url=f"{portal}portal.php?type=vod&action=create_link&cmd={channel}_&forced_storage=undefined&disable_ad=0&JsHttpRequest=1-xml";s=get_session()
	try:
		response=s.get(url,headers=headers,timeout=5,stream=_A);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F);source=source.replace(_C,'');token=re.findall(_Fy,source)
		if not token:xbmcgui.Dialog().notification(_D,A,xbmcgui.NOTIFICATION_ERROR,3000);return
		stream_url=token[0].replace('\\','').replace(_C,'');plugintools.play_resolved_url(stream_url)
	except requests.RequestException:xbmcgui.Dialog().notification(_D,A,xbmcgui.NOTIFICATION_ERROR,3000)
def todays_list(params):
	D='Notification(Server down, it seems that this server is not operational ,8000)';C='Ã ï¿½';B='Ã Â±';A='Se incarca canalele';date_today=date.today();text_today=date_today.strftime('%Y%m%d');today=int(text_today)
	try:mac=myaddon.getSetting('cam');server=myaddon.getSetting(_Co);portal=myaddon.getSetting(_Cp);userp=myaddon.getSetting(_Cf);nat=int(myaddon.getSetting('nat'));fec_texto=myaddon.getSetting('fec');fec=int(fec_texto)
	except:nat=20;mac='';server='';portal='';myaddon.setSetting('cam',mac);myaddon.setSetting(_Co,server);myaddon.setSetting(_Cp,portal);myaddon.setSetting('nat',str(nat));myaddon.setSetting('fec',text_today);fec=today
	if fec<today:nat=20
	maximum=_B
	if nat<=0:xbmcgui.Dialog().ok('MAXIMUM number of lists reached','You have reached the maximum number of lists to use today. You have to wait until tomorrow to be able to use the list again. We leave you with your last list for today');maximum=_A
	if fec==today and not maximum:dialog=xbmcgui.Dialog();ret=dialog.select('Select Option',[f"[COLOR skyblue]Get NEW List [/COLOR][ You have [COLOR yellow]{nat} [/COLOR]attempts left ]","[COLOR springgreen]Continue with Today's list[/COLOR]"])
	else:ret=0 if not maximum else 1
	if ret==0:
		headers={_J:_Cq}
		try:req=urllib.request.Request(_F_,headers=headers);server_list=urllib.request.urlopen(req).read().decode(_E);servidores=re.findall(_G0,server_list)
		except Exception:xbmcgui.Dialog().ok(_Dj,'Failed to retrieve server list. Please try again.');xbmc.executebuiltin(_BY);xbmc.executebuiltin(_AQ);return
		data=[];intento=1
		while not data and intento<=10:
			server=random.choice(servidores);mac,portal=mac_portal(server)
			if not mac or not portal:intento+=1;continue
			data,token=get_channels(mac,portal)
			if data:
				nat-=1;myaddon.setSetting('nat',str(nat));myaddon.setSetting('cam',mac);myaddon.setSetting(_Co,server);myaddon.setSetting(_Cp,portal);myaddon.setSetting('fec',text_today);pb=xbmcgui.DialogProgress();pb.create(A,'');i=1;total=len(data);porn=myaddon.getSetting(_X).replace(_C,'')
				for patron in sorted(data,key=lambda x:x[1]):
					title=str(patron[1]).replace('í','i').replace('ê','e').replace('ñ',B).replace('ú','u').replace('ó','o').replace('Á','a').replace('é','e').replace('Ñ',C).replace('á','a').replace('\\','');ids=str(patron[0]);tit=color(title)
					if not(_AF in tit.lower()or _AG in tit.lower()or _AH in tit.lower()or _AI in tit.lower()or _AJ in tit.lower()or _AK in tit.lower()or _AL in tit.lower()or _Aw in tit.lower()or _Ax in tit.lower()or _Ay in tit.lower()or _l in tit.lower()or _k in tit.lower()or _p in tit.lower()or _s in tit.lower()or _Az in tit.lower()or _t in tit.lower()or _r in tit.lower()or _A_ in tit.lower()or _B0 in tit.lower()or _B1 in tit.lower()or _B2 in tit.lower()or _q in tit.lower()or _X in tit.lower()or _B3 in tit.lower()or _B4 in tit.lower()and porn==_A8):plugintools.add_item(action=_C0,title=f"[COLOR white]{tit}[/COLOR]",thumbnail=params.get(_M),fanart=backgrnd1,plot=token,page=mac,extra=portal,url=ids,folder=_A);pb.update(int(100*i/total),f"{100*i/total}% - Loading the channel {title}");i+=1
				pb.close()
			else:intento+=1
		if intento>10 and not data:xbmcgui.Dialog().ok('MAXIMUM no. of attempts reached','Looks like no luck with this list, try your luck with another');xbmc.executebuiltin(_BY);xbmc.executebuiltin(_AQ);return
	elif ret==1:
		try:
			data,token=get_channels(mac,portal)
			if data:
				pb=xbmcgui.DialogProgress();pb.create(A,'');i=1;total=len(data);porn=myaddon.getSetting(_X).replace(_C,'')
				for patron in sorted(data,key=lambda x:x[1]):
					title=str(patron[1]).replace('í','i').replace('ê','e').replace('ñ',B).replace('ú','u').replace('ó','o').replace('Á','a').replace('é','e').replace('Ñ',C).replace('á','a').replace('\\','');ids=str(patron[0]);tit=color(title)
					if not(_AF in tit.lower()or _AG in tit.lower()or _AH in tit.lower()or _AI in tit.lower()or _AJ in tit.lower()or _AK in tit.lower()or _AL in tit.lower()or _Aw in tit.lower()or _Ax in tit.lower()or _Ay in tit.lower()or _l in tit.lower()or _k in tit.lower()or _p in tit.lower()or _s in tit.lower()or _Az in tit.lower()or _t in tit.lower()or _r in tit.lower()or _A_ in tit.lower()or _B0 in tit.lower()or _B1 in tit.lower()or _B2 in tit.lower()or _q in tit.lower()or _X in tit.lower()or _B3 in tit.lower()or _B4 in tit.lower()and porn==_A8):plugintools.add_item(action=_C0,title=f"[COLOR white]{tit}[/COLOR]",thumbnail=params.get(_M),fanart=backgrnd2,plot=token,page=mac,extra=portal,url=ids,folder=_A);pb.update(int(100*i/total),f"{100*i/total}% - Loading Channel {title}");i+=1
				pb.close()
			else:xbmc.executebuiltin(D);xbmc.executebuiltin(_BY)
		except Exception:xbmc.executebuiltin(D);xbmc.executebuiltin(_BY)
	elif ret==-1:xbmc.executebuiltin(_BY)
def view_channels(params):
	thumbnail=params.get(_M);mac=myaddon.getSetting(_Bf).replace(_C,'');portal=myaddon.getSetting(_Dk).replace(_C,'');selected=myaddon.getSetting(_CK).replace(_C,'');s=get_session();headers={_J:_u,_A5:f"mac={mac}; stb_lang=en; timezone=America/New_York",_Z:_a,_b:_c};url=f"{portal}portal.php?type=stb&action=handshake&JsHttpRequest=1-xml"
	try:response=s.get(url,headers=headers,timeout=5);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F);source=source.replace(_C,'')
	except requests.RequestException:xbmc.executebuiltin(f"XBMC.Notification(Unable to connect to SERVER: {selected}, {portal} {mac}, 8000)");return
	matches=re.findall(_Cl,source)
	if not matches:xbmc.executebuiltin(f"XBMC.Notification(Unable to connect to SERVER: {selected}, {source}, 8000)");return
	token=matches[0].replace(_C,'');headers={_J:_u,_A5:f"mac={mac}; stb_lang=en; timezone=America/New_York",_B5:f"Bearer {token}",_Z:_a,_b:_c};url=f"{portal}portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml"
	try:response=s.get(url,headers=headers,timeout=5);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F);source=source.replace(_C,'');passs=re.findall(_De,source)[0];typee=re.findall(_Df,source)[0]
	except(requests.RequestException,IndexError):passs='';typee=''
	payload={_Dg:'',_v:passs.replace(_C,''),_Dh:typee.replace(_C,'')};url=f"{portal}portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml"
	try:response=s.post(url,headers=headers,data=str(payload),timeout=5);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F);source=source.replace(_C,'')
	except requests.RequestException:xbmc.executebuiltin(f"XBMC.Notification([COLOR red]Problem [COLOR orange]{selected}[/COLOR], [COLOR orange]{portal} {mac}[/COLOR], 10000)");return
	data=plugintools.find_multiple_matches(source,_Fz);porn=myaddon.getSetting(_X).replace(_C,'');plugintools.add_item(title=_T,thumbnail=transparent,fanart=backgrnd,folder=_B,isPlayable=_B);plugintools.add_item(title=f"[COLOR springgreen]Server [ [COLOR blue]{selected} [COLOR yellow]# {mac} ][/COLOR]",thumbnail=transparent,fanart=backgrnd,folder=_B,isPlayable=_B);plugintools.add_item(title=_T,thumbnail=transparent,fanart=backgrnd,folder=_B,isPlayable=_B);plugintools.add_item(action=_DN,title=_Fr,thumbnail=stbmac,fanart=backgrnd2,page=mac,url=portal,folder=_A);plugintools.add_item(title=_T,thumbnail=transparent,fanart=backgrnd,folder=_B,isPlayable=_B);parse_errors=0
	for genres in data:
		patron=plugintools.find_single_match(genres,_Di)
		if not patron:parse_errors+=1;continue
		title=patron[1].replace(_C,'');ids=patron[0].replace(_C,'');tit=color(title)
		if not(_AF in tit.lower()or _AG in tit.lower()or _AH in tit.lower()or _AI in tit.lower()or _AJ in tit.lower()or _AK in tit.lower()or _AL in tit.lower()or _Aw in tit.lower()or _Ax in tit.lower()or _Ay in tit.lower()or _l in tit.lower()or _k in tit.lower()or _p in tit.lower()or _s in tit.lower()or _Az in tit.lower()or _t in tit.lower()or _r in tit.lower()or _A_ in tit.lower()or _B0 in tit.lower()or _B1 in tit.lower()or _B2 in tit.lower()or _q in tit.lower()or _X in tit.lower()or _B3 in tit.lower()or _B4 in tit.lower()and porn==_A8):plugintools.add_item(action=_C0,title=tit,thumbnail=thumbnail,fanart=backgrnd2,plot=token,page=mac,extra=portal,url=ids,folder=_A)
def change_server(params):
	server2=myaddon.getSetting('ser').replace(_C,'');selected=myaddon.getSetting(_CK).replace(_C,'');userp=myaddon.getSetting(_Cf).replace(_C,'');portal=myaddon.getSetting(_Dk).replace(_C,'');mac=myaddon.getSetting(_Bf).replace(_C,'');headers={_J:_Cq}
	try:
		req=urllib.request.Request(_F_,headers=headers);server_list=urllib.request.urlopen(req).read().decode(_E,errors=_F).replace(_C,'');lists=re.findall(_G0,server_list);servers_list=re.findall('(?s)(\\w+) - \\w+',server_list);dialog=xbmcgui.Dialog();retorno=dialog.select(f"[COLOR blue]Server ACTUAL: [/COLOR]{selected}",servers_list)
		if retorno!=-1:server2=lists[retorno].replace(_C,'');selected=servers_list[retorno].replace(_C,'');req=urllib.request.Request(f"https://pastebin.com/raw/{server2}",headers=headers);mac1=urllib.request.urlopen(req).read().decode(_E,errors=_F).replace(_C,'');mac=re.findall(_G1,mac1);portal=re.findall(_Dl,mac1.lower())[0].replace(_C,'');random.seed();maclista=random.choice(mac).replace(_C,'');myaddon.setSetting(_Bf,maclista);myaddon.setSetting(_Dk,portal);myaddon.setSetting('ser',server2);myaddon.setSetting(_CK,selected);xbmc.executebuiltin(_AQ);view_channels(params)
		else:xbmc.executebuiltin(_BY)
	except Exception:xbmc.executebuiltin(_BY)
def change_mac(params):
	try:server2=myaddon.getSetting('ser').replace(_C,'');macant=myaddon.getSetting(_Bf).replace(_C,'');selected=myaddon.getSetting(_CK).replace(_C,'')
	except Exception:server2='LdkTuNUf';macant='';selected=''
	try:
		headers={_J:_Cq};req=urllib.request.Request('https://pastebin.com/raw/'+server2,headers=headers);mac1=urllib.request.urlopen(req).read().decode(_E);mac='';mac=re.findall(_G1,mac1);portal=re.findall(_Dl,mac1.lower())[0];dialog=xbmcgui.Dialog();ret=dialog.select('MAC ACTUAL: [ '+str(selected)+' # '+str(macant)+' ]',['Change MAC','Continue w / MAC '+macant]);lists=[_AM,'no'];categorias=lists[ret]
		if _AM in categorias:
			newmac='';selectable='Choose a Random MAC'
			for mc in mac:selectable=selectable+_m+str(mc)
			mac_list=selectable.split(_m);ret=dialog.select('Choose a MAC:',mac_list)
			if ret==1:
				random.seed()
				while newmac==''or not newmac:newmac=random.choice(mac)
			elif ret==-1:newmac=macant
			else:newmac=mac[ret-1]
			if newmac!=macant:myaddon.setSetting(_Bf,newmac);xbmc.executebuiltin('XBMC.Notification( MAC nou, '+newmac+', 8000)')
		else:xbmc.executebuiltin(f"XBMC.Notification(Continue with MAC, {macant}, 8000)")
		xbmc.executebuiltin(_AQ);view_channels(params)
	except Exception:xbmc.executebuiltin(f"XBMC.Notification(New MAC Error, Continue with {macant}, 8000)");xbmc.executebuiltin(_AQ);xbmc.executebuiltin(_BY)
def mac_portal(server):
	date_today=date.today();text_today=date_today.strftime('%Y%m%d');headers={_J:_Cq}
	try:
		req=urllib.request.Request(f"https://pastebin.com/raw/{server}",headers=headers);data=urllib.request.urlopen(req).read().decode(_E,errors=_F).replace(_C,'');macx=re.findall('(00:1a:79:.*?........)',data)
		if not macx:xbmcgui.Dialog().ok(_Dj,'Failed to retrieve valid MAC addresses. Please try again.');return'',''
		portal=str(re.findall(_Dl,data.lower())[0]).replace(_C,'');mac=str(random.choice(macx)).replace(_C,'');myaddon.setSetting(_Co,server);myaddon.setSetting('cam',mac);myaddon.setSetting(_Cp,portal);myaddon.setSetting('fec',text_today);return mac,portal
	except Exception:xbmcgui.Dialog().ok(_Dj,'Failed to connect to the server. Please try again.');return'',''
def get_channels(mac,portal):
	A='token';usuario='';headers={_J:_u,_A5:f"mac={mac}; stb_lang=en; timezone=America/New_York",_Z:_a,_b:_c};url=f"{portal}portal.php?type=stb&action=handshake&JsHttpRequest=1-xml";cached_data=read_cache(url,mac)
	if cached_data:return cached_data[_CQ],cached_data[A]
	s=get_session()
	try:
		response=s.get(url,headers=headers,timeout=5);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F);source=source.replace(_C,'');token=re.findall(_Cl,source)[0].replace(_C,'');headers={_J:_u,_A5:f"mac={mac}; stb_lang=en; timezone=America/New_York",_B5:f"Bearer {token}",_Z:_a,_b:_c};url=f"{portal}portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml";response=s.get(url,headers=headers,timeout=5);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F);source=source.replace(_C,'');passs=re.findall(_De,source)[0].replace(_C,'');typee=re.findall(_Df,source)[0].replace(_C,'');payload={_Dg:usuario,_v:passs,_Dh:typee};url=f"{portal}portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml";response=s.post(url,headers=headers,data=str(payload),timeout=5);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F);source=source.replace(_C,'');genres=plugintools.find_multiple_matches(source,_Di)
		if not genres:return[],[]
		cache_data={_CQ:genres,A:token};write_cache(url,cache_data,mac);return genres,token
	except Exception:return[],[]
def ipkoditv_enigmax(params):
	params=dict(params);params[_M]=str(params.get(_M)or xtream or'');params[_K]=str(params.get(_K)or backgrnd or'')
	if portalxc=='':pxc=portalxtream();control.setSetting(_Bi,pxc);xbmc.executebuiltin(_AQ);ipkoditv_enigma(params)
	else:ipkoditv_enigma(params)
def ipkoditv_enigma(params):
	thumbnail=params.get(_M);url1=myaddon.getSetting(_Bi).replace(_C,'');username=myaddon.getSetting(_C5).replace(_C,'');password=myaddon.getSetting(_C6).replace(_C,'');url3=f"{url1}/enigma2.php?username={username}&password={password}";page=_Dm;url=url3+page;headers={_J:_A6,_i:_j,_Z:_a,_b:_c};cache_key=url;cached_data=sqlite_read_cache(cache_key)
	if cached_data:url=cached_data
	else:
		s=get_session()
		try:response=s.get(url,headers=headers,timeout=3);response.raise_for_status();url=response.text.encode(_E,errors=_F).decode(_E,errors=_F);url=url.replace(_C,'');sqlite_write_cache(cache_key,url)
		except requests.Timeout:xbmcgui.Dialog().notification(_D,'Server is slow or unresponsive. Please try again or use another server.',xbmcgui.NOTIFICATION_ERROR,3000);return
		except requests.RequestException:xbmcgui.Dialog().notification(_D,f"Failed to connect to server. Please try again.",xbmcgui.NOTIFICATION_ERROR,3000);return
	matches=re.findall('(?s)<title>.*?</title>.*?<description.*?>.*?<.*?CDATA.*?&cat_id=.*?>.*?',url,re.DOTALL)
	if not matches:xbmcgui.Dialog().notification(_D,_G2,xbmcgui.NOTIFICATION_ERROR,3000);return
	porn=myaddon.getSetting(_X).replace(_C,'')
	for genres in matches:
		url=plugintools.find_single_match(genres,'(&cat_id=.*?)..>.*?');description=plugintools.find_single_match(genres,_G3);description=base64.b64decode(description).decode(_E,errors=_F).replace(_C,'');title=plugintools.find_single_match(genres,_G4);title=base64.b64decode(title).decode(_E,errors=_F).replace(_C,'');stream_url=f"{url3}&type=get_live_streams{url}";tit=title.lower();is_adult=_AF in tit or _AG in tit or _AH in tit or _AI in tit or _AJ in tit or _AK in tit or _AL in tit or _Aw in tit or _Ax in tit or _Ay in tit or _l in tit or _k in tit or _p in tit or _s in tit or _Az in tit or _t in tit or _r in tit or _A_ in tit or _B0 in tit or _B1 in tit or _B2 in tit or _q in tit or _X in tit or _B3 in tit or _B4 in tit
		if porn==_N or porn==_A8 and not is_adult:plugintools.add_item(action=_DO,url=stream_url,title=color(title),thumbnail=thumbnail,fanart=backgrnd4,folder=_A)
def ipkoditv_enigmapb(params):
	thumbnail=params.get(_M);url1=params.get(_I);username=params.get(_S);password=params.get(_Y);url3=params.get(_P);page=_Dm;url=url3+page;request_headers=[[_J,_AN]]
	try:
		body,response_headers=plugintools.read_body_and_headers(url,headers=request_headers)
		if six.PY3:url_content=body.strip().decode(_E,errors=_F)
		else:url_content=body.strip()
	except urllib.error.URLError as e:
		if'WinError 10061'in str(e):xbmcgui.Dialog().notification(_D,'Server is offline or refusing connections. Please try another server.',xbmcgui.NOTIFICATION_ERROR,3000)
		elif'timed out'in str(e):xbmcgui.Dialog().notification(_D,'Server is not responding (timeout). Please try another server.',xbmcgui.NOTIFICATION_ERROR,3000)
		else:xbmcgui.Dialog().notification(_D,f"Cannot connect to server: {str(e)}. Please try another server.",xbmcgui.NOTIFICATION_ERROR,3000)
		return
	except urllib.error.HTTPError as e:xbmcgui.Dialog().notification(_D,f"Server error (HTTP {e.code}). It may be down or credentials are invalid. Try another server.",xbmcgui.NOTIFICATION_ERROR,3000);return
	except Exception:xbmcgui.Dialog().notification(_D,'Failed to connect to server. Please try another server.',xbmcgui.NOTIFICATION_ERROR,3000);return
	matches=re.findall('(?s)<title>.*?</title>.*?<description.*?>.*?<.*?CDATA.*?cat_id=.*?>.*?',url_content,re.DOTALL)
	if not matches:xbmcgui.Dialog().notification(_D,_G2,xbmcgui.NOTIFICATION_ERROR,3000);return
	porn=myaddon.getSetting(_X).replace(_C,'')==_N;parental_control=myaddon.getSetting(_CL).replace(_C,'')==_N;parental_password=myaddon.getSetting(_CM).replace(_C,'')or _CN;adult_choice=_G;handle=int(sys.argv[1])
	for genre in matches:
		url=plugintools.find_single_match(genre,'(.cat_id=.*?)..>.*?');description=plugintools.find_single_match(genre,_G3);description=base64.b64decode(description)
		if six.PY3:description=description.decode(_E,errors=_F)
		else:description=description
		title=plugintools.find_single_match(genre,_G4);message_bytes=base64.b64decode(title)
		if six.PY3:title=message_bytes.decode(_E,errors=_F)
		else:title=message_bytes
		url=url3+'&type=get_live_streams'+url;tit=title.lower();is_adult=_AF in tit or _AG in tit or _AH in tit or _AI in tit or _AJ in tit or _AK in tit or _AL in tit or _Aw in tit or _Ax in tit or _Ay in tit or _l in tit or _k in tit or _p in tit or _s in tit or _Az in tit or _t in tit or _r in tit or _A_ in tit or _B0 in tit or _B1 in tit or _B2 in tit or _q in tit or _X in tit or _B3 in tit or _B4 in tit
		if is_adult and not porn:continue
		if is_adult and parental_control and adult_choice is _G:
			dialog=xbmcgui.Dialog();ret=dialog.select(_CO,[_CP,_Cj]);adult_choice=[_AM,'no'][ret]
			if adult_choice==_AM:
				d=dialog.input(_Dc,type=xbmcgui.INPUT_ALPHANUM).replace(_w,'+').replace(_C,'')
				if d==parental_password:adult_choice=_Bs
				else:xbmcgui.Dialog().notification(_D,_Ck,xbmcgui.NOTIFICATION_ERROR,5000);adult_choice=_z
			else:adult_choice=_z
		if is_adult and parental_control and adult_choice==_z:continue
		li=xbmcgui.ListItem(colored_title);li.setArt({_U:thumbnail,_K:backgrnd2});item_url=sys.argv[0]+'?'+urlencode({_d:_DO,_I:url,_M:thumbnail});xbmcplugin.addDirectoryItem(handle,item_url,li,isFolder=_A)
	xbmcplugin.endOfDirectory(handle)
def ipkoditv_enigma2(params):
	thumbnail=params.get(_M);url3=params.get(_I,'').replace(_C,'');headers={_J:_A6,_i:_j,_Z:_a,_b:_c};cache_key=url3;cached_data=sqlite_read_cache(cache_key)
	if cached_data:url=cached_data
	else:
		s=get_session()
		try:response=s.get(url3,headers=headers,timeout=5);response.raise_for_status();url=response.text.encode(_E,errors=_F).decode(_E,errors=_F);url=url.replace(_C,'');sqlite_write_cache(cache_key,url)
		except requests.RequestException:xbmcgui.Dialog().notification(_D,'Failed to fetch Xtream streams',xbmcgui.NOTIFICATION_ERROR,3000);return
	matches=re.findall('(?s)<title>.*?</title>.*?<description.*?>.*?<.*?CDATA..*?..>.*?DATA.*?http.*?.ts',url,re.DOTALL);porn=myaddon.getSetting(_X).replace(_C,'');parental_control_enabled=myaddon.getSetting(_CL)==_N;parental_password=myaddon.getSetting(_CM)or _CN;adult_choice=_G;handle=int(sys.argv[1])
	for genre in matches:
		pattern=plugintools.find_single_match(genre,'(?s)<title>(.*?)</title>.*?<description.*?>(.*?)<.*?CDATA.(.*?)..>.*?DATA.*?(http.*?.ts)');url=pattern[3].replace(_C,'');title=base64.b64decode(pattern[0]).decode(_E,errors=_F).replace(_C,'');hour='';emision=plugintools.find_single_match(title,'(?s) .*?[A-Z].*?[A-Z].*? \\[.*?\\] ....*?min (.*)').replace('(','').replace('[','').replace(_n,'').replace(_m,'').replace('-','').replace(_CR,'').replace(_C,'');title=plugintools.find_single_match(title,'(.*?[A-zZ]: .*?\\[|.*?[A-zZ] .*?\\[|.*?[A-zZ]: .*?\\(|.*?[A-zZ]: .*? .*? |.*?[A-zZ]: [A-zZ].*|.*?[A-Z].*)').replace('(','').replace('[','').replace(_n,'').replace(_m,'').replace('-','').replace(_CR,'').replace(_C,'');description=base64.b64decode(pattern[1]).decode(_E,errors=_F).replace(_C,'');tit=title.lower();is_adult=_AF in tit or _AG in tit or _AH in tit or _AI in tit or _AJ in tit or _AK in tit or _AL in tit or _Aw in tit or _Ax in tit or _Ay in tit or _l in tit or _k in tit or _p in tit or _s in tit or _Az in tit or _t in tit or _r in tit or _A_ in tit or _B0 in tit or _B1 in tit or _B2 in tit or _q in tit or _X in tit or _B3 in tit or _B4 in tit
		if is_adult and porn==_A8:continue
		if is_adult and parental_control_enabled and adult_choice is _G:
			dialog=xbmcgui.Dialog();ret=dialog.select(_CO,[_CP,_Cj]);adult_choice=[_Bs,_z][ret]
			if adult_choice==_Bs:
				password_input=dialog.input('Enter Parental Control Password',type=xbmcgui.INPUT_ALPHANUM)
				if password_input!=parental_password:xbmcgui.Dialog().notification(_D,'Incorrect parental control password.',xbmcgui.NOTIFICATION_ERROR,3000);adult_choice=_z
		if porn==_N or porn==_A8 and not is_adult:
			if is_adult and parental_control_enabled and adult_choice==_z:continue
			li=xbmcgui.ListItem(f"[COLOR white]{title} [COLOR white]{hour} [COLOR lime]{emision}[/COLOR]");li.setArt({_U:thumbnail,_K:backgrnd3});li.setProperty(_AE,_N);item_url=sys.argv[0]+'?'+urlencode({_d:_BB,_I:url,_M:thumbnail});xbmcplugin.addDirectoryItem(handle,item_url,li,isFolder=_B)
	xbmcplugin.endOfDirectory(handle)
def xtreamocodespastebin(params):
	M='password\\=(.+?)\\&';L='username\\=(.+?)\\&';K='(htt.+?)\\/get.php';J='"active_cons":"(.*?)"';I='"active_cons":"';H='"max_connections":"(.*?)"';G='"max_connections":"';F='Unlimited';E='"exp_date":"(.*?)"';D='"exp_date":"';C='url3';B='null';A='server_data';country_map={'AD':'Andorra','AE':_Dn,'AF':_G5,'AG':_G6,'AI':'Anguilla','AL':'Albania','AM':'Armenia','AO':'Angola','AQ':_G7,'AR':_Cr,'AS':_G8,'AT':_Do,'AU':_Cs,'AW':'Aruba','AX':_G9,'AZ':_GA,'BA':_GB,'BB':'Barbados','BD':_Dp,'BE':_Dq,'BF':_GC,'BG':_Dr,'BH':_Ds,'BI':'Burundi','BJ':'Benin','BL':_GD,'BM':'Bermuda','BN':_GE,'BO':'Bolivia','BQ':_GF,'BR':_Ct,'BS':'Bahamas','BT':'Bhutan','BV':_GG,'BW':'Botswana','BY':'Belarus','BZ':'Belize','CA':_Cu,'CC':_GH,'CD':_GI,'CF':_GJ,'CG':'Congo','CH':_Dt,'CI':_GK,'CK':_GL,'CL':_Du,'CM':'Cameroon','CN':_Dv,'CO':_Dw,'CR':_GM,'CU':'Cuba','CV':_GN,'CW':'Curaçao','CX':_GO,'CY':_Dx,'CZ':_Dy,'DE':_Dz,'DJ':'Djibouti','DK':_D_,'DM':'Dominica','DO':_GP,'DZ':_E0,'EC':'Ecuador','EE':_E1,'EG':_E2,'EH':_GQ,'ER':'Eritrea','ES':_E3,'ET':'Ethiopia','FI':_E4,'FJ':'Fiji','FK':_GR,'FM':_GS,'FO':_GT,'FR':_E5,'GA':'Gabon','GB':_E6,'GD':'Grenada','GE':'Georgia','GF':_GU,'GG':'Guernsey','GH':_E7,'GI':_GV,'GL':_GW,'GM':'Gambia','GN':'Guinea','GP':_GX,'GQ':_GY,'GR':_E8,'GS':_GZ,'GT':_Ga,'GU':'Guam','GW':_Gb,'GY':'Guyana','HK':_Cv,'HM':_Gc,'HN':'Honduras','HR':_E9,'HT':'Haiti','HU':_EA,'ID':_Cw,'IE':_EB,'IL':_EC,'IM':_Gd,'IN':_Cx,'IO':_Ge,'IQ':'Iraq','IR':'Iran','IS':_ED,'IT':_EE,'JE':'Jersey','JM':'Jamaica','JO':_EF,'JP':_Cy,'KE':_EG,'KG':_Gf,'KH':_EH,'KI':'Kiribati','KM':'Comoros','KN':_Gg,'KP':_Gh,'KR':_Cz,'KW':_EI,'KY':_Gi,'KZ':_Gj,'LA':_EJ,'LB':_EK,'LC':_Gk,'LI':_Gl,'LK':_EL,'LR':'Liberia','LS':'Lesotho','LT':_EM,'LU':_EN,'LV':_EO,'LY':_EP,'MA':_EQ,'MC':'Monaco','MD':'Moldova','ME':_Gm,'MF':_Gn,'MG':_Go,'MH':_Gp,'MK':_Gq,'ML':'Mali','MM':_ER,'MN':_ES,'MO':'Macao','MP':_Gr,'MQ':_Gs,'MR':_Gt,'MS':_Gu,'MT':_ET,'MU':_Gv,'MV':'Maldives','MW':'Malawi','MX':_C_,'MY':_D0,'MZ':_EU,'NA':'Namibia','NC':_Gw,'NE':'Niger','NF':_Gx,'NG':_EV,'NI':_Gy,'NL':_EW,'NO':_EX,'NP':_EY,'NR':'Nauru','NU':'Niue','NZ':_D1,'OM':'Oman','PA':'Panama','PE':'Peru','PF':_Gz,'PG':_G_,'PH':_EZ,'PK':_Ea,'PL':_Eb,'PM':_H0,'PN':'Pitcairn','PR':_H1,'PS':_H2,'PT':_Ec,'PW':'Palau','PY':'Paraguay','QA':_Ed,'RE':'Réunion','RO':_Ee,'RS':_Ef,'RU':'Russia','RW':'Rwanda','SA':_Eg,'SB':_H3,'SC':_H4,'SD':'Sudan','SE':_Eh,'SG':_D2,'SH':_H5,'SI':_Ei,'SJ':_H6,'SK':_Ej,'SL':_H7,'SM':_H8,'SN':'Senegal','SO':'Somalia','SR':'Suriname','SS':_H9,'ST':_HA,'SV':_HB,'SX':_HC,'SY':_HD,'SZ':'Eswatini','TC':_HE,'TD':'Chad','TF':_HF,'TG':'Togo','TH':_D3,'TJ':_HG,'TK':'Tokelau','TL':_HH,'TM':_HI,'TN':_Ek,'TO':'Tonga','TR':_El,'TT':_HJ,'TV':'Tuvalu','TW':_D4,'TZ':_Em,'UA':'Ukraine','UG':_En,'UM':_HK,'US':_CS,'UY':'Uruguay','UZ':_HL,'VA':'Holy See','VC':_HM,'VE':_Eo,'VG':_HN,'VI':_HO,'VN':_Ep,'VU':'Vanuatu','WF':_HP,'WS':'Samoa','YE':'Yemen','YT':'Mayotte','ZA':_D5,'ZM':_Eq,'ZW':_Er}
	def get_geo_data(host,retries=3):
		parsed_url=urlparse(host);clean_host=parsed_url.hostname if parsed_url.hostname else host.split(':')[0];cache_key=f"geo_ip_{hashlib.md5(clean_host.encode()).hexdigest()}";cached=sqlite_read_cache(cache_key)
		if cached:country_code=cached.get(_CT,_Q);country=country_map.get(country_code,_Q);return country
		geo_services=[{_I:f"http://ip-api.com/json/{clean_host}",_A2:_HQ},{_I:f"https://ipinfo.io/{clean_host}/json",_A2:_o},{_I:f"https://freegeoip.app/json/{clean_host}",_A2:_CT}];country=_Q;country_code=_Q
		for service in geo_services:
			for attempt in range(retries):
				try:
					headers={_J:_A6,_i:_j,_Z:_a,_b:_c};geo_response=requests.get(service[_I],headers=headers,timeout=6);geo_response.raise_for_status();geo_data=geo_response.json()
					if service[_A2]in geo_data and geo_data[service[_A2]]:
						country_code=geo_data[service[_A2]];country=country_map.get(country_code,_Q)
						if country!=_Q:sqlite_write_cache(cache_key,{_CT:country_code},cache_duration=86400);return country
				except requests.Timeout:pass
				except requests.HTTPError:pass
				except Exception:pass
		sqlite_write_cache(cache_key,{_CT:country_code},cache_duration=86400);return country
	url=params.get(_I);thumbnail=params.get(_M);headers={_J:_A6,_i:_j,_Z:_a,_b:_c};server_check_mode=myaddon.getSetting(_HR)or _g;cache_key=f"xtream_responsive_servers_{url}";portalxc=myaddon.getSetting(_Bi)
	if not url or portalxc and url.startswith(portalxc):xbmcgui.Dialog().notification(_D,'Invalid server list URL or personal server detected.',xbmcgui.NOTIFICATION_ERROR,3000);return
	pb=xbmcgui.DialogProgress();pb.create(_D,_HS)
	try:read_url,read_header=plugintools.read_body_and_headers(url,headers=[[_J,headers[_J]]],timeout=3);url_content=read_url.strip().decode(_E,errors=_F)
	except Exception:pb.close();xbmcgui.Dialog().notification(_D,'Failed to retrieve server list. Please check your internet or try again later.',xbmcgui.NOTIFICATION_ERROR,3000);return
	matches=plugintools.find_multiple_matches(url_content,'(htt.+?\\/get.php\\?username\\=.+?\\&password\\=.+?\\&type)')
	if not matches:pb.close();xbmcgui.Dialog().notification(_D,'No valid servers found in the list. Please try again later.',xbmcgui.NOTIFICATION_ERROR,3000);return
	total_servers=len(matches)
	if server_check_mode==_g:
		dialog=xbmcgui.Dialog();num_servers=dialog.numeric(0,f"# Servers?\n([COLOR blue]Max[/COLOR]: [COLOR springgreen]{total_servers}[/COLOR])")
		try:
			num_servers=int(num_servers)
			if num_servers<=0 or num_servers>total_servers:raise ValueError
		except ValueError:pb.close();xbmcgui.Dialog().notification(_D,f"Please enter a number between 1 and {total_servers}.",xbmcgui.NOTIFICATION_ERROR,3000);return
		matches=matches[:num_servers];total_servers=len(matches);cached_servers=sqlite_read_cache(cache_key)
		if cached_servers:
			pb.update(0,'Loading cached servers...');valid_servers=0;server_results=[]
			def fetch_server_details(server_data):
				country=get_geo_data(server_data[_I]);parsed_url=urlparse(server_data[_I]);clean_url=parsed_url.hostname if parsed_url.hostname else server_data[_I].replace(_e,'').replace(_f,'')
				try:
					response=requests.get(f"{server_data[_I]}/player_api.php?username={server_data[_A4]}&password={server_data[_v]}",headers=headers,timeout=3);response.raise_for_status();content=response.text.encode(_E,errors=_F).decode(_E,errors=_F).replace(_C,'');exp_date=re.findall(E,content)[0]if D in content else B
					if exp_date!=B:
						expiration_date=datetime.fromtimestamp(int(exp_date))
						if expiration_date<datetime.now():return
						expiration_date=expiration_date.strftime(_Es)
					else:expiration_date=F
					max_connections=re.findall(H,content)[0]if G in content else _Q;active_connections=re.findall(J,content)[0]if I in content else _Q;return{_H:f"{country} - [COLOR springgreen]{expiration_date}[/COLOR] - ({active_connections}/{max_connections}) - {clean_url}",A:server_data,_o:country}
				except Exception:return{_H:f"{country} - [COLOR red]Error[/COLOR] - (? /?) - {clean_url}",A:server_data,_o:country}
			with ThreadPoolExecutor(max_workers=5)as executor:
				future_to_server={executor.submit(fetch_server_details,server_data):server_data for server_data in cached_servers[:num_servers]}
				for future in as_completed(future_to_server):
					if pb.iscanceled():pb.close();return
					result=future.result()
					if result:server_results.append(result);valid_servers+=1
			server_results.sort(key=lambda x:(x[_o]!=_CS,x[_o]==_Q,x[_o]));handle=int(sys.argv[1])
			for result in server_results:li=xbmcgui.ListItem(result[_H]);li.setArt({_U:thumbnail,_K:backgrnd1});item_url=sys.argv[0]+'?'+urlencode({_d:_Cb,_P:result[A][C],_Y:result[A][_v],_S:result[A][_A4],_I:result[A][_I],_M:thumbnail});xbmcplugin.addDirectoryItem(handle,item_url,li,isFolder=_A)
			pb.close();xbmcplugin.endOfDirectory(handle);xbmcgui.Dialog().notification(_D,f"Loaded {valid_servers} cached servers.",xbmcgui.NOTIFICATION_INFO,3000);return
		valid_servers=[]
		def test_server(genre):
			url=plugintools.find_single_match(genre,K)
			if not url.startswith((_e,_f)):return
			username=plugintools.find_single_match(genre,L);password=plugintools.find_single_match(genre,M)
			if not username or not password:return
			url3=url+_Et+username+_B6+password;s=get_session();test_url=url3+_Dm
			try:response=s.get(test_url,headers=headers,timeout=1);response.raise_for_status();return{_I:url,_A4:username,_v:password,C:url3}
			except requests.RequestException:return
		pb.update(0,f"Checking {total_servers} servers...")
		with ThreadPoolExecutor(max_workers=5)as executor:
			future_to_server={executor.submit(test_server,genre):genre for genre in matches};completed_servers=0
			for future in as_completed(future_to_server):
				if pb.iscanceled():pb.close();return
				completed_servers+=1
				if completed_servers%5==0 or completed_servers==total_servers:pb.update(int(100*completed_servers/total_servers),f"Checked {completed_servers} / {total_servers} servers...")
				server_data=future.result()
				if server_data:valid_servers.append(server_data)
		if valid_servers:sqlite_write_cache(cache_key,valid_servers,cache_duration=3600)
		valid_count=len(valid_servers);server_results=[]
		def fetch_server_details(server_data):
			country=get_geo_data(server_data[_I]);parsed_url=urlparse(server_data[_I]);clean_url=parsed_url.hostname if parsed_url.hostname else server_data[_I].replace(_e,'').replace(_f,'')
			try:
				response=requests.get(f"{server_data[_I]}/player_api.php?username={server_data[_A4]}&password={server_data[_v]}",headers=headers,timeout=3);response.raise_for_status();content=response.text.encode(_E,errors=_F).decode(_E,errors=_F).replace(_C,'');exp_date=re.findall(E,content)[0]if D in content else B
				if exp_date!=B:
					expiration_date=datetime.fromtimestamp(int(exp_date))
					if expiration_date<datetime.now():return
					expiration_date=expiration_date.strftime(_Es)
				else:expiration_date=F
				max_connections=re.findall(H,content)[0]if G in content else _Q;active_connections=re.findall(J,content)[0]if I in content else _Q;return{_H:f"{country} - [COLOR springgreen]{expiration_date}[/COLOR] - ({active_connections}/{max_connections}) - {clean_url}",A:server_data,_o:country}
			except Exception:return{_H:f"{country} - [COLOR red]Error[/COLOR] - (? /?) - {clean_url}",A:server_data,_o:country}
		with ThreadPoolExecutor(max_workers=5)as executor:
			future_to_server={executor.submit(fetch_server_details,server_data):server_data for server_data in valid_servers}
			for future in as_completed(future_to_server):
				if pb.iscanceled():pb.close();return
				result=future.result()
				if result:server_results.append(result)
		server_results.sort(key=lambda x:(x[_o]!=_CS,x[_o]==_Q,x[_o]));handle=int(sys.argv[1])
		for result in server_results:li=xbmcgui.ListItem(result[_H]);li.setArt({_U:thumbnail,_K:backgrnd1});item_url=sys.argv[0]+'?'+urlencode({_d:_Cb,_P:result[A][C],_Y:result[A][_v],_S:result[A][_A4],_I:result[A][_I],_M:thumbnail});xbmcplugin.addDirectoryItem(handle,item_url,li,isFolder=_A)
		pb.close();xbmcplugin.endOfDirectory(handle)
		if len(server_results)==0:xbmcgui.Dialog().notification(_D,'No responsive servers available. Please try again later.',xbmcgui.NOTIFICATION_ERROR,3000)
		else:xbmcgui.Dialog().notification(_D,f"Found {len(server_results)}/{total_servers} responsive servers.",xbmcgui.NOTIFICATION_INFO,3000)
	else:
		pb.update(0,'Loading original server list...');handle=int(sys.argv[1]);server_count=0
		for genre in matches:
			if pb.iscanceled():pb.close();return
			server_count+=1;url=plugintools.find_single_match(genre,K)
			if not url.startswith((_e,_f)):continue
			username=plugintools.find_single_match(genre,L);password=plugintools.find_single_match(genre,M)
			if not username or not password:continue
			url3=url+_Et+username+_B6+password;parsed_url=urlparse(url);clean_url=parsed_url.hostname if parsed_url.hostname else url.replace(_e,'').replace(_f,'');country=get_geo_data(url);li=xbmcgui.ListItem(f"{country} - {clean_url}");li.setArt({_U:thumbnail,_K:backgrnd1});item_url=sys.argv[0]+'?'+urlencode({_d:_Cb,_P:url3,_Y:password,_S:username,_I:url,_M:thumbnail});xbmcplugin.addDirectoryItem(handle,item_url,li,isFolder=_A);pb.update(int(100*server_count/total_servers),f"Processed {server_count}/{total_servers} servers...")
		pb.close();xbmcplugin.endOfDirectory(handle)
		if server_count==0:xbmcgui.Dialog().notification(_D,'No valid servers found in the list.',xbmcgui.NOTIFICATION_ERROR,3000)
		else:xbmcgui.Dialog().notification(_D,f"Processed {server_count}/{total_servers} servers.",xbmcgui.NOTIFICATION_INFO,3000)
def select_xtream_server(params):
	M='Canceled';L='password=(.+?)\\&';K='username=(.+?)\\&';J='(http.+?)\\/get\\.php';I='is_search';H='is_last_used';G='red';F='is_user_server';E='is_predefined';D='active_connections';C='exp_date';B='max_connections';A='None';global _geo_cache;_geo_cache={};addon=xbmcaddon.Addon(_Ce);show_geo=addon.getSetting('show_geo')==_N;server_check_mode=addon.getSetting(_HR)or _g;bypass_cache=addon.getSetting('bypass_cache')==_N;filter_connections=addon.getSetting('filter_connections')==_N and server_check_mode==_g;server_check_order=addon.getSetting(_D6)if server_check_mode==_g else _g;thumbnail=str(params.get(_M)or xtream or'');fanart=str(params.get(_K)or backgrnd or'');headers={_J:_A6,_i:_j,_Z:_a,_b:_c};country_map={'AD':'Andorra','AE':_Dn,'AF':_G5,'AG':_G6,'AI':'Anguilla','AL':'Albania','AM':'Armenia','AO':'Angola','AQ':_G7,'AR':_Cr,'AS':_G8,'AT':_Do,'AU':_Cs,'AW':'Aruba','AX':_G9,'AZ':_GA,'BA':_GB,'BB':'Barbados','BD':_Dp,'BE':_Dq,'BF':_GC,'BG':_Dr,'BH':_Ds,'BI':'Burundi','BJ':'Benin','BL':_GD,'BM':'Bermuda','BN':_GE,'BO':'Bolivia','BQ':_GF,'BR':_Ct,'BS':'Bahamas','BT':'Bhutan','BV':_GG,'BW':'Botswana','BY':'Belarus','BZ':'Belize','CA':_Cu,'CC':_GH,'CD':_GI,'CF':_GJ,'CG':'Congo','CH':_Dt,'CI':_GK,'CK':_GL,'CL':_Du,'CM':'Cameroon','CN':_Dv,'CO':_Dw,'CR':_GM,'CU':'Cuba','CV':_GN,'CW':'Curaçao','CX':_GO,'CY':_Dx,'CZ':_Dy,'DE':_Dz,'DJ':'Djibouti','DK':_D_,'DM':'Dominica','DO':_GP,'DZ':_E0,'EC':'Ecuador','EE':_E1,'EG':_E2,'EH':_GQ,'ER':'Eritrea','ES':_E3,'ET':'Ethiopia','FI':_E4,'FJ':'Fiji','FK':_GR,'FM':_GS,'FO':_GT,'FR':_E5,'GA':'Gabon','GB':_E6,'GD':'Grenada','GE':'Georgia','GF':_GU,'GG':'Guernsey','GH':_E7,'GI':_GV,'GL':_GW,'GM':'Gambia','GN':'Guinea','GP':_GX,'GQ':_GY,'GR':_E8,'GS':_GZ,'GT':_Ga,'GU':'Guam','GW':_Gb,'GY':'Guyana','HK':_Cv,'HM':_Gc,'HN':'Honduras','HR':_E9,'HT':'Haiti','HU':_EA,'ID':_Cw,'IE':_EB,'IL':_EC,'IM':_Gd,'IN':_Cx,'IO':_Ge,'IQ':'Iraq','IR':'Iran','IS':_ED,'IT':_EE,'JE':'Jersey','JM':'Jamaica','JO':_EF,'JP':_Cy,'KE':_EG,'KG':_Gf,'KH':_EH,'KI':'Kiribati','KM':'Comoros','KN':_Gg,'KP':_Gh,'KR':_Cz,'KW':_EI,'KY':_Gi,'KZ':_Gj,'LA':_EJ,'LB':_EK,'LC':_Gk,'LI':_Gl,'LK':_EL,'LR':'Liberia','LS':'Lesotho','LT':_EM,'LU':_EN,'LV':_EO,'LY':_EP,'MA':_EQ,'MC':'Monaco','MD':'Moldova','ME':_Gm,'MF':_Gn,'MG':_Go,'MH':_Gp,'MK':_Gq,'ML':'Mali','MM':_ER,'MN':_ES,'MO':'Macao','MP':_Gr,'MQ':_Gs,'MR':_Gt,'MS':_Gu,'MT':_ET,'MU':_Gv,'MV':'Maldives','MW':'Malawi','MX':_C_,'MY':_D0,'MZ':_EU,'NA':'Namibia','NC':_Gw,'NE':'Niger','NF':_Gx,'NG':_EV,'NI':_Gy,'NL':_EW,'NO':_EX,'NP':_EY,'NR':'Nauru','NU':'Niue','NZ':_D1,'OM':'Oman','PA':'Panama','PE':'Peru','PF':_Gz,'PG':_G_,'PH':_EZ,'PK':_Ea,'PL':_Eb,'PM':_H0,'PN':'Pitcairn','PR':_H1,'PS':_H2,'PT':_Ec,'PW':'Palau','PY':'Paraguay','QA':_Ed,'RE':'Réunion','RO':_Ee,'RS':_Ef,'RU':'Russia','RW':'Rwanda','SA':_Eg,'SB':_H3,'SC':_H4,'SD':'Sudan','SE':_Eh,'SG':_D2,'SH':_H5,'SI':_Ei,'SJ':_H6,'SK':_Ej,'SL':_H7,'SM':_H8,'SN':'Senegal','SO':'Somalia','SR':'Suriname','SS':_H9,'ST':_HA,'SV':_HB,'SX':_HC,'SY':_HD,'SZ':'Eswatini','TC':_HE,'TD':'Chad','TF':_HF,'TG':'Togo','TH':_D3,'TJ':_HG,'TK':'Tokelau','TL':_HH,'TM':_HI,'TN':_Ek,'TO':'Tonga','TR':_El,'TT':_HJ,'TV':'Tuvalu','TW':_D4,'TZ':_Em,'UA':'Ukraine','UG':_En,'UM':_HK,'US':_CS,'UY':'Uruguay','UZ':_HL,'VA':'Holy See','VC':_HM,'VE':_Eo,'VG':_HN,'VI':_HO,'VN':_Ep,'VU':'Vanuatu','WF':_HP,'WS':'Samoa','YE':'Yemen','YT':'Mayotte','ZA':_D5,'ZM':_Eq,'ZW':_Er};hardcoded_usa_servers=[_Bt,'cord-cutter.net','fortv.cc','nocable.cc','xxip25.top','panelguys.top','tvmate.icu','xxip1.top','xxip9.top','1tv41.icu','xxip43.top']
	if show_geo:
		tld_map={'de':_Dz,'fr':_E5,'nl':_EW,'it':_EE,'es':_E3,'pl':_Eb,'se':_Eh,'no':_EX,'dk':_D_,'fi':_E4,'be':_Dq,'at':_Do,'ch':_Dt,'gr':_E8,'pt':_Ec,'cz':_Dy,'hu':_EA,'ro':_Ee,'bg':_Dr,'hr':_E9,'rs':_Ef,'si':_Ei,'sk':_Ej,'lt':_EM,'lv':_EO,'ee':_E1,'ie':_EB,'lu':_EN,'mt':_ET,'cy':_Dx,'is':_ED,'tr':_El,'il':_EC,'ae':_Dn,'sa':_Eg,'qa':_Ed,'kw':_EI,'bh':_Ds,'om':'Oman','jo':_EF,'lb':_EK,'eg':_E2,'ma':_EQ,'tn':_Ek,'dz':_E0,'ly':_EP,'za':_D5,'ke':_EG,'ng':_EV,'gh':_E7,'tz':_Em,'ug':_En,'zm':_Eq,'zw':_Er,'mz':_EU,'br':_Ct,'ar':_Cr,'cl':_Du,'co':_Dw,'pe':'Peru','ve':_Eo,'mx':_C_,'ca':_Cu,'au':_Cs,'nz':_D1,'sg':_D2,'my':_D0,'th':_D3,_O:_Cw,'ph':_EZ,'vn':_Ep,'kr':_Cz,'jp':_Cy,'cn':_Dv,'hk':_Cv,'tw':_D4,'in':_Cx,'pk':_Ea,'bd':_Dp,'lk':_EL,'np':_EY,'mm':_ER,'kh':_EH,'la':_EJ,'mn':_ES}
		def get_geo_data(host):
			G='Fallback';F='International';E='Keyword';D='WHOIS';C='Hardcoded';B='API';A='TLD';global _geo_cache;hostname=urlparse(host).hostname or''
			if not hostname:return _A7,'Invalid'
			if hostname in _geo_cache:country,source=_geo_cache[hostname];return country,source
			ip=_G
			try:ip=socket.gethostbyname(hostname)
			except:pass
			apis=[{_I:f"https://ipinfo.io/{ip or hostname}/json",_A2:_o},{_I:f"https://freeipapi.com/api/json/{ip or hostname}",_A2:'countryName'},{_I:f"https://api.ip2location.io/?key=free&ip={ip or hostname}",_A2:'country_name'},{_I:f"http://ipwho.is/{ip or hostname}",_A2:_o},{_I:f"http://ip-api.com/json/{ip or hostname}?fields=country",_A2:_o}]
			for api in apis:
				try:
					r=requests.get(api[_I],headers=headers,timeout=3)
					if r.status_code==200:
						j=r.json();code=j.get(api[_A2])or j.get(_CT)or j.get(_HQ)
						if code:
							country=country_map.get(code.upper(),code.title());_geo_cache[hostname]=country,B
							if ip:_geo_cache[ip]=country,B
							return country,B
				except Exception as e:continue
			tld_suffixes={'co.uk':_E6,'com.br':_Ct,'com.ar':_Cr,'co.za':_D5,'com.au':_Cs,'co.nz':_D1,'ne.jp':_Cy,'com.mx':_C_,'co.in':_Cx,'co.id':_Cw,'com.sg':_D2,'co.th':_D3,'com.my':_D0,'co.kr':_Cz,'com.tw':_D4,'com.hk':_Cv};parts=hostname.split('.')
			for i in range(1,min(4,len(parts))):
				suffix='.'.join(parts[-i:]).lower()
				if suffix in tld_suffixes:country=tld_suffixes[suffix];_geo_cache[hostname]=country,A;return country,A
			tld=parts[-1].lower()
			if tld in tld_map:country=tld_map[tld];_geo_cache[hostname]=country,A;return country,A
			if any(h in hostname for h in hardcoded_usa_servers):country=_CS;_geo_cache[hostname]=country,C;return country,C
			try:
				w=whois.whois(hostname);cc=w.get(_o)or w.get('Country')
				if cc and isinstance(cc,str):cc=cc.strip().upper();country=country_map.get(cc,cc.title());_geo_cache[hostname]=country,D;return country,D
			except Exception as e:pass
			lower_host=hostname.lower()
			for(code,name)in country_map.items():
				if code.lower()in lower_host or name.lower().replace(_w,'')in lower_host:_geo_cache[hostname]=name,E;return name,E
			_geo_cache[hostname]=F,G;return F,G
	else:
		def get_geo_data(host):return'-',A
	server_lists=[];last_used_server=addon.getSetting(_CJ)
	if last_used_server:
		try:
			srv=json.loads(last_used_server)
			if all(k in srv for k in[_Au,_A4,_v]):
				host=srv[_Au][7:].split(_R)[0];maxc=srv.get(B,_Q);actc=srv.get(D,_Q);country=srv.get(_o,_A7)if show_geo else'-';exp=srv.get(C,_Q)
				if not(filter_connections and str(maxc)==str(actc)):conn_color=G if str(maxc)==str(actc)else _Eu;country_part=f"{country} | "if show_geo else'';title=f"[COLOR salmon]Last Used [COLOR white]| {host} | [COLOR red]{maxc}[/COLOR] | [COLOR {conn_color}]{actc}[/COLOR] | [COLOR blue]{exp}[/COLOR] | [COLOR white]{country_part}[/COLOR]";server_lists.append({_H:title,_I:f"{srv[_Au]}/get.php?username={srv[_A4]}&password={srv[_v]}&type=m3u",H:_A})
		except:addon.setSetting(_CJ,'')
	server_lists.append({_H:'[COLOR cyan]Search Xtream - Select List[/COLOR]',_d:_Bo,I:_A});server_lists.extend([{_H:_CA,_I:_CB,E:_A},{_H:_CC,_I:_CD,E:_A},{_H:_CE,_I:_CF,E:_A},{_H:_CG,_I:_CH,E:_A}]);user_list=addon.getSetting(_CI)
	if user_list and user_list.strip():server_lists.append({_H:_D7,_I:user_list})
	portalxc=addon.getSetting(_Bi);usernamexc=addon.getSetting(_C5);passxc=addon.getSetting(_C6)
	if all([portalxc,usernamexc,passxc]):
		server_lists.append({_H:'[COLOR yellow]Xtream - Your Server (Live)[/COLOR]',_d:_FS,F:_A})
		try:
			vod_ok=[_B];series_ok=[_B]
			def check_vod():
				try:result=xtream_vod_categories({_Bu:_N,_P:portalxc,_S:usernamexc,_Y:passxc},timeout=8);vod_ok[0]=bool(result)
				except:vod_ok[0]=_B
			def check_series():
				try:result=xtream_series_categories({_Bu:_N,_P:portalxc,_S:usernamexc,_Y:passxc},timeout=8);series_ok[0]=bool(result)
				except:series_ok[0]=_B
			t1=threading.Thread(target=check_vod);t2=threading.Thread(target=check_series);t1.start();t2.start();t1.join(9);t2.join(9)
			if vod_ok[0]:server_lists.append({_H:'[COLOR blue]Xtream - Your Server (1Click Movies)[/COLOR]',_d:_DQ,F:_A,_P:portalxc,_S:usernamexc,_Y:passxc,_W:'vod'})
			if series_ok[0]:server_lists.append({_H:'[COLOR springgreen]Xtream - Your Server (1Click TvShows)[/COLOR]',_d:_DR,F:_A,_P:portalxc,_S:usernamexc,_Y:passxc,_W:_D8})
		except Exception as e:pass
	dialog=xbmcgui.Dialog();ret=dialog.select('Select Server List',[s[_H]for s in server_lists])
	if ret==-1:return
	selected=server_lists[ret]
	if selected.get(F):
		url=f"{sys.argv[0]}?action={selected[_d]}"
		if selected.get(_P):url+=f"&page={quote(selected[_P])}&extra={quote(selected[_S])}&episode={quote(selected[_Y])}&plot={selected[_W]}"
		xbmc.executebuiltin(f"Container.Update({url},replace)");return
	if selected.get(I):action=selected.get(_d,_DS);xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?action={action},replace)");return
	if selected.get(H):srv=json.loads(addon.getSetting(_CJ));url=f"{sys.argv[0]}?action=xtreamocodespastebin_categories&page={quote(srv[_Au])}&extra={quote(srv[_A4])}&episode={quote(srv[_v])}";xbmc.executebuiltin(f"Container.Update({url},replace)");return
	url=selected[_I];cache_key=url;servers=sqlite_read_cache(cache_key)if not bypass_cache else _G
	if not servers:
		pb=xbmcgui.DialogProgress();pb.create(_D,_HS)
		try:
			r=requests.get(url,headers=headers,timeout=15);r.raise_for_status();content=r.text;servers=plugintools.find_multiple_matches(content,'(http.+?\\/get\\.php\\?username=.+?\\&password=.+?\\&type)')
			if not servers:
				for line in content.splitlines():
					line=line.strip()
					if line and not line.startswith('#'):
						parts=[p.strip()for p in line.split(_m)]
						if len(parts)>=3:servers.append(f"{parts[0]}/get.php?username={parts[1]}&password={parts[2]}&type=m3u")
		except Exception as e:dialog.notification(_x,'Failed to fetch list',xbmcgui.NOTIFICATION_ERROR);pb.close();return
		finally:pb.close()
	if servers and not bypass_cache:sqlite_write_cache(cache_key,servers,duration=86400)
	if not servers:dialog.notification(_x,'No servers found',xbmcgui.NOTIFICATION_ERROR);return
	if server_check_mode=='1':
		titles=[];server_map={};is_predefined=any(p in url for p in['raw.githubusercontent.com','pastebin.com'])
		for s in servers:
			base=plugintools.find_single_match(s,J);user=plugintools.find_single_match(s,K);pwd=plugintools.find_single_match(s,L)
			if not base or not user or not pwd:continue
			host=base[7:].split(_R)[0]
			if is_predefined:title=f"[COLOR white]{host}[/COLOR]"
			else:title=f"[COLOR salmon]{host}[/COLOR] | User: [COLOR yellow]{user}[/COLOR] | Pass: [COLOR cyan]{pwd}[/COLOR]"
			titles.append(title);server_map[title]=base,user,pwd
		ret=dialog.select('Select Server',titles)
		if ret==-1:return
		base,user,pwd=server_map[titles[ret]];url=f"{sys.argv[0]}?action=xtreamocodespastebin_categories&page={quote(base)}&extra={quote(user)}&episode={quote(pwd)}";xbmc.executebuiltin(f"Container.Update({url},replace)");return
	total=len(servers);max_check=dialog.input(f"# Servers?\n(Max: [COLOR springgreen]{total}[/COLOR])",type=xbmcgui.INPUT_NUMERIC)
	try:max_check=min(int(max_check),total)
	except:max_check=total
	if server_check_order=='1':random.shuffle(servers)
	servers=servers[:max_check];results_key=f"results_{url}_{max_check}";server_details=sqlite_read_cache(results_key)if not bypass_cache else[]
	if not server_details and not bypass_cache:server_details=[]
	online_count=[len(server_details)]
	if not server_details:
		pb=xbmcgui.DialogProgress();pb.create(_D,f"Checking {max_check} servers...");server_details=[];online_count=[0];cancel_event=threading.Event();session=requests.Session();session.headers.update(headers)
		def check_one(server):
			if cancel_event.is_set():return
			try:
				base=plugintools.find_single_match(server,J);user=plugintools.find_single_match(server,K);pwd=plugintools.find_single_match(server,L)
				if not base or not user or not pwd:return
				info_url=f"{base}/player_api.php?username={user}&password={pwd}"
				try:
					r=session.get(info_url,timeout=3)
					if r.status_code!=200:return
					j=r.json()
				except:return
				online_count[0]+=1;info=j.get('user_info',{});maxc=info.get(B,_Q);actc=info.get('active_cons',_Q);exp=info.get(C,_Q)
				if exp and str(exp).isdigit():
					try:exp=datetime.fromtimestamp(int(exp)).strftime(_Es)
					except:exp=_Q
				host=base[7:].split(_R)[0];country,_=get_geo_data(base)if show_geo else('-',A)
				if filter_connections:
					if str(maxc)==str(actc)and maxc not in(_Q,A,_G):return
					if maxc in(_Q,A,_G)and actc in(_Q,A,_G):return
					if maxc in(_Q,A,_G)and actc not in(_Q,A,_G):return
				conn_color=G if str(maxc)==str(actc)else _Eu;title=f"[COLOR white]{country}[/COLOR] | [COLOR red]{maxc}[/COLOR] | [COLOR {conn_color}]{actc}[/COLOR] | [COLOR blue]{exp}[/COLOR] | {host}"if show_geo and country!='-'else f"[COLOR white]{host}[/COLOR] | [COLOR red]{maxc}[/COLOR] | [COLOR {conn_color}]{actc}[/COLOR] | [COLOR blue]{exp}[/COLOR]";return{_H:title,_Au:base,_A4:user,_v:pwd,_o:country if show_geo else'-',C:exp,B:maxc,D:actc}
			except Exception as e:return
		max_workers=5 if platform.system()=='Android'else 10;from concurrent.futures import ThreadPoolExecutor
		with ThreadPoolExecutor(max_workers=max_workers)as exe:
			futures={exe.submit(check_one,s):s for s in servers};done=0
			while futures and not cancel_event.is_set():
				if pb.iscanceled():cancel_event.set();break
				xbmc.sleep(100);completed=[f for f in futures if f.done()]
				for f in completed:
					res=f.result()
					if res:server_details.append(res)
					del futures[f];done+=1
				pb.update(int(done*100/max_check),f"Checked: [COLOR cyan]{done}[/COLOR] / [COLOR dodgerblue]{max_check}[/COLOR] | Online: [COLOR yellow]{online_count[0]}[/COLOR] | Available: [COLOR springgreen]{len(server_details)}[/COLOR]")
			if cancel_event.is_set():
				for f in futures:f.cancel()
		try:pb.close()
		except:pass
		if server_details and not cancel_event.is_set():sqlite_write_cache(results_key,server_details,duration=86400)
		elif cancel_event.is_set():dialog.notification(M,f"Found {len(server_details)} before cancel",xbmcgui.NOTIFICATION_INFO)
	if not server_details:
		if cancel_event.is_set():dialog.notification(M,'No servers found before cancel',xbmcgui.NOTIFICATION_INFO)
		else:dialog.notification('No Servers','No valid servers found',xbmcgui.NOTIFICATION_ERROR)
		return
	titles=[s[_H]for s in server_details];dialog_title=f"Online: [COLOR yellow]{online_count[0]}[/COLOR] | Available: [COLOR springgreen]{len(server_details)}[/COLOR]";ret=dialog.select(dialog_title,titles)
	if ret==-1:return
	sel=server_details[ret];last_data={_Au:sel[_Au],_A4:sel[_A4],_v:sel[_v],_o:sel.get(_o,_A7)if show_geo else'-',C:sel.get(C,_Q),B:sel.get(B,_Q),D:sel.get(D,_Q)};addon.setSetting(_CJ,json.dumps(last_data));xbmc.sleep(200);xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_A);url=f"{sys.argv[0]}?action=xtreamocodespastebin_categories&page={quote(sel[_Au])}&extra={quote(sel[_A4])}&episode={quote(sel[_v])}";xbmc.executebuiltin(f"Container.Update({url},replace)")
def xtreamocodespastebin_categories(params):
	B='[COLOR white]-----------------------------------------------------------------------[/COLOR]';A='cat_id='
	try:
		page=urllib.parse.unquote(params.get(_P,''));username=urllib.parse.unquote(params.get(_S,''));password=urllib.parse.unquote(params.get(_Y,''));thumbnail=params.get(_M,xtream);fanart=params.get(_K,backgrnd)
		if not page or not username or not password:xbmcgui.Dialog().notification(addonname,_Ev,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)");return
		base_url=page.rstrip(_R);server_line=f"[COLOR yellow][B]Current Server: {base_url}[/B][/COLOR]";encoded_extra=urllib.parse.quote(username,safe='');encoded_episode=urllib.parse.quote(password,safe='');cache_key=f"live_categories_{hashlib.md5((page+_Et+encoded_extra+_B6+encoded_episode).encode(_E)).hexdigest()}";categories=sqlite_read_cache(cache_key)
		if not categories:
			categories=[]
			try:
				cat_url=f"{page}/enigma2.php?username={encoded_extra}&password={encoded_episode}&type=get_live_categories";headers={_J:_HT};resp=requests.get(cat_url,headers=headers,timeout=5);resp.raise_for_status();txt=resp.text.encode(_E,errors=_F).decode(_E,errors=_F).replace(_C,'')
				try:
					data=json.loads(txt)
					for c in data:
						cid=c.get(_Ch);cname=c.get(_C8)
						if cid and cname:categories.append({_O:cid,_L:cname})
				except ValueError:
					import xml.dom.minidom;doc=xml.dom.minidom.parseString(txt)
					for(i,ch)in enumerate(doc.getElementsByTagName('channel')):
						try:
							t=doc.getElementsByTagName(_H)[i].firstChild;u=doc.getElementsByTagName('playlist_url')[i].firstChild
							if t and u:name=base64.b64decode(t.nodeValue).decode(_E,errors=_F);url2=u.nodeValue.replace(_Ew,'').replace(']]>','');cid=url2.split(A)[-1]if A in url2 else str(i);categories.append({_O:cid,_L:name})
						except Exception:pass
				if categories:sqlite_write_cache(cache_key,categories,duration=86400)
			except Exception:xbmcgui.Dialog().notification(addonname,'Failed to load categories.',xbmcgui.NOTIFICATION_WARNING,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)");return
		has_vod=xtream_vod_categories({_P:page,_S:username,_Y:password,_Bu:_N});has_series=xtream_series_categories({_P:page,_S:username,_Y:password,_Bu:_N});handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,'Server Categories');xbmcplugin.setContent(handle,_CQ);xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_NONE)
		for txt in[_T,'\xa0\xa0\xa0\xa0\xa0[COLOR blue]D    [COLOR salmon]r    [COLOR violet]e    [COLOR yellow]a    [COLOR orange]m    [COLOR lime]M    [COLOR red]a    [COLOR blue]c    [COLOR salmon]h    [COLOR violet]i    [COLOR yellow]n    [COLOR orange]e[/COLOR]',B]:plugintools.add_item(action='',title=txt,thumbnail=icon,fanart=backgrnd,folder=_B)
		plugintools.add_item(action='',title=server_line,thumbnail=xtream,fanart=fanart,folder=_B);plugintools.add_item(action='',title=B,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action=_C2,title='[COLOR cyan]Change Server[/COLOR]',thumbnail=xtream,fanart=fanart,url='',folder=_A);search_url=f"{sys.argv[0]}?action=search_current_xtream_server&page={urllib.parse.quote(page,safe='')}&extra={urllib.parse.quote(username,safe='')}&episode={urllib.parse.quote(password,safe='')}";plugintools.add_item(action=_Fn,title='[COLOR cyan]Search This Server (Live + Movies + Series)[/COLOR]',thumbnail=xtream,fanart=fanart,url=search_url,folder=_A);vod_url=f"{sys.argv[0]}?action=xtream_vod_categories&page={urllib.parse.quote(page,safe='')}&extra={urllib.parse.quote(username,safe='')}&episode={urllib.parse.quote(password,safe='')}";series_url=f"{sys.argv[0]}?action=xtream_series_categories&page={urllib.parse.quote(page,safe='')}&extra={urllib.parse.quote(username,safe='')}&episode={urllib.parse.quote(password,safe='')}";plugintools.add_item(action=_DQ if has_vod else'',title='[COLOR salmon]1Click Movies[/COLOR]'if has_vod else'[COLOR gray]1Click Movies [Unavailable][/COLOR]',thumbnail=xtream,fanart=fanart,url=vod_url if has_vod else'',folder=has_vod);plugintools.add_item(action=_DR if has_series else'',title='[COLOR violet]1Click TvShows[/COLOR]'if has_series else'[COLOR gray]1Click TvShows [Unavailable][/COLOR]',thumbnail=xtream,fanart=fanart,url=series_url if has_series else'',folder=has_series);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);adult_tags=[_k,_l,_X,_p,_AS,_q,_BC,_BD,_BE,_s,_t,_BF,_BG,_BH,_BI,_BJ,_BK,_BL,_BM,_BN,_BO,_BP,_BQ,_BR,_BS,_BT,_BU,_BV,_AT,_AU,_AV,_AW,_AX,_AY,_AZ,_Aa,_Ab,_r,_Ac,_Ad,_Ae,_Af,_Ag,_Ah,_Ai,_Aj,_Ak,_Al,_Am,_An,_Ao,_Ap,_Aq];hide_adult=myaddon.getSetting(_BZ)==_N;radio_keywords=['live radio','radio stations',_Bg];useless_exact=[_CU,_Ex,'uncategorized']
		for cat in categories:
			name=cat[_L];cid=cat.get(_O,'');stripped_lower=name.strip().lower()
			if any(keyword in stripped_lower for keyword in radio_keywords):continue
			if stripped_lower in useless_exact:continue
			if hide_adult and any(t in stripped_lower for t in adult_tags):continue
			live_url=f"{page}/enigma2.php?username={encoded_extra}&password={encoded_episode}&type=get_live_streams&cat_id={cid}";plugintools.add_item(action=_FU,title=f"[COLOR white]{color(name)}[/COLOR]",thumbnail=xtream,fanart=fanart,url=live_url,page=page,extra=username,plot=password,folder=_A)
		xbmcplugin.endOfDirectory(handle,cacheToDisc=_A)
	except Exception as e:xbmcgui.Dialog().ok(addonname,'Unexpected error loading categories.')
def xtream_vod_categories(params,timeout=10):
	check_only=params.get(_Bu,_A8).lower()==_N
	try:
		page=urllib.parse.unquote_plus(params.get(_P,''));extra=urllib.parse.unquote_plus(params.get(_S,''));episode=urllib.parse.unquote_plus(params.get(_Y,''));thumbnail=params.get(_M,xtream);fanart=params.get(_K,backgrnd)
		if not check_only:
			if not page or not page.startswith((_e,_f))or not extra or not episode:xbmcgui.Dialog().notification(addonname,_Ev,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)");return _B
		try:
			cat_url=f"{page}/player_api.php?username={urllib.parse.quote_plus(extra)}&password={urllib.parse.quote_plus(episode)}&action=get_vod_categories";parsed_url=urllib.parse.urlparse(cat_url)
			if not parsed_url.scheme or not parsed_url.netloc:raise ValueError(_Ey)
		except ValueError:
			if not check_only:xbmcgui.Dialog().notification(addonname,_D9,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)")
			return _B
		adult_tags=[_k,_l,_X,_p,_AS,_q,_BC,_BD,_BE,_s,_t,_BF,_BG,_BH,_BI,_BJ,_BK,_BL,_BM,_BN,_BO,_BP,_BQ,_BR,_BS,_BT,_BU,_BV,_AT,_AU,_AV,_AW,_AX,_AY,_AZ,_Aa,_Ab,_r,_Ac,_Ad,_Ae,_Af,_Ag,_Ah,_Ai,_Aj,_Ak,_Al,_Am,_An,_Ao,_Ap,_Aq];hide_adult=myaddon.getSetting(_BZ)==_N;cache_key=f"vod_categories_{hashlib.md5((page+_HU+extra+_B6+episode).encode(_E)).hexdigest()}"
		if check_only:sqlite_write_cache(cache_key,_G,duration=0)
		categories=sqlite_read_cache(cache_key)
		if not categories:
			categories=[]
			try:
				headers={_J:_u};response=requests.get(cat_url,headers=headers,timeout=timeout);response.raise_for_status()
				try:
					data=response.json();categories_data=data.get(_HV,data)if isinstance(data,dict)else data
					if not isinstance(categories_data,list):categories_data=[]
					for category in categories_data:
						category_id=category.get(_Ch,'');category_name=category.get(_C8,'')
						if category_id and category_name:
							is_adult=any(tag in category_name.lower()for tag in adult_tags)
							if hide_adult and is_adult:continue
							categories.append({_O:str(category_id),_L:str(category_name)})
				except ValueError:
					if not check_only:xbmcgui.Dialog().notification(addonname,_HW,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)")
					return _B
				if categories and not check_only:sqlite_write_cache(cache_key,categories,duration=86400)
				elif not categories and not check_only:xbmcgui.Dialog().notification(addonname,'No VOD categories available. Please select another server.',xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)");return _B
			except requests.HTTPError as e:
				if not check_only:msg=_HX if e.response.status_code in(401,403)else f"Server error: {e.response.status_code}.";xbmcgui.Dialog().notification(addonname,msg,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)")
				return _B
			except requests.RequestException:
				if not check_only:xbmcgui.Dialog().notification(addonname,_HY,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)")
				return _B
			except Exception as e:
				if not check_only:xbmcgui.Dialog().notification(addonname,_HZ,xbmcgui.NOTIFICATION_ERROR,3000)
				return _B
		if check_only:excluded_categories=[_CU,_DA,_DB];valid_categories=[cat for cat in categories if not any(excluded.lower()in cat[_L].lower()for excluded in excluded_categories)and cat.get(_O,'')and not(hide_adult and any(tag in cat[_L].lower()for tag in adult_tags))];return bool(valid_categories)
		handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,'VOD Categories');xbmcplugin.setContent(handle,_CQ);excluded_categories=[_CU,_DA,_DB]
		for category in categories:
			name=category[_L];category_id=category.get(_O,'')
			if name.lower()in[ex.lower()for ex in excluded_categories]:continue
			is_adult=any(tag in name.lower()for tag in adult_tags)
			if hide_adult and is_adult:continue
			vod_url=f"{page}/player_api.php?username={urllib.parse.quote_plus(extra)}&password={urllib.parse.quote_plus(episode)}&action=get_vod_streams&category_id={category_id}";plugin_url=f"{sys.argv[0]}?action=xtream_vod_list&url={urllib.parse.quote_plus(vod_url)}&page={urllib.parse.quote_plus(page)}&extra={urllib.parse.quote_plus(extra)}&episode={urllib.parse.quote_plus(episode)}";plugintools.add_item(action=_FT,title=f"[COLOR white]{name}[/COLOR]",thumbnail=thumbnail,fanart=fanart,url=plugin_url,folder=_A)
		xbmcplugin.endOfDirectory(handle,cacheToDisc=_A);return _A
	except Exception as e:
		if not check_only:xbmcgui.Dialog().notification(addonname,_Ha,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)")
		return _B
def xtream_vod_list(params):
	try:
		url=urllib.parse.unquote_plus(params.get(_I,''));portal=urllib.parse.unquote_plus(params.get(_P,''));userp=urllib.parse.unquote_plus(params.get(_S,''));passp=urllib.parse.unquote_plus(params.get(_Y,''))
		if not url or not portal or not userp or not passp:xbmcgui.Dialog().notification(addonname,_DC,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)");return
		sort_mode=myaddon.getSetting('movie_sort');cache_key=f"vod_list_{hashlib.md5(url.encode(_E)).hexdigest()}_sort{sort_mode}";videos=sqlite_read_cache(cache_key)
		if not videos:
			videos=[]
			try:
				headers={_J:_HT,_i:_j,_Z:_a,_b:_c};response=session.get(url,headers=headers,timeout=10);response.raise_for_status();content=response.text.encode(_E,errors=_F).decode(_E,errors=_F).replace(_C,'')
				if not content:raise ValueError('Empty response from server')
				data=json.loads(content)
				if not isinstance(data,list):data=data.get('streams',data)if isinstance(data,dict)else[]
				enrich_tasks=[];use_tmdb=myaddon.getSetting('use_tmdb')==_N
				for item in data:
					name=item.get(_L,_A7);stream_id=str(item.get(_Bj,''))
					if not stream_id or not name.strip():continue
					enrich_tasks.append((item,name))
				tmdb_results={}
				if use_tmdb and enrich_tasks:
					with ThreadPoolExecutor(max_workers=18)as executor:
						future_to_index={executor.submit(_get_tmdb_details,name,_DD):idx for(idx,(item,name))in enumerate(enrich_tasks)}
						for future in as_completed(future_to_index):
							idx=future_to_index[future]
							try:tmdb_results[idx]=future.result()or{}
							except Exception:tmdb_results[idx]={}
				else:
					for idx in range(len(enrich_tasks)):tmdb_results[idx]={}
				temp_videos=[]
				for(idx,(item,name))in enumerate(enrich_tasks):
					tmdb_info=tmdb_results.get(idx,{});thumbnail=item.get(_Bv,'')or xtream
					if not thumbnail.startswith((_e,_f)):thumbnail=xtream
					extension=item.get(_y,_AA);stream_url=f"{portal}/movie/{userp}/{passp}/{item.get(_Bj)}.{extension}";final_thumb=tmdb_info.get(_CV)or thumbnail;plot=tmdb_info.get(_Bw)or item.get(_DE,'')or item.get(_W,'')or _CW;year=tmdb_info.get(_Ez)or item.get(_B7,'')or item.get(_Hb,'')or'';runtime=tmdb_info.get(_E_)or str(item.get(_Hc,'')or item.get(_A3,''));server_rating_raw=item.get(_h,'')or item.get(_Hd,'')or _g;tmdb_rating_num=.0
					if tmdb_info.get(_h,'')!=_Q:
						try:tmdb_rating_num=float(tmdb_info[_h].split(_R)[0])
						except:pass
					numeric_rating=tmdb_rating_num if tmdb_rating_num>0 else float(server_rating_raw or 0);rating_for_display=str(numeric_rating)if numeric_rating>0 else server_rating_raw;genre=item.get(_Ba,'')or item.get(_C8,'');cast=item.get(_AO,'').split(', ')if item.get(_AO)else[];rating_str=''
					if myaddon.getSetting('show_movie_rating')==_N:
						try:
							r=float(rating_for_display)
							if r>0:rating_str=f" [COLOR yellow]* {r:.1f}[/COLOR]"
						except:pass
					added_date_str=''
					if myaddon.getSetting('show_movie_date')==_N:
						added_ts=item.get('added')
						if added_ts and str(added_ts).isdigit():
							try:added_date=datetime.fromtimestamp(int(added_ts));added_date_str=f" [COLOR cyan]{added_date.strftime(_He)}[/COLOR]"
							except:pass
					display_name=name+rating_str+added_date_str;temp_videos.append({_Bx:display_name,_L:name,_CX:stream_url,_U:final_thumb,_K:final_thumb,_W:plot,_AO:cast,_h:numeric_rating,'rating_display':rating_for_display,_B7:str(year),_A3:runtime,_Ba:genre})
				videos=temp_videos
				if sort_mode==_g:videos=sorted(videos,key=lambda x:x[_L].lower())
				elif sort_mode=='1':videos=sorted(videos,key=lambda x:x[_L].lower(),reverse=_A)
				elif sort_mode=='3':videos=list(reversed(videos))
				elif sort_mode=='4':videos=sorted(videos,key=lambda x:float(x[_h])if isinstance(x[_h],(int,float))else .0,reverse=_A)
				if videos:sqlite_write_cache(cache_key,videos,cache_duration=86400)
			except Exception as e:xbmcgui.Dialog().notification(addonname,'Failed to load VOD. Check server.',xbmcgui.NOTIFICATION_ERROR,3000);return
		if not videos:xbmcgui.Dialog().notification(addonname,'No VOD content in this category.',xbmcgui.NOTIFICATION_INFO,3000);return
		handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,'VOD Movies');xbmcplugin.setContent(handle,_DF);adult_tags=[_k,_l,_X,_p,_AS,_q,_BC,_BD,_BE,_s,_t,_BF,_BG,_BH,_BI,_BJ,_BK,_BL,_BM,_BN,_BO,_BP,_BQ,_BR,_BS,_BT,_BU,_BV,_AT,_AU,_AV,_AW,_AX,_AY,_AZ,_Aa,_Ab,_r,_Ac,_Ad,_Ae,_Af,_Ag,_Ah,_Ai,_Aj,_Ak,_Al,_Am,_An,_Ao,_Ap,_Aq]
		for video in videos:
			if myaddon.getSetting(_BZ)==_A8 or not any(tag in video[_L].lower()for tag in adult_tags):liz=xbmcgui.ListItem(video[_Bx]);liz.setArt({_U:video[_U],_K:video[_K]});liz.setInfo(_AB,{_H:video[_Bx],_W:video[_W],_B7:int(video[_B7])if video[_B7].isdigit()else _G,_AO:video[_AO],_h:float(video[_h])if isinstance(video[_h],(int,float))and video[_h]>0 else _G,_A3:int(video[_A3])if video[_A3].isdigit()else _G,_Ba:video[_Ba]});liz.setProperty(_AE,_N);u=f"{sys.argv[0]}?action=xtream_vod_play&url={urllib.parse.quote_plus(video[_CX])}&page={urllib.parse.quote_plus(portal)}&extra={urllib.parse.quote_plus(userp)}&episode={urllib.parse.quote_plus(passp)}&title={urllib.parse.quote_plus(video[_L])}";xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=liz,isFolder=_B)
		xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_UNSORTED);xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_TITLE);xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_VIDEO_YEAR);xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_VIDEO_RATING);xbmcplugin.endOfDirectory(handle,cacheToDisc=_A)
	except Exception as e:xbmcgui.Dialog().notification(addonname,'VOD Error. Check log.',xbmcgui.NOTIFICATION_ERROR,3000)
def xtream_vod_play(params):
	try:
		stream_url=urllib.parse.unquote_plus(params.get(_I,''));portal=urllib.parse.unquote_plus(params.get(_P,''));userp=urllib.parse.unquote_plus(params.get(_S,''));passp=urllib.parse.unquote_plus(params.get(_Y,''));title=urllib.parse.unquote_plus(params.get(_H,_A7))
		if not stream_url or not portal or not userp or not passp:xbmcgui.Dialog().notification(addonname,'Missing credentials.',xbmcgui.NOTIFICATION_ERROR,3000);return
		full_url=stream_url;headers={_J:_A6,'Referer':portal,_i:_j,_Z:_a};encoded_headers=_n.join([f"{k}={urllib.parse.quote_plus(v)}"for(k,v)in headers.items()]);play_url=f"{full_url}|{encoded_headers}";ext=full_url.split('.')[-1].lower()if'.'in full_url else _AA;mime_type=_Hf if ext in[_AA,'mkv','avi']else'video/x-matroska'if ext=='mkv'else _Hg;liz=xbmcgui.ListItem(label=title);liz.setPath(play_url);liz.setMimeType(mime_type);liz.setProperty(_AE,_N)
		if'/series/'in full_url:liz.setInfo(_AB,{_Bb:_Y,_H:title})
		else:liz.setInfo(_AB,{_Bb:_DD,_H:title})
		xbmc.Player().stop();xbmc.executebuiltin('Playlist.Clear');handle=int(sys.argv[1]);xbmcplugin.setResolvedUrl(handle,_A,liz);xbmc.Player().play(play_url,liz)
	except Exception:xbmcgui.Dialog().notification(addonname,'Play failed.',xbmcgui.NOTIFICATION_ERROR,5000)
def xtream_list(params):
	D='\\+.*?(min|mi).*?';C='\\[\\d{1,2}:\\d{2}\\s*-\\s*\\d{1,2}:\\d{2}\\]';B='===';A='\\s{2,}'
	try:
		api_url=params.get(_I,'').replace(_C,'');server_url=params.get(_P,'').replace(_C,'');username=params.get(_S,'').replace(_C,'');password=params.get(_W,'').replace(_C,'')
		if not api_url:xbmcgui.Dialog().notification(_D,'Invalid category URL',xbmcgui.NOTIFICATION_ERROR,3000);return
		handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,'Live Channels');xbmcplugin.setContent(handle,_DF);headers={_J:_A6,_i:_j,_Z:_a,_b:_c};body,_=plugintools.read_body_and_headers(api_url,headers=headers,timeout=15);xml_response=body.decode(_E,errors=_F).replace(_C,'')
		if not xml_response.strip():xbmcgui.Dialog().notification(_D,'No channels available',xbmcgui.NOTIFICATION_INFO,3000);return
		try:root=ET.fromstring(xml_response)
		except ET.ParseError:xbmcgui.Dialog().notification(_D,_Dd,xbmcgui.NOTIFICATION_ERROR,3000);return
		channels=[]
		for channel_elem in root.findall('.//channel'):
			try:
				title_text=channel_elem.findtext(_H,'');desc_text=channel_elem.findtext(_DE,'');stream_text=channel_elem.findtext(_CX,'');thumb_text=channel_elem.findtext('desc_image','')
				if title_text and stream_text:
					stream_url=stream_text
					if stream_url.startswith(_Ew)and stream_url.endswith(']]>'):stream_url=stream_url[9:-3]
					thumbnail=thumb_text or''
					if thumbnail.startswith(_Ew)and thumbnail.endswith(']]>'):thumbnail=thumbnail[9:-3]
					if not thumbnail or not thumbnail.startswith((_e,_f)):thumbnail=xtream
					else:thumbnail=thumbnail
					clean_title=title_text;clean_desc=desc_text
					try:
						if title_text:decoded_title=base64.b64decode(title_text+B).decode(_E,errors=_F);clean_title=decoded_title.strip()
						if desc_text:decoded_desc=base64.b64decode(desc_text+B).decode(_E,errors=_F);clean_desc=decoded_desc.strip()
					except Exception:clean_title=title_text;clean_desc=desc_text
					parts=re.split(C,clean_title)
					if len(parts)==2 and parts[1].strip():channel_name=parts[0].strip();epg_part=re.sub(D,'',parts[1]).strip()
					else:channel_name=clean_title;epg_part=''
					display_name=channel_name.replace('[','').replace(']','').replace('(','').replace(')','').replace('SD','').replace('UHD','').replace('HD','').replace('FHD','').replace(_CR,'').replace(_m,'').replace('-','').replace(A,_w).strip();epg_info=re.sub(A,_w,epg_part).strip();clean_desc='';channels.append({_H:clean_title,_DE:clean_desc,_CX:stream_url,_M:thumbnail})
			except Exception:continue
		if not channels:xbmcgui.Dialog().notification(_D,'No channels in this category',xbmcgui.NOTIFICATION_INFO,3000);xbmcplugin.endOfDirectory(handle);return
		for channel in channels:
			clean_title=channel[_H];stream_url=channel[_CX];thumbnail=channel[_M];description=channel[_DE]
			if not stream_url:continue
			parts=re.split(C,clean_title)
			if len(parts)==2 and parts[1].strip():channel_name=parts[0].strip();epg_part=re.sub(D,'',parts[1]).strip()
			else:channel_name=clean_title;epg_part=''
			display_name=channel_name.replace('[','').replace(']','').replace('(','').replace(')','').replace('SD','').replace('UHD','').replace('HD','').replace('FHD','').replace(_CR,'').replace(_m,'').replace('-','').replace(A,_w).strip();epg_info=re.sub(A,_w,epg_part).strip();colored_title=f"[COLOR white]{display_name}[/COLOR]"
			if epg_info:colored_title+=f" [COLOR lime]{epg_info}[/COLOR]"
			li=xbmcgui.ListItem(label=colored_title);li.setArt({_U:thumbnail,_K:backgrnd});li.setProperty(_AE,_N);li.setInfo(_AB,{_H:colored_title,_W:description,_Bb:_AB});play_params={_d:_BB,_H:colored_title,_I:stream_url,_M:thumbnail,_K:backgrnd};play_url=sys.argv[0]+'?'+urlencode(play_params);xbmcplugin.addDirectoryItem(handle=handle,url=play_url,listitem=li,isFolder=_B)
		xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_LABEL);xbmcplugin.endOfDirectory(handle)
	except Exception:xbmcplugin.endOfDirectory(int(sys.argv[1]))
def xtream_series_categories(params,timeout=10):
	D='india tv series';C='anime';B='docuseries';A='classic tv shows';check_only=params.get(_Bu,_A8).lower()==_N
	try:
		page=urllib.parse.unquote_plus(params.get(_P,''));extra=urllib.parse.unquote_plus(params.get(_S,''));episode=urllib.parse.unquote_plus(params.get(_Y,''));thumbnail=params.get(_M,xtream);fanart=params.get(_K,backgrnd)
		if not check_only:
			if not page or not page.startswith((_e,_f))or not extra or not episode:xbmcgui.Dialog().notification(addonname,_Ev,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)");return _B
		try:
			cat_url=f"{page}/player_api.php?username={urllib.parse.quote_plus(extra)}&password={urllib.parse.quote_plus(episode)}&action=get_series_categories";parsed_url=urllib.parse.urlparse(cat_url)
			if not parsed_url.scheme or not parsed_url.netloc:raise ValueError(_Ey)
		except ValueError:
			if not check_only:xbmcgui.Dialog().notification(addonname,_D9,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)")
			return _B
		adult_tags=[_k,_l,_X,_p,_AS,_q,_BC,_BD,_BE,_s,_t,_BF,_BG,_BH,_BI,_BJ,_BK,_BL,_BM,_BN,_BO,_BP,_BQ,_BR,_BS,_BT,_BU,_BV,_AT,_AU,_AV,_AW,_AX,_AY,_AZ,_Aa,_Ab,_r,_Ac,_Ad,_Ae,_Af,_Ag,_Ah,_Ai,_Aj,_Ak,_Al,_Am,_An,_Ao,_Ap,_Aq];hide_adult=myaddon.getSetting(_BZ)==_N;cache_key=f"series_categories_{hashlib.md5((page+_HU+extra+_B6+episode).encode(_E)).hexdigest()}"
		if check_only:sqlite_write_cache(cache_key,_G,duration=0)
		categories=sqlite_read_cache(cache_key)
		if not categories:
			categories=[]
			try:
				headers={_J:_u};response=requests.get(cat_url,headers=headers,timeout=timeout);response.raise_for_status()
				try:
					data=response.json();categories_data=data.get(_HV,data)if isinstance(data,dict)else data
					if not isinstance(categories_data,list):categories_data=[]
					for category in categories_data:
						category_id=str(category.get(_Ch,''));category_name=str(category.get(_C8,''))
						if category_id and category_name:
							is_adult=any(tag in category_name.lower()for tag in adult_tags)
							if hide_adult and is_adult:continue
							categories.append({_O:category_id,_L:category_name})
				except ValueError:
					if not check_only:xbmcgui.Dialog().notification(addonname,_HW,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)")
					return _B
				if categories and not check_only:sqlite_write_cache(cache_key,categories,duration=86400)
				elif not categories and not check_only:xbmcgui.Dialog().notification(addonname,'No series categories available. Please select another server.',xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)");return _B
			except requests.HTTPError as e:
				if not check_only:msg=_HX if e.response.status_code in(401,403)else f"Server error: {e.response.status_code}.";xbmcgui.Dialog().notification(addonname,msg,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)")
				return _B
			except requests.RequestException:
				if not check_only:xbmcgui.Dialog().notification(addonname,_HY,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)")
				return _B
			except Exception as e:
				if not check_only:xbmcgui.Dialog().notification(addonname,_HZ,xbmcgui.NOTIFICATION_ERROR,3000)
				return _B
		if check_only:excluded_categories=[_CU,_DA,_DB,A,B,_Ex,C,D];valid_categories=[cat for cat in categories if not any(excluded.lower()in cat[_L].lower()for excluded in excluded_categories)and cat.get(_O,'')and not(hide_adult and any(tag in cat[_L].lower()for tag in adult_tags))];return bool(valid_categories)
		handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,'Series Categories');xbmcplugin.setContent(handle,_CQ);excluded_categories=[_CU,_DA,_DB,A,B,_Ex,C,D]
		for category in categories:
			name=category[_L];category_id=category.get(_O,'')
			if any(excluded.lower()in name.lower()for excluded in excluded_categories):continue
			is_adult=any(tag in name.lower()for tag in adult_tags)
			if hide_adult and is_adult:continue
			if not category_id:continue
			series_url=f"{page}/player_api.php?username={urllib.parse.quote_plus(extra)}&password={urllib.parse.quote_plus(episode)}&action=get_series&category_id={category_id}";plugin_url=f"{sys.argv[0]}?action=xtream_series_list&url={urllib.parse.quote_plus(series_url)}&page={urllib.parse.quote_plus(page)}&extra={urllib.parse.quote_plus(extra)}&episode={urllib.parse.quote_plus(episode)}";plugintools.add_item(action=_FV,title=f"[COLOR white]{name}[/COLOR]",thumbnail=thumbnail,fanart=fanart,url=plugin_url,folder=_A)
		xbmcplugin.endOfDirectory(handle,cacheToDisc=_A);return _A
	except Exception as e:
		if not check_only:xbmcgui.Dialog().notification(addonname,_Ha,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)")
		return _B
def xtream_series_list(params):
	A='releaseDate'
	try:
		url=urllib.parse.unquote_plus(params.get(_I,''));portal=urllib.parse.unquote_plus(params.get(_P,''));username=urllib.parse.unquote_plus(params.get(_S,''));password=urllib.parse.unquote_plus(params.get(_Y,''));thumbnail=params.get(_M,xtream);fanart=params.get(_K,backgrnd)
		if not url or not portal or not username or not password:xbmcgui.Dialog().notification(addonname,_DC,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)");return
		sort_mode=myaddon.getSetting('tvshow_sort');cache_key=f"series_list_{hashlib.md5(url.encode(_E)).hexdigest()}_sort{sort_mode}";series=sqlite_read_cache(cache_key)
		if not series:
			series=[]
			try:
				headers={_J:_A6,_i:_j,_Z:_a,_b:_c};response=session.get(url,headers=headers,timeout=10);response.raise_for_status();content=response.text.encode(_E,errors=_F).decode(_E,errors=_F).replace(_C,'')
				if not content:raise ValueError(_Hh)
				data=json.loads(content)
				if not isinstance(data,list):raise ValueError('Invalid series data format')
				enrich_tasks=[];use_tmdb=myaddon.getSetting('use_tmdb')==_N
				for item in data:
					name=item.get(_L,_A7);series_id=str(item.get(_B8,''))
					if not series_id or not name.strip():continue
					enrich_tasks.append((item,name))
				tmdb_results={}
				if use_tmdb and enrich_tasks:
					with ThreadPoolExecutor(max_workers=18)as executor:
						future_to_index={executor.submit(_get_tmdb_details,name,'tv'):idx for(idx,(item,name))in enumerate(enrich_tasks)}
						for future in as_completed(future_to_index):
							idx=future_to_index[future]
							try:tmdb_results[idx]=future.result()or{}
							except Exception:tmdb_results[idx]={}
				else:
					for idx in range(len(enrich_tasks)):tmdb_results[idx]={}
				temp_series=[]
				for(idx,(item,name))in enumerate(enrich_tasks):
					tmdb_info=tmdb_results.get(idx,{});server_thumb=item.get(_Bc,xtream);server_fanart=item.get(_Bk,[backgrnd]);fanart_item=server_fanart[0]if isinstance(server_fanart,list)and server_fanart else backgrnd;final_thumb=tmdb_info.get(_CV)or server_thumb;final_fanart=tmdb_info.get(_CV)or fanart_item;plot=tmdb_info.get(_Bw)or item.get(_W,'')or _CW;year=tmdb_info.get(_Ez)or(item.get(A,'').split('-')[0]if item.get(A)else'');server_rating_raw=str(item.get(_Hd,'')or item.get(_h,'')or _g);tmdb_rating_num=.0
					if tmdb_info.get(_h,'')!=_Q:
						try:tmdb_rating_num=float(tmdb_info[_h].split(_R)[0])
						except:pass
					server_rating_num=.0
					try:server_rating_num=float(server_rating_raw)
					except:pass
					numeric_rating=tmdb_rating_num if tmdb_rating_num>0 else server_rating_num;rating_for_display=numeric_rating if numeric_rating>0 else server_rating_raw;genre=item.get(_Ba,'');cast=item.get(_AO,'').split(', ')if item.get(_AO)else[];duration=str(item.get(_Bl,'')or item.get(_A3,''));rating_str=''
					if myaddon.getSetting('show_series_rating')==_N:
						try:
							r=float(rating_for_display)
							if r>0:rating_str=f" [COLOR yellow]* {r:.1f}[/COLOR]"
						except:pass
					added_date_str=''
					if myaddon.getSetting('show_series_date')==_N:
						added_ts=item.get('added')
						if added_ts and str(added_ts).isdigit():
							try:added_date=datetime.fromtimestamp(int(added_ts));added_date_str=f" [COLOR cyan]{added_date.strftime(_He)}[/COLOR]"
							except:pass
					display_name=name+rating_str+added_date_str;tmdb_id=_G
					if tmdb_info:
						try:
							cleaned=clean_title_for_tmdb(name);search_url=f"{TMDB_BASE_URL}/search/tv?api_key={TMDB_API_KEY}&query={cleaned.replace(_w,'+')}&language=en-US";resp=session.get(search_url,timeout=8);search_data=resp.json()
							if search_data.get(_C4):tmdb_id=search_data[_C4][0][_O]
						except:pass
					temp_series.append({_L:name,_Bx:display_name,_B8:item.get(_B8),_U:final_thumb,_K:final_fanart,_W:plot,_AO:cast,_h:numeric_rating,_B7:year,_A3:duration,_Ba:genre,_DG:tmdb_id})
				series=temp_series
				if sort_mode==_g:series=sorted(series,key=lambda x:x[_L].lower())
				elif sort_mode=='1':series=sorted(series,key=lambda x:x[_L].lower(),reverse=_A)
				elif sort_mode=='3':series=list(reversed(series))
				elif sort_mode=='4':series=sorted(series,key=lambda x:float(x[_h])if isinstance(x[_h],(int,float))else .0,reverse=_A)
				if series:sqlite_write_cache(cache_key,series,cache_duration=86400)
			except Exception as e:xbmcgui.Dialog().notification(addonname,'Failed to load series.',xbmcgui.NOTIFICATION_ERROR,3000);return
		if not series:xbmcgui.Dialog().notification(addonname,'No series available in this category.',xbmcgui.NOTIFICATION_INFO,3000);return
		handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,'Series Content');xbmcplugin.setContent(handle,'tvshows');adult_tags=[_k,_l,_X,_p,_AS,_q,_BC,_BD,_BE,_s,_t,_BF,_BG,_BH,_BI,_BJ,_BK,_BL,_BM,_BN,_BO,_BP,_BQ,_BR,_BS,_BT,_BU,_BV,_AT,_AU,_AV,_AW,_AX,_AY,_AZ,_Aa,_Ab,_r,_Ac,_Ad,_Ae,_Af,_Ag,_Ah,_Ai,_Aj,_Ak,_Al,_Am,_An,_Ao,_Ap,_Aq]
		for ser in series:
			if myaddon.getSetting(_BZ)==_A8 or not any(tag in ser[_L].lower()for tag in adult_tags):
				liz=xbmcgui.ListItem(ser[_Bx]);liz.setArt({_U:ser[_U],_K:ser[_K]});liz.setInfo(_AB,{_H:ser[_Bx],_W:ser[_W],_B7:int(ser[_B7])if ser[_B7].isdigit()else _G,_AO:ser[_AO],_h:float(ser[_h])if isinstance(ser[_h],(int,float))and ser[_h]>0 else _G,_A3:ser[_A3],_Ba:ser[_Ba],_Bb:'tvshow'});series_url=f"{portal}/player_api.php?username={urllib.parse.quote_plus(username)}&password={urllib.parse.quote_plus(password)}&action=get_series_info&series_id={ser[_B8]}";u=f"{sys.argv[0]}?action=xtream_series_seasons&url={urllib.parse.quote_plus(series_url)}&page={urllib.parse.quote_plus(portal)}&extra={urllib.parse.quote_plus(username)}&episode={urllib.parse.quote_plus(password)}"
				if ser.get(_DG):u+=f"&tmdb_id={ser[_DG]}"
				xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=liz,isFolder=_A)
		xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_UNSORTED);xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_TITLE);xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_VIDEO_YEAR);xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_VIDEO_RATING);xbmcplugin.endOfDirectory(handle,cacheToDisc=_A)
	except Exception as e:xbmcgui.Dialog().notification(addonname,'Series Error. Check log.',xbmcgui.NOTIFICATION_ERROR,3000)
def xtream_series_seasons(params):
	A='air_date'
	try:
		url=urllib.parse.unquote_plus(params.get(_I,''));portal=urllib.parse.unquote_plus(params.get(_P,''));username=urllib.parse.unquote_plus(params.get(_S,''));password=urllib.parse.unquote_plus(params.get(_Y,''));tmdb_id_param=params.get(_DG)
		if not url or not portal or not username or not password:xbmcgui.Dialog().notification(addonname,_DC,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)");return
		try:
			parsed_url=urllib.parse.urlparse(url)
			if not parsed_url.scheme or not parsed_url.netloc:raise ValueError(f"Invalid URL format: {url}")
		except ValueError:xbmcgui.Dialog().notification(addonname,_D9,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)");return
		try:parsed_query=urllib.parse.parse_qs(parsed_url.query);series_id=parsed_query.get(_B8,[''])[0]
		except Exception:series_id=_F0
		cache_key=f"series_info_{hashlib.md5(url.encode(_E)).hexdigest()}";data=sqlite_read_cache(cache_key)
		if not data:
			try:
				headers={_J:_A6,_i:_j,_Z:_a,_b:_c};response=session.get(url,headers=headers,timeout=10);response.raise_for_status();content=response.text.encode(_E,errors=_F).decode(_E,errors=_F).replace(_C,'')
				if not content:raise ValueError(_Hh)
				data=json.loads(content)
				if not isinstance(data,dict):raise ValueError('Invalid data format')
				if data:sqlite_write_cache(cache_key,data,cache_duration=86400)
			except Exception as e:xbmcgui.Dialog().notification(addonname,'Failed to load series info.',xbmcgui.NOTIFICATION_ERROR,3000);return
		episodes=data.get(_A0,{})
		if not isinstance(episodes,dict)or not episodes:xbmcgui.Dialog().notification(addonname,'No seasons available for this series.',xbmcgui.NOTIFICATION_INFO,3000);return
		info=data.get(_B9,{});series_name=info.get(_L,_Hi);server_thumb=info.get(_Bc,xtream);server_fanart=info.get(_Bk,[backgrnd])[0]if isinstance(info.get(_Bk),list)else info.get(_Bk,backgrnd);handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,f"Seasons - {series_name}");xbmcplugin.setContent(handle,_AP);seasons=sorted(episodes.keys(),key=lambda k:int(k)if k.isdigit()else 0)
		for season_num in seasons:
			try:
				season_int=int(season_num)if season_num.isdigit()else 0;season_poster=server_thumb;season_plot=info.get(_W,'')or _CW;season_air_date=''
				if tmdb_id_param:
					try:
						tmdb_id=int(tmdb_id_param);season_url=f"{TMDB_BASE_URL}/tv/{tmdb_id}/season/{season_int}";season_resp=session.get(season_url,params={_F1:TMDB_API_KEY,_F2:_F3},timeout=8);season_data=season_resp.json()
						if season_data.get(_DH):season_poster=f"https://image.tmdb.org/t/p/w500{season_data[_DH]}"
						if season_data.get(_Bw):season_plot=season_data[_Bw]
						if season_data.get(A):air_year=season_data[A][:4];season_air_date=air_year
					except Exception as e:pass
				season_title=f"Season {season_num}"
				if season_air_date:season_title+=f" [COLOR cyan]({season_air_date})[/COLOR]"
				liz=xbmcgui.ListItem(season_title);liz.setArt({_U:season_poster,_K:season_poster or server_fanart});liz.setInfo(_AB,{_H:season_title,_W:season_plot,_By:season_int,_Bb:_By});u=f"{sys.argv[0]}?action=xtream_season_list&url={urllib.parse.quote_plus(url)}&season={urllib.parse.quote_plus(str(season_num))}&page={urllib.parse.quote_plus(portal)}&extra={urllib.parse.quote_plus(username)}&episode={urllib.parse.quote_plus(password)}";xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=liz,isFolder=_A)
			except Exception as e:continue
		if not seasons:xbmcgui.Dialog().notification(addonname,'No seasons found.',xbmcgui.NOTIFICATION_INFO,3000);return
		xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_LABEL);xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_UNSORTED);xbmcplugin.endOfDirectory(handle,cacheToDisc=_A)
	except Exception as e:xbmcgui.Dialog().notification(addonname,'Error loading seasons.',xbmcgui.NOTIFICATION_ERROR,3000)
def xtream_season_list(params):
	try:
		url=urllib.parse.unquote_plus(params.get(_I,''));season=urllib.parse.unquote_plus(params.get(_By,''));portal=urllib.parse.unquote_plus(params.get(_P,''));username=urllib.parse.unquote_plus(params.get(_S,''));password=urllib.parse.unquote_plus(params.get(_Y,''))
		if not url or not season or not portal or not username or not password:xbmcgui.Dialog().notification(addonname,_DC,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)");return
		try:
			parsed_url=urllib.parse.urlparse(url)
			if not parsed_url.scheme or not parsed_url.netloc:raise ValueError(_Ey)
		except ValueError:xbmcgui.Dialog().notification(addonname,_D9,xbmcgui.NOTIFICATION_ERROR,3000);xbmc.executebuiltin(f"RunPlugin({sys.argv[0]}?action=select_xtream_server)");return
		try:parsed_query=urllib.parse.parse_qs(parsed_url.query);series_id=parsed_query.get(_B8,[''])[0]
		except Exception:series_id=_F0
		cache_key=f"series_info_{hashlib.md5(url.encode(_E)).hexdigest()}";data=sqlite_read_cache(cache_key)
		if not data:
			try:
				headers={_J:_A6,_i:_j,_Z:_a,_b:_c};response=session.get(url,headers=headers,timeout=10);response.raise_for_status();content=response.text.encode(_E,errors=_F).decode(_E,errors=_F).replace(_C,'');data=json.loads(content)
				if data:sqlite_write_cache(cache_key,data,cache_duration=86400)
			except Exception as e:xbmcgui.Dialog().notification(addonname,'Failed to load episodes.',xbmcgui.NOTIFICATION_ERROR,3000);return
		episodes=data.get(_A0,{}).get(season,[])
		if not episodes:xbmcgui.Dialog().notification(addonname,'No episodes available for this season.',xbmcgui.NOTIFICATION_INFO,3000);return
		info=data.get(_B9,{});series_name=info.get(_L,_Hi);season_int=int(season)if season.isdigit()else 0;tmdb_series=_get_tmdb_details(series_name,media_type='tv');series_thumb=info.get(_Bc,xtream);series_fanart=info.get(_Bk,[backgrnd])[0]if isinstance(info.get(_Bk),list)else info.get(_Bk,backgrnd);final_fanart=tmdb_series.get(_CV)or series_fanart;handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,f"{series_name} - Season {season}");xbmcplugin.setContent(handle,_A0);adult_tags=[_k,_l,_X,_p,_AS,_q,_BC,_BD,_BE,_s,_t,_BF,_BG,_BH,_BI,_BJ,_BK,_BL,_BM,_BN,_BO,_BP,_BQ,_BR,_BS,_BT,_BU,_BV,_AT,_AU,_AV,_AW,_AX,_AY,_AZ,_Aa,_Ab,_r,_Ac,_Ad,_Ae,_Af,_Ag,_Ah,_Ai,_Aj,_Ak,_Al,_Am,_An,_Ao,_Ap,_Aq]
		for ep in episodes:
			try:
				server_title=ep.get(_H,f"Episode {ep.get(_AD,'?')}");ep_num=ep.get(_AD,0);ep_id=ep.get(_O,'');ext=ep.get(_y,_AA);stream_url=f"{portal}/series/{username}/{password}/{ep_id}.{ext}";ep_info=ep.get(_B9,{});server_plot=ep_info.get(_W,'');server_releasedate=ep_info.get(_Hb,'');server_duration=ep_info.get(_Hc,'')or ep_info.get(_A3,'');server_thumb=ep_info.get('movie_image',series_thumb)
				if any(tag in server_title.lower()for tag in adult_tags):continue
				episode_title=server_title;episode_plot=server_plot or _CW;episode_airdate=server_releasedate;episode_thumb=server_thumb;episode_duration=server_duration
				if tmdb_series:
					if ep_num:
						try:ep_int=int(ep_num);episode_display=f"S{season_int:02d}E{ep_int:02d} - {server_title}"
						except:episode_display=server_title
					else:episode_display=server_title
				else:episode_display=server_title
				liz=xbmcgui.ListItem(episode_display);liz.setArt({_U:episode_thumb,_K:final_fanart});liz.setInfo(_AB,{_H:episode_display,_W:episode_plot,'premiered':episode_airdate,_A3:episode_duration if str(episode_duration).isdigit()else _G,_By:season_int,_Y:int(ep_num)if str(ep_num).isdigit()else 0,_Bb:_Y});liz.setProperty(_AE,_N);u=f"{sys.argv[0]}?action=xtream_vod_play&url={urllib.parse.quote_plus(stream_url)}&page={urllib.parse.quote_plus(portal)}&extra={urllib.parse.quote_plus(username)}&episode={urllib.parse.quote_plus(password)}&title={urllib.parse.quote_plus(episode_display)}";xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=liz,isFolder=_B)
			except Exception as e:continue
		xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_EPISODE);xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_TITLE);xbmcplugin.addSortMethod(handle,xbmcplugin.SORT_METHOD_UNSORTED);xbmcplugin.endOfDirectory(handle,cacheToDisc=_A)
	except Exception as e:xbmcgui.Dialog().notification(addonname,'Error loading episodes.',xbmcgui.NOTIFICATION_ERROR,3000)
def xtream_live_play(params):
	url=params.get(_I,'');portal=params.get(_P,control.setting(_Bi));userp=params.get(_S,control.setting(_C5));passp=params.get(_Y,control.setting(_C6))
	if not portal or not userp or not passp:xbmcgui.Dialog().ok(addonname,'No server credentials provided. Please select a server first.');return
	try:parsed_url=urlparse(url);stream_id=parsed_url.path.split(_R)[-1].split('.')[0];extension=parsed_url.path.split('.')[-1]if'.'in parsed_url.path else'ts';play_url=f"{portal}/live/{userp}/{passp}/{stream_id}.{extension}";headers={_J:_A6,_i:_j,_Z:_a,_b:_c};encoded_headers=_n.join([f"{k}={urllib.parse.quote_plus(v)}"for(k,v)in headers.items()]);play_url+=f"|{encoded_headers}";mime_type='video/mp2t'if extension=='ts'else _Hg if extension=='m3u8'else _Hf;liz=xbmcgui.ListItem(path=play_url);liz.setMimeType(mime_type);liz.setProperty(_AE,_N);xbmcplugin.setResolvedUrl(int(sys.argv[1]),_A,liz);xbmc.Player().play(play_url,liz)
	except Exception:xbmcgui.Dialog().ok(addonname,'Failed to play live stream.')
def linkdirectoxc(params):
	try:
		stream_url=params.get(_I,'').replace(_C,'');title=params.get(_H,'Live Stream').replace(_C,'')
		if not stream_url:xbmcgui.Dialog().notification(_D,'No stream URL available',xbmcgui.NOTIFICATION_ERROR,3000);xbmcplugin.setResolvedUrl(int(sys.argv[1]),_B,xbmcgui.ListItem());return
		li=xbmcgui.ListItem(label=title);li.setPath(stream_url);li.setProperty(_AE,_N);info_tag=li.getVideoInfoTag();info_tag.setTitle(title);info_tag.setMediaType(_AB);li.setArt({_U:params.get(_M,xtream),_K:params.get(_K,backgrnd)});xbmcplugin.setResolvedUrl(int(sys.argv[1]),_A,li)
	except Exception:
		xbmcgui.Dialog().notification(_D,'Playback failed.',xbmcgui.NOTIFICATION_ERROR,5000)
		try:xbmcplugin.setResolvedUrl(int(sys.argv[1]),_B,xbmcgui.ListItem())
		except:pass
def m3u(params):plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_Av,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action=_FZ,title='[COLOR cyan]Search Free M3U - ALL Lists[/COLOR]',thumbnail=search_icon,fanart=backgrnd,folder=_A);mac=myaddon.getSetting(_A1);portal=myaddon.getSetting(_AR);plugintools.add_item(action=_V,title=_Hj,thumbnail=free,fanart=backgrnd1,page='',url=_Hk,folder=_A);plugintools.add_item(action=_V,title='[COLOR springgreen]US Xumo[/COLOR]',thumbnail=free,fanart=backgrnd2,page='',url=_Hl,folder=_A);plugintools.add_item(action=_V,title='[COLOR yellow]US TvPass[/COLOR]',thumbnail=free,fanart=backgrnd3,page='',url=_Hm,folder=_A);plugintools.add_item(action=_V,title='[COLOR blue]US Tubi[/COLOR]',thumbnail=free,fanart=backgrnd4,page='',url=_Hn,folder=_A);plugintools.add_item(action=_V,title='[COLOR springgreen]US Stirr[/COLOR]',thumbnail=free,fanart=backgrnd5,page='',url=_Ho,folder=_A);plugintools.add_item(action=_V,title='[COLOR yellow]US Samsung[/COLOR]',thumbnail=free,fanart=backgrnd1,page='',url=_Hp,folder=_A);plugintools.add_item(action=_V,title='[COLOR blue]US Roku[/COLOR]',thumbnail=free,fanart=backgrnd2,page='',url=_Hq,folder=_A);plugintools.add_item(action=_V,title='[COLOR springgreen]US Pluto[/COLOR]',thumbnail=free,fanart=backgrnd3,page='',url=_Hr,folder=_A);plugintools.add_item(action=_V,title='[COLOR yellow]US PBS[/COLOR]',thumbnail=free,fanart=backgrnd4,page='',url=_Hs,folder=_A);plugintools.add_item(action=_V,title='[COLOR blue]US MovieOnJoy[/COLOR]',thumbnail=free,fanart=backgrnd5,page='',url=_Ht,folder=_A);plugintools.add_item(action=_V,title='[COLOR springgreen]US Local[/COLOR]',thumbnail=free,fanart=backgrnd1,page='',url=_Hu,folder=_A);plugintools.add_item(action=_V,title='[COLOR yellow]US KlowdTv[/COLOR]',thumbnail=free,fanart=backgrnd2,page='',url=_Hv,folder=_A);plugintools.add_item(action=_V,title='[COLOR blue]US FireTv[/COLOR]',thumbnail=free,fanart=backgrnd3,page='',url=_Hw,folder=_A);plugintools.add_item(action=_V,title='[COLOR springgreen]UK[/COLOR]',thumbnail=free,fanart=backgrnd4,page='',url=_Hx,folder=_A);plugintools.add_item(action=_V,title='[COLOR yellow]IPTV.Org US[/COLOR]',thumbnail=free,fanart=backgrnd5,page='',url=_Hy,folder=_A);plugintools.add_item(action=_V,title='[COLOR blue]IPTV.Org UK[/COLOR]',thumbnail=free,fanart=backgrnd1,page='',url=_Hz,folder=_A);plugintools.add_item(action=_V,title='[COLOR springgreen]IPTV.Org Spanish[/COLOR]',thumbnail=free,fanart=backgrnd2,page='',url=_H_,folder=_A);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B)
def listm3u1(params):
	A='Notification(Error,Failed to load playlist,5000,DefaultIconError.png)';url=params.get(_I,'').strip();default_thumbnail=params.get(_M,'')
	if not url:xbmc.executebuiltin(A);return
	try:response=urllib.request.urlopen(url);m3u_data=response.read().decode(_E).splitlines()
	except Exception as e:xbmc.executebuiltin(A);return
	for(i,line)in enumerate(m3u_data):
		line=line.strip()
		if not line or line.startswith('#'):continue
		if not(line.startswith(_e)or line.startswith(_f)):continue
		title=_A7;thumbnail=default_thumbnail
		if i>0 and m3u_data[i-1].startswith('#EXTINF'):
			extinf_line=m3u_data[i-1];title_match=re.search(',(.+)$',extinf_line)
			if title_match:title=title_match.group(1).strip()
			logo_match=re.search('tvg-logo="([^"]+)"',extinf_line)
			if logo_match:thumbnail=logo_match.group(1).strip()
		list_item=xbmcgui.ListItem(title);video_info=list_item.getVideoInfoTag();video_info.setTitle(title)
		if thumbnail:list_item.setArt({_U:thumbnail})
		plugin_url=f"plugin://plugin.video.dreammachine/?action=radio_play&title={urllib.parse.quote(title)}&url={urllib.parse.quote(line)}&thumbnail={urllib.parse.quote(thumbnail)}&plot={urllib.parse.quote(params.get(_W,''))}&extra={urllib.parse.quote(params.get(_S,''))}&page={urllib.parse.quote(params.get(_P,''))}";xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=plugin_url,listitem=list_item,isFolder=_B)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
def radio_play(params):
	A='Notification(Error,Failed to play channel,500,DefaultIconError.png)';url=params.get(_I,'').strip();title=params.get(_H,_A7);thumbnail=params.get(_M,'')
	if not(url.startswith(_e)or url.startswith(_f)):xbmc.executebuiltin('Notification(Error,Invalid URL format,1000,DefaultIconError.png)');return
	headers={_J:_A6,_i:_j,_Z:_a,_b:_c};list_item=xbmcgui.ListItem(title);video_info=list_item.getVideoInfoTag();video_info.setTitle(title)
	if thumbnail:list_item.setArt({_U:thumbnail})
	header_string=_n.join([f"{key}={value}"for(key,value)in headers.items()]);finalurl=f"{url}|{header_string}"if header_string else url;player=xbmc.Player();playlist=xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	if xbmc.getCondVisibility('Player.Playing'):player.stop();playlist.clear();xbmc.sleep(500)
	try:
		player.play(finalurl,list_item)
		for _ in range(80):
			if player.isPlaying():return
			xbmc.sleep(250)
	except Exception as e:xbmc.executebuiltin(A)
	if not player.isPlaying():player.stop();playlist.clear();xbmc.sleep(250);xbmc.executebuiltin(A)
def m3ugithub(params):plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_Av,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action=_FX,title='[COLOR cyan]Search Premium M3U - ALL Lists[/COLOR]',thumbnail=search_icon,fanart=backgrnd,folder=_A);mac=myaddon.getSetting(_A1);portal=myaddon.getSetting(_AR);plugintools.add_item(action=_V,title='[COLOR blue]Dream1Click 1[/COLOR]',thumbnail=premium,fanart=backgrnd,page='',url=_F4,folder=_A);plugintools.add_item(action=_V,title='[COLOR springgreen]Dream1Click 2[/COLOR]',thumbnail=premium,fanart=backgrnd,page='',url=_F5,folder=_A);plugintools.add_item(action=_V,title='[COLOR yellow]Dream1Click 3[/COLOR]',thumbnail=premium,fanart=backgrnd,page='',url=_F6,folder=_A);plugintools.add_item(action=_V,title='[COLOR blue]Movies - English & Español[/COLOR]',thumbnail=premium,fanart=backgrnd,page='',url=_F7,folder=_A);plugintools.add_item(action=_V,title='[COLOR springgreen]24 / 7[/COLOR]',thumbnail=premium,fanart=backgrnd,page='',url='https://gitlab.com/beequeen171819/bq/-/raw/main/24-7COORD.m3u8',folder=_A);plugintools.add_item(action=_V,title='[COLOR yellow]TvApp[/COLOR]',thumbnail=premium,fanart=backgrnd,page='',url=_F8,folder=_A);plugintools.add_item(action=_V,title=_Hj,thumbnail=premium,fanart=backgrnd,page='',url=_F9,folder=_A);plugintools.add_item(action=_V,title='[COLOR springgreen]US 2[/COLOR]',thumbnail=premium,fanart=backgrnd,page='',url=_FA,folder=_A);plugintools.add_item(action=_V,title='[COLOR yellow]US 3[/COLOR]',thumbnail=premium,fanart=backgrnd,page='',url=_FB,folder=_A);plugintools.add_item(action=_V,title='[COLOR blue]UK[/COLOR]',thumbnail=premium,fanart=backgrnd,page='',url=_FC,folder=_A);plugintools.add_item(action=_V,title='[COLOR yellow]Latin America[/COLOR]',thumbnail=premium,fanart=backgrnd,page='',url=_FD,folder=_A);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B)
def radio(params):plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_Av,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action=_FY,title='[COLOR cyan]Search Radio[/COLOR]',thumbnail=search_icon,fanart=backgrnd,folder=_A);plugintools.add_item(action=_V,title='[COLOR blue]World Radio Stations[/COLOR]',thumbnail=radiothmb,fanart=backgrnd,page='',url=_FE,folder=_A);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B)
def search_mac(params):
	A='itv';global _search_cancelled;query=search_popup()
	if query is _G:set_search_cancelled(_A);xbmcgui.Dialog().notification(_D,_CY,xbmcgui.NOTIFICATION_INFO,3000);return
	elif query=='':xbmcgui.Dialog().notification(_D,_DI,xbmcgui.NOTIFICATION_INFO,3000);return
	portal=myaddon.getSetting(_AR).replace(_C,'');mac=myaddon.getSetting(_A1).replace(_C,'');s=requests.Session();pb=xbmcgui.DialogProgress();pb.create(_D,'Searching Stb - Mac (Live Channels)...')
	try:
		token=macs_handshake(s,portal,mac)
		if not token:pb.close();xbmcgui.Dialog().notification(_D,_Fu,xbmcgui.NOTIFICATION_ERROR,3000);return
		source=macs_categories(s,token,portal,mac)
		if not source:pb.close();xbmcgui.Dialog().notification(_D,'Failed to fetch live genres',xbmcgui.NOTIFICATION_ERROR,3000);return
		try:json_data=json.loads(source);genres=json_data.get(_A9,[])if isinstance(json_data.get(_A9),list)else json_data.get(_A9,{}).get(_At,[]);live_data=[(g.get(_O,''),g.get(_H,''),A)for g in genres if g.get(_O)and g.get(_H)]
		except json.JSONDecodeError:
			live_data=[(id,title,A)for(id,title)in plugintools.find_multiple_matches(source,_Db)]
			if not live_data:live_data=[(id,name,A)for(id,name)in plugintools.find_multiple_matches(source,_Fs)]
		if not live_data:pb.close();xbmcgui.Dialog().notification(_D,'No genres available for live channels',xbmcgui.NOTIFICATION_ERROR,3000);return
		data=live_data;results=[];headers={_J:_u,_A5:f"mac={mac}; stb_lang=en; timezone=America/New_York",_B5:f"Bearer {token}",_Z:_a,_b:_c,_i:_j,_Cm:_BW,_Cn:_BW};porn=myaddon.getSetting(_X).replace(_C,'')==_N;parental_control=myaddon.getSetting(_CL).replace(_C,'')==_N;parental_password=myaddon.getSetting(_CM).replace(_C,'')or _CN;adult_choice=_G
		def fetch_genre_channels(ids,title,content_type,genre_idx,total_genres):
			nonlocal adult_choice
			if is_search_cancelled()or pb.iscanceled():return[],genre_idx
			is_adult=_AF in title.lower()or _AG in title.lower()or _AH in title.lower()or _AI in title.lower()or _AJ in title.lower()or _AK in title.lower()or _AL in title.lower()or _Aw in title.lower()or _Ax in title.lower()or _Ay in title.lower()or _l in title.lower()or _k in title.lower()or _p in title.lower()or _s in title.lower()or _Az in title.lower()or _t in title.lower()or _r in title.lower()or _A_ in title.lower()or _B0 in title.lower()or _B1 in title.lower()or _B2 in title.lower()or _q in title.lower()or _X in title.lower()or _B3 in title.lower()or _B4 in title.lower()
			if is_adult and not porn:return[],genre_idx
			if is_adult and parental_control and adult_choice is _G:
				dialog=xbmcgui.Dialog();ret=dialog.select(_CO,[_CP,'[COLOR aqua]Skip Adult Content[/COLOR]']);adult_choice=[_AM,'no'][ret]
				if adult_choice==_AM:
					d=dialog.input(_Dc,type=xbmcgui.INPUT_ALPHANUM).replace(_w,'+').replace(_C,'')
					if d==parental_password:adult_choice=_Bs
					else:xbmcgui.Dialog().notification(_D,_Ck,xbmcgui.NOTIFICATION_ERROR,5000);adult_choice=_z
				else:adult_choice=_z
			if is_adult and parental_control and adult_choice==_z:return[],genre_idx
			pb.update(int(genre_idx/total_genres*100),f"Searching Live Genre {genre_idx}/{total_genres}: {title}...");cache_key=f"{portal}portal.php?type=itv&action=get_ordered_list&genre={ids}&query={query}";cached_data=read_cache(cache_key,mac);genre_results=[]
			if cached_data and isinstance(cached_data,list):
				for(name,ch_id)in cached_data:
					if query.lower()in name.lower():genre_results.append({_d:_C1,_H:name,_M:params.get(_M,stbmac),_K:backgrnd1,_I:ch_id,_P:mac,_W:token,_S:portal,_Ar:_B,_As:_A})
				return genre_results,genre_idx
			genre_data=[];pn=1;max_pages=40
			while pn<=max_pages:
				page_url=f"{portal}portal.php?type=itv&action=get_ordered_list&genre={ids}&force_ch_link_check=&fav=0&sortby=number&hd=0&p={pn}&JsHttpRequest=1-xml"
				try:
					response=s.get(page_url,headers=headers,timeout=5);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F).replace(_C,'')
					try:json_data=json.loads(source);channels=json_data.get(_A9,{}).get(_At,[]);page_data=[(ch.get(_L,''),ch.get(_O,''))for ch in channels if _L in ch and _O in ch]
					except json.JSONDecodeError:
						page_data=re.findall(_Fv,source)
						if not page_data:page_data=re.findall(_Fw,source)
					if not page_data:break
					genre_data+=page_data;pn+=1
				except requests.RequestException:break
			if genre_data:
				write_cache(cache_key,genre_data,mac)
				for(name,ch_id)in genre_data:
					if query.lower()in name.lower():genre_results.append({_d:_C1,_H:name,_M:params.get(_M,stbmac),_K:backgrnd1,_I:ch_id,_P:mac,_W:token,_S:portal,_Ar:_B,_As:_A})
			return genre_results,genre_idx
		with ThreadPoolExecutor(max_workers=5)as executor:
			future_to_genre={executor.submit(fetch_genre_channels,ids,title,content_type,idx,len(data)):(ids,title,content_type)for(idx,(ids,title,content_type))in enumerate(data,1)};last_genre_idx=0
			for future in as_completed(future_to_genre):
				if is_search_cancelled()or pb.iscanceled():set_search_cancelled(_A);break
				try:genre_results,genre_idx=future.result();results.extend(genre_results);last_genre_idx=max(last_genre_idx,genre_idx)
				except Exception as e:pass
		if results:
			handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,'Stb - Mac Search Results (Live Channels)');xbmcplugin.setContent(handle,_C7)
			for result in results:plugintools.add_item(action=result[_d],title=f"[COLOR white]{color(result[_H])}[/COLOR]",thumbnail=result[_M],fanart=result[_K],url=result.get(_I,''),page=result.get(_P,''),plot=result.get(_W,''),extra=result.get(_S,''),folder=result[_Ar],isPlayable=result.get(_As,_B))
			xbmcgui.Dialog().notification(_D,f"Found {len(results)} results",xbmcgui.NOTIFICATION_INFO,3000);xbmcplugin.endOfDirectory(handle,updateListing=_B)
		else:xbmcgui.Dialog().notification(_D,'No results found for the search query',xbmcgui.NOTIFICATION_INFO,3000)
	except Exception as e:xbmcgui.Dialog().notification(_D,'Search failed due to an error',xbmcgui.NOTIFICATION_ERROR,3000)
	finally:pb.close()
def search_current_xtream_server(params):
	H=',10025)';G='&episode=';F='&extra=';E='&page=';D='live';C='ClearProperty(_SEARCH_CACHE_KEY_results,10025)';B='ClearProperty(_SEARCH_CACHE_KEY_key,10025)';A='player_api.php?username=';page=urllib.parse.unquote(params.get(_P,''));extra=urllib.parse.unquote(params.get(_S,''));episode=urllib.parse.unquote(params.get(_Y,''))
	if not page or not extra or not episode:xbmcgui.Dialog().ok(_D,'No server selected.');return
	base=page.rstrip(_R)+_R;username=extra;password=episode;original_query=search_popup()
	if not original_query or original_query.strip()=='':return
	query=original_query.strip();terms=[t.strip().lower()for t in query.split(_n)if t.strip()]
	if not terms:terms=['']
	xbmc.executebuiltin('ClearProperty(last_search_query,10025)');xbmc.executebuiltin(B);xbmc.executebuiltin(C);import hashlib;cache_string=base+username+query;cache_key=hashlib.md5(cache_string.encode(_E)).hexdigest();cached_key=xbmc.getInfoLabel('Window(10025).Property(_SEARCH_CACHE_KEY_key)');cached_results=xbmc.getInfoLabel('Window(10025).Property(_SEARCH_CACHE_KEY_results)')
	if cached_key==cache_key and cached_results:results=eval(cached_results)
	else:
		xbmc.executebuiltin(B);xbmc.executebuiltin(C);hide_adult=myaddon.getSetting(_BZ)==_N;pb=xbmcgui.DialogProgress();pb.create(_D,'Searching… [B]'+query.capitalize()+'[/B]');results=[];completed=0;total_tasks=3
		def update_progress():nonlocal completed;completed+=1;pb.update(int(completed/total_tasks*100))
		def search_live():
			if pb.iscanceled():return
			try:
				r=session.get(base+A+username+_B6+password+'&action=get_live_streams',timeout=12)
				if r.ok:
					for s in r.json():
						name_lower=s.get(_L,'').lower()
						if not any(t in name_lower for t in terms):continue
						if hide_adult and is_adult(s):continue
						sid=s.get(_Bj);ext=s.get(_y,'m3u8')
						if sid:url=base+'live/'+username+_R+password+_R+str(sid)+'.'+ext;icon=s.get(_Bv)or xtream;clean=re.sub(_I0,'',s.get(_L,'')).strip();results.append((D,clean+' [COLOR lime][Live][/COLOR]',url,icon))
			except:pass
			update_progress()
		def search_vod():
			if pb.iscanceled():return
			try:
				r=session.get(base+A+username+_B6+password+'&action=get_vod_streams',timeout=12)
				if r.ok:
					for m in r.json():
						name_lower=m.get(_L,'').lower()
						if not any(t in name_lower for t in terms):continue
						if hide_adult and is_adult(m):continue
						sid=m.get(_Bj);ext=m.get(_y,_AA)
						if sid:url=base+'movie/'+username+_R+password+_R+str(sid)+'.'+ext;thumb=m.get(_Bv)or xtream;results.append(('vod',m.get(_L,''),url,thumb))
			except:pass
			update_progress()
		def search_series():
			if pb.iscanceled():return
			try:
				r=session.get(base+A+username+_B6+password+'&action=get_series',timeout=14)
				if r.ok:
					for s in r.json():
						name_lower=s.get(_L,'').lower()
						if not any(t in name_lower for t in terms):continue
						if hide_adult and is_adult(s):continue
						sid=s.get(_B8)
						if sid:info_url=base+A+username+_B6+password+'&action=get_series_info&series_id='+str(sid);thumb=s.get(_Bc)or xtream;play_url='plugin://plugin.video.dreammachine/?action=xtream_series_seasons&url='+quote(info_url)+E+quote(base)+F+quote(username)+G+quote(password);results.append((_D8,s.get(_L,'')+' [COLOR violet][Series][/COLOR]',play_url,thumb))
			except:pass
			update_progress()
		global session
		if _DJ not in globals():session=requests.Session();session.headers.update({_J:_B_})
		with ThreadPoolExecutor(max_workers=5)as ex:ex.submit(search_live);ex.submit(search_vod);ex.submit(search_series)
		while completed<total_tasks and not pb.iscanceled():xbmc.sleep(100)
		pb.close()
		if not results:xbmcgui.Dialog().ok(_D,'No results found.');return
		results.sort(key=lambda x:({_D8:0,'vod':1,D:2}.get(x[0],9),x[1].lower()));xbmc.executebuiltin('SetProperty(_SEARCH_CACHE_KEY_key,'+cache_key+H);xbmc.executebuiltin('SetProperty(_SEARCH_CACHE_KEY_results,'+repr(results)+H)
	handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,'Search → '+query.capitalize());xbmcplugin.setContent(handle,_FF)
	for(typ,title,url,thumb)in results:
		li=xbmcgui.ListItem(title);li.setArt({_U:thumb,_K:backgrnd1})
		if typ==_D8:li.setInfo(_AB,{_Bb:'tvshow'});xbmcplugin.addDirectoryItem(handle,url,li,isFolder=_A)
		else:li.setProperty(_AE,_N);li.setInfo(_AB,{_Bb:_AB,_H:title});play_url='plugin://plugin.video.dreammachine/?action=xtream_vod_play&url='+quote(url)+E+quote(base)+F+quote(username)+G+quote(password)if typ=='vod'else'plugin://plugin.video.dreammachine/?action=linkdirectoxc&url='+quote(url)+_FG+quote(title);xbmcplugin.addDirectoryItem(handle,play_url,li,isFolder=_B)
	xbmcplugin.endOfDirectory(handle,cacheToDisc=_A);save_query=_G;prop_query=xbmc.getInfoLabel(_C9)
	if prop_query:save_query=prop_query.strip();xbmc.executebuiltin(_Br)
	elif original_query:
		candidate=original_query.strip()
		if candidate:
			current_favs=get_favorite_searches()
			if candidate.lower()not in[f.lower()for f in current_favs]:save_query=candidate
	if save_query:prompt_add_favorite(save_query)
def search_xtream_live(params):
	original_query=search_popup()
	if not original_query or original_query.strip()=='':xbmcgui.Dialog().notification(_D,_FH,xbmcgui.NOTIFICATION_INFO,3000);xbmc.executebuiltin(_AC);return
	query=original_query.strip();terms=[t.strip().lower()for t in query.split(_n)if t.strip()]
	if not terms:terms=['']
	server_options=[_CA,_CC,_CE,_CG];user_list=myaddon.getSetting(_CI)or''
	if user_list.strip():server_options.append(_D7)
	choice=xbmcgui.Dialog().select('Select List to Search (Live TV)',server_options)
	if choice==-1:xbmc.executebuiltin(_AC);return
	urls=[_CB,_CD,_CF,_CH];search_url=urls[choice]if choice<4 else user_list.strip();list_label=server_options[choice].split('[')[0].strip();hide_adult=myaddon.getSetting(_BZ)==_N;priority_raw=myaddon.getSetting('country_priority_list')or'US,UK,AU,CA,DE,FR';PRIORITY_COUNTRIES=[c.strip().upper()for c in priority_raw.split(_m)if c.strip()];pb=xbmcgui.DialogProgress();pb.create(_D,f"Searching Live TV in {list_label}...");global session
	if _DJ not in globals():session=requests.Session();session.headers.update({_J:_B_});adapter=requests.adapters.HTTPAdapter(pool_connections=10,pool_maxsize=10);session.mount(_e,adapter);session.mount(_f,adapter)
	if not hasattr(search_xtream_live,_FI):search_xtream_live.memory_cache={};search_xtream_live.cache_lock=threading.Lock()
	memory=search_xtream_live.memory_cache;cache_lock=search_xtream_live.cache_lock;blacklist_key='BLACKLIST_LIVE_SEARCH';blacklisted=read_search_cache(blacklist_key)or set();results=[];FLAG={'US':'US','UK':'UK','CA':'CA','DE':'DE','FR':'FR','ES':'ES','IT':'IT','NL':'NL','AU':'AU','BR':'BR','PT':'PT','PL':'PL','TR':'TR','IN':'IN'}
	def detect_country(name):
		name_up=name.upper()
		for code in PRIORITY_COUNTRIES+list(FLAG.keys()):
			if code in name_up:return code
	def robust_get(url,connect=3,read=10):
		try:
			if pb.iscanceled():return
			r=session.get(url,timeout=(connect,read))
			if r.status_code in(403,404,451,500,502,503,504):return
			r.raise_for_status();return r
		except:return
	pb.update(0,'Loading server list...');r=robust_get(search_url)
	if not r:pb.close();xbmcgui.Dialog().notification(_D,'Failed to load list',xbmcgui.NOTIFICATION_ERROR);xbmc.executebuiltin(_AC);return
	servers=[]
	for line in r.text.splitlines():
		line=line.strip()
		if not line or line.startswith('#'):continue
		m=re.search('username=([^&]+)&password=([^&]+)',line)
		if not m:continue
		base_match=re.search('(https?://[^/|&]+)',line)
		if base_match:
			base=base_match.group(1).rstrip(_R)+_R
			if _Bt not in base:servers.append((base,m.group(1),m.group(2)))
	check_order=myaddon.getSetting(_D6)
	if check_order=='1':import random;random.shuffle(servers)
	if not servers:pb.close();xbmcgui.Dialog().notification(_D,'No valid servers',xbmcgui.NOTIFICATION_INFO);xbmc.executebuiltin(_AC);return
	total=len(servers);checked=0;counter_lock=threading.Lock()
	def fetch_server(args):
		nonlocal checked;base,u,p=args;key=f"{base}{u}"
		if key in blacklisted:return
		catalog_key=f"CAT_LIVE_{base}_{u}"
		with cache_lock:
			if memory.get(catalog_key):return
		api=f"{base}player_api.php?username={u}&password={p}&action=get_live_streams";r2=robust_get(api,connect=2,read=8)
		if not r2:
			if not pb.iscanceled():blacklisted.add(key)
			return
		try:data=r2.json()
		except:return
		with cache_lock:memory[catalog_key]=_A
		server_host=base.replace(_e,'').replace(_f,'').split(_R)[0].split(':')[0]
		for s in data:
			if not isinstance(s,dict):continue
			name=s.get(_L)or'';name_lower=name.lower()
			if not any(t in name_lower for t in terms):continue
			if hide_adult and is_adult(s):continue
			stream_id=s.get(_Bj)
			if not stream_id:continue
			ext=s.get(_y)or'm3u8';icon=s.get(_Bv)or xtream;url=f"{base}live/{u}/{p}/{stream_id}.{ext}";epg_match=re.search('\\[(.*?)\\]',name);clean_name=re.sub(_I0,'',name).strip();epg=f"[COLOR lime][{epg_match.group(1)}][/COLOR]"if epg_match else'';title_parts=[clean_name]
			if epg:title_parts.append(epg)
			country=detect_country(name)
			if country and country in FLAG:title_parts.append(FLAG[country])
			clean_title=_w.join(title_parts);country_code=country or'';tier=0;idx=PRIORITY_COUNTRIES.index(country_code)if country_code in PRIORITY_COUNTRIES else-1
			if idx==-1:tier=1 if not country_code else 2;idx=0
			sort_key=tier,idx,clean_name.lower();results.append((sort_key,clean_title,url,icon,server_host))
		with counter_lock:
			checked+=1
			if not pb.iscanceled():pb.update(int(checked/total*100),f"Checked {checked}/{total}")
	with ThreadPoolExecutor(max_workers=5)as executor:
		futures=[executor.submit(fetch_server,server)for server in servers]
		for future in futures:
			if pb.iscanceled():break
			try:future.result(timeout=1)
			except:pass
	pb.close()
	if blacklisted:write_search_cache(blacklist_key,list(blacklisted),ttl=7200)
	if not results:xbmcgui.Dialog().notification(_D,_Fx,xbmcgui.NOTIFICATION_INFO);xbmc.executebuiltin(_AC);return
	results.sort(key=lambda x:x[0]);handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,f"Live Search: {query.capitalize()}");xbmcplugin.setContent(handle,_FF);plugintools.add_item(action=_Bo,title=_FJ,thumbnail=_FK,fanart=backgrnd1,folder=_A,isPlayable=_B);grouped={}
	for(_,clean_title,url,thumb,server_host)in results:grouped.setdefault(clean_title,[]).append((url,thumb or xtream,server_host))
	for(clean_title,sources)in grouped.items():
		urls=[u for(u,_,_)in sources];thumbs=[t for(_,t,_)in sources];hosts=[h for(_,_,h)in sources];thumb=next((t for t in thumbs if t),xtream);count=len(urls)
		if count==1:
			host=hosts[0]
			if show_server_names:display=f"{clean_title} [COLOR salmon][{host}][/COLOR]"
			else:display=clean_title
		else:display=f"{clean_title} [COLOR lime]({count} source{'s'if count>1 else''})[/COLOR]"
		folder_url=f"plugin://plugin.video.dreammachine/?action=show_live_sources&title={quote(clean_title)}&sources={quote('|||'.join(urls))}&thumb={quote(thumb)}";li=xbmcgui.ListItem(display);li.setArt({_U:thumb,_K:backgrnd1});xbmcplugin.addDirectoryItem(handle=handle,url=folder_url,listitem=li,isFolder=_A)
	if not grouped:li=xbmcgui.ListItem('[I][COLOR lightgrey]No matching channels found[/COLOR][/I]');li.setArt({_U:_FL,_K:backgrnd});xbmcplugin.addDirectoryItem(handle=handle,url='',listitem=li,isFolder=_B)
	xbmcplugin.endOfDirectory(handle,succeeded=_A,updateListing=_B,cacheToDisc=_A);xbmcgui.Dialog().notification(_D,f"Found {len(grouped)} channels",xbmcgui.NOTIFICATION_INFO,4000);save_query=_G;prop_query=xbmc.getInfoLabel(_C9)
	if prop_query:save_query=prop_query.strip();xbmc.executebuiltin(_Br)
	elif original_query:
		candidate=original_query.strip()
		if candidate:
			current_favs=get_favorite_searches()
			if candidate.lower()not in[f.lower()for f in current_favs]:save_query=candidate
	if save_query:prompt_add_favorite(save_query)
def show_live_sources(params):
	title=unquote(params[_H]);sources=unquote(params[_BA]).split('|||');sources=[s.strip()for s in sources if s.strip()];thumb=unquote(params.get(_U,xtream));handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,title);xbmcplugin.setContent(handle,_FF)
	for url in sources:
		if not url.strip():continue
		host_match=re.search(_I1,url);host=host_match.group(1).replace(_e,'').replace(_f,'').split(_R)[0].split(':')[0]if host_match else _A7
		if show_server_names:display_title=f"{title} [COLOR salmon][{host}][/COLOR]"
		else:display_title=title
		li=xbmcgui.ListItem(display_title);li.setArt({_U:thumb,_K:backgrnd1});li.setProperty(_AE,_N);play_url=f"plugin://plugin.video.dreammachine/?action=linkdirectoxc&url={quote(url)}&title={quote(title)}";xbmcplugin.addDirectoryItem(handle,play_url,li,isFolder=_B)
	xbmcplugin.endOfDirectory(handle,succeeded=_A,cacheToDisc=_B)
def search_xtream_vod(params):
	original_query=search_popup()
	if not original_query or original_query.strip()=='':xbmcgui.Dialog().notification(_D,_FH,xbmcgui.NOTIFICATION_INFO,3000);xbmc.executebuiltin(_AC);return
	query=original_query.strip();terms=[t.strip().lower()for t in query.split(_n)if t.strip()]
	if not terms:terms=['']
	server_options=[_CA,_CC,_CE,_CG];user_list=myaddon.getSetting(_CI)or''
	if user_list.strip():server_options.append(_D7)
	choice=xbmcgui.Dialog().select('Select List to Search (Movies)',server_options)
	if choice==-1:xbmc.executebuiltin(_AC);return
	urls=[_CB,_CD,_CF,_CH];search_url='';is_your_server=_B;list_label=''
	if choice>=4:
		if user_list.strip():search_url=user_list;list_label=_I2
		else:search_url=f"{portalxc}/get.php?username={usernamexc}&password={passxc}";list_label=_I3;is_your_server=_A
	else:search_url=urls[choice];list_label=f"List {choice+1}"
	hide_adult=myaddon.getSetting(_BZ)==_N;pb=xbmcgui.DialogProgress();pb.create(_D,f"Searching Movies in {list_label}...");unique_movies={}
	if not hasattr(search_xtream_vod,_FI):search_xtream_vod.memory_cache={};search_xtream_vod.cache_lock=threading.Lock()
	memory=search_xtream_vod.memory_cache;cache_lock=search_xtream_vod.cache_lock;blacklist_key='BLACKLIST_VOD_SEARCH';blacklisted=read_search_cache(blacklist_key)or set();global session
	if _DJ not in globals():session=requests.Session();session.headers.update({_J:_B_});adapter=requests.adapters.HTTPAdapter(pool_connections=6,pool_maxsize=6);session.mount(_e,adapter);session.mount(_f,adapter)
	def robust_get(url,retries=1,connect=2,read=6):
		for _ in range(retries+1):
			if pb.iscanceled():return
			try:
				r=session.get(url,timeout=(connect,read))
				if r.status_code in(403,404,451,500,502,503,504):return
				r.raise_for_status();return r
			except requests.ReadTimeout:xbmc.sleep(300)
			except:return
	try:
		if is_your_server:
			pb.update(0,_I4);api_url=f"{portalxc}/player_api.php?username={usernamexc}&password={passxc}&action=get_vod_streams";r=robust_get(api_url,connect=2,read=10);catalog=r.json()if r else[];server_host=portalxc.replace(_e,'').replace(_f,'').split(_R)[0].split(':')[0]
			for m in catalog:
				if not isinstance(m,dict):continue
				name=m.get(_L,'').strip()
				if not name:continue
				name_lower=name.lower()
				if not any(term in name_lower for term in terms):continue
				if name not in unique_movies:unique_movies[name]={_U:str(m.get(_Bv)or''),_BA:[]}
				stream_id=m.get(_Bj);ext=m.get(_y,_AA)
				if stream_id:url=f"{portalxc}/movie/{usernamexc}/{passxc}/{stream_id}.{ext}";unique_movies[name][_BA].append((url,server_host))
		else:
			r=robust_get(search_url,connect=2,read=10)
			if not r:pb.close();xbmc.executebuiltin(_AC);return
			content=r.content.decode(_E,_F);servers=[]
			for line in[l.strip()for l in content.splitlines()if l.strip()and not l.startswith('#')]:
				try:
					if _m in line and len(line.split(_m,2))>=3:
						b=line.split(_m,2)[0].strip().rstrip(_R)+_R;u,p=line.split(_m,2)[1].strip(),line.split(_m,2)[2].strip()
						if _Bt not in b:servers.append((b,u,p))
					else:
						m=re.search(_I5,line)
						if m:
							s=m.group(1);b_match=re.search(_I6,s)
							if b_match:
								b=b_match.group(1)
								if _Bt not in b:
									u=plugintools.find_single_match(s,_I7);p=plugintools.find_single_match(s,_I8)
									if b and u and p:servers.append((b,u,p))
				except:continue
			total=len(servers);pb.update(0,f"Found {total} servers...");checked=0;counter_lock=threading.Lock()
			def fetch_server(base,u,p):
				nonlocal checked;key=f"{base}{u}"
				if key in blacklisted:return
				catalog_key=f"CATALOG_VOD_{base}_{u}"
				with cache_lock:0
				api_url=f"{base}player_api.php?username={u}&password={p}&action=get_vod_streams";r=robust_get(api_url,connect=2,read=6)
				if r is _G:
					if not pb.iscanceled():blacklisted.add(key)
					with counter_lock:
						checked+=1
						if not pb.iscanceled():pb.update(int(checked/total*100)if total>0 else 100,f"Checked {checked}/{total}")
					return
				if r.status_code in(403,404,451,500,502,503,504):blacklisted.add(key)
				catalog=r.json()
				with cache_lock:memory[catalog_key]=_A
				server_host=base.replace(_e,'').replace(_f,'').split(_R)[0].split(':')[0]
				for m in catalog:
					if not isinstance(m,dict):continue
					name=m.get(_L,'').strip()
					if not name:continue
					name_lower=name.lower()
					if not any(term in name_lower for term in terms):continue
					if name not in unique_movies:unique_movies[name]={_U:str(m.get(_Bv)or''),_BA:[]}
					stream_id=m.get(_Bj);ext=m.get(_y,_AA)
					if stream_id:url=f"{base}movie/{u}/{p}/{stream_id}.{ext}";unique_movies[name][_BA].append((url,server_host))
				with counter_lock:
					checked+=1
					if not pb.iscanceled():pb.update(int(checked/total*100)if total>0 else 100,f"Checked {checked}/{total}")
			max_threads=min(6,total or 1)
			with ThreadPoolExecutor(max_workers=max_threads)as executor:
				futures=[executor.submit(fetch_server,b,u,p)for(b,u,p)in servers];done=set()
				while len(done)<len(futures):
					if pb.iscanceled():break
					for future in futures:
						if future in done:continue
						if future.done():
							try:future.result()
							except:pass
							done.add(future)
					xbmc.sleep(50)
		handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,f"Movie Search: {query.capitalize()}");xbmcplugin.setContent(handle,_DF);plugintools.add_item(action=_Bo,title=_FJ,thumbnail=_FK,fanart=backgrnd1,folder=_A,isPlayable=_B);added=_B
		for(full,data)in unique_movies.items():
			title=color(full);thumb=data[_U]or xtream;sources=data[_BA];source_count=len(sources)
			if hide_adult and is_adult({_L:full}):continue
			if source_count==1:
				host=sources[0][1]
				if show_server_names:display_title=f"{title} [COLOR salmon][{host}][/COLOR]"
				else:display_title=title
			else:display_title=f"{title} [COLOR lime]({source_count} source{'s'if source_count>1 else''})[/COLOR]"
			folder_url=f"plugin://plugin.video.dreammachine/?action=show_movie_sources&title={quote(full)}&sources={quote(_n.join(s[0]for s in sources))}";plugintools.add_item(action='',title=display_title,thumbnail=thumb,fanart=backgrnd1,url=folder_url,folder=_A);added=_A
		if not added:li=xbmcgui.ListItem('[I][COLOR lightgrey]No matching movies found[/COLOR][/I]');li.setArt({_U:_FL,_K:backgrnd});xbmcplugin.addDirectoryItem(handle=handle,url='',listitem=li,isFolder=_B)
		xbmcplugin.endOfDirectory(handle)
		if pb.iscanceled():xbmcgui.Dialog().notification(_D,_I9,xbmcgui.NOTIFICATION_INFO,3000)
		else:xbmcgui.Dialog().notification(_D,f"Found {len(unique_movies)} movies",xbmcgui.NOTIFICATION_INFO,3000)
		if blacklisted:write_search_cache(blacklist_key,list(blacklisted),ttl=7200)
	except Exception:pass
	finally:pb.close()
	save_query=_G;prop_query=xbmc.getInfoLabel(_C9)
	if prop_query:save_query=prop_query.strip();xbmc.executebuiltin(_Br)
	elif original_query:
		candidate=original_query.strip()
		if candidate:
			current_favs=get_favorite_searches()
			if candidate.lower()not in[f.lower()for f in current_favs]:save_query=candidate
	if save_query:prompt_add_favorite(save_query)
def show_movie_sources(params):
	title=unquote(params.get(_H,''));sources=unquote(params.get(_BA,'')).split(_n);handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,title);xbmcplugin.setContent(handle,_DF)
	for url in sources:
		if not url.strip():continue
		host_match=re.search(_I1,url);host=host_match.group(1).replace(_e,'').replace(_f,'').split(_R)[0].split(':')[0]if host_match else _A7
		if show_server_names:display_title=f"{color(title)} [COLOR salmon][{host}][/COLOR]"
		else:display_title=color(title)
		plugintools.add_item(action=_BB,title=display_title,thumbnail=xtream,fanart=backgrnd1,url=url,isPlayable=_A,folder=_B)
	xbmcplugin.endOfDirectory(handle,succeeded=_A)
def search_xtream_series(params):
	original_query=search_popup()
	if not original_query or original_query.strip()=='':xbmcgui.Dialog().notification(_D,_FH,xbmcgui.NOTIFICATION_INFO,3000);xbmc.executebuiltin(_AC);return
	query=original_query.strip();terms=[t.strip().lower()for t in query.split(_n)if t.strip()]
	if not terms:terms=['']
	server_options=[_CA,_CC,_CE,_CG];user_list=myaddon.getSetting(_CI)or''
	if user_list.strip():server_options.append(_D7)
	choice=xbmcgui.Dialog().select('Select List to Search (Series)',server_options)
	if choice==-1:xbmc.executebuiltin(_AC);return
	urls=[_CB,_CD,_CF,_CH];search_url='';is_your_server=_B;list_label=''
	if choice>=4:
		if user_list.strip():search_url=user_list;list_label=_I2
		else:search_url=f"{portalxc}/get.php?username={usernamexc}&password={passxc}";list_label=_I3;is_your_server=_A
	else:search_url=urls[choice];list_label=f"List {choice+1}"
	pb=xbmcgui.DialogProgress();pb.create(_D,f"Searching Series in {list_label}...");unique_series={}
	if not hasattr(search_xtream_series,_FI):search_xtream_series.memory_cache={};search_xtream_series.cache_lock=threading.Lock()
	memory=search_xtream_series.memory_cache;cache_lock=search_xtream_series.cache_lock;blacklist_key='BLACKLIST_SERIES_SEARCH';blacklisted=read_search_cache(blacklist_key)or set();global session
	if _DJ not in globals():session=requests.Session();session.headers.update({_J:_B_});adapter=requests.adapters.HTTPAdapter(pool_connections=6,pool_maxsize=6);session.mount(_e,adapter);session.mount(_f,adapter)
	def robust_get(url,retries=1,connect=2,read=6):
		for _ in range(retries+1):
			if pb.iscanceled():return
			try:
				r=session.get(url,timeout=(connect,read))
				if r.status_code in(403,404,451,500,502,503,504):return
				r.raise_for_status();return r
			except requests.ReadTimeout:xbmc.sleep(300)
			except:return
	try:
		if is_your_server:
			pb.update(0,_I4);api_url=f"{portalxc}/player_api.php?username={usernamexc}&password={passxc}&action=get_series";r=robust_get(api_url,connect=2,read=10);catalog=r.json()if r else[];server_host=portalxc.replace(_e,'').replace(_f,'').split(_R)[0].split(':')[0]
			for s in catalog:
				if not isinstance(s,dict):continue
				name=s.get(_L,'').strip()
				if not name:continue
				name_lower=name.lower()
				if not any(term in name_lower for term in terms):continue
				if name not in unique_series:unique_series[name]={_U:str(s.get(_Bc)or''),_Bd:[]}
				series_id=s.get(_B8)
				if series_id:unique_series[name][_Bd].append(f"{portalxc}|{usernamexc}|{passxc}|{series_id}|{server_host}")
		else:
			r=robust_get(search_url,connect=2,read=10)
			if not r:pb.close();xbmc.executebuiltin(_AC);return
			content=r.content.decode(_E,_F);servers=[]
			for line in[l.strip()for l in content.splitlines()if l.strip()and not l.startswith('#')]:
				try:
					if _m in line and len(line.split(_m,2))>=3:
						b=line.split(_m,2)[0].strip().rstrip(_R)+_R;u,p=line.split(_m,2)[1].strip(),line.split(_m,2)[2].strip()
						if _Bt not in b:servers.append((b,u,p))
					else:
						m=re.search(_I5,line)
						if m:
							s=m.group(1);b_match=re.search(_I6,s)
							if b_match:
								b=b_match.group(1)
								if _Bt not in b:
									u=plugintools.find_single_match(s,_I7);p=plugintools.find_single_match(s,_I8)
									if b and u and p:servers.append((b,u,p))
				except:continue
			total=len(servers);pb.update(0,f"Found {total} servers...");checked=0;counter_lock=threading.Lock()
			def fetch_server(base,u,p):
				nonlocal checked;key=f"{base}{u}"
				if key in blacklisted:return
				catalog_key=f"CATALOG_SER_{base}_{u}"
				with cache_lock:0
				api_url=f"{base}player_api.php?username={u}&password={p}&action=get_series";r=robust_get(api_url,connect=2,read=6)
				if r is _G:
					if not pb.iscanceled():blacklisted.add(key)
					with counter_lock:
						checked+=1
						if not pb.iscanceled():pb.update(int(checked/total*100)if total>0 else 100,f"Checked {checked}/{total}")
					return
				if r.status_code in(403,404,451,500,502,503,504):blacklisted.add(key)
				catalog=r.json()
				with cache_lock:memory[catalog_key]=_A
				server_host=base.replace(_e,'').replace(_f,'').split(_R)[0].split(':')[0]
				for s in catalog:
					if not isinstance(s,dict):continue
					name=s.get(_L,'').strip()
					if not name:continue
					name_lower=name.lower()
					if not any(term in name_lower for term in terms):continue
					if name not in unique_series:unique_series[name]={_U:str(s.get(_Bc)or''),_Bd:[]}
					series_id=s.get(_B8)
					if series_id:unique_series[name][_Bd].append(f"{base}|{u}|{p}|{series_id}|{server_host}")
				with counter_lock:
					checked+=1
					if not pb.iscanceled():pb.update(int(checked/total*100)if total>0 else 100,f"Checked {checked}/{total}")
			max_threads=min(6,total or 1)
			with ThreadPoolExecutor(max_workers=max_threads)as executor:
				futures=[executor.submit(fetch_server,b,u,p)for(b,u,p)in servers];done=set()
				while len(done)<len(futures):
					if pb.iscanceled():break
					for future in futures:
						if future in done:continue
						if future.done():
							try:future.result()
							except:pass
							done.add(future)
					xbmc.sleep(50)
		handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,'Series Search Results');xbmcplugin.setContent(handle,'tvshows');plugintools.add_item(action=_Bo,title=_FJ,thumbnail=_FK,fanart=backgrnd1,folder=_A,isPlayable=_B);added=_B
		for(full,data)in unique_series.items():
			title=color(full);thumb=data[_U];raw_servers=data[_Bd];clean=[];seen=set()
			for s in raw_servers:
				if s.count(_n)==4 and s not in seen:seen.add(s);clean.append(s)
			if not clean:continue
			servers_str='||'.join(clean);url=f"plugin://plugin.video.dreammachine/?action=merged_series_seasons&servers={quote(servers_str)}&title={quote(full)}"
			if len(clean)==1:
				label=clean[0].split(_n,4)[-1]
				if show_server_names:server_part=f" [COLOR salmon][{label}][/COLOR]"
				else:server_part=''
				plugintools.add_item(action='',title=f"{title}{server_part}",thumbnail=thumb,fanart=backgrnd1,url=url,folder=_A)
			else:plugintools.add_item(action='',title=f"{title} [COLOR lime]({len(clean)} sources)[/COLOR]",thumbnail=thumb,fanart=backgrnd1,url=url,folder=_A)
			added=_A
		if not added:li=xbmcgui.ListItem('[I][COLOR lightgrey]No matching series found[/COLOR][/I]');li.setArt({_U:_FL,_K:backgrnd});xbmcplugin.addDirectoryItem(handle=handle,url='',listitem=li,isFolder=_B)
		xbmcplugin.endOfDirectory(handle)
		if pb.iscanceled():xbmcgui.Dialog().notification(_D,_I9,xbmcgui.NOTIFICATION_INFO,3000)
		else:xbmcgui.Dialog().notification(_D,f"Found {len(unique_series)} series",xbmcgui.NOTIFICATION_INFO,3000)
		if blacklisted:write_search_cache(blacklist_key,list(blacklisted),ttl=7200)
	except Exception:pass
	finally:pb.close()
	save_query=_G;prop_query=xbmc.getInfoLabel(_C9)
	if prop_query:save_query=prop_query.strip();xbmc.executebuiltin(_Br)
	elif original_query:
		candidate=original_query.strip()
		if candidate:
			current_favs=get_favorite_searches()
			if candidate.lower()not in[f.lower()for f in current_favs]:save_query=candidate
	if save_query:prompt_add_favorite(save_query)
def merged_series_seasons(params):
	global _current_series_cache;_current_series_cache={};servers_str=unquote(params.get(_Bd,''));title=unquote(params.get(_H,''));servers=[p for e in servers_str.split('||')if(p:=e.split(_n,4))and len(p)==5]
	if not servers:xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_B);return
	handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,title);xbmcplugin.setContent(handle,_AP);all_seasons=set()
	def fetch_series_info(base,u,p,series_id):
		cache_key=f"INFO_{base}_{u}_{series_id}";cached=read_search_cache(cache_key)
		if cached:return cache_key,cached,base,u,p
		url=f"{base}player_api.php?username={u}&password={p}&action=get_series_info&series_id={series_id}"
		try:
			r=session.get(url,timeout=10)
			if r.status_code!=200:return cache_key,_G,base,u,p
			full_data=r.json()
		except:return cache_key,_G,base,u,p
		info_part=full_data.get(_B9)or{};seasons_raw=full_data.get(_AP)or[];episodes_raw=full_data.get(_A0)or{};clean_seasons=[]
		for s in seasons_raw:
			if isinstance(s,dict):
				sn=s.get(_Be)
				if sn not in(_G,0,_g):clean_seasons.append({_Be:sn})
		clean_episodes={}
		for(season_key,ep_list)in episodes_raw.items():
			if season_key in(_g,0):continue
			if not isinstance(ep_list,list):continue
			clean_list=[]
			for ep in ep_list:
				if not isinstance(ep,dict):continue
				clean_ep={};ep_id=ep.get(_O);ep_num=ep.get(_AD);title_val=ep.get(_H,'')
				if ep_id is not _G:clean_ep[_O]=ep_id
				if ep_num is not _G:clean_ep[_AD]=ep_num
				if title_val:clean_ep[_H]=title_val.strip()
				ext=ep.get(_y)
				if ext and ext!=_AA:clean_ep[_y]=ext
				if _O in clean_ep:clean_list.append(clean_ep)
			if clean_list:clean_episodes[season_key]=clean_list
		stripped={_B9:{_L:info_part.get(_L,''),_Bl:info_part.get(_Bl,'')},_AP:clean_seasons,_A0:clean_episodes};write_search_cache(cache_key,stripped,ttl=86400);return cache_key,stripped,base,u,p
	max_workers=min(50,len(servers)or 1)
	with ThreadPoolExecutor(max_workers=max_workers)as executor:
		futures=[executor.submit(fetch_series_info,base,u,p,series_id)for(base,u,p,series_id,_)in servers]
		for future in as_completed(futures):
			cache_key,cached,_,_,_=future.result()
			if cached:
				_current_series_cache[cache_key]=cached
				for s in cached.get(_AP,[]):
					sn=s.get(_Be)
					if sn not in(_G,0,_g):all_seasons.add(str(sn))
				if not all_seasons:
					for key in cached.get(_A0,{}):
						if key not in(_g,0):all_seasons.add(str(key))
	if not all_seasons:xbmcgui.Dialog().ok(_D,'No seasons found for this series.');xbmcplugin.endOfDirectory(handle,succeeded=_B);return
	for season_str in sorted(all_seasons,key=lambda x:int(x)):season=int(season_str);folder_url='plugin://plugin.video.dreammachine/?action=merged_season_episodes&servers='+quote(servers_str)+'&season='+str(season)+_FG+quote(title+' – Season '+str(season));plugintools.add_item(action='',title=f"Season {season}",thumbnail=xtream,fanart=backgrnd1,url=folder_url,folder=_A)
	xbmcplugin.endOfDirectory(handle)
def merged_season_episodes(params):
	servers_str=unquote(params.get(_Bd,''));season=params.get(_By,'');title=unquote(params.get(_H,''));servers=[p for e in servers_str.split('||')if(p:=e.split(_n,4))and len(p)==5]
	if not servers:xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_B);return
	handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,title);xbmcplugin.setContent(handle,_A0);all_eps={}
	def fetch_series_info(base,u,p,series_id,name):
		cache_key=f"INFO_{base}_{u}_{series_id}";cached=_current_series_cache.get(cache_key)or read_search_cache(cache_key)
		if cached:return cache_key,cached,base,u,p,name
		url=f"{base}player_api.php?username={u}&password={p}&action=get_series_info&series_id={series_id}"
		try:
			r=session.get(url,timeout=10)
			if r.status_code!=200:return cache_key,_G,base,u,p,name
			full_data=r.json()
		except:return cache_key,_G,base,u,p,name
		info_part=full_data.get(_B9)or{};seasons_raw=full_data.get(_AP)or[];episodes_raw=full_data.get(_A0)or{};clean_seasons=[]
		for s in seasons_raw:
			if isinstance(s,dict):
				sn=s.get(_Be)
				if sn not in(_G,0,_g):clean_seasons.append({_Be:sn})
		clean_episodes={}
		for(season_key,ep_list)in episodes_raw.items():
			if season_key in(_g,0):continue
			if not isinstance(ep_list,list):continue
			clean_list=[]
			for ep in ep_list:
				if not isinstance(ep,dict):continue
				clean_ep={};ep_id=ep.get(_O);ep_num=ep.get(_AD);title_val=ep.get(_H,'')
				if ep_id is not _G:clean_ep[_O]=ep_id
				if ep_num is not _G:clean_ep[_AD]=ep_num
				if title_val:clean_ep[_H]=title_val.strip()
				ext=ep.get(_y)
				if ext and ext!=_AA:clean_ep[_y]=ext
				if _O in clean_ep:clean_list.append(clean_ep)
			if clean_list:clean_episodes[season_key]=clean_list
		stripped={_B9:{_L:info_part.get(_L,''),_Bl:info_part.get(_Bl,'')},_AP:clean_seasons,_A0:clean_episodes};write_search_cache(cache_key,stripped,ttl=86400);return cache_key,stripped,base,u,p,name
	check_order=myaddon.getSetting(_D6)
	if check_order=='1':import random;random.shuffle(servers)
	max_workers=min(50,len(servers)or 1)
	with ThreadPoolExecutor(max_workers=max_workers)as executor:
		futures=[executor.submit(fetch_series_info,base,u,p,series_id,name)for(base,u,p,series_id,name)in servers]
		for future in as_completed(futures):
			cache_key,cached,current_base,current_u,current_p,current_name=future.result()
			if cached:
				_current_series_cache[cache_key]=cached;eps=cached.get(_A0,{}).get(season,[])
				for ep in eps:
					ep_num=ep.get(_AD)
					if ep_num is _G:continue
					ep_num_str=str(ep_num);ep_title=ep.get(_H,f"Episode {ep_num}").strip()
					if ep_num_str not in all_eps:all_eps[ep_num_str]={_H:ep_title,_BA:[]}
					ext=ep.get(_y,_AA);ep_id=ep.get(_O)
					if ep_id:stream=f"{current_base}series/{current_u}/{current_p}/{ep_id}.{ext}";all_eps[ep_num_str][_BA].append(f"{stream}|{current_name}")
	if not all_eps:xbmcgui.Dialog().ok(_D,'No episodes found for this season.');xbmcplugin.endOfDirectory(handle,succeeded=_B);return
	for ep_num_str in sorted(all_eps.keys(),key=lambda x:int(x)):data=all_eps[ep_num_str];ep_title=data[_H];folder_url='plugin://plugin.video.dreammachine/?action=merged_episode_sources&servers='+quote(servers_str)+'&season='+season+'&ep_num='+ep_num_str+_FG+quote(title+' – '+ep_title);plugintools.add_item(action='',title=ep_title,thumbnail=xtream,fanart=backgrnd1,url=folder_url,folder=_A)
	xbmcplugin.endOfDirectory(handle)
def merged_episode_sources(params):
	servers_str=unquote(params.get(_Bd,''));season=params.get(_By,'');ep_num_str=params.get('ep_num','');title=unquote(params.get(_H,''))
	try:ep_num=int(ep_num_str)
	except:xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_B);return
	servers=[p for e in servers_str.split('||')if(p:=e.split(_n,4))and len(p)==5]
	if not servers:xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_B);return
	handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,title);xbmcplugin.setContent(handle,_A0);sources=[];real_ep_title=f"Episode {ep_num}"
	def fetch_series_info(base,u,p,series_id,name):
		cache_key=f"INFO_{base}_{u}_{series_id}";cached=_current_series_cache.get(cache_key)or read_search_cache(cache_key)
		if cached:return cache_key,cached,base,u,p,name
		url=f"{base}player_api.php?username={u}&password={p}&action=get_series_info&series_id={series_id}"
		try:
			r=session.get(url,timeout=10)
			if r.status_code!=200:return cache_key,_G,base,u,p,name
			full_data=r.json()
		except:return cache_key,_G,base,u,p,name
		info_part=full_data.get(_B9)or{};seasons_raw=full_data.get(_AP)or[];episodes_raw=full_data.get(_A0)or{};clean_seasons=[]
		for s in seasons_raw:
			if isinstance(s,dict):
				sn=s.get(_Be)
				if sn not in(_G,0,_g):clean_seasons.append({_Be:sn})
		clean_episodes={}
		for(season_key,ep_list)in episodes_raw.items():
			if season_key in(_g,0):continue
			if not isinstance(ep_list,list):continue
			clean_list=[]
			for ep in ep_list:
				if not isinstance(ep,dict):continue
				clean_ep={};ep_id=ep.get(_O);ep_num=ep.get(_AD);title_val=ep.get(_H,'')
				if ep_id is not _G:clean_ep[_O]=ep_id
				if ep_num is not _G:clean_ep[_AD]=ep_num
				if title_val:clean_ep[_H]=title_val.strip()
				ext=ep.get(_y)
				if ext and ext!=_AA:clean_ep[_y]=ext
				if _O in clean_ep:clean_list.append(clean_ep)
			if clean_list:clean_episodes[season_key]=clean_list
		stripped={_B9:{_L:info_part.get(_L,''),_Bl:info_part.get(_Bl,'')},_AP:clean_seasons,_A0:clean_episodes};write_search_cache(cache_key,stripped,ttl=86400);return cache_key,stripped,base,u,p,name
	check_order=myaddon.getSetting(_D6)
	if check_order=='1':import random;random.shuffle(servers)
	max_workers=min(50,len(servers)or 1)
	with ThreadPoolExecutor(max_workers=max_workers)as executor:
		futures=[executor.submit(fetch_series_info,base,u,p,series_id,name)for(base,u,p,series_id,name)in servers]
		for future in as_completed(futures):
			cache_key,cached,current_base,current_u,current_p,current_name=future.result()
			if cached:
				_current_series_cache[cache_key]=cached;eps=cached.get(_A0,{}).get(season,[])
				for ep in eps:
					if str(ep.get(_AD))==ep_num_str:
						new_title=ep.get(_H,'').strip()
						if new_title:real_ep_title=new_title
						ext=ep.get(_y,_AA);ep_id=ep.get(_O)
						if ep_id:stream=f"{current_base}series/{current_u}/{current_p}/{ep_id}.{ext}";sources.append(f"{stream}|{current_name}")
						break
	if not sources:xbmcgui.Dialog().ok(_D,'No playable sources found for this episode.');xbmcplugin.endOfDirectory(handle,succeeded=_B);return
	series_name=title.split('–',1)[0].strip()if'–'in title else title;xbmcplugin.setPluginCategory(handle,f"{series_name} – {real_ep_title}")
	for src in sources:
		url,srv=src.rsplit(_n,1)
		if show_server_names:item_title=f"{real_ep_title} [COLOR salmon][{srv}][/COLOR]"
		else:item_title=real_ep_title
		plugintools.add_item(action=_BB,title=item_title,thumbnail=xtream,fanart=backgrnd1,url=url,isPlayable=_A,folder=_B)
	xbmcplugin.endOfDirectory(handle)
def xtream_seasons(params):
	parts=params[_I].split(_n,4)
	if len(parts)!=5:return
	base,u,p,series_id,_=parts;pb=xbmcgui.DialogProgress();pb.create(_D,'Loading Seasons...');cache_key=f"SEASONS_{base}_{u}_{series_id}";seasons=sqlite_read_cache(cache_key)
	if not seasons:
		url=f"{base}player_api.php?username={u}&password={p}&action=get_series_info&series_id={series_id}"
		try:resp=requests.get(url,timeout=8);data=resp.json()if resp.status_code==200 else{};seasons=data.get(_AP,[]);sqlite_write_cache(cache_key,seasons)
		except Exception as e:xbmc.log(f"[xtream_seasons] API error: {str(e)}",xbmc.LOGERROR);seasons=[]
	pb.close()
	if not seasons:xbmcgui.Dialog().ok(_D,'No seasons found');return
	for season in seasons:season_num=season.get(_Be,_g);title=f"Season {season_num}";cover=season.get(_Bc,'');plugintools.add_item(action=_Ff,title=color(title),thumbnail=str(cover or xtream or''),fanart=backgrnd1,url=f"{base}|{u}|{p}|{series_id}|{season_num}",folder=_A,isPlayable=_B)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
def xtream_episodes(params):
	parts=params[_I].split(_n,4)
	if len(parts)!=5:return
	base,u,p,series_id,season_num=parts;pb=xbmcgui.DialogProgress();pb.create(_D,'Loading Episodes...');cache_key=f"EPISODES_{base}_{u}_{series_id}_{season_num}";episodes=sqlite_read_cache(cache_key)
	if not episodes:
		url=f"{base}player_api.php?username={u}&password={p}&action=get_series_info&series_id={series_id}"
		try:resp=requests.get(url,timeout=8);data=resp.json()if resp.status_code==200 else{};episodes=data.get(_A0,{}).get(season_num,[]);sqlite_write_cache(cache_key,episodes)
		except Exception as e:xbmc.log(f"[xtream_episodes] API error: {str(e)}",xbmc.LOGERROR);episodes=[]
	pb.close()
	if not episodes:xbmcgui.Dialog().ok(_D,'No episodes found');return
	for ep in episodes:
		ep_num=ep.get(_AD,'?');title=ep.get(_H,f"Episode {ep_num}");stream_id=ep.get(_O);ext=ep.get(_y,'mkv')
		if not stream_id:continue
		stream_url=f"{base}series/{u}/{p}/{stream_id}.{ext}";plugintools.add_item(action=_BB,title=color(title),thumbnail=str(ep.get(_Bc)or xtream or''),fanart=backgrnd1,url=stream_url,folder=_B,isPlayable=_A)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
def search_premium_m3u(params):
	global _search_cancelled;query=search_popup()
	if query is _G:set_search_cancelled(_A);xbmcgui.Dialog().notification(_D,_CY,xbmcgui.NOTIFICATION_INFO,3000);return
	elif query=='':xbmcgui.Dialog().notification(_D,_DI,xbmcgui.NOTIFICATION_INFO,3000);return
	pb=xbmcgui.DialogProgress();pb.create(_D,'Searching Premium...')
	try:
		base_params={_d:_Ci,_M:premium,_K:backgrnd1};results=[];premium_urls=[_F4,_F5,_F6,_F7,_IA,_F8,_F9,_FA,_FB,_FC,_IB,_FD,_IC];was_cancelled=_B;request_headers=[[_J,_AN]]
		for(idx,url)in enumerate(premium_urls,1):
			if is_search_cancelled()or pb.iscanceled():set_search_cancelled(_A);was_cancelled=_A;xbmc.log('dreammachine.search_premium_m3u: Search cancelled by user',xbmc.LOGINFO);break
			pb.update(int(idx/len(premium_urls)*100),f"Searching List {idx}/{len(premium_urls)}...")
			try:
				cache_key=f"{url}&query={query}&section=premium";cached_data=sqlite_read_cache(cache_key)
				if cached_data:results.extend(cached_data);xbmc.log(f"dreammachine.search_premium_m3u: Loaded {len(cached_data)} cached results for server {idx}",xbmc.LOGINFO);continue
				server_results=fetch_m3u_url(url,query,request_headers,base_params);results.extend(server_results)
			except Exception as e:xbmc.log(f"dreammachine.search_premium_m3u: Error processing server {idx} ({url}): {str(e)}",xbmc.LOGERROR)
		if results:
			handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,'Premium Search Results');xbmcplugin.setContent(handle,_C7)
			for result in results:plugintools.add_item(action=result[_d],title=f"[COLOR white]{color(result[_H])}[/COLOR]",thumbnail=result[_M],fanart=result[_K],url=result.get(_I,''),page=result.get(_P,''),plot=result.get(_W,''),extra=result.get(_S,''),episode=result.get(_Y,''),folder=result[_Ar],isPlayable=result.get(_As,_B))
			message=f"Found {len(results)} results"+(_ID if was_cancelled else'');xbmcgui.Dialog().notification(_D,message,xbmcgui.NOTIFICATION_INFO,3000);xbmcplugin.endOfDirectory(handle,updateListing=_B)
		else:message=_IE if was_cancelled else'No results found in Premium';xbmcgui.Dialog().notification(_D,message,xbmcgui.NOTIFICATION_INFO,3000)
	finally:pb.close()
def search_radio(params):
	global _search_cancelled;query=search_popup()
	if query is _G:set_search_cancelled(_A);xbmcgui.Dialog().notification(_D,_CY,xbmcgui.NOTIFICATION_INFO,3000);return
	elif query=='':xbmcgui.Dialog().notification(_D,_DI,xbmcgui.NOTIFICATION_INFO,3000);return
	pb=xbmcgui.DialogProgress();pb.create(_D,'Searching Radio...');results=[];was_cancelled=_B;radio_url=_FE
	try:
		pb.update(0,'Preparing search...');cache_key=f"{radio_url}&query={query}&section=radio";cached_data=read_cache(cache_key)
		if cached_data and not(is_search_cancelled()or pb.iscanceled()):results=cached_data[:];pb.update(100,f"Loaded {len(results)} cached results")
		elif is_search_cancelled()or pb.iscanceled():was_cancelled=_A
		else:
			pb.update(20,'Downloading and searching radio list...');server_results=search_radio_channels(query,{_M:radiothmb,_K:backgrnd1})
			if is_search_cancelled()or pb.iscanceled():was_cancelled=_A
			else:
				results=server_results
				if results:write_cache(cache_key,results)
				pb.update(100,f"Found {len(results)} stations")
		if results and not was_cancelled:
			handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,'Radio Search Results');xbmcplugin.setContent(handle,'songs')
			for result in results:plugintools.add_item(action=_Cc,title=f"[COLOR white]{color(result[_H])}[/COLOR]",thumbnail=result[_M],fanart=result[_K],url=result.get(_I,''),page='',plot='',extra='',episode='',folder=_B,isPlayable=_A)
			xbmcplugin.endOfDirectory(handle,updateListing=_B);xbmcgui.Dialog().notification(_D,f"Found {len(results)} radio stations",xbmcgui.NOTIFICATION_INFO,4000)
		else:msg=_CY if was_cancelled else'No radio stations found';xbmcgui.Dialog().notification(_D,msg,xbmcgui.NOTIFICATION_INFO,3000)
	except Exception:xbmcgui.Dialog().notification(_D,'Search error',xbmcgui.NOTIFICATION_ERROR,4000)
	finally:pb.close();set_search_cancelled(_B)
def search_mac_channels(query,base_params):
	results=[];portal=myaddon.getSetting(_AR);mac=myaddon.getSetting(_A1)
	if not portal or not mac:return results
	s=get_session();token=macs_handshake(s,portal,mac)
	if not token:return results
	source=macs_categories(s,token,portal,mac)
	if not source:return results
	try:json_data=json.loads(source);genres=json_data.get(_A9,[])if isinstance(json_data.get(_A9),list)else json_data.get(_A9,{}).get(_At,[]);genres_data=[(g.get(_O,''),g.get(_H,''))for g in genres if g.get(_O)and g.get(_H)]
	except json.JSONDecodeError:genres_data=plugintools.find_multiple_matches(source,_Db)
	genres_data.append((_g,_Ft));headers={_J:_A6,_i:_j,_Z:_a,_b:_c};cache_key_base=f"{portal}portal.php?type=itv&action=get_ordered_list&query={query}"
	for(genre_id,_)in genres_data:
		cache_key=f"{cache_key_base}&genre={genre_id}";cached_data=read_cache(cache_key,mac)
		if cached_data and isinstance(cached_data,list):results.extend(cached_data);continue
		channels=[];pn=1;max_pages=40
		while pn<=max_pages:
			page_url=f"{portal}portal.php?type=itv&action=get_ordered_list&genre={genre_id}&force_ch_link_check=&sortby=number&hd=0&p={pn}&JsHttpRequest=1-xml"
			try:
				response=s.get(page_url,headers=headers,timeout=5);response.raise_for_status();source=response.text.encode(_E,errors=_F).decode(_E,errors=_F).replace(_C,'');json_data=json.loads(source);page_channels=[(ch.get(_L,''),ch.get(_O,''))for ch in json_data.get(_A9,{}).get(_At,[])if _L in ch and _O in ch and query.lower()in ch.get(_L,'').lower()]
				if not page_channels:break
				channels+=page_channels;pn+=1
			except Exception:break
		if channels:
			write_cache(cache_key,channels,mac)
			for(name,ch_id)in channels:results.append({_d:_C1,_H:name,_M:base_params[_M],_K:base_params[_K],_I:ch_id,_P:mac,_W:token,_S:portal,_Ar:_B,_As:_A})
	return results
def search_m3u(params):
	global _search_cancelled;query=search_popup()
	if query is _G:set_search_cancelled(_A);xbmcgui.Dialog().notification(_D,_CY,xbmcgui.NOTIFICATION_INFO,3000);return
	elif query=='':xbmcgui.Dialog().notification(_D,_DI,xbmcgui.NOTIFICATION_INFO,3000);return
	pb=xbmcgui.DialogProgress();pb.create(_D,'Searching Free...')
	try:
		base_params={_d:'free',_M:free,_K:backgrnd1};results=[];m3u_urls=[_Hk,_Hl,_Hm,_Hn,_Ho,_Hp,_Hq,_Hr,_Hs,_Ht,_Hu,_Hv,_Hw,_Hx,_Hy,_Hz,_H_];was_cancelled=_B;request_headers=[[_J,_AN]]
		for(idx,url)in enumerate(m3u_urls,1):
			if is_search_cancelled()or pb.iscanceled():set_search_cancelled(_A);was_cancelled=_A;xbmc.log('dreammachine.search_m3u: Search cancelled by user',xbmc.LOGINFO);break
			pb.update(int(idx/len(m3u_urls)*100),f"Searching List {idx}/{len(m3u_urls)}...")
			try:
				cache_key=f"{url}&query={query}&section=free";cached_data=read_cache(cache_key)
				if cached_data:results.extend(cached_data);xbmc.log(f"dreammachine.search_m3u: Loaded {len(cached_data)} cached results for server {idx}",xbmc.LOGINFO);continue
				server_results=fetch_m3u_url(url,query,request_headers,base_params);results.extend(server_results)
			except Exception as e:xbmc.log(f"dreammachine.search_m3u: Error processing server {idx} ({url}): {str(e)}",xbmc.LOGERROR)
		if results:
			handle=int(sys.argv[1]);xbmcplugin.setPluginCategory(handle,'Free Search Results');xbmcplugin.setContent(handle,_C7)
			for result in results:plugintools.add_item(action=result[_d],title=f"[COLOR white]{color(result[_H])}[/COLOR]",thumbnail=result[_M],fanart=result[_K],url=result.get(_I,''),page=result.get(_P,''),plot=result.get(_W,''),extra=result.get(_S,''),episode=result.get(_Y,''),folder=result[_Ar],isPlayable=result.get(_As,_B))
			message=f"Found {len(results)} results"+(_ID if was_cancelled else'');xbmcgui.Dialog().notification(_D,message,xbmcgui.NOTIFICATION_INFO,3000);xbmcplugin.endOfDirectory(handle,updateListing=_B)
		else:message=_IE if was_cancelled else'No results found in Free';xbmcgui.Dialog().notification(_D,message,xbmcgui.NOTIFICATION_INFO,3000)
	finally:pb.close()
def fetch_m3u_url(url,query,headers,base_params):
	results=[];cache_key=f"{url}&query={query}";cached_data=read_cache(cache_key)
	if cached_data:return cached_data
	try:
		body,_=plugintools.read_body_and_headers(url,headers=headers,timeout=3);content=body.strip().decode(_E,errors=_F);matches=re.findall(_IF,content)
		for(thumb,title,stream_url)in matches:
			if query.lower()in title.lower():results.append({_d:_Cc,_H:title.strip(),_M:thumb or base_params[_M],_K:base_params[_K],_I:stream_url.strip(),_Ar:_B,_As:_A})
		if results:write_cache(cache_key,results)
	except Exception:pass
	return results
def search_premium_m3u_channels(query,base_params):
	results=[];premium_urls=[_F4,_F5,_F6,_F7,_IA,_F8,_F9,_FA,_FB,_FC,_IB,_FD,_IC];request_headers=[[_J,_AN]];MAX_WORKERS=min(4,multiprocessing.cpu_count())
	with ThreadPoolExecutor(max_workers=MAX_WORKERS)as executor:
		future_to_url={executor.submit(fetch_m3u_url,url,query,request_headers,base_params):url for url in premium_urls}
		for future in as_completed(future_to_url):
			try:results.extend(future.result())
			except Exception as e:xbmc.log(f"dreammachine.search_premium_m3u_channels: Error processing {future_to_url[future]}: {str(e)}",xbmc.LOGERROR)
	return results
def search_radio_channels(query,base_params):
	results=[];radio_url=_FE;request_headers=[[_J,_AN]];cache_key=f"{radio_url}&query={query}";cached_data=read_cache(cache_key)
	if cached_data:return cached_data
	try:
		body,_=plugintools.read_body_and_headers(radio_url,headers=request_headers,timeout=3);content=body.strip().decode(_E,errors=_F);matches=re.findall(_IF,content)
		for(thumb,title,stream_url)in matches:
			if query.lower()in title.lower():results.append({_d:_Cc,_H:title.strip(),_M:thumb or base_params[_M],_K:base_params[_K],_I:stream_url.strip(),_Ar:_B,_As:_A})
		if results:write_cache(cache_key,results)
	except Exception:pass
	return results
def color(tit):
	C='angliuk';B='ukrain';A='keywords';tit=tit.replace('\xa0',_w).replace('\t',_w).strip();epg_match=re.search('(.*?)\\s*\\[?(\\d{1,2}:\\d{2}\\s*-\\s*\\d{1,2}:\\d{2})\\]?(?:\\s*\\[\\d+\\s*min\\s*left\\])?(?:\\s*(.*))?$',tit,re.IGNORECASE)
	if epg_match and epg_match.group(2):channel_name=epg_match.group(1).strip()if epg_match.group(1)else tit.strip();epg_info=epg_match.group(3).strip()if epg_match.group(3)else''
	else:
		channel_name=tit.strip();epg_info='';epg_match_alt=re.search('\\s*\\[?(\\d{1,2}:\\d{2}\\s*-\\s*\\d{1,2}:\\d{2})\\]?(?:\\s*\\[\\d+\\s*min\\s*left\\])?(?:\\s*(.*))?$',tit,re.IGNORECASE)
		if epg_match_alt and epg_match_alt.group(1):epg_info=epg_match_alt.group(2).strip()if epg_match_alt.group(2)else'';channel_name=tit[:tit.lower().rfind(epg_match_alt.group(1).lower())].strip()
	display_name=channel_name.replace('[','').replace(']','').replace('(','').replace(')','').replace('  ',_w).replace('SD','').replace('UHD','').replace('HD','').replace('FHD','').replace(_CR,'').replace(_m,'').replace('-','').strip();tit_lower=tit.lower();exclusions=['tr/ ','fr | dazn','australia','tr: ','tr_','tr-','tr|','tr | ','ua | ','tr ',B,'centro','canal','ukran','africa','skyglass',C,'kstv','group','tivusat','musica ','musica:','blica','ceca','venus',C,'danimarca','america latina',B,'cairogroup','club8','cvn','iptv','rus -','plus','turk','sica','samoa','gran','monte','raukten','focus','geographic']
	if any(exclusion in tit_lower for exclusion in exclusions):return f"[COLOR white]{tit}[/COLOR]"
	categories={'Adult':{A:[_AF,_AG,_AH,_AI,_AJ,_AK,_AL,_k,_l,_X,_p,_AS,_q,_BC,_BD,_BE,_s,_t,_BF,_BG,_BH,_BI,_BJ,_BK,_BL,_BM,_BN,_BO,_BP,_BQ,_BR,_BS,_BT,_BU,_BV,_AT,_AU,_AV,_AW,_AX,_AY,_AZ,_Aa,_Ab,_r,_Ac,_Ad,_Ae,_Af,_Ag,_Ah,_Ai,_Aj,_Ak,_Al,_Am,_An,_Ao,_Ap,_Aq],_Bh:'fuchsia'},'US':{A:['|us| ','us ','usa','u.s.a','united states','us -','us-','us |','us|','us:','us :','english 24/7','24-7 english','kids 24/7','usa :','kids zone','ppv | ufc',"sports fanatic's",'24/7 channels','main events','|en|'],_Bh:_Eu},'UK':{A:['uk ','uk','united kingdom','uk -','uk-','uk |','uk|','uk:','uk :','england'],_Bh:'yellow'},_Cu:{A:['name | ca','ca ','canada','canadian','ca -','ca-','ca |','ca|','ca:','ca :'],_Bh:'blue'},'GR':{A:['gr ','gr','cyprus','greece','greek','gr -','gr-','gr |','gr|','gr:','gr :'],_Bh:'orange'}};tit_lower=display_name.lower();is_genre=any(any(keyword in tit_lower for keyword in config[A])for config in categories.values())
	if epg_info:is_genre=_B
	if is_genre:
		selected_color='white'
		for(category,config)in categories.items():
			if any(keyword in tit_lower for keyword in config[A]):selected_color=config[_Bh];break
		colored_title=f"[COLOR {selected_color}]{display_name}[/COLOR]"
	else:
		colored_title=f"[COLOR white]{display_name}[/COLOR]"
		if epg_info:colored_title+=f" [COLOR lime]{epg_info}[/COLOR]"
	return colored_title
def log(message):xbmc.log(f"dreammachine: {message}",xbmc.LOGINFO)
def xtream_search_selector(params):
	options=['[COLOR blue]1. Live TV[/COLOR]','[COLOR springgreen]2. Movies ( VOD )[/COLOR]','[COLOR yellow]3. TVShow ( VOD )[/COLOR]'];choice=xbmcgui.Dialog().select('Select Search Type',options)
	if choice==-1:xbmc.executebuiltin(_Br);return
	if choice==0:search_xtream_live(params)
	elif choice==1:search_xtream_vod(params)
	elif choice==2:search_xtream_series(params)
alist=[['[COLOR yellow]Latin Pop[/COLOR]','PL5UAxiHKWNlVNCW4ittbdgqeW5RzvCDlw','icon.png','Youtube',_FM],['[COLOR white]Movie Playlist[/COLOR]','PLPju5hHOSiozROpr8lhTJVPysIvlRqII0','movies.jpg','YouTube Movies Playlist',_FM],['Manele','manele in trend','RobertaGym.jpg','Muzica de pe Youtube','search'],['[COLOR white]Sample Live Stream[/COLOR]','https://www.youtube.com/watch?v=example_stream','stream.jpg','Sample Stream','stream']]
media_sources=[('DreamTube','json','https://raw.githubusercontent.com/mu51c/m3u/refs/heads/main/dm_youtube.json','directory')]
def youtube(params):plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_Av,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);plugintools.add_item(action=_Fi,title='[COLOR white]Search YouTube[/COLOR]',thumbnail=search,url='https://www.youtube.com/results?search_query=',fanart=backgrnd1,folder=_A);plugintools.add_item(action=_DT,title='[COLOR white]Play YouTube Video[/COLOR]',thumbnail=utube,url='',fanart=backgrnd2,folder=_B,isPlayable=_A);plugintools.add_item(action=_Fh,title='[COLOR white]Play YouTube Playlist[/COLOR]',thumbnail=utube,url='',fanart=backgrnd3,folder=_A,isPlayable=_B);plugintools.add_item(action=_Fj,title='[COLOR white]Media Playlists[/COLOR]',thumbnail=utube,url='',fanart=backgrnd5,folder=_A);plugintools.add_item(action='',title=_T,thumbnail=icon,fanart=backgrnd,folder=_B);xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_A)
def Search_yt(params):
	url=params.get(_I)+keyboard_input('','Search Youtube:',_B).replace(_w,'+');header=[];header.append([_J,_AN]);read_url,read_header=plugintools.read_body_and_headers(url,headers=header);url=read_url.strip().decode(_E);matches=re.findall('(?s)height":202},{"url":"(.+?)".*?title.*?text":"(.+?)"}.*?"videoId":"(.*?)"',url,re.DOTALL);log(matches)
	for(thumb,title,url)in matches:plugintools.add_item(action=_DU,title=title,url=url,thumbnail=icon,fanart=backgrnd,folder=_B,isPlayable=_A)
def ytfilme(params):
	plugintools.log('dreammachine.ytfilme');thumbnail=params.get(_M);url3=params.get(_I);xbmc.log(f"dreammachine.ytfilme: Processing URL {url3}",xbmc.LOGINFO)
	if not url3:xbmc.log(f"dreammachine.ytfilme: No URL provided",xbmc.LOGERROR);plugintools.message(_x,'No URL provided for movies.');xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_A);return
	try:
		request_headers=[[_J,_AN]];body,response_headers=plugintools.read_body_and_headers(url3,headers=request_headers);url=body.strip().decode(_E);xbmc.log(f"dreammachine.ytfilme: Fetched content length {len(url)} from {url3}",xbmc.LOGINFO);matches=plugintools.find_multiple_matches(url,'(#EXTINF:\\d+,tvg-name\\=".+?" tvg-logo\\=".+?"\nhttps\\:\\/\\/www\\.youtube\\.com\\/watch\\?v\\=.+?\n)');xbmc.log(f"dreammachine.ytfilme: Found {len(matches)} matches in {url3}",xbmc.LOGINFO);item_count=0
		for genre in matches:
			pattern=plugintools.find_single_match(genre,'(?s)#EXTINF:\\d+,tvg-name\\="(.+?)" tvg-logo\\="(.+?)"\nhttps\\:\\/\\/www\\.youtube\\.com\\/watch\\?v\\=(.+?)\n')
			if not pattern:xbmc.log(f"dreammachine.ytfilme: Failed to parse match {genre[:100]}... in {url3}",xbmc.LOGWARNING);continue
			url=pattern[2];title=pattern[0];thmb=pattern[1];plugintools.add_item(action=_DU,url=url,title='[LOWERCASE][CAPITALIZE][COLOR white]'+title+' [/CAPITALIZE][/LOWERCASE][/COLOR]',thumbnail=thmb or icon,fanart=backgrnd,info_labels={_Bz:title},folder=_B,isPlayable=_A);item_count+=1;xbmc.log(f"dreammachine.ytfilme: Added item {title} with URL https://www.youtube.com/watch?v={url}",xbmc.LOGINFO)
		if item_count==0:xbmc.log(f"dreammachine.ytfilme: No valid items parsed from {url3}",xbmc.LOGERROR);plugintools.message(_x,f"No valid movies found in {url3}. Check the source URL.")
	except Exception as e:xbmc.log(f"dreammachine.ytfilme: Error processing URL {url3}: {str(e)}",xbmc.LOGERROR);plugintools.message(_x,f"Failed to load movies from {url3}: {str(e)}")
	xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_A)
def yt_main_list(params):
	plugintools.add_item(action=_DV,title='[COLOR white]Default Playlists[/COLOR]',thumbnail=icon,url='',fanart=backgrnd,folder=_A,isPlayable=_B);json_urls=[('Bonus Movies','https://raw.githubusercontent.com/MetalDudesMusic/PTFM/main/bonusmovies'),('Redlist Playlists','https://raw.githubusercontent.com/MetalDudesMusic/Dude/main/musician/Redlist.json')]
	for(title,json_url)in json_urls:plugintools.add_item(action=_Cd,title=_BX+title+_Bm,thumbnail=icon,url=json_url,fanart=backgrnd,folder=_A,isPlayable=_B)
	xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_A)
def list_default_playlists(params):
	youtube='plugin://plugin.video.youtube/channel/MI-ID-CANAL/playlists/';youtubesearch='plugin://plugin.video.youtube/search/?q=MI-ID-SEARCH&search_type=notvalid';youtubepl='plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/'
	for i in range(len(alist)):
		title=alist[i][0];channel_id=alist[i][1];logo=str(xbmcvfs.translatePath(os.path.join(mislogos,alist[i][2])));descrip=alist[i][3];tip=alist[i][4]
		if tip=='channel':videos=youtube.replace('MI-ID-CANAL',channel_id);action=_Bq;folder=_A;isPlayable=_B
		elif tip=='search':videos=youtubesearch.replace('MI-ID-SEARCH',channel_id);action=_Bq;folder=_A;isPlayable=_B
		elif tip==_FM:videos=youtubepl.replace('MI-ID-PLAYLIST',channel_id);action=_Bq;folder=_A;isPlayable=_B
		elif tip=='stream':videos=channel_id;action=_Bp;folder=_B;isPlayable=_A
		else:xbmc.log(f"dreammachine.list_default_playlists: Unknown type {tip} for {title}",xbmc.LOGWARNING);continue
		datamovie={_Bz:descrip};plugintools.add_item(action=action,url=videos,title=_BX+title+_Bm,thumbnail=logo,fanart=str(backgrnd),info_labels=datamovie,folder=folder,isPlayable=isPlayable)
	xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_A)
def media_playlists(params):
	for(title,source_type,url,item_type)in media_sources:
		if source_type=='hardcoded':action=_DV
		elif source_type=='json':action=_Cd
		elif source_type=='xml':action=_Fg
		else:xbmc.log(f"dreammachine.media_playlists: Unknown source type {source_type} for {title}",xbmc.LOGWARNING);continue
		plugintools.add_item(action=action,title=_BX+title+_Bm,thumbnail=icon,url=url,fanart=backgrnd,folder=_A,isPlayable=_B)
	xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_A)
def list_json_playlists(params):
	A='plugin';json_url=params.get(_I);cache_path=CACHE_DIR;max_items=100;cache_duration=3600
	try:
		url_hash=hashlib.md5(json_url.encode()).hexdigest();cache_file=os.path.join(cache_path,f"{url_hash}.json")
		if xbmcvfs.exists(cache_file):
			cache_stat=xbmcvfs.Stat(cache_file);cache_time=cache_stat.st_mtime()
			if time.time()-cache_time<cache_duration:
				with xbmcvfs.File(cache_file,'r')as f:json_data=json.load(f)
			else:xbmcvfs.delete(cache_file)
		if not xbmcvfs.exists(cache_file):
			request_headers=[[_J,_AN]];body,response_headers=plugintools.read_body_and_headers(json_url,headers=request_headers);json_data=json.loads(body.decode(_E))
			with xbmcvfs.File(cache_file,'w')as f:json.dump(json_data,f)
		seen_urls=set();item_count=0
		for(index,item)in enumerate(json_data.get('items',[])):
			if index>=max_items:break
			title=item.get(_H,_A7);link=item.get('link','');thumbnail=item.get(_M,icon);fanart=item.get(_K,backgrnd);item_type=item.get('type',A)
			if isinstance(link,list):
				if link and isinstance(link[0],str):link=link[0]
				else:continue
			if not link or not isinstance(link,str):continue
			if item_type==A:
				if link.startswith(_IG):link='plugin://'+link
				elif not link.startswith('plugin://plugin.video.youtube/playlist/'):continue
				action=_Bq;folder=_A;isPlayable=_B
			elif item_type=='dir':
				if link.lower().endswith(_Da):action=_Cd;folder=_A;isPlayable=_B
				else:action='ytfilme';folder=_A;isPlayable=_B
			elif item_type=='item':
				youtube_match=re.match('(?:https?://)?(?:www\\.)?(?:youtube\\.com/watch\\?v=|youtu\\.be/)([\\w-]{11})',link)
				if youtube_match:video_id=youtube_match.group(1);link=f"plugin://plugin.video.youtube/play/?video_id={video_id}";action=_DT;folder=_B;isPlayable=_A
				else:action=_Bp;folder=_B;isPlayable=_A
			else:xbmc.log(f"dreammachine.list_json_playlists: Unknown item type {item_type} for {title} in {json_url}",xbmc.LOGWARNING);continue
			if item_type==A and link in seen_urls:continue
			seen_urls.add(link);plugintools.add_item(action=action,url=link,title=_BX+title+_Bm,thumbnail=thumbnail,fanart=fanart,info_labels={_Bz:title},folder=folder,isPlayable=isPlayable);item_count+=1;time.sleep(.01)
		if item_count==0:xbmc.log(f"dreammachine.list_json_playlists: No valid items loaded from {json_url}",xbmc.LOGERROR);plugintools.message(_x,f"No valid items found in {json_url}. Check the JSON source.")
	except Exception as e:xbmc.log(f"dreammachine.list_json_playlists: Error loading JSON {json_url}: {str(e)}",xbmc.LOGERROR);plugintools.message(_x,f"Failed to load playlist from {json_url}: {str(e)}")
	xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_A)
def yt_stream_list(params):
	json_url='https://raw.githubusercontent.com/MetalDudesMusic/Dude/main/yt247.json'
	try:
		request_headers=[[_J,_AN]];body,response_headers=plugintools.read_body_and_headers(json_url,headers=request_headers);json_data=json.loads(body.decode(_E))
		for item in json_data.get('items',[]):
			title=item.get(_H,_A7);link=item.get('link','');thumbnail=item.get(_M,icon);fanart=item.get(_K,backgrnd);item_type=item.get('type','item');datamovie={_Bz:title}
			if item_type!='item':xbmc.log(f"dreammachine.yt_stream_list: Unsupported item type {item_type} for {title} in {json_url}",xbmc.LOGWARNING);continue
			if not link:xbmc.log(f"dreammachine.yt_stream_list: Missing link for {title} in {json_url}",xbmc.LOGWARNING);continue
			plugintools.add_item(action=_Bp,url=link,title=_BX+title+_Bm,thumbnail=thumbnail,fanart=fanart,info_labels=datamovie,folder=_B,isPlayable=_A)
	except Exception as e:xbmc.log(f"dreammachine.yt_stream_list: Error loading JSON {json_url}: {str(e)}",xbmc.LOGERROR);plugintools.message(_x,'Failed to load live streams.')
	xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_A)
def list_xml_streams(params):
	xml_url=params.get(_I)
	try:
		request_headers=[[_J,_AN]];body,response_headers=plugintools.read_body_and_headers(xml_url,headers=request_headers);xml_content=body.decode(_E,errors=_F).strip();xml_content=xml_content.lstrip('\ufeff');xml_content=re.sub('&(?![A-Za-z0-9#]+;)','&',xml_content);xml_content=re.sub('[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]','',xml_content);wrapped_content=f"<items>{xml_content}</items>"
		try:root=ET.fromstring(wrapped_content);items=root.findall('.//item');log(f"Found {len(items)} items in XML")
		except ET.ParseError as e:log(f"XML parsing failed: {str(e)}");items=[]
		item_count=0
		if not items:
			log('Falling back to regex parsing due to XML parsing failure');item_matches=re.findall('<item>\\s*?<title>(.*?)</title>\\s*?<link>(.*?)</link>\\s*?<thumbnail>(.*?)</thumbnail>\\s*?<fanart>(.*?)</fanart>\\s*?</item>',wrapped_content,re.DOTALL)
			for(title,link,thumbnail,fanart)in item_matches:
				try:
					if not link:xbmc.log(f"dreammachine.list_xml_streams: Missing link for {title} in {xml_url}",xbmc.LOGWARNING);continue
					plugintools.add_item(action=_Bp,url=link,title=_BX+title+_Bm,thumbnail=thumbnail or icon,fanart=fanart or backgrnd,info_labels={_Bz:title},folder=_B,isPlayable=_A);item_count+=1;log(f"Successfully added item (regex): {title}")
				except Exception as e:xbmc.log(f"dreammachine.list_xml_streams: Error processing regex item {title}: {str(e)}",xbmc.LOGERROR);continue
		else:
			for item in items:
				try:
					title_elem=item.find(_H);link_elem=item.find('link');thumbnail_elem=item.find(_M);fanart_elem=item.find(_K);title=title_elem.text if title_elem is not _G else _A7;link=link_elem.text if link_elem is not _G else'';thumbnail=thumbnail_elem.text if thumbnail_elem is not _G else icon;fanart=fanart_elem.text if fanart_elem is not _G and fanart_elem.text else backgrnd;datamovie={_Bz:title}
					if not link:xbmc.log(f"dreammachine.list_xml_streams: Missing link for {title} in {xml_url}",xbmc.LOGWARNING);continue
					plugintools.add_item(action=_Bp,url=link,title=_BX+title+_Bm,thumbnail=thumbnail,fanart=fanart,info_labels=datamovie,folder=_B,isPlayable=_A);item_count+=1;log(f"Successfully added item: {title}")
				except Exception as e:xbmc.log(f"dreammachine.list_xml_streams: Error processing item {title}: {str(e)}",xbmc.LOGERROR);continue
		if item_count==0:xbmc.log(f"dreammachine.list_xml_streams: No valid items loaded from {xml_url}",xbmc.LOGERROR);plugintools.message(_x,'No radio streams could be loaded.')
	except Exception as e:xbmc.log(f"dreammachine.list_xml_streams: Error loading XML {xml_url}: {str(e)}",xbmc.LOGERROR);plugintools.message(_x,f"Failed to load radio streams: {str(e)}")
	xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_A)
def play_stream(params):
	url=params.get(_I)
	if not url:plugintools.message(_x,'No URL provided.');return
	try:
		if'youtube.com/watch?v='in url:
			import resolveurl;video_id=url.split('v=')[-1].split('&')[0];finalurl=resolveurl.resolve(f"https://www.youtube.com/watch?v={video_id}")
			if finalurl:plugintools.play_resolved_url(finalurl);log(f"Playing YouTube stream: {finalurl}")
			else:plugintools.message(_x,'Unable to resolve YouTube stream.')
		else:xbmc.Player().play(url);log(f"Playing direct stream: {url}")
	except Exception as e:xbmc.log(f"dreammachine.play_stream: Error playing stream {url}: {str(e)}",xbmc.LOGERROR);plugintools.message(_x,f"Failed to play stream: {str(e)}")
def lanza(params):
	theLists=params.get(_I)
	if _IG in theLists:
		playlist_id=theLists.split(_R)[-2]if _R in theLists else _F0;urls_to_try=[theLists,f"plugin://plugin.video.youtube/play/?playlist_id={playlist_id}"]
		for(attempt,url)in enumerate(urls_to_try,1):
			try:
				xbmc.executebuiltin('ActivateWindow(Videos, %s)'%url);xbmc.sleep(2000)
				if xbmc.getCondVisibility('Container.HasFiles'):return
				raise Exception(f"Playlist {playlist_id} failed with URL {url}")
			except Exception as e:
				xbmc.log(f"dreammachine.lanza: Error loading playlist {url}: {str(e)}",xbmc.LOGERROR)
				if attempt==len(urls_to_try):
					if not xbmc.getCondVisibility('Window.IsActive(busydialognocancel)'):plugintools.message(_x,f"Failed to load YouTube playlist ({playlist_id}). Check YouTube addon or playlist ID.")
					xbmc.sleep(1000)
				xbmc.sleep(1000)
	else:xbmc.Player().play(theLists)
def playyt(params):
	import resolveurl;url=keyboard_input('','Play YouTube ID:',_B)
	if url:
		finalurl=resolveurl.resolve(_IH+url)
		if finalurl:plugintools.play_resolved_url(finalurl);log(finalurl)
		else:plugintools.message(_x,'Unable to resolve YouTube video URL.')
	else:plugintools.message('Info',_II)
def add_playlist(params):
	if not xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):plugintools.message(_x,'YouTube addon is required.');return
	playlist_id=keyboard_input('','Enter YouTube Playlist ID:',_B)
	if playlist_id:url=f"plugin://plugin.video.youtube/playlist/{playlist_id}/";plugintools.add_item(action=_Bq,url=url,title='[COLOR white]Custom Playlist[/COLOR]',thumbnail=icon,fanart=backgrnd,folder=_A,isPlayable=_B);xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_A)
	else:plugintools.message('Info',_II);xbmc.executebuiltin(_AC);xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=_B)
def resolve_resolveurl_youtube(params):import resolveurl;finalurl=resolveurl.resolve(_IH+params.get(_I));plugintools.play_resolved_url(finalurl);log(finalurl)
TMDB_API_KEY='6ca3392e2903d0ddafc2dae3044ee31f'
TMDB_BASE_URL='https://api.themoviedb.org/3'
_tmdb_cache={}
def clean_title_for_tmdb(title):
	if not title:return''
	cleaned=re.sub('\\s*\\(\\d{4}\\)\\s*$','',title);cleaned=re.sub('\\s*\\d{4}\\s*$','',cleaned);cleaned=re.sub('\\s*(HD|4K|1080p|720p|SD|BluRay|WEBRip).*','',cleaned,flags=re.IGNORECASE);cleaned=re.sub('\\s*[-:–|].*','',cleaned);return cleaned.strip()
def _get_tmdb_details(title,media_type=_DD):
	A='Retry-After';cleaned_title=clean_title_for_tmdb(title)
	if not cleaned_title:return{}
	cache_key=f"{media_type}:{cleaned_title.lower()}"
	if cache_key in _tmdb_cache:return _tmdb_cache[cache_key]
	try:
		search_url=f"{TMDB_BASE_URL}/search/{media_type}";params={_F1:TMDB_API_KEY,_DY:cleaned_title.replace(_w,'+'),_F2:_F3};search_response=session.get(search_url,params=params,timeout=8)
		if search_response.status_code==429:retry_after=search_response.headers.get(A);wait=int(retry_after)if retry_after and retry_after.isdigit()else 3;xbmc.sleep(wait*1000+500);search_response=session.get(search_url,params=params,timeout=8);search_response.raise_for_status()
		search_response.raise_for_status();search_data=search_response.json()
		if not search_data.get(_C4):_tmdb_cache[cache_key]={};return{}
		item_id=search_data[_C4][0][_O];details_url=f"{TMDB_BASE_URL}/{media_type}/{item_id}";details_params={_F1:TMDB_API_KEY,_F2:_F3};details_response=session.get(details_url,params=details_params,timeout=8)
		if details_response.status_code==429:retry_after=details_response.headers.get(A);wait=int(retry_after)if retry_after and retry_after.isdigit()else 3;xbmc.sleep(wait*1000+500);details_response=session.get(details_url,params=details_params,timeout=8);details_response.raise_for_status()
		details_response.raise_for_status();details=details_response.json();poster=f"https://image.tmdb.org/t/p/w500{details.get(_DH,'')}"if details.get(_DH)else'';overview=details.get(_Bw,_CW);rating=details.get('vote_average',0);rating_str=f"{rating:.1f}/10"if rating>0 else _Q
		if media_type==_DD:release=details.get('release_date','')[:4];runtime=details.get(_E_,_Q);runtime_str=f"{runtime} min"if runtime!=_Q else _Q;release_str=release if release else _Q
		else:release=details.get('first_air_date','')[:4];release_str=release if release else _Q;runtime_str=_Q
		result={_CV:poster,_Bw:overview,_h:rating_str,_Ez:release_str,_E_:runtime_str};_tmdb_cache[cache_key]=result;return result
	except Exception as e:xbmc.log(f"[DreamMachine] TMDb error for '{title}': {str(e)}",xbmc.LOGWARNING);_tmdb_cache[cache_key]={};return{}
if __name__=='__main__':run()
