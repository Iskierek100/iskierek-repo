ISKIEREK IPTV FULL
==================

Opis
-----
Iskierek IPTV Full to rozbudowana wtyczka Kodi typu "all-in-one" do obsługi IPTV.
Wtyczka wspiera trzy typy źródeł:
- Stalker / MAC
- Xtream Codes
- M3U (URL i plik lokalny)

Głównym celem projektu jest wygodne oglądanie polskiej telewizji z własnym silnikiem
sortowania kanałów, grupowaniem, poprawianiem nazw, eksportem list oraz obsługą VOD,
seriali, pobierania i nagrywania.

Najważniejsze funkcje
---------------------
1. Obsługa źródeł IPTV:
   - Stalker / MAC
   - Xtream
   - M3U URL
   - M3U plik lokalny

2. Polska TV:
   - inteligentne sortowanie polskich kanałów
   - własne grupy i kolejność kanałów
   - poprawianie nazw kanałów
   - ukrywanie kanałów
   - zmiana nazw kanałów
   - eksport pełnej listy polskiej
   - eksport pojedynczych grup

3. VOD i Seriale:
   - odtwarzanie filmów
   - odtwarzanie seriali
   - pobieranie filmów
   - pobieranie odcinków

4. Nagrywanie TV:
   - start nagrywania z menu kontekstowego kanału
   - stop nagrywania
   - info o aktywnym nagrywaniu
   - nagrywanie przez ffmpeg
   - fallback do nagrywania wewnętrznego Python, jeśli ffmpeg nie jest dostępny
   - podgląd statusu nagrywania w ustawieniach

5. Eksport M3U:
   - eksport "Wszystkie Polskie"
   - eksport pojedynczej grupy
   - dla Xtream eksport bezpośrednich linków
   - dla Stalkera eksport plugin:// lub direct w zależności od trybu
   - eksport grup z menu kontekstowego

6. Kontrola rodzicielska:
   - globalny PIN
   - odblokowanie / zablokowanie kanałów 18+
   - ukrywanie kategorii adult

7. EPG:
   - zewnętrzne XMLTV
   - cache programu TV
   - szybkie ładowanie z lokalnego pliku EPG
   - przesunięcie czasu EPG

8. Manager dostawców:
   - dodawanie dostawców z poziomu wtyczki
   - edycja dostawców
   - usuwanie dostawców
   - aktywacja / dezaktywacja
   - import / eksport listy dostawców

9. Ustawienia Polskiej TV:
   - import / eksport konfiguracji polskich grup
   - reset do ustawień domyślnych
   - edycja ignorowanych prefixów
   - edycja ignorowanych suffixów
   - edycja wyjątków nazw

Architektura
------------
Wtyczka została podzielona na moduły tematyczne:

resources/lib/menu/
- home_menu.py
- provider_menu.py
- settings_menu.py

resources/lib/tv/
- groups.py
- live.py
- epg.py
- channel_switch.py

resources/lib/vod/
- movies.py
- series.py

resources/lib/tools/
- cache_tools.py
- provider_manager.py
- media_tools.py
- providers_backup.py

resources/lib/core/
- channels.py
- sorting.py
- polish_settings.py

resources/lib/providers/
- provider_api.py
- stalker.py
- xtream.py
- m3u.py

resources/lib/recording/
- recorder.py

resources/lib/downloads/
- downloader.py
- exporters.py

Dzięki temu:
- menu i wygląd są oddzielone od logiki
- live TV jest oddzielone od VOD
- serce polskiego sortowania jest oddzielone od providerów
- narzędzia mają osobne miejsce

Zarządzanie dostawcami
----------------------
Dostawcy nie są konfigurujący klasycznie przez rozbudowany settings.xml.
Zarządzanie odbywa się z poziomu menu wtyczki:

Menu główne:
- lista aktywnych dostawców
- Zarządzaj dostawcami
- Ustawienia Polskiej TV

W "Zarządzaj dostawcami":
- Dodaj dostawcę
- Importuj dostawców
- Eksportuj dostawców
- Importuj ustawienia Polskiej TV
- Eksportuj ustawienia Polskiej TV

Typy dostawców
--------------
1. Stalker
   Wymagane:
   - URL
   - MAC
   Opcjonalne:
   - Serial
   - Device ID
   - Signature

2. Xtream
   Wymagane:
   - URL
   - Username
   - Password

3. M3U
   Wspierane źródła:
   - URL listy M3U
   - plik lokalny M3U

Uwagi o M3U
-----------
Listy M3U mogą mieć:
- poprawne group-title
- jedną wspólną grupę
- brak dobrych nazw
- streamy HLS, TS, AceStream lub inne lokalne proxy

Wtyczka stara się przepuścić je przez ten sam silnik polskiego sortowania co Stalker i Xtream.

Uwagi o Stalker
---------------
Stalker często generuje linki dynamiczne / tymczasowe.
Oznacza to:
- odtwarzanie działa najlepiej przez samą wtyczkę
- niektóre eksporty direct mogą mieć ograniczoną trwałość
- eksport plugin:// jest najbezpieczniejszy dla Kodi

Nagrywanie
----------
Nagrywanie TV obsługiwane jest z menu kontekstowego kanału.

Tryby:
- start nagrywania
- stop nagrywania
- info o aktywnym nagraniu

Backend:
- ffmpeg, jeśli dostępny
- fallback Python, jeśli ffmpeg nie istnieje

Folder nagrań ustawiany jest globalnie w settings.xml.

Pobieranie
----------
Pobieranie dostępne jest dla:
- filmów VOD
- odcinków seriali

Opcje:
- pobieranie do pliku
- wznowienie pobierania przez plik .part, jeśli serwer wspiera resume

Media Manager
-------------
Wtyczka posiada przegląd:
- pobranych plików
- nagranych plików

Z poziomu managera można:
- odtwarzać pliki
- usuwać pliki

Pliki konfiguracyjne
--------------------
W katalogu profilu dodatku zapisywane są m.in.:
- providers.json
- selected_groups.json
- hidden_channels.json
- custom_names.json
- user_sorting.json
- epg_raw.json
- recording_state.json
- channel_state.json

Folder eksportów:
- exports/

Folder nagrań / pobrań:
- ustawiany w settings.xml

Settings.xml
------------
Settings.xml zostało ograniczone do minimum:
- EPG
- domyślne opcje nowych dostawców
- ścieżka do ffmpeg
- katalog nagrań i pobrań

Cała reszta konfiguracji odbywa się z poziomu menu wtyczki.

Rozwój
------
Wtyczka została przebudowana modułowo tak, aby łatwo rozwijać:
- UI
- TV
- VOD
- providery
- nagrywanie
- pobieranie
- eksport
- polskie grupy

Możliwe dalsze kierunki rozwoju:
- next / prev channel
- harmonogram nagrań
- test połączenia dostawcy
- backup pełnej konfiguracji
- dalsze dopracowanie silnika grup

Projekt
-------
Iskierek IPTV Full
Rozwijana jako pełny kombajn IPTV dla Kodi.
