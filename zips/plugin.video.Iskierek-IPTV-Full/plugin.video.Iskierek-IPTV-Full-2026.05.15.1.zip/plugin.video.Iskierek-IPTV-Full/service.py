# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import os
import time
import urllib.parse
import threading

from resources.lib import common, config, timeshift
from resources.lib.providers import provider_api
from resources.lib.recording import recorder
from resources.lib.tv import live as tv_live

ADDON_ID = 'plugin.video.Iskierek-IPTV-Full'
monitor = xbmc.Monitor()


# ── RELAY PROXY SERVICE ──────────────────────────────────────

def _start_relay_service():
    try:
        from resources.lib.tools import stream_relay
        stream_relay.start_relay_service()
        xbmc.log('[Iskierek IPTV Full] Relay service uruchomiony', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'[Iskierek IPTV Full] Relay service start error: {e}', xbmc.LOGERROR)


def _stop_relay_service():
    try:
        from resources.lib.tools import stream_relay
        stream_relay.stop_relay_service()
        xbmc.log('[Iskierek IPTV Full] Relay service zatrzymany', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'[Iskierek IPTV Full] Relay service stop error: {e}', xbmc.LOGERROR)


def _relay_should_be_running():
    try:
        from resources.lib.tools.proxy_tools import stream_proxy_is_required
        return bool(stream_proxy_is_required())
    except Exception as e:
        xbmc.log(f'[Iskierek IPTV Full] _relay_should_be_running error: {e}', xbmc.LOGERROR)
        return False


def _relay_watchdog():
    """
    Pilnuje stanu relay zgodnie z ustawieniami proxy:
    - proxy streamów ON  -> relay ma działać
    - proxy streamów OFF -> relay ma być zatrzymany
    """
    try:
        from resources.lib.tools import stream_relay

        should_run = _relay_should_be_running()
        relay_ok = stream_relay.check_relay_health(timeout=1.0)
        relay_has_state = stream_relay.get_relay_port() is not None

        if should_run:
            if not relay_ok:
                xbmc.log('[Iskierek IPTV Full] Relay watchdog: relay powinien działać, uruchamiam', xbmc.LOGINFO)
                _start_relay_service()
        else:
            if relay_has_state:
                xbmc.log('[Iskierek IPTV Full] Relay watchdog: proxy streamów wyłączone, zatrzymuję relay', xbmc.LOGINFO)
                _stop_relay_service()

    except Exception as e:
        xbmc.log(f'[Iskierek IPTV Full] _relay_watchdog error: {e}', xbmc.LOGERROR)

# ── ORYGINALNE FUNKCJE ───────────────────────────────────────

def _clear_plugin_playback_identity():
    try:
        win = xbmcgui.Window(10000)
        win.clearProperty('IskierekPlaybackPlugin')
        win.clearProperty('IskierekTvPlaybackActive')
    except Exception as e:
        xbmc.log(f"[Iskierek IPTV Full] _clear_plugin_playback_identity error: {e}", xbmc.LOGERROR)


def _get_plugin_playback_identity():
    try:
        win = xbmcgui.Window(10000)
        playback_plugin = (win.getProperty('IskierekPlaybackPlugin') or '').strip()
        tv_playback_active = win.getProperty('IskierekTvPlaybackActive') == '1'
        return playback_plugin, tv_playback_active
    except Exception as e:
        xbmc.log(f"[Iskierek IPTV Full] _get_plugin_playback_identity error: {e}", xbmc.LOGERROR)
        return '', False


def update_epg_if_needed():
    try:
        portals = config.get_all_portals()
        if not portals:
            return

        portal = portals[0]
        provider = provider_api.get_provider(portal)

        if not common.read_json_safe(common.epg_raw_file):
            provider.update_epg_database(common.addondir)
            return

        try:
            age = time.time() - os.path.getmtime(common.epg_raw_file)
            if age > 43200:
                provider.update_epg_database(common.addondir)
        except Exception:
            provider.update_epg_database(common.addondir)

    except Exception as e:
        xbmc.log(f"[Iskierek IPTV Full] service EPG error: {e}", xbmc.LOGERROR)


def process_scheduled_recordings_if_needed():
    try:
        recorder.process_scheduled_recordings()
    except Exception as e:
        xbmc.log(f"[Iskierek IPTV Full] service REC TIMER error: {e}", xbmc.LOGERROR)


def _is_refreshable_sorted_tv_state(state):
    try:
        if str(state.get('state_kind', '')) != 'tv_sorted':
            return False

        if state.get('state_refresh_enabled', False) != True:
            return False

        channels = state.get('channels', [])
        portal = state.get('portal', {})

        if not channels or not portal:
            return False

        sample = channels[0]
        if 'cmd' not in sample:
            return False
        if 'group_name' not in sample:
            return False
        if 'start_ts' not in sample or 'stop_ts' not in sample:
            return False

        return True
    except Exception:
        return False


def _has_expired_program_in_state(state):
    try:
        channels = state.get('channels', [])
        now_ts = int(time.time())

        for item in channels:
            try:
                stop_ts = int(float(item.get('stop_ts', 0) or 0))
                if stop_ts and stop_ts <= now_ts:
                    return True
            except Exception:
                continue

        return False
    except Exception:
        return False


def _refresh_sorted_tv_state(state):
    try:
        portal = state.get('portal', {})
        if not portal:
            return False

        refresh_custom_order = bool(state.get('state_refresh_custom_order', False))

        xbmc.log(
            f"[Iskierek IPTV Full] service refresh meta: forcing full sorted TV rebuild, custom_order={refresh_custom_order}",
            xbmc.LOGINFO
        )

        if not refresh_custom_order:
            return False

        return tv_live.rebuild_tv_channel_state(
            portal=portal,
            custom_order=True,
            filter_group='ALL_POLISH',
            genre_id='',
            genre_name='Wszystkie Polskie',
            overlay_full_state=True
        )

    except Exception as e:
        xbmc.log(f"[Iskierek IPTV Full] service _refresh_sorted_tv_state error: {e}", xbmc.LOGERROR)
        return False


def refresh_channel_state_if_needed(last_refresh_ts):
    try:
        state = common.read_json_safe(common.channel_state_file)
        if not state:
            return last_refresh_ts

        if not _is_refreshable_sorted_tv_state(state):
            return last_refresh_ts

        if not _has_expired_program_in_state(state):
            return last_refresh_ts

        now_ts = int(time.time())

        if now_ts - last_refresh_ts < 20:
            return last_refresh_ts

        xbmc.log(
            f"[Iskierek IPTV Full] service JSON refresh trigger: expired program detected, now={now_ts}",
            xbmc.LOGINFO
        )

        ok = _refresh_sorted_tv_state(state)

        xbmc.log(
            f"[Iskierek IPTV Full] service JSON refresh result={ok}",
            xbmc.LOGINFO
        )

        if ok:
            return now_ts

        return last_refresh_ts

    except Exception as e:
        xbmc.log(f"[Iskierek IPTV Full] service state refresh error: {e}", xbmc.LOGERROR)
        return last_refresh_ts


def _is_timeshift_technical_stop():
    try:
        return timeshift.is_technical_stop_in_progress()
    except Exception:
        return False


class IskierekPlayerMonitor(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._last_playing_file = ''
        self._av_started_ok = False

    def _remember_current_file(self):
        try:
            self._last_playing_file = self.getPlayingFile() or ''
        except Exception:
            self._last_playing_file = ''

    def _is_timeshift_playback(self):
        try:
            playing_file = self._last_playing_file or ''
            playing_file_l = str(playing_file).replace('\\', '/').lower()

            state = common.read_json_safe(common.timeshift_state_file)
            ts_file = str(state.get('file', '') or '').replace('\\', '/').lower()
            snapshot_file = str(state.get('snapshot_file', '') or '').replace('\\', '/').lower()

            if ts_file and ts_file in playing_file_l:
                return True

            if snapshot_file and snapshot_file in playing_file_l:
                return True

            if 'timeshift' in playing_file_l:
                return True

        except Exception as e:
            xbmc.log(f'[Iskierek IPTV Full] _is_timeshift_playback error: {e}', xbmc.LOGERROR)

        return False

    def onAVStarted(self):
        try:
            self._av_started_ok = True
            self._remember_current_file()

            win = xbmcgui.Window(10000)
            if win.getProperty('IskierekChannelSwitchInProgress') == '1':
                xbmc.log('[Iskierek IPTV Full] player onAVStarted -> clear switch flag', xbmc.LOGINFO)
                win.clearProperty('IskierekChannelSwitchInProgress')
        except Exception as e:
            xbmc.log(f'[Iskierek IPTV Full] player onAVStarted error: {e}', xbmc.LOGERROR)

    def onPlayBackStarted(self):
        try:
            self._remember_current_file()
        except Exception as e:
            xbmc.log(f'[Iskierek IPTV Full] player onPlayBackStarted error: {e}', xbmc.LOGERROR)

    def onPlayBackStopped(self):
        try:
            win = xbmcgui.Window(10000)

            return_owner = win.getProperty('IskierekReturnOwner') or ''
            return_live_active = win.getProperty('IskierekReturnLiveActive') == '1'
            switch_in_progress = win.getProperty('IskierekChannelSwitchInProgress') == '1'

            playback_plugin = win.getProperty('IskierekPlaybackPlugin') or ''
            tv_playback_active = win.getProperty('IskierekTvPlaybackActive') == '1'
            is_our_playback = (playback_plugin == ADDON_ID and tv_playback_active)

            xbmc.log(
                f'[Iskierek IPTV Full] player stop: owner={return_owner} active={return_live_active} '
                f'switch={switch_in_progress} av_started={self._av_started_ok} '
                f'our_plugin={playback_plugin} tv_active={tv_playback_active}',
                xbmc.LOGINFO
            )

            if not is_our_playback:
                xbmc.log('[Iskierek IPTV Full] stop ignored - not our playback', xbmc.LOGINFO)
                return

            is_timeshift_playback = False
            try:
                is_timeshift_playback = self._is_timeshift_playback() or timeshift.is_timeshift_active()
            except Exception:
                is_timeshift_playback = False

            technical_stop = _is_timeshift_technical_stop()
            failed_start_during_switch = False

            if switch_in_progress:
                # normalny switch: stary kanał się zatrzymuje, nowy startuje
                if self._av_started_ok:
                    xbmc.log('[Iskierek IPTV Full] stop ignored because of channel switch', xbmc.LOGINFO)
                    return

                # błąd startu kanału - AV nie wystartowało
                xbmc.log(
                    '[Iskierek IPTV Full] stop during channel switch, but AV never started -> treating as failed playback start',
                    xbmc.LOGINFO
                )
                failed_start_during_switch = True
                win.clearProperty('IskierekChannelSwitchInProgress')

            if technical_stop:
                xbmc.log('[Iskierek IPTV Full] stop ignored because timeshift technical stop is in progress', xbmc.LOGINFO)
                return

            if is_timeshift_playback:
                try:
                    xbmc.log('[Iskierek IPTV Full] player stop -> stopping timeshift buffer', xbmc.LOGINFO)
                    timeshift.stop_timeshift_buffer(remove_files=True)
                except Exception as e:
                    xbmc.log(f'[Iskierek IPTV Full] stop timeshift on stop error: {e}', xbmc.LOGERROR)

            _clear_plugin_playback_identity()

            if return_owner != 'live_window' or not return_live_active:
                return

            portal_json = win.getProperty('IskierekLivePortal') or '{}'
            custom_order = win.getProperty('IskierekLiveCustomOrder') or 'true'
            filter_group = win.getProperty('IskierekLiveFilterGroup') or 'ALL_POLISH'
            genre_id = win.getProperty('IskierekLiveGenreId') or ''
            genre_name = win.getProperty('IskierekLiveGenreName') or ''

            query = urllib.parse.urlencode({
                'mode': 'restore_live_window',
                'portal': portal_json,
                'custom_order': custom_order,
                'filter_group': filter_group,
                'genre_id': genre_id,
                'genre_name': genre_name
            })

            url = f'plugin://{ADDON_ID}/?{query}'

            win.clearProperty('IskierekReturnOwner')
            win.clearProperty('IskierekReturnLiveActive')
            win.clearProperty('IskierekLivePortal')
            win.clearProperty('IskierekLiveCustomOrder')
            win.clearProperty('IskierekLiveFilterGroup')
            win.clearProperty('IskierekLiveGenreId')
            win.clearProperty('IskierekLiveGenreName')
            win.clearProperty('IskierekChannelSwitchInProgress')
            win.clearProperty('IskierekLiveForceClose')

            # Dla failed-start: najpierw zamknij dialog błędu, potem restore live window
            if failed_start_during_switch:
                xbmc.log(f'[Iskierek IPTV Full] player stop -> restoring live window after failed start: {url}', xbmc.LOGINFO)

                def _restore_after_failed_start():
                    try:
                        xbmc.sleep(700)

                        # zamknij modalny dialog błędu/confirm
                        for _ in range(3):
                            xbmc.executebuiltin('Dialog.Close(all,true)')
                            xbmc.sleep(150)

                        xbmc.sleep(200)
                        xbmc.executebuiltin(f'RunPlugin({url})')
                    except Exception as e:
                        xbmc.log(f'[Iskierek IPTV Full] restore after failed start error: {e}', xbmc.LOGERROR)

                t = threading.Thread(target=_restore_after_failed_start)
                t.daemon = True
                t.start()
            else:
                xbmc.log(f'[Iskierek IPTV Full] player stop -> restoring live window: {url}', xbmc.LOGINFO)
                xbmc.executebuiltin(
                    f'AlarmClock(IskierekRestoreLiveWindow,RunPlugin({url}),00:00,silent)'
                )

        except Exception as e:
            xbmc.log(f'[Iskierek IPTV Full] player onPlayBackStopped error: {e}', xbmc.LOGERROR)
        finally:
            self._last_playing_file = ''
            self._av_started_ok = False

    def onPlayBackEnded(self):
        try:
            win = xbmcgui.Window(10000)

            switch_in_progress = win.getProperty('IskierekChannelSwitchInProgress') == '1'

            playback_plugin, tv_playback_active = _get_plugin_playback_identity()
            is_this_addon_playback = (playback_plugin == ADDON_ID and tv_playback_active)

            xbmc.log(
                f'[Iskierek IPTV Full] player ended event '
                f'switch={switch_in_progress} plugin={playback_plugin} tv_active={tv_playback_active}',
                xbmc.LOGINFO
            )

            if not is_this_addon_playback:
                xbmc.log('[Iskierek IPTV Full] player ended ignored - foreign playback', xbmc.LOGINFO)
                return

            is_timeshift_playback = False
            try:
                is_timeshift_playback = self._is_timeshift_playback() or timeshift.is_timeshift_active()
            except Exception:
                is_timeshift_playback = False

            technical_stop = _is_timeshift_technical_stop()

            if switch_in_progress:
                return

            if technical_stop:
                xbmc.log('[Iskierek IPTV Full] player ended ignored because timeshift technical stop is in progress', xbmc.LOGINFO)
                return

            if is_timeshift_playback:
                try:
                    xbmc.log('[Iskierek IPTV Full] player ended -> stopping timeshift buffer', xbmc.LOGINFO)
                    timeshift.stop_timeshift_buffer(remove_files=True)
                except Exception as e:
                    xbmc.log(f'[Iskierek IPTV Full] stop timeshift on ended error: {e}', xbmc.LOGERROR)

            _clear_plugin_playback_identity()

        except Exception as e:
            xbmc.log(f'[Iskierek IPTV Full] player onPlayBackEnded error: {e}', xbmc.LOGERROR)
        finally:
            self._last_playing_file = ''
            self._av_started_ok = False

    def onPlayBackError(self):
        try:
            win = xbmcgui.Window(10000)

            playback_plugin = win.getProperty('IskierekPlaybackPlugin') or ''
            tv_playback_active = win.getProperty('IskierekTvPlaybackActive') == '1'

            if playback_plugin != ADDON_ID or not tv_playback_active:
                return

            xbmc.log('[Iskierek IPTV Full] Błąd odtwarzania kanału - przywracam okno live', xbmc.LOGINFO)

            try:
                if timeshift.is_timeshift_active():
                    timeshift.stop_timeshift_buffer(remove_files=True)
            except Exception:
                pass

            _clear_plugin_playback_identity()

            return_owner = win.getProperty('IskierekReturnOwner')
            return_live_active = win.getProperty('IskierekReturnLiveActive') == '1'

            if return_owner == 'live_window' and return_live_active:
                portal_json = win.getProperty('IskierekLivePortal') or '{}'
                custom_order = win.getProperty('IskierekLiveCustomOrder') or 'true'
                filter_group = win.getProperty('IskierekLiveFilterGroup') or 'ALL_POLISH'
                genre_id = win.getProperty('IskierekLiveGenreId') or ''
                genre_name = win.getProperty('IskierekLiveGenreName') or ''

                query = urllib.parse.urlencode({
                    'mode': 'restore_live_window',
                    'portal': portal_json,
                    'custom_order': custom_order,
                    'filter_group': filter_group,
                    'genre_id': genre_id,
                    'genre_name': genre_name
                })

                url = f'plugin://{ADDON_ID}/?{query}'

                win.clearProperty('IskierekReturnOwner')
                win.clearProperty('IskierekReturnLiveActive')

                xbmc.executebuiltin(
                    f'AlarmClock(IskierekRestoreAfterError,RunPlugin({url}),00:00,silent)'
                )

        except Exception as e:
            xbmc.log(f'[Iskierek IPTV Full] onPlayBackError error: {e}', xbmc.LOGERROR)
        finally:
            self._last_playing_file = ''
            self._av_started_ok = False


if __name__ == '__main__':
    player_monitor = IskierekPlayerMonitor()

    xbmc.sleep(5000)

    # Start trwałego relay od razu przy starcie usługi
    _start_relay_service()

    tick = 0
    last_state_refresh_ts = 0

    while not monitor.abortRequested():
        if tick % 3600 == 0:
            update_epg_if_needed()

        process_scheduled_recordings_if_needed()
        last_state_refresh_ts = refresh_channel_state_if_needed(last_state_refresh_ts)

        if monitor.waitForAbort(1):
            break

        tick += 1

    _stop_relay_service()