# -*- coding: utf-8 -*-
import xbmc,xbmcgui,time
from resources.lib import common

def get_progress_bar(start_ts,stop_ts):
    try:
        now=time.time()
        if start_ts==0 or stop_ts==0: return ""
        if now<start_ts: return "[COLOR grey]..........[/COLOR]"
        duration=stop_ts-start_ts;elapsed=now-start_ts
        if duration<=0: return ""
        total_len=8;percent=int((elapsed/duration)*total_len)
        if percent>total_len: percent=total_len
        if percent<0: percent=0
        return "[COLOR lime]"+("*"*percent)+"[/COLOR]"+"[COLOR grey]"+("."*(total_len-percent))+"[/COLOR]"
    except: return ""

def _ask_pin(title='Podaj PIN rodzicielski'):
    kb=xbmc.Keyboard('',title,True)
    kb.setHiddenInput(True)
    kb.doModal()
    if not kb.isConfirmed():
        return None
    return kb.getText().strip()

def ensure_parental_pin():
    if common.has_parental_pin():
        return True

    xbmcgui.Dialog().ok(common.addonname,'Ustaw nowy PIN rodzicielski.')
    pin1=_ask_pin('Nowy PIN rodzicielski')
    if not pin1:
        return False
    pin2=_ask_pin('Potwierdź nowy PIN')
    if not pin2:
        return False
    if pin1!=pin2:
        xbmcgui.Dialog().ok(common.addonname,'PIN-y nie są zgodne.')
        return False

    common.set_parental_pin(pin1)
    xbmcgui.Dialog().notification(common.addonname,'PIN został ustawiony',xbmcgui.NOTIFICATION_INFO)
    return True

def change_parental_pin():
    if not common.has_parental_pin():
        return ensure_parental_pin()

    old_pin=_ask_pin('Podaj stary PIN')
    if old_pin is None:
        return False
    if not common.verify_parental_pin(old_pin):
        xbmcgui.Dialog().ok(common.addonname,'Nieprawidłowy stary PIN')
        return False

    new_pin=_ask_pin('Podaj nowy PIN')
    if not new_pin:
        return False
    new_pin2=_ask_pin('Potwierdź nowy PIN')
    if not new_pin2:
        return False
    if new_pin!=new_pin2:
        xbmcgui.Dialog().ok(common.addonname,'PIN-y nie są zgodne.')
        return False

    common.set_parental_pin(new_pin)
    xbmcgui.Dialog().notification(common.addonname,'PIN został zmieniony',xbmcgui.NOTIFICATION_INFO)
    return True

def verify_parental_access():
    if not common.has_parental_pin():
        return ensure_parental_pin()

    pin=_ask_pin('Podaj PIN rodzicielski')
    if pin is None:
        return False
    if not common.verify_parental_pin(pin):
        xbmcgui.Dialog().ok(common.addonname,'Nieprawidłowy PIN')
        return False
    return True

def is_adult_visible(portal):
    if not common.is_parental_enabled():
        return True
    try:
        portal_key=common.get_portal_key(portal);win=xbmcgui.Window(10000)
        return win.getProperty('iskierka.adult.visible.'+portal_key)=='1'
    except: return False

def unlock_adult(portal):
    if not common.is_parental_enabled():
        return True
    if not verify_parental_access():
        return False
    try:
        portal_key=common.get_portal_key(portal);win=xbmcgui.Window(10000)
        win.setProperty('iskierka.adult.visible.'+portal_key,'1')
        xbmcgui.Dialog().notification('OK','Kanały 18+ zostały odblokowane',xbmcgui.NOTIFICATION_INFO)
        return True
    except: return False

def lock_adult(portal):
    try:
        portal_key=common.get_portal_key(portal);win=xbmcgui.Window(10000)
        win.clearProperty('iskierka.adult.visible.'+portal_key)
        xbmcgui.Dialog().notification('OK','Kanały 18+ zostały zablokowane',xbmcgui.NOTIFICATION_INFO)
    except: pass