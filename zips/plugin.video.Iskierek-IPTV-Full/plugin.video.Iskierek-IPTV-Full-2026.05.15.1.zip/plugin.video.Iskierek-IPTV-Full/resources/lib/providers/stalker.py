# -*- coding: utf-8 -*-
import sys
import urllib.parse
import json
import os
import urllib.request, urllib.error
import re, uuid
import random
import ssl
import math
import hashlib
import gzip
import shutil
import xml.etree.ElementTree as ET
import time
from datetime import datetime, timedelta
import xbmc
import xbmcaddon
from resources.lib import common

key = None
mac = ':'.join(re.findall('..', '%012x' % uuid.getnode()))
sn = None
device_id = None
device_id2 = None
signature = None
cache_version = '22'

USER_AGENT = 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3'
X_USER_AGENT = 'Model: MAG250; Link: WiFi'
IMAGE_DESC = 'ImageDescription: 0.2.18-r23-pub-254; ImageDate: Wed Aug 29 10:49:26 EEST 2018; PORTAL version: 5.1.1; API Version: JS API version: 328; STB API version: 134; Player Engine version: 0x566'
ADULT_KEYWORDS = ['adult', 'xxx', '18+', 'erotic', 'porno', 'doros', 'hard', 'night', 'redlight', 'pornbox', 'sex', 'brazzers', 'hustler']

def _is_portal_obj(arg):
    return isinstance(arg, dict)


def _resolve_portal_args(arg1, arg2=None, arg3=None, arg4=None):
    """
    Obsługa dwóch trybów:
    1) starego: (portal_mac, url, serial, path)
    2) nowego: (portal, path) albo (portal, extra)
    """
    if _is_portal_obj(arg1):
        portal = arg1
        return (
            portal.get('mac', ''),
            portal.get('url', ''),
            portal.get('serial', None),
            arg2
        )
    return (arg1, arg2, arg3, arg4)


def _resolve_portal_and_cat(arg1, arg2=None):
    """
    Obsługa:
    - starego trybu stalkerowego, gdzie cat idzie z common.args
    - nowego trybu: (portal, cat)
    """
    if _is_portal_obj(arg1):
        portal = arg1
        return (
            portal.get('mac', ''),
            portal.get('url', ''),
            portal.get('serial', None),
            arg2
        )

    return (arg1, arg2, None, None)

def is_json(myjson):
    try: json_object = json.loads(myjson)
    except ValueError: return False
    return True

def get_token():
    global key
    return key

def setMac(nmac):
    global mac
    if nmac and re.match("[0-9a-f]{2}([-:])[0-9a-f]{2}(\\1[0-9a-f]{2}){4}$", nmac.lower()):
        mac = nmac

def setSerialNumber(serial):
    global sn, device_id, device_id2, signature
    if serial and serial.get('custom') == True:
        sn = serial['sn']
        device_id = serial['device_id']
        device_id2 = serial['device_id2']
        signature = serial['signature']
        return
    try:
        seed_val = int(hashlib.sha256(mac.encode('utf-8')).hexdigest(), 16)
        random.seed(seed_val)
        chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        if not sn: sn = ''.join(random.choice(chars) for _ in range(13))
        device_id = ''.join(random.choice(chars) for _ in range(64))
        device_id2 = ''.join(random.choice(chars) for _ in range(64))
        signature = hashlib.sha256((sn + mac).encode('utf-8')).hexdigest().upper()
    except: pass

def retrieveData(url, values):
    global key, mac, sn
    load = '/portal.php'
    base_url = url.rstrip('/')
    if '/c/' in base_url:
        referer = base_url
    elif base_url.endswith('/c'):
        referer = base_url
    else:
        referer = base_url + '/c/'

    cookie_str = f'mac={mac}'
    if key:
        cookie_str += f'; access_token={key}'

    headers = {
        'User-Agent': USER_AGENT,
        'Cookie': cookie_str,
        'Referer': referer,
        'X-User-Agent': X_USER_AGENT,
        'Accept': '*/*',
        'Connection': 'Keep-Alive'
    }

    if sn:
        headers['SN'] = sn
    if key:
        headers['Authorization'] = 'Bearer ' + key

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    data = urllib.parse.urlencode(values).encode('utf-8')

    # wymuszenie proxy
    try:
        from resources.lib.tools.proxy_tools import enforce_proxy
        proxy_result = enforce_proxy()
        if proxy_result is False:
            return {}
    except Exception:
        pass

    def send_request(req_url, req_data=None):
        req = urllib.request.Request(req_url, req_data, headers)
        try:
            return urllib.request.urlopen(req, context=ctx, timeout=30).read().decode('utf-8', errors='ignore')
        except urllib.error.HTTPError as e:
            return e.read().decode('utf-8', errors='ignore')
        except:
            return None

    try:
        full_url = base_url + load + '?' + data.decode('utf-8')
        resp = send_request(full_url)
        if resp and is_json(resp):
            return json.loads(resp)
        resp = send_request(base_url + load, data)
        if resp and is_json(resp):
            return json.loads(resp)
    except:
        pass
    return {}

def handshake(url):
    global key
    if not url or not mac: return
    try:
        info = retrieveData(url, values={'type': 'stb', 'action': 'handshake', 'token': ''})
        if info and 'js' in info and 'token' in info['js']:
            key = info['js']['token']
            getProfile(url)
    except:
        key = None

def getProfile(url):
    global sn, device_id, device_id2, signature
    values = {'type': 'stb', 'action': 'get_profile', 'hd': '1', 'auth_second_step': '0', 'num_banks': '1', 'stb_type': 'MAG250', 'image_version': '216', 'hw_version': '1.7-BD-00', 'not_valid_token': '0', 'ver': IMAGE_DESC}
    if sn: values.update({'sn': sn, 'device_id': device_id, 'device_id2': device_id2, 'signature': signature})
    retrieveData(url, values)
    sendWatchdog(url)

def sendWatchdog(url):
    values = {'type': 'watchdog', 'action': 'get_events', 'init': '0', 'cur_play_type': '0', 'event_active_id': '0'}
    retrieveData(url, values)

def _clean_cmd(cmd):
    if not cmd: return ""
    if 'ffmpeg ' in cmd: cmd = cmd.replace('ffmpeg ', '').strip()
    if 'http' in cmd:
        parts = cmd.split(' ')
        for p in parts:
            if p.startswith('http'): return p.strip()
    return cmd.strip()


def getLinkTV(portal_mac, url, serial, cmd):
    setMac(portal_mac); setSerialNumber(serial); handshake(url)
    sendWatchdog(url)

    clean_c = _clean_cmd(cmd)
    if 'http' in clean_c and 'localhost' not in clean_c: return clean_c

    info = retrieveData(url, values={'type': 'itv', 'action': 'create_link', 'cmd': cmd, 'forced_storage': '0', 'disable_ad': '0', 'JsHttpRequest': '1-xml'})
    if info and 'js' in info and 'cmd' in info['js']:
        link = _clean_cmd(info['js']['cmd'])
        if 'localhost' in link:
            base = url.split('/c')[0]
            link = link.replace('localhost', base.split('://')[1].split(':')[0])
        return link
    raise Exception("Błąd TV: Nie udało się wygenerować linku")

def getLinkVoD(portal_mac, url, serial, cmd):
    setMac(portal_mac); setSerialNumber(serial); handshake(url)
    sendWatchdog(url)
    if 'http' in cmd and 'ffmpeg' not in cmd: return _clean_cmd(cmd)
    info = retrieveData(url, values={'type': 'vod', 'action': 'create_link', 'cmd': cmd})
    if info and 'js' in info:
        if 'cmd' in info['js']: return _clean_cmd(info['js']['cmd'])
        if 'url' in info['js']: return info['js']['url']
    raise Exception("Błąd VOD")

def getLinkSeries(portal_mac, url, serial, cmd, episode):
    setMac(portal_mac); setSerialNumber(serial); handshake(url)
    sendWatchdog(url)
    values = {'type': 'vod', 'action': 'create_link', 'cmd': cmd, 'series': str(episode)}
    info = retrieveData(url, values=values)
    if info and 'js' in info:
        if 'cmd' in info['js']: return _clean_cmd(info['js']['cmd'])
        if 'url' in info['js']: return info['js']['url']
    raise Exception("Błąd Seriali")


def getGenres(arg1, arg2=None, arg3=None, arg4=None):
    portal_mac, url, serial, path = _resolve_portal_args(arg1, arg2, arg3, arg4)
    return _generic_get_genres(portal_mac, url, serial, path, 'itv', 'genres')


def getVoDgenres(arg1, arg2=None, arg3=None, arg4=None):
    portal_mac, url, serial, path = _resolve_portal_args(arg1, arg2, arg3, arg4)
    return _generic_get_genres(portal_mac, url, serial, path, 'vod', 'vodgenres')


def getSergenres(arg1, arg2=None, arg3=None, arg4=None):
    portal_mac, url, serial, path = _resolve_portal_args(arg1, arg2, arg3, arg4)
    return _generic_get_genres(portal_mac, url, serial, path, 'series', 'sergenres')

def _generic_get_genres(portal_mac, url, serial, path, type_api, key_name):
    safe_name = "_".join(re.findall("[a-zA-Z0-9]+", url))
    portalurl = os.path.join(common.cachedir, f"{safe_name}-{key_name}")
    now = time.time()
    setMac(portal_mac); setSerialNumber(serial)
    cached_data = common.read_json_safe(portalurl)
    if cached_data and isinstance(cached_data, dict):
        if 'version' in cached_data and cached_data.get('version') == cache_version:
             if ((now - float(cached_data.get('time', 0))) / 3600) < 12:
                 if cached_data.get(key_name): return cached_data
    handshake(url)
    info = retrieveData(url, values = {'type' : type_api, 'action' : 'get_categories', 'JsHttpRequest' : '1-xml'})
    if (not info or 'js' not in info or not info['js']) and type_api == 'itv':
         info = retrieveData(url, values = {'type' : type_api, 'action' : 'get_genres', 'JsHttpRequest' : '1-xml'})
    results = info.get('js', {}) if info else {}
    genres = {}
    iterator = results if isinstance(results, list) else results.values() if isinstance(results, dict) else []
    for i in iterator:
        if isinstance(i, dict):
            vid = str(i.get("id"))
            if not vid: continue
            raw_title = i.get("title") or i.get("alias") or i.get("name") or "Bez nazwy"
            genres[vid] = { "alias": common.clean_bad_chars(i.get("alias")), "title": common.clean_bad_chars(raw_title), "cat": vid }
    data = { "version": cache_version, "time": now, key_name: genres }
    if genres: common.write_json_safe(portalurl, data)
    return data

def getAllChannels(portal_mac, url, serial, path):
    now = time.time()
    safe_url = "_".join(re.findall("[a-zA-Z0-9]+", url))
    portalurl = os.path.join(common.cachedir, safe_url + 'channels')

    setMac(portal_mac)
    setSerialNumber(serial)

    cached_data = common.read_json_safe(portalurl)
    if cached_data:
        if 'version' in cached_data and cached_data.get('version') == cache_version:
            if ((now - float(cached_data.get('time', 0))) / 3600) < 2:
                return cached_data

    handshake(url)

    channels_list = []
    existing_ids = set()

    try:
        info = retrieveData(url, values={
            'type': 'itv',
            'action': 'get_all_channels',
            'JsHttpRequest': '1-xml'
        })
        if info and 'js' in info and 'data' in info['js']:
            for result in info['js']['data']:
                cid = str(result['id'])
                if cid not in existing_ids:
                    channels_list.append({
                        "id": cid,
                        "number": result.get("number", 0),
                        "name": common.clean_bad_chars(result.get("name", "")),
                        "cmd": result.get('cmd', ''),
                        "logo": result.get("logo", ""),
                        "genre_id": str(result.get('tv_genre_id'))
                    })
                    existing_ids.add(cid)
    except:
        pass

    genres_data = getGenres(portal_mac, url, serial, path)
    genres_map = genres_data.get('genres', {})

    target_genres = []

    for gid, gvals in genres_map.items():
        g_title = str(gvals.get('title', '')).lower()

        # Jeśli brak kanałów z get_all_channels, pobieramy wszystko
        # albo zawsze dociągamy gatunki adult
        if not channels_list or any(k in g_title for k in ADULT_KEYWORDS):
            target_genres.append(gid)

    for gid in target_genres:
        page = 1
        while page <= 30:
            try:
                g_info = retrieveData(url, values={
                    'type': 'itv',
                    'action': 'get_ordered_list',
                    'genre': gid,
                    'sortby': 'number',
                    'fav': 0,
                    'p': page,
                    'force_ch_link_check': 0,
                    'JsHttpRequest': '1-xml'
                })

                if not g_info or 'js' not in g_info or 'data' not in g_info['js']:
                    break

                data_list = g_info['js']['data']
                if not data_list:
                    break

                for result in data_list:
                    cid = str(result['id'])
                    if cid not in existing_ids:
                        channels_list.append({
                            "id": cid,
                            "number": result.get("number", 0),
                            "name": common.clean_bad_chars(result.get("name", "")),
                            "cmd": result.get('cmd', ''),
                            "logo": result.get("logo", ""),
                            "genre_id": str(gid)
                        })
                        existing_ids.add(cid)

                max_page_items = int(g_info['js'].get('max_page_items', 14))
                total_items = int(g_info['js'].get('total_items', 0))
                if max_page_items == 0:
                    max_page_items = 14

                if page >= math.ceil(total_items / max_page_items):
                    break

                page += 1

            except:
                break

    data = {
        "version": cache_version,
        "time": now,
        "channels": channels_list
    }
    common.write_json_safe(portalurl, data)
    return data


def getVoD(portal_mac, url, serial, path):
    cat = common.args.get('cat', [''])[0]; now = time.time()
    portalurl = os.path.join(common.cachedir, "_".join(re.findall("[a-zA-Z0-9]+", url)) + '-vod' + cat)
    setMac(portal_mac);
    cached_data = common.read_json_safe(portalurl)
    if cached_data:
        if 'version' in cached_data and cached_data.get('version') == cache_version:
             if ((now - float(cached_data.get('time', 0))) / 3600) < 12: return cached_data
    handshake(url); vod_list = []; page = 1;
    while True:
        info = retrieveData(url, values = {'type' : 'vod', 'action' : 'get_ordered_list', 'category' : cat, 'sortby' : 'added', 'not_ended' : '0', 'p' : page, 'fav' : '0', 'JsHttpRequest' : '1-xml'})
        if not info or 'js' not in info or 'data' not in info['js']: break
        total_items = float(info['js'].get('total_items', 0)); max_page_items = float(info['js'].get('max_page_items', 10));
        if max_page_items == 0: max_page_items = 10
        pages = math.ceil(total_items/max_page_items); results = info['js']['data']
        if not results: break
        for i in results:
            vod_list.append({ "name": common.clean_bad_chars(i.get("name")), "cmd": i.get('cmd'), "logo": i.get("screenshot_uri"), "plot": common.clean_bad_chars(i.get("description")), "genre": common.clean_bad_chars(i.get('genres_str')), "year": i.get("year") })
        page += 1;
        if page > pages or page > 50: break;
    data = { "version": cache_version, "time": now, "vod"+cat: vod_list }
    common.write_json_safe(portalurl, data)
    return data

def getSeries(portal_mac, url, serial, path):
    cat = common.args.get('cat', [''])[0]; now = time.time()
    portalurl = os.path.join(common.cachedir, "_".join(re.findall("[a-zA-Z0-9]+", url)) + '-ser' + cat)
    setMac(portal_mac);
    cached_data = common.read_json_safe(portalurl)
    if cached_data:
        if 'version' in cached_data and cached_data.get('version') == cache_version:
             if ((now - float(cached_data.get('time', 0))) / 3600) < 12: return cached_data
    handshake(url); series = []
    for page in range(1, 50):
        info = retrieveData(url, values = {'type' : 'series', 'action' : 'get_ordered_list', 'category' : cat, 'sortby' : 'added', 'not_ended' : '0', 'p' : page, 'fav' : '0', 'JsHttpRequest' : '1-xml'})
        if not info or 'js' not in info or 'data' not in info['js']: break
        total_items = info['js'].get('total_items', 0); data_list = info['js']['data']
        if not data_list: break
        for result in data_list:
            series.append({ "category": result.get('category_id'), "cat": result.get("id"), "name": common.clean_bad_chars(result.get("name")), "cmd": result.get('cmd'), "logo": result.get("screenshot_uri"), "plot": common.clean_bad_chars(result.get("description")), "genre": common.clean_bad_chars(result.get('genres_str')), "year": result.get("year") })
        if len(series) >= total_items: break
    data = { "version" : cache_version, "time" : now, 'ser'+cat: series }
    common.write_json_safe(portalurl, data)
    return data

def get_seasons(portal_mac, url, serial, path):
    cat = common.args.get('cat', [''])[0]; category = common.args.get('category', [''])[0]; now = time.time()
    portalurl = os.path.join(common.cachedir, "_".join(re.findall("[a-zA-Z0-9]+", url)) + '-seasons' + cat)
    setMac(portal_mac);
    cached_data = common.read_json_safe(portalurl)
    if cached_data:
        if 'version' in cached_data and cached_data.get('version') == cache_version:
             if ((now - float(cached_data.get('time', 0))) / 3600) < 12: return cached_data
    handshake(url); seasons = []
    for page in range(1, 50):
        info = retrieveData(url, values={'type': 'series', 'action': 'get_ordered_list', 'category': category, 'movie_id': cat, 'sortby': 'added', 'season_id': '0', 'episod_id': '0', 'p': page, 'JsHttpRequest': '1-xml'})
        if not info or 'js' not in info or 'data' not in info['js']: break
        total_items = info['js'].get('total_items', 0)
        for result in info['js']['data']:
            seasons.append({ "name": result.get('name'), "category": result.get('category_id'), "cat": result.get("id"), "cmd": result.get('cmd'), "logo": result.get("screenshot_uri"), "plot": common.clean_bad_chars(result.get("description")), "genre": common.clean_bad_chars(result.get('genres_str')), "year": result.get("year"), "series": result.get("series", []) })
        if len(seasons) >= total_items or not info['js']['data']: break
    data = { "version": cache_version, "time": now, 'seasons' + cat: seasons }
    common.write_json_safe(portalurl, data)
    return data

def get_episodes(portal_mac, url, serial, path):
    cat = common.args.get('cat', [''])[0]; category = common.args.get('category', [''])[0]; now = time.time()
    portalurl = os.path.join(common.cachedir, "_".join(re.findall("[a-zA-Z0-9]+", url)) + '-episodes')
    setMac(portal_mac);
    if not os.path.exists(path): os.makedirs(path)
    handshake(url); episodes = []
    for page in range(1, 5):
        info = retrieveData(url, values={'type': 'series', 'action': 'get_ordered_list', 'category': category, 'movie_id': cat, 'sortby': 'added', 'season_id': '0', 'episod_id': '0', 'p': page, 'JsHttpRequest': '1-xml'})
        if not info or 'js' not in info or 'data' not in info['js']: break
        data_list = info['js']['data']
        if not data_list: break
        for result in data_list:
            series_indices = result.get("series", []); clean_name = common.clean_bad_chars(result.get('name'))
            if isinstance(series_indices, list) and len(series_indices) > 0:
                for ep_number in series_indices:
                    episodes.append({ "episode": str(ep_number), "name": clean_name, "category": result.get('category_id'), "cat": result.get("id"), "cmd": result.get('cmd'), "logo": result.get("screenshot_uri"), "genre": result.get('genres_str'), "year": result.get("year"), "series": series_indices })
            else:
                ep_num = "1"
                if isinstance(series_indices, list) and len(series_indices) == 1: ep_num = str(series_indices[0])
                episodes.append({ "episode": ep_num, "name": clean_name, "category": result.get('category_id'), "cat": result.get("id"), "cmd": result.get('cmd'), "logo": result.get("screenshot_uri"), "genre": result.get('genres_str'), "year": result.get("year"), "series": series_indices })
        if len(data_list) < 10: break
    data = { "version": cache_version, "time": now, 'episodes': episodes }
    common.write_json_safe(portalurl, data)
    return data

def getAccountInfo(portal_mac, url, serial, path):
    global key, sn, device_id, device_id2, signature
    key = None
    setMac(portal_mac); setSerialNumber(serial)
    handshake(url)
    values = { 'type' : 'stb', 'action' : 'get_profile', 'hd' : '1', 'ver' : IMAGE_DESC, 'num_banks' : '1', 'stb_type' : 'MAG250', 'JsHttpRequest' : '1-xml'}
    if sn: values['sn'] = sn; values['device_id'] = device_id; values['device_id2'] = device_id2; values['signature'] = signature
    info = retrieveData(url, values)
    if info and 'js' in info: return info['js']
    return {}

def get_external_epg(path):
    json_epg_path = common.epg_raw_file
    final_epg = {}
    now = time.time()
    need_update = False

    if not os.path.exists(json_epg_path):
        need_update = True
    else:
        try:
            age = now - os.path.getmtime(json_epg_path)
            if age > 43200: # 12 godzin
                need_update = True
        except:
            need_update = True

    if need_update:
        update_epg_database(path)

    raw_data = common.read_json_safe(json_epg_path)
    if raw_data:
        try:
            for ch_name, events in raw_data.items():
                sorted_events = sorted([e for e in events if e['stop'] > now], key=lambda x: x['start'])

                if not sorted_events: continue

                upcoming = sorted_events[:3]
                full_info = ""
                short_on_list = ""
                current_title = ""
                next_title = ""
                start_ts = 0
                stop_ts = 0
                current_prog_img = ""
                chan_logo = ""

                for i, evt in enumerate(upcoming):
                    s_dt = datetime.fromtimestamp(evt['start'])
                    e_dt = datetime.fromtimestamp(evt['stop'])
                    start_h = s_dt.strftime('%H:%M')
                    stop_h = e_dt.strftime('%H:%M')

                    if i == 0:
                        is_now = evt['start'] <= now <= evt['stop']
                        color = "yellow" if is_now else "white"

                        short_on_list = f"{start_h} : {evt['title']}"
                        current_title = evt['title']
                        start_ts = evt['start']
                        stop_ts = evt['stop']
                        current_prog_img = evt.get('img', '')
                        chan_logo = evt.get('chan_logo', '')

                        full_info += f"[B][COLOR {color}]{start_h} - {stop_h} : {evt['title']}[/COLOR][/B]\n"
                        if evt.get('desc'): full_info += f"{evt['desc']}\n"
                        full_info += "\n[COLOR blue]Następnie:[/COLOR]\n"
                    else:
                        if i == 1: next_title = f"{start_h} {evt['title']}"
                        full_info += f"[COLOR white]{start_h}[/COLOR] {evt['title']}\n"

                final_epg[ch_name] = {
                    'plot': full_info.strip(),
                    'prog_img': current_prog_img,
                    'chan_logo': chan_logo,
                    'short_info': short_on_list,
                    'epg_current': current_title,
                    'epg_next': next_title,
                    'start_ts': start_ts,
                    'stop_ts': stop_ts
                }
            return final_epg
        except Exception as e:
            xbmc.log(f"EPG Error: {str(e)}", xbmc.LOGERROR)
    return {}

def update_epg_database(path):
    common.check_folders()
    TIME_SHIFT = 0
    epg_urls = []
    now_ts = time.time()

    try:
        my_addon = xbmcaddon.Addon()
        shift_str = my_addon.getSetting('epg_timeshift')
        if shift_str: TIME_SHIFT = int(shift_str)
        for i in range(1, 4):
            val = my_addon.getSetting(f'epg_url_{i}')
            if val and len(val) > 4: epg_urls.append(val.strip())
    except: pass

    if not epg_urls: epg_urls.append("https://epg.ovh/pl.gz")

    raw_db = {}
    cutoff_time = now_ts - 7200

    for idx, url in enumerate(epg_urls):
        xml_path = os.path.join(common.epgdir, f'epg_cache_{idx}.xml')
        gz_path = os.path.join(common.epgdir, f'epg_cache_{idx}.gz')

        if not os.path.exists(xml_path) or (now_ts - os.path.getmtime(xml_path)) > 43200:

                # wymuszenie proxy dla EPG
            try:
                from resources.lib.tools.proxy_tools import enforce_proxy
                proxy_result = enforce_proxy()
                if proxy_result is False:
                    continue
            except Exception:
                pass

            # proxy
            try:
                from resources.lib.tools.proxy_tools import get_proxy_opener, should_use_proxy_for
                use_proxy = should_use_proxy_for('epg')
                proxy_opener = get_proxy_opener() if use_proxy else None
            except Exception:
                proxy_opener = None

            try:
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE

                if proxy_opener:
                    response = proxy_opener.open(req, timeout=60)
                else:
                    response = urllib.request.urlopen(req, context=ctx, timeout=60)

                with response:
                    with open(gz_path if url.endswith('.gz') else xml_path, 'wb') as f_out:
                        shutil.copyfileobj(response, f_out)

                if url.endswith('.gz'):
                    with gzip.open(gz_path, 'rb') as f_gz:
                        with open(xml_path, 'wb') as f_xml:
                            shutil.copyfileobj(f_gz, f_xml)
                    if os.path.exists(gz_path): os.remove(gz_path)

            except: continue

        if os.path.exists(xml_path):
            try:
                context = ET.iterparse(xml_path, events=("start", "end"))
                context = iter(context)
                event, root = next(context)

                channels_map = {}
                logos_map = {}
                temp_events = {}

                for event, elem in context:
                    if event == "end" and elem.tag == "channel":
                        cid = elem.get('id')
                        dname = elem.find('display-name')
                        icon = elem.find('icon')
                        if dname is not None and dname.text:
                            channels_map[cid] = common.clean_channel_name(dname.text)
                        if icon is not None:
                            logos_map[cid] = icon.get('src')
                        root.clear()

                    elif event == "end" and elem.tag == "programme":
                        try:
                            raw_start = elem.get('start')[:14]
                            raw_stop = elem.get('stop')[:14]
                            dt_start = datetime.strptime(raw_start, '%Y%m%d%H%M%S')
                            dt_stop = datetime.strptime(raw_stop, '%Y%m%d%H%M%S')

                            if TIME_SHIFT != 0:
                                dt_start += timedelta(hours=TIME_SHIFT)
                                dt_stop += timedelta(hours=TIME_SHIFT)

                            ts_start = dt_start.timestamp()
                            ts_stop = dt_stop.timestamp()

                            if ts_stop < cutoff_time:
                                root.clear()
                                continue

                            cid = elem.get('channel')
                            if cid not in temp_events: temp_events[cid] = []

                            title_elem = elem.find('title')
                            title = title_elem.text if title_elem is not None else "Bez tytułu"

                            desc_elem = elem.find('desc')
                            desc = desc_elem.text if desc_elem is not None else ""

                            icon_elem = elem.find('icon')
                            prog_img = icon_elem.get('src') if icon_elem is not None else ""

                            temp_events[cid].append({
                                'start': ts_start,
                                'stop': ts_stop,
                                'title': title,
                                'desc': desc,
                                'img': prog_img
                            })
                        except: pass
                        root.clear()

                for cid, events in temp_events.items():
                    if cid in channels_map:
                        norm_key = channels_map[cid]
                        chan_logo = logos_map.get(cid, "")
                        for e in events: e['chan_logo'] = chan_logo
                        if norm_key not in raw_db: raw_db[norm_key] = []
                        raw_db[norm_key].extend(events)

            except Exception as e:
                xbmc.log(f"Parser Error: {str(e)}", xbmc.LOGERROR)

    common.write_json_safe(common.epg_raw_file, raw_db)
    return raw_db