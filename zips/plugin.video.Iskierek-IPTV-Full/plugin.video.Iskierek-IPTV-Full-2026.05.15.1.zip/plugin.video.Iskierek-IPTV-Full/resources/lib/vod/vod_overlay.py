# -*- coding: utf-8 -*-
import json
import time
import os
import threading
import xbmc
import xbmcgui

from resources.lib import common
from resources.lib.vod import vod_switch


class VodOverlay(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__()
        self.state = common.read_json_safe(common.vod_state_file)
        self.items = self.state.get('items', [])
        self.filtered_items = self.items[:]
        self.current_index = self.state.get('current_index', -1)
        self.content_type = self.state.get('content_type', 'vod')
        self.search_text = ''
        self.sticky = common.addon.getSetting('overlay_sticky') == 'true'

    def onInit(self):
        self.list = self.getControl(11)
        self._update_pin()
        self.fill_list()

    # ── PINEZKA ──────────────────────────────────────────────
    def _update_pin(self):
        try:
            red_pin = self.getControl(30)
            white_pin = self.getControl(34)

            if self.sticky:
                red_pin.setVisible(True)
                white_pin.setVisible(False)
            else:
                red_pin.setVisible(False)
                white_pin.setVisible(True)
        except Exception:
            pass

    def _toggle_sticky(self):
        self.sticky = not self.sticky
        common.addon.setSetting('overlay_sticky', 'true' if self.sticky else 'false')
        self._update_pin()

        status = '[COLOR lime]WŁ[/COLOR]' if self.sticky else '[COLOR red]WYŁ[/COLOR]'
        xbmcgui.Dialog().notification(
            common.addonname,
            f'Pinezka: {status}',
            xbmcgui.NOTIFICATION_INFO,
            2000
        )

    # ── LISTA ────────────────────────────────────────────────
    def _apply_filter(self):
        if not self.search_text:
            self.filtered_items = self.items[:]
            return

        q = self.search_text.lower().strip()
        self.filtered_items = [
            item for item in self.items
            if q in str(item.get('title', '')).lower() or q in str(item.get('plot', '')).lower()
        ]

    def fill_list(self):
        self._apply_filter()
        self.list.reset()
        items = []
        selected_pos = 0

        for idx, item in enumerate(self.filtered_items):
            title = item.get('title', 'Pozycja')
            plot = item.get('plot', '')
            logo = item.get('logo_url', '')

            original_index = -1
            for oi, full in enumerate(self.items):
                if full == item:
                    original_index = oi
                    break

            label = f"{original_index + 1}.   {title}" if original_index >= 0 else title
            if original_index == self.current_index:
                label = f"[COLOR red]{label}[/COLOR]"
                selected_pos = idx

            li = xbmcgui.ListItem(label)
            li.setArt({'icon': logo, 'thumb': logo})
            li.setProperty('Program', plot)
            li.setProperty('NextTitle', '')
            li.setProperty('Progress', '0')
            li.setProperty('IsPlaying', 'true' if original_index == self.current_index else '')
            items.append(li)

        self.list.addItems(items)
        if items and 0 <= selected_pos < len(items):
            self.list.selectItem(selected_pos)

        try:
            base_label = 'FILMY' if self.content_type == 'vod' else 'ODCINKI'
            if self.search_text:
                self.getControl(21).setLabel(f'{base_label}  •  SZUKAJ: {self.search_text}')
            else:
                self.getControl(21).setLabel(base_label)
        except:
            pass

    def _search(self):
        kb = xbmc.Keyboard(self.search_text, 'Szukaj')
        kb.doModal()
        if not kb.isConfirmed():
            return
        self.search_text = kb.getText().strip()
        self.fill_list()

    def _clear_search(self):
        if not self.search_text:
            return
        self.search_text = ''
        self.fill_list()

    # ── EVENTY ───────────────────────────────────────────────
    def onAction(self, action):
        aid = action.getId()
        if aid in [9, 10, 13, 92]:
            self.close()
            return
        if aid == 117:
            self._context_menu()

    def onClick(self, controlId):
        if controlId in [30, 34]:
            self._toggle_sticky()
            return

        if controlId != 11:
            return

        pos = self.list.getSelectedPosition()
        if pos < 0 or pos >= len(self.filtered_items):
            return

        item = self.filtered_items[pos]
        original_index = -1
        for oi, full in enumerate(self.items):
            if full == item:
                original_index = oi
                break

        if original_index < 0:
            return

        vod_switch.play_index(original_index)

        if self.sticky:
            xbmc.sleep(500)
            self.state = common.read_json_safe(common.vod_state_file)
            self.items = self.state.get('items', [])
            self.current_index = self.state.get('current_index', -1)
            self.fill_list()
        else:
            self.close()

    def _context_menu(self):
        pos = self.list.getSelectedPosition()
        if pos < 0 or pos >= len(self.filtered_items):
            return

        item = self.filtered_items[pos]
        portal = self.state.get('portal', {})
        title = item.get('title', 'Pozycja')
        cmd = item.get('cmd', '')
        logo = item.get('logo_url', '')

        sticky_status = '[COLOR lime]WŁ[/COLOR]' if self.sticky else '[COLOR red]WYŁ[/COLOR]'

        download_params = {
            "mode": "download_vod",
            "cmd": cmd,
            "title": title,
            "logo_url": logo,
            "portal": json.dumps(portal)
        }

        download_stop_params = {
            "mode": "download_stop",
            "portal": json.dumps(portal)
        }

        media_manager_params = {
            "mode": "media_manager"
        }

        provider_settings_params = {
            "mode": "provider_settings",
            "portal": json.dumps(portal)
        }

        menu_items = [
            (
                f'Pinezka: {sticky_status}',
                lambda: self._toggle_sticky()
            ),
            (
                'Szukaj',
                lambda: self._search()
            ),
            (
                'Wyczyść szukanie',
                lambda: self._clear_search()
            ),
            (
                'Pobierz',
                lambda: (
                    xbmc.executebuiltin(
                        'RunPlugin({})'.format(common.build_url(download_params))
                    ),
                )
            ),
            (
                'Stop pobierania',
                lambda: (
                    xbmc.executebuiltin(
                        'RunPlugin({})'.format(common.build_url(download_stop_params))
                    ),
                )
            ),
            (
                'Pobrane i nagrane',
                lambda: (
                    self.close(),
                    xbmc.sleep(200),
                    xbmc.executebuiltin(
                        'ActivateWindow(Videos,{},return)'.format(
                            common.build_url(media_manager_params)
                        )
                    )
                )
            ),
            (
                'Ustawienia',
                lambda: (
                    self.close(),
                    xbmc.sleep(200),
                    xbmc.executebuiltin(
                        'ActivateWindow(Videos,{},return)'.format(
                            common.build_url(provider_settings_params)
                        )
                    )
                )
            )
        ]

        labels = [m[0] for m in menu_items]
        choice = xbmcgui.Dialog().select(title, labels)
        if choice < 0:
            return

        try:
            action = menu_items[choice][1]
            action()
        except Exception as e:
            xbmc.log(f'[VodOverlay] context menu action error: {e}', xbmc.LOGERROR)


def open_overlay():
    state = common.read_json_safe(common.vod_state_file)
    items = state.get('items', [])
    if not items:
        xbmcgui.Dialog().notification(common.addonname, 'Brak zapisanej listy VOD', xbmcgui.NOTIFICATION_ERROR)
        return
    win = VodOverlay('vod_overlay.xml', common.addon_path, 'Default', '1080i')
    win.doModal()
    del win