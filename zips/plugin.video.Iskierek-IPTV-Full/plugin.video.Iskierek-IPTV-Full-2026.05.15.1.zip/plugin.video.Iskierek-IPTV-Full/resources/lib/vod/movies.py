# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,json
from resources.lib import common
from resources.lib.providers import provider_api
from resources.lib.navigation import is_adult_visible

def vodgenreLevel(portal):
    xbmcplugin.setContent(common.addon_handle,'files');provider=provider_api.get_provider(portal)
    try: data=provider.getVoDgenres(portal,common.addondir)
    except Exception as e: xbmcgui.Dialog().notification(common.addonname,str(e),xbmcgui.NOTIFICATION_ERROR);return
    genres=data['vodgenres'];saved_data=common.read_json_safe(common.selected_groups_file);portal_key=common.get_portal_key(portal);mac_data=saved_data.get(portal_key,{})
    if isinstance(mac_data,list): mac_data={'vod':[]}
    my_selected=mac_data.get('vod',[])
    if not my_selected:
        li=xbmcgui.ListItem("[COLOR yellow]Brak grup VOD. Kliknij, aby wybrać.[/COLOR]");url=common.build_url({'mode':'manage_groups_list','g_type':'vod','portal':json.dumps(portal)})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=True);xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True);return
    for gid,item in list(genres.items()):
        if gid not in my_selected: continue
        title=str(item.get("title","")).title();title_lower=title.lower()
        if any(w in title_lower for w in provider.ADULT_KEYWORDS) and not is_adult_visible(portal): continue
        url=common.build_url({'mode':'vod','genre_name':title,'cat':item["cat"],'portal':json.dumps(portal)});li=xbmcgui.ListItem(title);li.setArt({'icon':common.icon4,'fanart':common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=True)
    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def vodLevel(portal):
    provider=provider_api.get_provider(portal);cat=common.args.get('cat',[None])[0];genre_name=str(common.args.get('genre_name',[""])[0]);genre_lower=genre_name.lower()
    if any(w in genre_lower for w in provider.ADULT_KEYWORDS) and not is_adult_visible(portal):
        xbmcgui.Dialog().ok('Blokada','Ta kategoria VOD jest zablokowana.\nUżyj opcji "Odblokuj 18+" w menu portalu.');return
    try:
        if portal.get('type')=='xtream': data=provider.getVoD(portal,cat)
        else: data=provider.getVoD(portal['mac'],portal['url'],portal['serial'],common.addondir)
    except Exception as e:
        xbmcgui.Dialog().notification(common.addonname,str(e),xbmcgui.NOTIFICATION_ERROR);return
    vod_data_list=data.get('vod'+str(cat),[])
    overlay_items=[]
    for i in vod_data_list:
        try:
            name=str(i.get("name","Bez tytułu"));logo=i.get("logo","");cmd=i.get("cmd");ext=i.get("extension","mp4");plot=str(i.get("plot",""))
            logo_url='DefaultVideo.png'
            if logo:
                if str(logo).startswith('http'): logo_url=logo
                else:
                    base=portal['url'].split('/c/')[0] if '/c/' in portal['url'] else portal['url'].rstrip('/')
                    logo_url=f"{base}/stalker_portal/misc/logos/320/{logo}"
            url=common.build_url({'mode':'play_vod','cmd':cmd,'title':name,'logo_url':logo_url,'portal':json.dumps(portal),'ext':ext})
            li=xbmcgui.ListItem(name);li.setInfo(type='Video',infoLabels={'title':name,'plot':plot,'year':str(i.get("year","")),'genre':str(i.get("genre","")),'mediatype':'movie'});li.setArt({'icon':logo_url,'thumb':logo_url,'fanart':common.fanart});li.setProperty('IsPlayable','true')
            download_params={'mode':'download_vod','cmd':cmd,'title':name,'logo_url':logo_url,'portal':json.dumps(portal),'ext':ext}
            li.addContextMenuItems([('[COLOR yellow]Pobierz film[/COLOR]',f'RunPlugin({common.build_url(download_params)})')])
            xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=False)

            overlay_items.append({
                'title': name,
                'plot': plot,
                'logo_url': logo_url,
                'cmd': cmd,
                'ext': ext
            })
        except: continue
    common.write_json_safe(common.vod_state_file, {'items': overlay_items, 'current_index': -1, 'portal': portal, 'content_type': 'vod'})
    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)
