# -*- coding: utf-8 -*-
import xbmcplugin
import xbmcgui
import xbmc
import json
from resources.lib import common
from resources.lib.pvr import pvr_bridge as bridge

def _is_pvr_simple_enabled():
    try:
        query = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Addons.GetAddonDetails",
            "params": {
                "addonid": "pvr.iptvsimple",
                "properties": ["enabled", "installed"]
            }
        }

        response = xbmc.executeJSONRPC(json.dumps(query))
        data = json.loads(response)

        addon = data.get('result', {}).get('addon', {})
        installed = addon.get('installed', False)
        enabled = addon.get('enabled', False)

        if not installed:
            return None

        return bool(enabled)

    except:
        return None

def PVRMenuLevel(portal):
    xbmcplugin.setContent(common.addon_handle, 'files')



    url_start = common.build_url({'mode':'pvr_bridge_start','portal':json.dumps(portal)})
    li_start = xbmcgui.ListItem('Wygeneruj liste m3u')
    li_start.setArt({'icon':common.icon13,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_start,listitem=li_start,isFolder=False)

    url_refresh_client = common.build_url({'mode':'refresh_pvr_client_experimental','portal':json.dumps(portal)})
    li_refresh_client = xbmcgui.ListItem('Odśwież liste m3u')
    li_refresh_client.setArt({'icon':common.icon12,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_refresh_client,listitem=li_refresh_client,isFolder=False)

    url_tv = common.build_url({'mode':'open_pvr_tv','portal':json.dumps(portal)})
    li_tv = xbmcgui.ListItem('Odtwarzaj liste m3u')
    li_tv.setArt({'icon':common.icon42,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_tv,listitem=li_tv,isFolder=False)







    url_info = common.build_url({'mode':'pvr_bridge_info','portal':json.dumps(portal)})
    li_info = xbmcgui.ListItem('Informacje')
    li_info.setArt({'icon':common.icon15,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_info,listitem=li_info,isFolder=False)

    url_settings = common.build_url({'mode': 'pvr_settings', 'portal': json.dumps(portal)})
    li_settings = xbmcgui.ListItem('Ustawienia')
    li_settings.setArt({'icon': common.icon14, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_settings, listitem=li_settings, isFolder=True)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)

def PVRSettingsLevel(portal):
    xbmcplugin.setContent(common.addon_handle, 'files')

    fallback_icon = common.icon25 if bridge.is_fallback_enabled() else common.icon26
    url_toggle = common.build_url({'mode': 'pvr_toggle_fallback', 'portal': json.dumps(portal)})
    li_toggle = xbmcgui.ListItem('Lokalny serwer')
    li_toggle.setArt({'icon': fallback_icon, 'thumb': fallback_icon, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_toggle, listitem=li_toggle, isFolder=False)

    url_stop = common.build_url({'mode': 'pvr_bridge_stop', 'portal': json.dumps(portal)})
    li_stop = xbmcgui.ListItem('Zatrzymaj serwer')
    li_stop.setArt({'icon': common.icon40, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_stop, listitem=li_stop, isFolder=False)

    current_folder = bridge.get_export_folder()
    url_client_settings = common.build_url({'mode': 'open_pvr_client_settings', 'portal': json.dumps(portal)})
    li_client_settings = xbmcgui.ListItem('Ustawienia klienta TV')
    li_client_settings.setArt({'icon': common.icon8, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_client_settings, listitem=li_client_settings, isFolder=False)

    url_folder = common.build_url({'mode': 'pvr_bridge_choose_folder', 'portal': json.dumps(portal)})
    li_folder = xbmcgui.ListItem(f'Miejsce zapisu pliku M3U\n{current_folder}')
    li_folder.setArt({'icon': common.icon41, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_folder, listitem=li_folder, isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)