# -*- coding: utf-8 -*-
import xbmcplugin, xbmcgui, json
from resources.lib import common


def set_portal_title(portal, section=""):
    try:
        portal_name = portal.get("name", "IPTV")
        xbmcplugin.setPluginCategory(
            common.addon_handle,
            f"{portal_name} / {section}" if section else portal_name,
        )
    except:
        pass


def SelectLevel(portal):
    set_portal_title(portal, "Menu")
    xbmcplugin.setContent(common.addon_handle, "files")

    url_pl=common.build_url({'mode':'channels','custom_order':'true','filter_group':'ALL_POLISH','portal':json.dumps(portal),'genre_name':'Wszystkie Polskie'})
    li_pl=xbmcgui.ListItem('Polska TV widok skórki')
    li_pl.setArt({'icon':common.icon1,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_pl,listitem=li_pl,isFolder=True)

    url_pl = common.build_url(
        {
            "mode": "live_window",
            "custom_order": "true",
            "filter_group": "ALL_POLISH",
            "portal": json.dumps(portal),
            "genre_name": "Wszystkie Polskie",
            "genre_id": "",
        }
    )
    li_pl = xbmcgui.ListItem("Polska")
    li_pl.setArt({"icon": common.icon1, "thumb": common.icon1, "fanart": common.fanart})
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle, url=url_pl, listitem=li_pl, isFolder=False
    )

    url_pvr = common.build_url({"mode": "pvr_menu", "portal": json.dumps(portal)})
    li_pvr = xbmcgui.ListItem("Telewizja")
    li_pvr.setArt(
        {"icon": common.icon8, "thumb": common.icon8, "fanart": common.fanart}
    )
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle, url=url_pvr, listitem=li_pvr, isFolder=True
    )

    url_guide = common.build_url(
        {
            "mode": "tv_guide",
            "custom_order": "true",
            "filter_group": "ALL_POLISH",
            "portal": json.dumps(portal),
            "genre_name": "Wszystkie Polskie",
        }
    )
    li_guide = xbmcgui.ListItem("Przewodnik")
    li_guide.setArt(
        {"icon": common.icon2, "thumb": common.icon2, "fanart": common.fanart}
    )
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle, url=url_guide, listitem=li_guide, isFolder=False
    )


    url_groups = common.build_url(
        {"mode": "polish_groups_menu", "portal": json.dumps(portal)}
    )
    li_groups = xbmcgui.ListItem("Grupy")
    li_groups.setArt(
        {"icon": common.icon3, "thumb": common.icon3, "fanart": common.fanart}
    )
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle, url=url_groups, listitem=li_groups, isFolder=True
    )

    if portal.get("type") != "m3u":
        url_vod = common.build_url({"mode": "vodgen", "portal": json.dumps(portal)})
        li_vod = xbmcgui.ListItem("Filmy")
        li_vod.setArt(
            {"icon": common.icon4, "thumb": common.icon4, "fanart": common.fanart}
        )
        xbmcplugin.addDirectoryItem(
            handle=common.addon_handle, url=url_vod, listitem=li_vod, isFolder=True
        )

        url_ser = common.build_url({"mode": "sergen", "portal": json.dumps(portal)})
        li_ser = xbmcgui.ListItem("Seriale")
        li_ser.setArt(
            {"icon": common.icon5, "thumb": common.icon5, "fanart": common.fanart}
        )
        xbmcplugin.addDirectoryItem(
            handle=common.addon_handle, url=url_ser, listitem=li_ser, isFolder=True
        )

    if portal.get("type") == "m3u":
        url_raw = common.build_url(
            {
                "mode": "channels",
                "genre_id": "*",
                "genre_name": "M3U",
                "portal": json.dumps(portal),
            }
        )
        li_raw = xbmcgui.ListItem("M3U")
        li_raw.setArt(
            {"icon": common.icon6, "thumb": common.icon6, "fanart": common.fanart}
        )
    else:
        url_raw = common.build_url(
            {"mode": "my_groups_view", "portal": json.dumps(portal)}
        )
        li_raw = xbmcgui.ListItem("Zagraniczna")
        li_raw.setArt(
            {"icon": common.icon10, "thumb": common.icon10, "fanart": common.fanart}
        )
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle, url=url_raw, listitem=li_raw, isFolder=True
    )

    url_search = common.build_url({"mode": "global_search"})
    li_search = xbmcgui.ListItem("Szukaj")
    li_search.setArt(
        {"icon": common.icon7, "thumb": common.icon7, "fanart": common.fanart}
    )
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle, url=url_search, listitem=li_search, isFolder=False
    )




    url_settings = common.build_url(
        {"mode": "provider_settings", "portal": json.dumps(portal)}
    )
    li_settings = xbmcgui.ListItem("Narzędzia")
    li_settings.setArt(
        {"icon": common.icon9, "thumb": common.icon9, "fanart": common.fanart}
    )
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle,
        url=url_settings,
        listitem=li_settings,
        isFolder=True,
    )

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)
