# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,json
from resources.lib import common,config



def homeLevel():

    xbmcplugin.setContent(common.addon_handle, 'files')
    xbmcplugin.setPluginCategory(common.addon_handle, 'Dostawcy IPTV')
    portals = config.get_all_portals()

    if not portals:
        li = xbmcgui.ListItem('Brak aktywnych dostawców')
        li.setArt({'icon': common.icon17, 'fanart': common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle, url='', listitem=li, isFolder=False)
    else:
        for p in portals:
            try:
                label = p.get('name', 'Portal')
                ptype = p.get('type', '')

                # Dobierz ikonę do typu dostawcy
                if ptype == 'stalker':
                    icon = common.icon58   # ikona dla MAC/Stalker
                elif ptype == 'xtream':
                    icon = common.icon59    # ikona dla Xtream
                elif ptype == 'm3u':
                    icon = common.icon60       # ikona dla M3U
                else:
                    icon = common.icon0          # domyślna

                url = common.build_url({'mode': 'sel', 'portal': json.dumps(p)})
                li = xbmcgui.ListItem(label)
                li.setArt({
                    'icon': icon,
                    'thumb': icon,
                    'fanart': common.fanart
                })
                xbmcplugin.addDirectoryItem(
                    handle=common.addon_handle,
                    url=url,
                    listitem=li,
                    isFolder=True
                )
            except:
                pass

    #url_dummy=common.build_url({'mode':'refresh_list'})
    #li_sep=xbmcgui.ListItem('')
    #li_sep.setArt({'fanart':common.fanart})
    #xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_dummy,listitem=li_sep,isFolder=False)

    add_url=common.build_url({'mode':'provider_add'})
    li_add=xbmcgui.ListItem('Dodaj dostawcę')
    li_add.setArt({'icon':common.icon16,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=add_url,listitem=li_add,isFolder=False)

    url_manage=common.build_url({'mode':'providers_manager'})
    li_manage=xbmcgui.ListItem('Zarządzaj dostawcami')
    li_manage.setArt({'icon':common.icon35,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_manage,listitem=li_manage,isFolder=True)

    url_polish=common.build_url({'mode':'polish_settings'})
    li_polish=xbmcgui.ListItem('Narzędzia polskiej TV')
    li_polish.setArt({'icon':common.icon9,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_polish,listitem=li_polish,isFolder=True)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=False)
