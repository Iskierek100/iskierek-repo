# -*- coding: utf-8 -*-
# settings_levels.py
import xbmcplugin
import xbmcgui
import json

from resources.lib import common
from resources.lib.recording import recorder
from resources.lib.pvr import pvr_bridge as bridge
from resources.lib.tools import keymap_tools
from resources.lib import timeshift
from resources.lib.downloads import downloader


def ProviderSettingsLevel(portal):
    current_portal = common.get_provider_by_id(portal.get('id', '')) or portal
    xbmcplugin.setContent(common.addon_handle, 'files')
    xbmcplugin.setPluginCategory(common.addon_handle, f"{current_portal.get('name', '')}/Ustawienia")

    url_groups = common.build_url({'mode': 'provider_settings_groups', 'portal': json.dumps(current_portal)})
    li_groups = xbmcgui.ListItem('Grupy i kanały')
    li_groups.setArt({'icon': common.icon3, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_groups, listitem=li_groups, isFolder=True)

    url_recording = common.build_url({'mode': 'provider_settings_recording', 'portal': json.dumps(current_portal)})
    li_recording = xbmcgui.ListItem('Pobieranie i nagrywanie')
    li_recording.setArt({'icon': common.icon27, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_recording, listitem=li_recording, isFolder=True)

    url_tools = common.build_url({'mode': 'provider_settings_tools', 'portal': json.dumps(current_portal)})
    li_tools = xbmcgui.ListItem('Skróty klawiszowe')
    li_tools.setArt({'icon': common.icon28, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_tools, listitem=li_tools, isFolder=True)

    url_proxy = common.build_url({'mode': 'proxy_settings'})
    li_proxy = xbmcgui.ListItem('Proxy/VPN')
    li_proxy.setArt({'icon': common.icon10, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_proxy, listitem=li_proxy, isFolder=True)

    url_cache = common.build_url({'mode': 'cache', 'portal': json.dumps(current_portal)})
    li_cache = xbmcgui.ListItem('Skasuj plik EPG')
    li_cache.setArt({'icon': common.icon29, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_cache, listitem=li_cache, isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)


def GroupsSettingsLevel(portal):
    current_portal = common.get_provider_by_id(portal.get('id', '')) or portal
    xbmcplugin.setContent(common.addon_handle, 'files')

    url_edit_pl = common.build_url({'mode': 'edit_pl_supergroup', 'portal': json.dumps(current_portal)})
    li_edit_pl = xbmcgui.ListItem('Edytuj grupy polskie')
    li_edit_pl.setArt({'icon': common.icon1, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_edit_pl, listitem=li_edit_pl, isFolder=False)

    url_groups_vod = common.build_url({'mode': 'open_group_select', 'g_type': 'vod', 'portal': json.dumps(current_portal)})
    li_groups_vod = xbmcgui.ListItem('Edytuj grupy filmowe')
    li_groups_vod.setArt({'icon': common.icon4, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_groups_vod, listitem=li_groups_vod, isFolder=False)

    url_groups_ser = common.build_url({'mode': 'open_group_select', 'g_type': 'ser', 'portal': json.dumps(current_portal)})
    li_groups_ser = xbmcgui.ListItem('Edytuj grupy seriale')
    li_groups_ser.setArt({'icon': common.icon5, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_groups_ser, listitem=li_groups_ser, isFolder=False)

    url_groups_tv = common.build_url({'mode': 'open_group_select', 'g_type': 'tv', 'portal': json.dumps(current_portal)})
    li_groups_tv = xbmcgui.ListItem('Edytuj grupy zagraniczne')
    li_groups_tv.setArt({'icon': common.icon10, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_groups_tv, listitem=li_groups_tv, isFolder=False)

    url_hidden = common.build_url({'mode': 'hidden_manager', 'portal': json.dumps(current_portal)})
    li_hidden = xbmcgui.ListItem('Zarządzaj ukrytymi kanałami')
    li_hidden.setArt({'icon': common.icon30, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_hidden, listitem=li_hidden, isFolder=True)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)


def RecordingSettingsLevel(portal):
    current_portal = common.get_provider_by_id(portal.get('id', '')) or portal
    xbmcplugin.setContent(common.addon_handle, 'files')

    # ── STATUS NAGRYWANIA ────────────────────────────────
    recording_status = recorder.get_recording_status()
    if recording_status.get('active'):
        li_status = xbmcgui.ListItem('Nagrywanie')
        li_status.setArt({'icon': common.icon25, 'thumb': common.icon25, 'fanart': common.fanart})
        xbmcplugin.addDirectoryItem(
            handle=common.addon_handle,
            url=common.build_url({'mode': 'refresh_list'}),
            listitem=li_status,
            isFolder=False
        )

        url_info = common.build_url({'mode': 'recording_info'})
        li_info = xbmcgui.ListItem('Info o nagrywaniu')
        li_info.setArt({'icon': common.icon_info, 'fanart': common.fanart})
        xbmcplugin.addDirectoryItem(
            handle=common.addon_handle,
            url=url_info,
            listitem=li_info,
            isFolder=False
        )

        url_stop = common.build_url({'mode': 'record_tv_stop'})
        li_stop = xbmcgui.ListItem('Stop nagrywania')
        li_stop.setArt({'icon': common.icon26, 'thumb': common.icon26, 'fanart': common.fanart})
        xbmcplugin.addDirectoryItem(
            handle=common.addon_handle,
            url=url_stop,
            listitem=li_stop,
            isFolder=False
        )
    else:
        li_status = xbmcgui.ListItem('Status nagrywania')
        li_status.setArt({'icon': common.icon26, 'thumb': common.icon26, 'fanart': common.fanart})
        xbmcplugin.addDirectoryItem(
            handle=common.addon_handle,
            url=common.build_url({'mode': 'refresh_list'}),
            listitem=li_status,
            isFolder=False
        )

    # ── MENEDŻER POBIERANIA ──────────────────────────────
    dl_status = downloader.get_download_status()
    if dl_status.get('active'):
        dl_title = dl_status.get('title', '')
        dl_percent = dl_status.get('percent', 0)
        dl_speed = dl_status.get('speed', '')
        dl_icon = common.icon25
        dl_label = f'Menedżer pobierania  |  {dl_title} [{dl_percent}% {dl_speed}]'
    else:
        dl_icon = common.icon26
        dl_label = 'Menedżer pobierania'

    url_dl_mgr = common.build_url({'mode': 'download_manager'})
    li_dl_mgr = xbmcgui.ListItem(dl_label)
    li_dl_mgr.setArt({'icon': dl_icon, 'thumb': dl_icon, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle,
        url=url_dl_mgr,
        listitem=li_dl_mgr,
        isFolder=True
    )

    # ── TIMESHIFT ────────────────────────────────────────
    ts_icon = common.icon25 if timeshift.is_timeshift_enabled() else common.icon26
    url_ts = common.build_url({'mode': 'toggle_timeshift'})
    li_ts = xbmcgui.ListItem('Status timeshift')
    li_ts.setArt({'icon': ts_icon, 'thumb': ts_icon, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle,
        url=url_ts,
        listitem=li_ts,
        isFolder=False
    )

    url_schedule = common.build_url({'mode': 'record_schedule_manager'})
    li_schedule = xbmcgui.ListItem('Programator nagrań')
    li_schedule.setArt({'icon': common.icon31, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle,
        url=url_schedule,
        listitem=li_schedule,
        isFolder=True
    )

    current_recordings_dir = common.addon.getSetting('recordings_dir').strip()
    if not current_recordings_dir:
        current_recordings_dir = 'Nie ustawiono'

    url_choose_dir = common.build_url({'mode': 'choose_recordings_dir'})
    li_choose_dir = xbmcgui.ListItem(f'Folder nagrań i pobrań\n{current_recordings_dir}')
    li_choose_dir.setArt({'icon': common.icon41, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle,
        url=url_choose_dir,
        listitem=li_choose_dir,
        isFolder=False
    )

    url_media = common.build_url({'mode': 'media_manager'})
    li_media = xbmcgui.ListItem('Pobrane i nagrane')
    li_media.setArt({'icon': common.icon27, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle,
        url=url_media,
        listitem=li_media,
        isFolder=True
    )

    url_m3u = common.build_url({'mode': 'm3u_lists_menu', 'portal': json.dumps(current_portal)})
    li_m3u = xbmcgui.ListItem('Listy M3U')
    li_m3u.setArt({'icon': common.icon6, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle,
        url=url_m3u,
        listitem=li_m3u,
        isFolder=True
    )

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)


def M3UListsLevel(portal):
    current_portal = common.get_provider_by_id(portal.get('id', '')) or portal
    xbmcplugin.setContent(common.addon_handle, 'files')

    url_export = common.build_url({'mode': 'export_polish_m3u', 'portal': json.dumps(current_portal)})
    li_export = xbmcgui.ListItem('Zapisz polskie kanały do pliku M3U')
    li_export.setArt({'icon': common.icon20, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle,
        url=url_export,
        listitem=li_export,
        isFolder=False
    )

    url_open_exports = common.build_url({'mode': 'open_exports_dir'})
    li_open_exports = xbmcgui.ListItem('Otwórz folder zapisu pliku M3U')
    li_open_exports.setArt({'icon': common.icon11, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(
        handle=common.addon_handle,
        url=url_open_exports,
        listitem=li_open_exports,
        isFolder=False
    )

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)


def ToolsSettingsLevel(portal):
    xbmcplugin.setContent(common.addon_handle, 'files')
    xbmcplugin.setPluginCategory(common.addon_handle, 'Ustawienia klawiszowe')

    current_ov = keymap_tools._get_setting("kv_overlay_name", "O")
    url_ov = common.build_url({'mode': 'set_keymap_overlay'})
    li_ov = xbmcgui.ListItem(f'Skrót otwierania listy kanałów: [COLOR gold]{current_ov}[/COLOR]')
    li_ov.setArt({'icon': common.icon28, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, url_ov, li_ov, False)

    url_sw = common.build_url({'mode': 'set_keymap_switches'})
    li_sw = xbmcgui.ListItem('Skrót przełączania kanałów')
    li_sw.setArt({'icon': common.icon28, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, url_sw, li_sw, False)

    lock_icon = common.icon25 if keymap_tools._get_setting("kv_mouse_lock", "false") == "true" else common.icon26
    url_lock = common.build_url({'mode': 'set_keymap_mouselock'})
    li_lock = xbmcgui.ListItem('Blokada OSD na ruch myszki')
    li_lock.setArt({'icon': lock_icon, 'thumb': lock_icon, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, url_lock, li_lock, False)

    url_apply = common.build_url({'mode': 'apply_keymap'})
    li_apply = xbmcgui.ListItem('Utwórz wybrane skróty')
    li_apply.setArt({'icon': common.icon13, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, url_apply, li_apply, False)

    url_rm = common.build_url({'mode': 'remove_keymap'})
    li_rm = xbmcgui.ListItem('Usuń wszystkie wybrane skróty')
    li_rm.setArt({'icon': common.icon29, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, url_rm, li_rm, False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)