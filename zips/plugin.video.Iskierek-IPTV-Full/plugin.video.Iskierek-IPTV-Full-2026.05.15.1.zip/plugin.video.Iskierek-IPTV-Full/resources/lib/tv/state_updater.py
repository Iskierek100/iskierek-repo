# -*- coding: utf-8 -*-
import time

import xbmc

from resources.lib import common
from resources.lib.tv import live as tv_live


def _looks_like_tv_state(state):
    try:
        channels = state.get('channels', [])
        portal = state.get('portal', {})

        if not channels or not portal:
            return False

        sample = channels[0]
        if 'cmd' not in sample:
            return False
        if 'group_name' not in sample:
            return False

        return True
    except Exception:
        return False


def _should_refresh_tv_state(state):
    try:
        if not xbmc.Player().isPlaying():
            return False

        if not _looks_like_tv_state(state):
            return False

        current_index = int(state.get('current_index', -1))
        channels = state.get('channels', [])

        if current_index < 0 or current_index >= len(channels):
            return True

        current_item = channels[current_index]
        stop_ts = int(float(current_item.get('stop_ts', 0) or 0))
        now_ts = int(time.time())

        if not stop_ts:
            return True

        if now_ts >= stop_ts - 15:
            return True

        return False
    except Exception:
        return False


def run_state_updater_loop():
    monitor = xbmc.Monitor()
    last_refresh_ts = 0

    xbmc.log('[StateUpdater] started', xbmc.LOGINFO)

    while not monitor.abortRequested():
        try:
            state = common.read_json_safe(common.channel_state_file)

            if _should_refresh_tv_state(state):
                now_ts = int(time.time())

                if now_ts - last_refresh_ts >= 30:
                    portal = state.get('portal', {})
                    if portal:
                        ok = tv_live.rebuild_all_polish_channel_state(portal)
                        xbmc.log(f'[StateUpdater] rebuild_all_polish_channel_state result={ok}', xbmc.LOGINFO)
                        last_refresh_ts = now_ts

        except Exception as e:
            xbmc.log(f'[StateUpdater] loop error: {e}', xbmc.LOGERROR)

        if monitor.waitForAbort(10):
            break

    xbmc.log('[StateUpdater] stopped', xbmc.LOGINFO)