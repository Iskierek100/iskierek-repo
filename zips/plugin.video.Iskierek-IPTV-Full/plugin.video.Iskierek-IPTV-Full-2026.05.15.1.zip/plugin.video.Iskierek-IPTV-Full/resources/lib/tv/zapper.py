# -*- coding: utf-8 -*-
import time
import threading
import xbmc
import xbmcgui

from resources.lib import common
from resources.lib.tv import channel_switch
from resources.lib import timeshift

PROP_PREFIX = 'Iskierek.ChannelSwitch'
PROP_LAST_ACTION_TIME = f'{PROP_PREFIX}.LastActionTime'
PROP_ZAPPER_OPEN = f'{PROP_PREFIX}.ZapperOpen'

PROP_PLAYBACK_PLUGIN = 'IskierekPlaybackPlugin'
PROP_TV_PLAYBACK_ACTIVE = 'IskierekTvPlaybackActive'
ALLOWED_ADDON_ID = 'plugin.video.Iskierek-IPTV-Full'


def _get_bool_setting(setting_id, default=False):
    try:
        return common.addon.getSetting(setting_id) == 'true'
    except Exception:
        return default


def _get_int_setting(setting_id, default=2000):
    try:
        v = common.addon.getSetting(setting_id)
        return int(v) if str(v).strip().isdigit() else default
    except Exception:
        return default


def _can_open_zapper():
    try:
        win = xbmcgui.Window(10000)

        # musi być aktywny właściwy plugin
        if win.getProperty(PROP_PLAYBACK_PLUGIN) != ALLOWED_ADDON_ID:
            return False

        # musi być aktywne odtwarzanie TV
        if win.getProperty(PROP_TV_PLAYBACK_ACTIVE) != '1':
            return False

        return True
    except Exception:
        return False


class ZapperWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super(ZapperWindow, self).__init__(*args, **kwargs)
        self._closed = False

        self.auto_switch = _get_bool_setting('zapper_auto_switch', False)
        self.auto_delay_ms = _get_int_setting('zapper_auto_delay_ms', 2000)

    def onInit(self):
        if not _can_open_zapper():
            self.close()
            return

        xbmcgui.Window(10000).setProperty(PROP_ZAPPER_OPEN, '1')
        channel_switch.preview_init_to_current()
        self._update_timeshift_icon()

        try:
            self.setFocusId(20)
        except Exception:
            try:
                self.setFocusId(1)
            except Exception:
                pass

        if self.auto_switch:
            self._touch()
            self._start_idle_timer()

    def _update_timeshift_icon(self):
        try:
            ts_off = self.getControl(38)
            ts_on = self.getControl(39)

            if timeshift.is_timeshift_enabled():
                ts_off.setVisible(False)
                ts_on.setVisible(True)
            else:
                ts_off.setVisible(True)
                ts_on.setVisible(False)
        except Exception:
            pass

    def onAction(self, action):
        if self._closed:
            return

        act = action.getId()

        ACTION_MOVE_UP = 3
        ACTION_MOVE_DOWN = 4
        ACTION_PAGE_UP = 5
        ACTION_PAGE_DOWN = 6
        ACTION_PREVIOUS_MENU = 10
        ACTION_SELECT_ITEM = 7
        ACTION_NAV_BACK = 92
        ACTION_ENTER = 135

        ACTION_MOUSE_WHEEL_UP = 104
        ACTION_MOUSE_WHEEL_DOWN = 105

        if act in (ACTION_MOUSE_WHEEL_UP, ACTION_MOVE_UP, ACTION_PAGE_UP):
            channel_switch.preview_step(-1)
            if self.auto_switch:
                self._touch()
            return

        if act in (ACTION_MOUSE_WHEEL_DOWN, ACTION_MOVE_DOWN, ACTION_PAGE_DOWN):
            channel_switch.preview_step(1)
            if self.auto_switch:
                self._touch()
            return

        if act in (ACTION_SELECT_ITEM, ACTION_ENTER):
            channel_switch.preview_commit_now()
            self.close()
            return

        if act in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            channel_switch.preview_cancel()
            self.close()
            return

    def onClick(self, controlId):
        if controlId in (38, 39):
            try:
                timeshift.toggle_timeshift()
            except Exception:
                pass
            xbmc.sleep(200)
            self._update_timeshift_icon()
            return

        if controlId in (20, 21):
            channel_switch.preview_commit_now()
            self.close()
            return

    def _touch(self):
        xbmcgui.Window(10000).setProperty(PROP_LAST_ACTION_TIME, str(time.time()))

    def _start_idle_timer(self):
        def _worker():
            mon = xbmc.Monitor()
            while not mon.abortRequested() and not self._closed:
                xbmc.sleep(50)

                last = xbmcgui.Window(10000).getProperty(PROP_LAST_ACTION_TIME)
                if not last:
                    continue
                try:
                    last_t = float(last)
                except Exception:
                    continue

                if (time.time() - last_t) * 1000.0 >= float(self.auto_delay_ms):
                    channel_switch.preview_commit_now()
                    try:
                        self.close()
                    except Exception:
                        pass
                    return

        t = threading.Thread(target=_worker)
        t.daemon = True
        t.start()

    def close(self):
        self._closed = True
        try:
            xbmcgui.Window(10000).clearProperty(PROP_ZAPPER_OPEN)
        except Exception:
            pass
        super(ZapperWindow, self).close()


def open_zapper():
    if not _can_open_zapper():
        return

    try:
        if xbmcgui.Window(10000).getProperty(PROP_ZAPPER_OPEN) == '1':
            return
    except Exception:
        pass

    w = ZapperWindow('zapper.xml', common.addon_path, 'Default', '1080i')
    w.doModal()
    del w
