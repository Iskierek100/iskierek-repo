# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcplugin,json,time,os
import hashlib
from resources.lib import common
from resources.lib.providers import provider_api
from resources.lib.recording import recorder
from resources.lib.tv import channel_switch
import resources.lib.core.sorting as sorting
from resources.lib.menu.provider_menu import set_portal_title
from resources.lib.tv.epg import load_epg_cache_fast, get_epg_cache_item
from resources.lib.navigation import get_progress_bar,is_adult_visible

def _calc_progress(start_ts,stop_ts):
    try:
        now=time.time()
        if not start_ts or not stop_ts or stop_ts<=start_ts: return 0
        val=int(((now-start_ts)/(stop_ts-start_ts))*100)
        if val<0: val=0
        if val>100: val=100
        return val
    except: return 0

def _build_playable_state_for_polish_tv(portal):
    sorting.reload_config()
    provider = provider_api.get_provider(portal)

    portal_key = common.get_portal_key(portal)
    custom_names = common.read_json_safe(common.custom_names_file).get(portal_key, {})
    hidden_channels = common.read_json_safe(common.hidden_channels_file).get(portal_key, [])
    default_icon = common.icon0
    bad_hosts = ['103.176.90.95']

    try:
        if portal.get('type') in ['xtream', 'm3u']:
            sorted_all = sorting.get_smart_sorted_list(provider, portal, None, None, common.addondir)
        else:
            sorted_all = sorting.get_smart_sorted_list(
                provider,
                portal['mac'],
                portal['url'],
                portal['serial'],
                common.addondir
            )
    except Exception as e:
        xbmc.log(f"[POLISH TV STATE ERROR] sorting failed: {str(e)}", xbmc.LOGERROR)
        return []

    if not sorted_all:
        return []

    saved_data = common.read_json_safe(common.selected_groups_file)
    default_groups = [g[0] for g in sorting.ORDERED_GROUPS] + ['POZOSTAŁE']
    allowed_groups = saved_data.get('pl_supergroup', default_groups)

    final_list = [
        ch for ch in sorted_all
        if ch.get('_my_group_name') in allowed_groups
    ]

    filtered_final_list = []
    for item in final_list:
        if item.get('is_header'):
            continue

        base_name = str(item.get('display_name', item.get('name', '')))
        item['_original_key'] = base_name

        if base_name in hidden_channels:
            continue

        if base_name in custom_names:
            item['display_name'] = custom_names[base_name]

        filtered_final_list.append(item)

    current_epg_cache = load_epg_cache_fast()
    playable_state = []
    state_index = 0

    for item in filtered_final_list:
        title = item.get('display_name', item.get('name', ''))
        cmd = item.get('cmd', '')

        playable_state.append({
            'title': title,
            'cmd': cmd,
            'logo_url': item.get('logo', ''),
            'plot': '',
            'program': '',
            'next_program': '',
            'progress': 0,
            'start_ts': 0,
            'stop_ts': 0,
            'group_name': item.get('_my_group_name', 'POZOSTAŁE')
        })

        item['_state_index'] = state_index
        state_index += 1

    for item in filtered_final_list:
        try:
            display_name = item.get('display_name', 'Nieznany')
            norm_name = common.clean_channel_name(display_name)

            plot_desc = "Brak informacji."
            epg_current = ""
            epg_next = ""
            start_ts = 0
            stop_ts = 0
            chosen_logo = None
            e = None

            e = get_epg_cache_item(current_epg_cache, display_name)

            if e:
                epg_logo = e.get('chan_logo') or e.get('logo') or e.get('icon')
                if epg_logo and str(epg_logo).startswith('http'):
                    if not any(host in str(epg_logo) for host in bad_hosts):
                        chosen_logo = str(epg_logo)

                plot_desc = e.get('plot', plot_desc)
                epg_current = e.get('epg_current', "")
                epg_next = e.get('epg_next', "")
                start_ts = e.get('start_ts', 0)
                stop_ts = e.get('stop_ts', 0)

            if not chosen_logo:
                portal_logo_raw = item.get("logo", "")
                if portal_logo_raw and str(portal_logo_raw).lower() != 'none':
                    if str(portal_logo_raw).startswith('http'):
                        if not any(host in str(portal_logo_raw) for host in bad_hosts):
                            chosen_logo = str(portal_logo_raw)
                    else:
                        base = portal['url'].split('/c/')[0] if '/c/' in portal['url'] else portal['url'].rstrip('/')
                        chosen_logo = f"{base}/stalker_portal/misc/logos/320/{portal_logo_raw}"

            if not chosen_logo:
                chosen_logo = default_icon

            idx = item.get('_state_index', -1)
            if 0 <= idx < len(playable_state):
                playable_state[idx]['logo_url'] = chosen_logo
                playable_state[idx]['plot'] = plot_desc
                playable_state[idx]['program'] = epg_current
                playable_state[idx]['next_program'] = epg_next
                playable_state[idx]['progress'] = _calc_progress(start_ts, stop_ts)
                playable_state[idx]['start_ts'] = start_ts
                playable_state[idx]['stop_ts'] = stop_ts

        except Exception as e:
            xbmc.log(f"[POLISH TV STATE ERROR] item build failed: {str(e)}", xbmc.LOGERROR)
            continue

    return playable_state

def _build_playable_state_for_sorted_tv(portal, filter_group='ALL_POLISH', genre_id='', genre_name=''):
    sorting.reload_config()
    provider = provider_api.get_provider(portal)

    portal_key = common.get_portal_key(portal)
    custom_names = common.read_json_safe(common.custom_names_file).get(portal_key, {})
    hidden_channels = common.read_json_safe(common.hidden_channels_file).get(portal_key, [])
    default_icon = common.icon0
    bad_hosts = ['103.176.90.95']

    try:
        if portal.get('type') in ['xtream', 'm3u']:
            sorted_all = sorting.get_smart_sorted_list(provider, portal, None, None, common.addondir)
        else:
            sorted_all = sorting.get_smart_sorted_list(
                provider,
                portal['mac'],
                portal['url'],
                portal['serial'],
                common.addondir
            )
    except Exception as e:
        xbmc.log(f"[SORTED TV STATE ERROR] sorting failed: {str(e)}", xbmc.LOGERROR)
        return []

    if not sorted_all:
        return []

    saved_data = common.read_json_safe(common.selected_groups_file)
    default_groups = [g[0] for g in sorting.ORDERED_GROUPS] + ['POZOSTAŁE']
    allowed_groups = saved_data.get('pl_supergroup', default_groups)

    if filter_group == 'ALL_POLISH':
        final_list = [
            ch for ch in sorted_all
            if ch.get('_my_group_name') in allowed_groups
        ]
    elif filter_group and filter_group not in ['', 'None']:
        final_list = [
            ch for ch in sorted_all
            if ch.get('_my_group_name') == filter_group and not ch.get('is_header')
        ]
    else:
        final_list = sorted_all

    filtered_final_list = []
    for item in final_list:
        if item.get('is_header'):
            continue

        original_key = str(item.get('display_name', item.get('name', '')))
        item['_original_key'] = original_key

        if original_key in hidden_channels:
            continue

        if original_key in custom_names:
            item['display_name'] = custom_names[original_key]

        filtered_final_list.append(item)

    current_epg_cache = load_epg_cache_fast()
    playable_state = []
    state_index = 0

    for item in filtered_final_list:
        title = item.get('display_name', item.get('name', ''))
        cmd = item.get('cmd', '')

        playable_state.append({
            'title': title,
            'orig_title': item.get('_original_key', title),
            'cmd': cmd,
            'logo_url': item.get('logo', ''),
            'plot': '',
            'program': '',
            'next_program': '',
            'progress': 0,
            'start_ts': 0,
            'stop_ts': 0,
            'group_name': item.get('_my_group_name', 'POZOSTAŁE')
        })

        item['_state_index'] = state_index
        state_index += 1

    for item in filtered_final_list:
        try:
            display_name = item.get('display_name', 'Nieznany')

            plot_desc = "Brak informacji."
            epg_current = ""
            epg_next = ""
            start_ts = 0
            stop_ts = 0
            chosen_logo = None
            e = None

            e = get_epg_cache_item(current_epg_cache, display_name)

            if e:
                epg_logo = e.get('chan_logo') or e.get('logo') or e.get('icon')
                if epg_logo and str(epg_logo).startswith('http'):
                    if not any(host in str(epg_logo) for host in bad_hosts):
                        chosen_logo = str(epg_logo)

                plot_desc = e.get('plot', plot_desc)
                epg_current = e.get('epg_current', "")
                epg_next = e.get('epg_next', "")
                start_ts = e.get('start_ts', 0)
                stop_ts = e.get('stop_ts', 0)

            if not chosen_logo:
                portal_logo_raw = item.get("logo", "")
                if portal_logo_raw and str(portal_logo_raw).lower() != 'none':
                    if str(portal_logo_raw).startswith('http'):
                        if not any(host in str(portal_logo_raw) for host in bad_hosts):
                            chosen_logo = str(portal_logo_raw)
                    else:
                        base = portal['url'].split('/c/')[0] if '/c/' in portal['url'] else portal['url'].rstrip('/')
                        chosen_logo = f"{base}/stalker_portal/misc/logos/320/{portal_logo_raw}"

            if not chosen_logo:
                chosen_logo = default_icon

            idx = item.get('_state_index', -1)
            if 0 <= idx < len(playable_state):
                playable_state[idx]['logo_url'] = chosen_logo
                playable_state[idx]['plot'] = plot_desc
                playable_state[idx]['program'] = epg_current
                playable_state[idx]['next_program'] = epg_next
                playable_state[idx]['progress'] = _calc_progress(start_ts, stop_ts)
                playable_state[idx]['start_ts'] = start_ts
                playable_state[idx]['stop_ts'] = stop_ts

        except Exception as e:
            xbmc.log(f"[SORTED TV STATE ERROR] item build failed: {str(e)}", xbmc.LOGERROR)
            continue

    return playable_state

def rebuild_all_polish_channel_state(portal):
    return rebuild_tv_channel_state(
        portal=portal,
        custom_order=True,
        filter_group='ALL_POLISH',
        genre_id='',
        genre_name='Wszystkie Polskie'
    )

def rebuild_tv_channel_state(portal, custom_order=True, filter_group='ALL_POLISH', genre_id='', genre_name='', overlay_full_state=False):
    try:
        if not custom_order:
            xbmc.log("[Iskierek IPTV Full] rebuild_tv_channel_state skipped: custom_order=False", xbmc.LOGINFO)
            return False

        effective_group = 'ALL_POLISH' if overlay_full_state else filter_group
        effective_genre_id = '' if overlay_full_state else (genre_id or '')
        effective_genre_name = 'Wszystkie Polskie' if overlay_full_state else (genre_name or '')

        playable_state = _build_playable_state_for_sorted_tv(
            portal=portal,
            filter_group=effective_group,
            genre_id=effective_genre_id,
            genre_name=effective_genre_name
        )

        if not playable_state:
            return False

        old_state = common.read_json_safe(common.channel_state_file)
        old_index = int(old_state.get('current_index', -1))
        old_channels = old_state.get('channels', [])

        current_index = -1
        current_title = ''
        current_cmd = ''

        try:
            if 0 <= old_index < len(old_channels):
                current_title = str(old_channels[old_index].get('title', '')).strip()
                current_cmd = str(old_channels[old_index].get('cmd', '')).strip()
        except Exception:
            current_title = ''
            current_cmd = ''

        if not current_title:
            try:
                playing_title = xbmc.getInfoLabel('VideoPlayer.Title') or ''
                playing_title = playing_title.strip()
                if ' : ' in playing_title:
                    playing_title = playing_title.split(' : ', 1)[0].strip()
                current_title = playing_title
            except Exception:
                current_title = ''

        if current_cmd or current_title:
            for idx, item in enumerate(playable_state):
                item_title = str(item.get('title', '')).strip()
                item_cmd = str(item.get('cmd', '')).strip()

                if current_cmd and current_title:
                    if item_cmd == current_cmd and item_title == current_title:
                        current_index = idx
                        break

        if current_index < 0 and current_cmd:
            for idx, item in enumerate(playable_state):
                item_cmd = str(item.get('cmd', '')).strip()
                if item_cmd == current_cmd:
                    current_index = idx
                    break

        if current_index < 0 and current_title:
            for idx, item in enumerate(playable_state):
                item_title = str(item.get('title', '')).strip()
                if item_title == current_title:
                    current_index = idx
                    break

        channel_switch.save_channel_state(playable_state, current_index, portal)

        try:
            state = common.read_json_safe(common.channel_state_file)

            state['state_kind'] = 'tv_sorted'
            state['state_refresh_enabled'] = True
            state['state_refresh_custom_order'] = True

            if overlay_full_state:
                state['state_refresh_group'] = 'ALL_POLISH'
                state['state_refresh_genre_id'] = ''
                state['state_refresh_genre_name'] = 'Wszystkie Polskie'
                state['start_group'] = 'WSZYSTKIE'
            else:
                state['state_refresh_group'] = filter_group if filter_group not in ['', 'None'] else 'ALL_POLISH'
                state['state_refresh_genre_id'] = genre_id or ''
                state['state_refresh_genre_name'] = genre_name or ''
                state['start_group'] = filter_group if filter_group not in ['', 'None', 'ALL_POLISH'] else 'WSZYSTKIE'

            common.write_json_safe(common.channel_state_file, state)
        except Exception as e:
            xbmc.log(f"[Iskierek IPTV Full] save sorted TV refresh meta error: {str(e)}", xbmc.LOGERROR)

        xbmc.log(
            f"[Iskierek IPTV Full] rebuilt sorted TV channel_state, items={len(playable_state)}, current_index={current_index}, current_title={current_title}, current_cmd={current_cmd}, group={effective_group}, overlay_full_state={overlay_full_state}",
            xbmc.LOGINFO
        )
        return True

    except Exception as e:
        xbmc.log(f"[Iskierek IPTV Full] rebuild_tv_channel_state error: {str(e)}", xbmc.LOGERROR)
        return False

def refresh_existing_channel_state_epg():
    try:
        state = common.read_json_safe(common.channel_state_file)
        if not isinstance(state, dict):
            return False

        channels = state.get('channels', [])
        if not channels:
            return False

        current_epg_cache = load_epg_cache_fast()
        if not current_epg_cache:
            return False

        refreshed_channels = []

        for ch in channels:
            item = dict(ch)

            try:
                display_name = item.get('title', 'Nieznany')
                e = get_epg_cache_item(current_epg_cache, display_name)

                if e:
                    item['plot'] = e.get('plot', item.get('plot', '') or 'Brak informacji.')
                    item['program'] = e.get('epg_current', item.get('program', ''))
                    item['next_program'] = e.get('epg_next', item.get('next_program', ''))
                    item['start_ts'] = e.get('start_ts', item.get('start_ts', 0))
                    item['stop_ts'] = e.get('stop_ts', item.get('stop_ts', 0))

                    epg_logo = e.get('chan_logo') or item.get('logo_url', '')
                    if epg_logo:
                        item['logo_url'] = epg_logo

                item['progress'] = _calc_progress(
                    item.get('start_ts', 0),
                    item.get('stop_ts', 0)
                )

            except Exception as e:
                xbmc.log(f"[Iskierek IPTV Full] refresh_existing_channel_state_epg item error: {str(e)}", xbmc.LOGERROR)

            refreshed_channels.append(item)

        state['channels'] = refreshed_channels
        common.write_json_safe(common.channel_state_file, state)

        xbmc.log(f"[Iskierek IPTV Full] refresh_existing_channel_state_epg ok, items={len(refreshed_channels)}", xbmc.LOGINFO)
        return True

    except Exception as e:
        xbmc.log(f"[Iskierek IPTV Full] refresh_existing_channel_state_epg error: {str(e)}", xbmc.LOGERROR)
        return False

def channelLevel(portal):
    sorting.reload_config()
    set_portal_title(portal,'TV');provider=provider_api.get_provider(portal)
    xbmcplugin.setContent(common.addon_handle,'episodes')
    genre_name=str(common.args.get('genre_name',[""])[0]);selected_genre_id=str(common.args.get('genre_id',[None])[0]);use_custom_order=str(common.args.get('custom_order',['false'])[0])=='true';filter_group=str(common.args.get('filter_group',[None])[0])
    portal_key=common.get_portal_key(portal);custom_names=common.read_json_safe(common.custom_names_file).get(portal_key,{});hidden_channels=common.read_json_safe(common.hidden_channels_file).get(portal_key,[]);default_icon=common.icon0;bad_hosts=['103.176.90.95']
    genre_lower=(genre_name or '').lower();is_adult_genre=any(w in genre_lower for w in provider.ADULT_KEYWORDS)
    if is_adult_genre and not is_adult_visible(portal):
        xbmcgui.Dialog().ok('Blokada','Ta kategoria jest zablokowana.\nUżyj opcji "Odblokuj 18+" w menu portalu.');return

    if use_custom_order:
        try:
            if portal.get('type') in ['xtream','m3u']: sorted_all=sorting.get_smart_sorted_list(provider,portal,None,None,common.addondir)
            else: sorted_all=sorting.get_smart_sorted_list(provider,portal['mac'],portal['url'],portal['serial'],common.addondir)
        except Exception as e:
            xbmc.log(f"[CHANNEL LEVEL ERROR] use_custom_order failed: {str(e)}",xbmc.LOGERROR);xbmcgui.Dialog().ok(common.addonname,f"Błąd listy kanałów:\n{str(e)}");return
        if not sorted_all: return
        if filter_group=='ALL_POLISH':
            saved_data=common.read_json_safe(common.selected_groups_file)
            default_groups=[g[0] for g in sorting.ORDERED_GROUPS] + ['POZOSTAŁE']
            allowed_groups=saved_data.get('pl_supergroup',default_groups)
            final_list=[ch for ch in sorted_all if ch.get('_my_group_name') in allowed_groups]
        elif filter_group and filter_group!='None':
            final_list=[ch for ch in sorted_all if ch.get('_my_group_name')==filter_group and not ch.get('is_header')]
        else:
            final_list=sorted_all
    else:
        try:
            if portal.get('type') in ['xtream','m3u']: data=provider.getAllChannels(portal,common.addondir)
            else: data=provider.getAllChannels(portal['mac'],portal['url'],portal['serial'],common.addondir)
        except: return
        raw_channels=data.get('channels',[]);unique_channels={}
        for ch in raw_channels:
            if selected_genre_id!='None' and selected_genre_id!='*' and str(ch.get("genre_id"))!=selected_genre_id: continue
            clean=str(ch.get('name','Nieznany')).replace('PL:','').strip()
            for suffix in [' FHD',' HD',' VIP',' (NOCONN)',' RAW']: clean=clean.replace(suffix,'')
            clean=clean.strip()
            if clean not in unique_channels: ch['display_name']=clean;unique_channels[clean]=ch
        final_list=list(unique_channels.values());final_list.sort(key=lambda x:x.get('display_name','').lower())

    filtered_final_list=[]
    for item in final_list:
        if item.get('is_header'):
            if not use_custom_order or (filter_group and filter_group!='None'): continue
            filtered_final_list.append(item);continue
        base_name=str(item.get('display_name',item.get('name','')));item['_original_key']=base_name
        if base_name in hidden_channels: continue
        if base_name in custom_names: item['display_name']=custom_names[base_name]
        filtered_final_list.append(item)

    current_epg_cache=load_epg_cache_fast();real_channel_number=1
    playable_state=[];state_index=0

    for item in filtered_final_list:
        if item.get('is_header',False): continue
        title=item.get('display_name',item.get('name',''));cmd=item.get('cmd','')
        playable_state.append({'title':title,'cmd':cmd,'logo_url':item.get('logo',''),'plot':'','program':'','next_program':'','progress':0,'start_ts':0,'stop_ts':0,'group_name':item.get('_my_group_name','POZOSTAŁE')})
        item['_state_index']=state_index
        state_index+=1

    for i in filtered_final_list:
        try:
            display_name=i.get('display_name','Nieznany')
            if i.get('is_header',False):
                li=xbmcgui.ListItem(f"[COLOR red]<><> {display_name} <><>[/COLOR]");li.setArt({'icon':'DefaultAddonService.png','thumb':'DefaultAddonService.png'})
                xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=common.build_url({'mode':'refresh_list'}),listitem=li,isFolder=False);continue

            cmd=str(i.get("cmd") or "");norm_name=common.clean_channel_name(display_name)
            plot_desc="Brak informacji.";epg_current="";epg_next="";start_ts=0;stop_ts=0;epg_prog_img="";chosen_logo=None;e=None

            e=get_epg_cache_item(current_epg_cache,display_name)

            if e:
                epg_logo=e.get('chan_logo') or e.get('logo') or e.get('icon')
                if epg_logo and str(epg_logo).startswith('http'):
                    if not any(host in str(epg_logo) for host in bad_hosts): chosen_logo=str(epg_logo)
                plot_desc=e.get('plot',plot_desc);epg_current=e.get('epg_current',"");epg_next=e.get('epg_next',"");epg_prog_img=e.get('prog_img',"");start_ts=e.get('start_ts',0);stop_ts=e.get('stop_ts',0)

            if not chosen_logo:
                portal_logo_raw=i.get("logo","")
                if portal_logo_raw and str(portal_logo_raw).lower()!='none':
                    if str(portal_logo_raw).startswith('http'):
                        if not any(host in str(portal_logo_raw) for host in bad_hosts): chosen_logo=str(portal_logo_raw)
                    else:
                        base=portal['url'].split('/c/')[0] if '/c/' in portal['url'] else portal['url'].rstrip('/')
                        chosen_logo=f"{base}/stalker_portal/misc/logos/320/{portal_logo_raw}"
            if not chosen_logo: chosen_logo=default_icon

            idx=i.get('_state_index',-1)
            if 0<=idx<len(playable_state):
                playable_state[idx]['logo_url']=chosen_logo
                playable_state[idx]['plot']=plot_desc
                playable_state[idx]['program']=epg_current
                playable_state[idx]['next_program']=epg_next
                playable_state[idx]['progress']=_calc_progress(start_ts,stop_ts)
                playable_state[idx]['start_ts']=start_ts
                playable_state[idx]['stop_ts']=stop_ts

            rec_status=recorder.get_recording_status()
            rec_title=str(rec_status.get('title','')).strip().lower()
            channel_title=str(display_name).strip().lower()
            rec_prefix='[COLOR red]● REC[/COLOR] ' if rec_status.get('active') and rec_title==channel_title else ''
            
            ch_num=str(real_channel_number)
            if epg_current:
                bar=get_progress_bar(start_ts,stop_ts);epg_short=epg_current[:55].strip()+".." if len(epg_current)>55 else epg_current;full_label=f"{rec_prefix}[B]{ch_num}. {display_name}[/B]\n{bar} [COLOR yellow]{epg_short}[/COLOR]"
            else:
                full_label=f"{rec_prefix}[B]{ch_num}. {display_name}[/B]"

            url=common.build_url({'mode':'play_tv_ts','cmd':cmd,'title':display_name,'logo_url':chosen_logo,'portal':json.dumps(portal),'plot':plot_desc,'program':epg_current,'stop_ts':stop_ts,'channel_index':idx})
            li=xbmcgui.ListItem(full_label);final_fanart=epg_prog_img if (epg_prog_img and epg_prog_img.startswith('http')) else common.fanart
            li.setArt({'icon':chosen_logo,'thumb':chosen_logo,'poster':chosen_logo,'fanart':final_fanart,'landscape':final_fanart})
            li.setInfo(type='Video',infoLabels={'title':display_name,'plot':plot_desc,'mediatype':'channel'});li.setProperty('IsPlayable','true')

            orig_key=i.get('_original_key',display_name)
            epg_params={'mode':'show_epg','norm_name':norm_name,'icon':chosen_logo,'cmd':cmd,'channel_name':display_name,'portal':json.dumps(portal)}
            rename_params={'mode':'rename_channel','id_key':orig_key,'current_name':display_name,'portal':json.dumps(portal)}
            hide_params={'mode':'hide_channel','id_key':orig_key,'portal':json.dumps(portal)}
            settings_params={'mode':'provider_settings','portal':json.dumps(portal)}
            record_unlimited_params={'mode':'record_tv_start','cmd':cmd,'title':display_name,'logo_url':chosen_logo,'portal':json.dumps(portal),'stop_ts':stop_ts,'record_mode':'unlimited'}
            record_program_params={'mode':'record_tv_program','cmd':cmd,'title':display_name,'logo_url':chosen_logo,'portal':json.dumps(portal),'start_ts':start_ts,'stop_ts':stop_ts}
            record_custom_params={'mode':'record_tv_start','cmd':cmd,'title':display_name,'logo_url':chosen_logo,'portal':json.dumps(portal),'stop_ts':stop_ts,'record_mode':'custom'}
            record_stop_params={'mode':'record_tv_stop','portal':json.dumps(portal)}
            record_info_params={'mode':'recording_info','portal':json.dumps(portal)}
            timeshift_toggle_params={'mode':'toggle_timeshift'}
            guide_params={
                'mode':'tv_guide',
                'custom_order':common.args.get('custom_order',['false'])[0],
                'filter_group':common.args.get('filter_group',[''])[0],
                'genre_id':common.args.get('genre_id',[''])[0],
                'genre_name':common.args.get('genre_name',[''])[0],
                'portal':json.dumps(portal)
            }
            
            # proxy_test_params = {
            #     'mode': 'proxy_test_for_channel',
            #     'cmd': cmd,
            #     'title': display_name,
            #     'logo_url': chosen_logo,
            #     'portal': json.dumps(portal)
            # }

            # proxy_pick_favorite_params = {
            #     'mode': 'proxy_pick_favorite_for_channel',
            #     'cmd': cmd,
            #     'title': display_name,
            #     'logo_url': chosen_logo,
            #     'portal': json.dumps(portal),
            #     'plot': plot_desc,
            #     'program': epg_current,
            #     'stop_ts': stop_ts,
            #     'channel_index': idx
            # }
            # proxy_cycle_favorite_params = {
            #     'mode': 'proxy_cycle_favorite_for_channel',
            #     'cmd': cmd,
            #     'title': display_name,
            #     'logo_url': chosen_logo,
            #     'portal': json.dumps(portal),
            #     'plot': plot_desc,
            #     'program': epg_current,
            #     'stop_ts': stop_ts,
            #     'channel_index': idx
            # }
            
            context_items=[
                
                #('[COLOR cyan]Testuj proxy dla tego kanału[/COLOR]',f'RunPlugin({common.build_url(proxy_test_params)})'),
                #('[COLOR gold]Następne ulubione proxy i odtwórz[/COLOR]',f'RunPlugin({common.build_url(proxy_cycle_favorite_params)})'),
                #('[COLOR cyan]Ulubione proxy dla tego kanału[/COLOR]',f'RunPlugin({common.build_url(proxy_pick_favorite_params)})'),
                
                ('[COLOR yellow]Pełny przewodnik TV[/COLOR]',f'RunPlugin({common.build_url(guide_params)})'),
                ('[COLOR yellow]Włącz/Wyłącz timeshift[/COLOR]',f'RunPlugin({common.build_url(timeshift_toggle_params)})'),
                ('[COLOR yellow]Nagraj bez limitu[/COLOR]',f'RunPlugin({common.build_url(record_unlimited_params)})'),
                ('[COLOR yellow]Nagraj do końca programu[/COLOR]',f'RunPlugin({common.build_url(record_program_params)})'),
                ('[COLOR yellow]Nagraj własny czas[/COLOR]',f'RunPlugin({common.build_url(record_custom_params)})'),
                ('[COLOR yellow]Zmień nazwę[/COLOR]',f'RunPlugin({common.build_url(rename_params)})'),
                ('[COLOR yellow]Ukryj kanał[/COLOR]',f'RunPlugin({common.build_url(hide_params)})'),
                ('[COLOR orange]Ustawienia[/COLOR]',f'Container.Update({common.build_url(settings_params)})')
            ]

            if recorder.is_recording_active():
                context_items.append(('[COLOR yellow]Info o nagrywaniu[/COLOR]',f'RunPlugin({common.build_url(record_info_params)})'))
                context_items.append(('[COLOR red]Stop nagrywania[/COLOR]',f'RunPlugin({common.build_url(record_stop_params)})'))

            context_items.append(('[COLOR yellow]Odśwież listę[/COLOR]','Container.Refresh'))
            li.addContextMenuItems(context_items)

            xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=False);real_channel_number+=1
        except: continue

    channel_switch.save_channel_state(playable_state,-1,portal)

    try:
        state=common.read_json_safe(common.channel_state_file)

        if use_custom_order:
            state['state_kind']='tv_sorted'
            state['state_refresh_enabled']=True
            state['state_refresh_custom_order']=True
            state['state_refresh_group']=filter_group if filter_group not in [None,'None',''] else 'ALL_POLISH'
            state['state_refresh_genre_id']=common.args.get('genre_id',[''])[0]
            state['state_refresh_genre_name']=common.args.get('genre_name',[''])[0]
        else:
            state['state_kind']='tv_provider'
            state['state_refresh_enabled']=False
            state['state_refresh_custom_order']=False
            state['state_refresh_group']=''
            state['state_refresh_genre_id']=common.args.get('genre_id',[''])[0]
            state['state_refresh_genre_name']=common.args.get('genre_name',[''])[0]

        if use_custom_order and filter_group and filter_group not in ['None','ALL_POLISH','']:
            state['start_group']=filter_group
        else:
            state['start_group']='WSZYSTKIE'

        common.write_json_safe(common.channel_state_file,state)
    except Exception as e:
        xbmc.log(f"[Iskierek IPTV Full] save start_group error: {str(e)}",xbmc.LOGERROR)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=False)

def build_live_channel_data(portal, custom_order=True, filter_group='ALL_POLISH', genre_id='', genre_name=''):
    sorting.reload_config()
    provider = provider_api.get_provider(portal)

    portal_key = common.get_portal_key(portal)
    custom_names = common.read_json_safe(common.custom_names_file).get(portal_key, {})
    hidden_channels = common.read_json_safe(common.hidden_channels_file).get(portal_key, [])
    default_icon = common.icon0
    bad_hosts = ['103.176.90.95']

    genre_lower = (genre_name or '').lower()
    is_adult_genre = any(w in genre_lower for w in provider.ADULT_KEYWORDS)
    if is_adult_genre and not is_adult_visible(portal):
        return {'error': 'adult_locked', 'channels': [], 'groups': []}

    if custom_order:
        try:
            if portal.get('type') in ['xtream', 'm3u']:
                sorted_all = sorting.get_smart_sorted_list(provider, portal, None, None, common.addondir)
            else:
                sorted_all = sorting.get_smart_sorted_list(
                    provider,
                    portal['mac'],
                    portal['url'],
                    portal['serial'],
                    common.addondir
                )
        except Exception as e:
            xbmc.log(f"[LIVE XML] build_live_channel_data sorting error: {str(e)}", xbmc.LOGERROR)
            return {'error': str(e), 'channels': [], 'groups': []}

        if not sorted_all:
            return {'error': '', 'channels': [], 'groups': []}

        if filter_group == 'ALL_POLISH':
            saved_data = common.read_json_safe(common.selected_groups_file)
            default_groups = [g[0] for g in sorting.ORDERED_GROUPS] + ['POZOSTAŁE']
            allowed_groups = saved_data.get('pl_supergroup', default_groups)
            final_list = [ch for ch in sorted_all if ch.get('_my_group_name') in allowed_groups]
        elif filter_group and filter_group != 'None':
            final_list = [ch for ch in sorted_all if ch.get('_my_group_name') == filter_group and not ch.get('is_header')]
        else:
            final_list = sorted_all
    else:
        try:
            if portal.get('type') in ['xtream', 'm3u']:
                data = provider.getAllChannels(portal, common.addondir)
            else:
                data = provider.getAllChannels(portal['mac'], portal['url'], portal['serial'], common.addondir)
        except Exception as e:
            xbmc.log(f"[LIVE XML] build_live_channel_data provider error: {str(e)}", xbmc.LOGERROR)
            return {'error': str(e), 'channels': [], 'groups': []}

        raw_channels = data.get('channels', [])
        unique_channels = {}
        for ch in raw_channels:
            if genre_id != 'None' and genre_id != '*' and str(ch.get("genre_id")) != str(genre_id):
                continue

            clean = str(ch.get('name', 'Nieznany')).replace('PL:', '').strip()
            for suffix in [' FHD', ' HD', ' VIP', ' (NOCONN)', ' RAW']:
                clean = clean.replace(suffix, '')
            clean = clean.strip()

            if clean not in unique_channels:
                ch['display_name'] = clean
                unique_channels[clean] = ch

        final_list = list(unique_channels.values())
        final_list.sort(key=lambda x: x.get('display_name', '').lower())

    filtered_final_list = []
    for item in final_list:
        if item.get('is_header'):
            continue

        original_key = str(item.get('display_name', item.get('name', '')))
        item['_original_key'] = original_key

        if original_key in hidden_channels:
            continue

        if original_key in custom_names:
            item['display_name'] = custom_names[original_key]

        filtered_final_list.append(item)

    current_epg_cache = load_epg_cache_fast()
    result_channels = []
    groups = []
    rec_status = recorder.get_recording_status()
    rec_active = rec_status.get('active')
    rec_title = str(rec_status.get('title', '')).strip().lower()

    real_channel_number = 1

    for item in filtered_final_list:
        try:
            display_name = item.get('display_name', item.get('name', 'Nieznany'))
            cmd = str(item.get('cmd') or '')
            group_name = item.get('_my_group_name', 'POZOSTAŁE')
            orig_key = item.get('_original_key', display_name)

            if group_name not in groups:
                groups.append(group_name)

            plot_desc = "Brak informacji."
            epg_current = ""
            epg_next = ""
            start_ts = 0
            stop_ts = 0
            epg_prog_img = ""
            chosen_logo = None
            guide_items = []

            e = get_epg_cache_item(current_epg_cache, display_name)

            if e:
                epg_logo = e.get('chan_logo') or e.get('logo') or e.get('icon')
                if epg_logo and str(epg_logo).startswith('http'):
                    if not any(host in str(epg_logo) for host in bad_hosts):
                        chosen_logo = str(epg_logo)

                plot_desc = e.get('plot', plot_desc)
                epg_current = e.get('epg_current', "")
                epg_next = e.get('epg_next', "")
                epg_prog_img = e.get('prog_img', "")
                start_ts = e.get('start_ts', 0)
                stop_ts = e.get('stop_ts', 0)
                guide_items = e.get('guide_items', []) or []

            if not chosen_logo:
                portal_logo_raw = item.get("logo", "")
                if portal_logo_raw and str(portal_logo_raw).lower() != 'none':
                    if str(portal_logo_raw).startswith('http'):
                        if not any(host in str(portal_logo_raw) for host in bad_hosts):
                            chosen_logo = str(portal_logo_raw)
                    else:
                        base = portal['url'].split('/c/')[0] if '/c/' in portal['url'] else portal['url'].rstrip('/')
                        chosen_logo = f"{base}/stalker_portal/misc/logos/320/{portal_logo_raw}"

            if not chosen_logo:
                chosen_logo = default_icon

            is_recording = rec_active and rec_title == str(display_name).strip().lower()
            progress_val = _calc_progress(start_ts, stop_ts)

            fanart = epg_prog_img if (epg_prog_img and str(epg_prog_img).startswith('http')) else common.fanart
            image = epg_prog_img if (epg_prog_img and str(epg_prog_img).startswith('http')) else chosen_logo

            result_channels.append({
                'title': display_name,
                '_original_key': orig_key,
                'cmd': cmd,
                'logo_url': chosen_logo,
                'plot': plot_desc,
                'program': epg_current,
                'next_program': epg_next,
                'progress': progress_val,
                'start_ts': start_ts,
                'stop_ts': stop_ts,
                'group_name': group_name,
                'prog_img': epg_prog_img,
                'fanart': fanart,
                'image': image,
                'is_recording': is_recording,
                'channel_number': real_channel_number,
                'guide_items': guide_items
            })

            real_channel_number += 1

        except Exception as e:
            xbmc.log(f"[LIVE XML] build_live_channel_data item error: {str(e)}", xbmc.LOGERROR)
            continue

    final_groups = ['WSZYSTKIE'] + groups if groups else ['WSZYSTKIE']

    save_live_window_cache(
        portal=portal,
        channels=result_channels,
        groups=final_groups,
        custom_order=custom_order,
        filter_group=filter_group,
        genre_id=genre_id,
        genre_name=genre_name
    )

    return {
        'error': '',
        'channels': result_channels,
        'groups': final_groups
    }

def save_live_channel_state_from_data(channels, current_index, portal):
    try:
        playable_state = []

        for ch in channels:
            playable_state.append({
                'title': ch.get('title', ''),
                'cmd': ch.get('cmd', ''),
                'logo_url': ch.get('logo_url', ''),
                'plot': ch.get('plot', ''),
                'program': ch.get('program', ''),
                'next_program': ch.get('next_program', ''),
                'progress': ch.get('progress', 0),
                'start_ts': ch.get('start_ts', 0),
                'stop_ts': ch.get('stop_ts', 0),
                'group_name': ch.get('group_name', 'POZOSTAŁE')
            })

        xbmc.log(
            f"[LIVE XML] save_live_channel_state_from_data channels={len(playable_state)} current_index={current_index}",
            xbmc.LOGINFO
        )

        channel_switch.save_channel_state(playable_state, current_index, portal)
        return True

    except Exception as e:
        xbmc.log(f"[LIVE XML] save_live_channel_state_from_data error: {str(e)}", xbmc.LOGERROR)
        return False

def clear_live_window_cache():
    try:
        if os.path.exists(common.live_window_cache_file):
            os.remove(common.live_window_cache_file)
            xbmc.log("[LIVE XML CACHE] cache cleared", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[LIVE XML CACHE] clear error: {str(e)}", xbmc.LOGERROR)

def _build_live_cache_key(portal, custom_order=True, filter_group='ALL_POLISH', genre_id='', genre_name=''):
    try:
        portal_key = common.get_portal_key(portal)
    except Exception:
        portal_key = 'unknown'

    raw = {
        'portal_key': portal_key,
        'custom_order': bool(custom_order),
        'filter_group': str(filter_group or ''),
        'genre_id': str(genre_id or ''),
        'genre_name': str(genre_name or '')
    }

    return hashlib.md5(json.dumps(raw, sort_keys=True).encode('utf-8')).hexdigest()


def load_live_window_cache(portal, custom_order=True, filter_group='ALL_POLISH', genre_id='', genre_name=''):
    try:
        data = common.read_json_safe(common.live_window_cache_file)
        if not isinstance(data, dict):
            return None

        cache_key = _build_live_cache_key(portal, custom_order, filter_group, genre_id, genre_name)
        item = data.get(cache_key)

        if not isinstance(item, dict):
            return None

        channels = item.get('channels', [])
        groups = item.get('groups', [])

        if not isinstance(channels, list) or not channels:
            return None

        return {
            'error': '',
            'channels': channels,
            'groups': groups
        }
    except Exception as e:
        xbmc.log(f"[LIVE XML CACHE] load error: {str(e)}", xbmc.LOGERROR)
        return None


def save_live_window_cache(portal, channels, groups, custom_order=True, filter_group='ALL_POLISH', genre_id='', genre_name=''):
    try:
        all_cache = common.read_json_safe(common.live_window_cache_file)
        if not isinstance(all_cache, dict):
            all_cache = {}

        cache_key = _build_live_cache_key(portal, custom_order, filter_group, genre_id, genre_name)

        all_cache[cache_key] = {
            'saved_at': int(time.time()),
            'channels': channels,
            'groups': groups
        }

        common.write_json_safe(common.live_window_cache_file, all_cache)
        return True
    except Exception as e:
        xbmc.log(f"[LIVE XML CACHE] save error: {str(e)}", xbmc.LOGERROR)
        return False

def rebuild_tv_channel_state_from_live_cache(portal, custom_order=True, filter_group='ALL_POLISH', genre_id='', genre_name=''):
    try:
        data = load_live_window_cache(
            portal=portal,
            custom_order=custom_order,
            filter_group=filter_group,
            genre_id=genre_id,
            genre_name=genre_name
        )

        if not data:
            data = build_live_channel_data(
                portal=portal,
                custom_order=custom_order,
                filter_group=filter_group,
                genre_id=genre_id,
                genre_name=genre_name
            )

        channels = data.get('channels', [])
        if not channels:
            return False

        playable_state = []
        for ch in channels:
            playable_state.append({
                'title': ch.get('title', ''),
                'cmd': ch.get('cmd', ''),
                'logo_url': ch.get('logo_url', ''),
                'plot': ch.get('plot', ''),
                'program': ch.get('program', ''),
                'next_program': ch.get('next_program', ''),
                'progress': ch.get('progress', 0),
                'start_ts': ch.get('start_ts', 0),
                'stop_ts': ch.get('stop_ts', 0),
                'group_name': ch.get('group_name', 'POZOSTAŁE')
            })

        old_state = common.read_json_safe(common.channel_state_file)
        old_index = int(old_state.get('current_index', -1))
        old_channels = old_state.get('channels', [])

        current_index = -1
        current_title = ''
        current_cmd = ''

        try:
            if 0 <= old_index < len(old_channels):
                current_title = str(old_channels[old_index].get('title', '')).strip()
                current_cmd = str(old_channels[old_index].get('cmd', '')).strip()
        except Exception:
            current_title = ''
            current_cmd = ''

        if not current_title:
            try:
                playing_title = xbmc.getInfoLabel('VideoPlayer.Title') or ''
                playing_title = playing_title.strip()
                if ' : ' in playing_title:
                    playing_title = playing_title.split(' : ', 1)[0].strip()
                current_title = playing_title
            except Exception:
                current_title = ''

        if current_cmd or current_title:
            for idx, item in enumerate(playable_state):
                item_title = str(item.get('title', '')).strip()
                item_cmd = str(item.get('cmd', '')).strip()

                if current_cmd and current_title:
                    if item_cmd == current_cmd and item_title == current_title:
                        current_index = idx
                        break

        if current_index < 0 and current_cmd:
            for idx, item in enumerate(playable_state):
                item_cmd = str(item.get('cmd', '')).strip()
                if item_cmd == current_cmd:
                    current_index = idx
                    break

        if current_index < 0 and current_title:
            for idx, item in enumerate(playable_state):
                item_title = str(item.get('title', '')).strip()
                if item_title == current_title:
                    current_index = idx
                    break

        channel_switch.save_channel_state(playable_state, current_index, portal)

        try:
            state = common.read_json_safe(common.channel_state_file)

            state['state_kind'] = 'tv_sorted'
            state['state_refresh_enabled'] = True
            state['state_refresh_custom_order'] = True
            state['state_refresh_group'] = filter_group if filter_group not in ['', 'None'] else 'ALL_POLISH'
            state['state_refresh_genre_id'] = genre_id or ''
            state['state_refresh_genre_name'] = genre_name or ''
            state['start_group'] = filter_group if filter_group not in ['', 'None', 'ALL_POLISH'] else 'WSZYSTKIE'

            common.write_json_safe(common.channel_state_file, state)
        except Exception as e:
            xbmc.log(f"[LIVE XML CACHE] save state meta error: {str(e)}", xbmc.LOGERROR)

        return True

    except Exception as e:
        xbmc.log(f"[LIVE XML CACHE] rebuild_tv_channel_state_from_live_cache error: {str(e)}", xbmc.LOGERROR)
        return False