# -*- coding: utf-8 -*-
import json
import time

import xbmc
import xbmcgui

from resources.lib import common
from resources.lib.providers import provider_api
from resources.lib.tv import channel_switch
from resources.lib.recording import recorder
import resources.lib.core.sorting as sorting
from resources.lib.navigation import is_adult_visible
from resources.lib.tv import guide_overlay
from resources.lib.tv import program_info


VISIBLE_ROWS = 5
VISIBLE_PROGRAMS = 5

# USUWAMY: HEADER_GROUP_LEFT_ID = 31, HEADER_GROUP_RIGHT_ID = 32, HEADER_HOME_ID = 33
# bo teraz: 31=lewa strzałka grup, 32=prawa strzałka grup, 33=home (w stopce)
HEADER_GROUP_LEFT_ID = 31
HEADER_GROUP_RIGHT_ID = 32
HEADER_HOME_ID = 33  # przeniesiony do stopki
HEADER_GROUP_LABEL_ID = 34

TEXTBOX_ID = 44
TEXTBOX_SCROLL_ID = 65
TEXTBOX_PROXY_ID = 66

SIDE_LEFT_UP_ID = 81
SIDE_LEFT_DOWN_ID = 82
SIDE_RIGHT_UP_ID = 83
SIDE_RIGHT_DOWN_ID = 84

# Stopka - akcje
BOTTOM_RECINFO_ID = 52
BOTTOM_SCHEDULE_ID = 53
BOTTOM_SETTINGS_ID = 54
BOTTOM_SEARCH_ID = 55
BOTTOM_NOW_ID = 56

# Stopka - czas
BOTTOM_BIG_LEFT_ID = 71
BOTTOM_LEFT_ID = 72
BOTTOM_RIGHT_ID = 73
BOTTOM_BIG_RIGHT_ID = 74

BASE_CHANNEL_ID = 100
BASE_CHANNEL_ICON_ID = 200
BASE_CHANNEL_LABEL_ID = 210
BASE_CHANNEL_PROGRESS_ID = 300

BASE_ROW_BG_ID = 800
BASE_EVENT_BG_NORMAL_ID = 12000
BASE_EVENT_BG_SCHEDULED_ID = 13000
BASE_EVENT_BTN_ID = 1000
BASE_EVENT_TIME_ID = 10000
BASE_EVENT_TITLE_ID = 11000

BASE_EVENT_BORDER_TOP_ID = 14000
BASE_EVENT_BORDER_BOTTOM_ID = 15000
BASE_EVENT_BORDER_LEFT_ID = 16000
BASE_EVENT_BORDER_RIGHT_ID = 17000

# ZMIENIONE WYMIARY
GRID_LEFT = 524
GRID_TOP = 125          # ← było 142
GRID_RIGHT = 1866
GRID_WIDTH = GRID_RIGHT - GRID_LEFT

ROW_HEIGHT = 103
ROW_GAP = 4
ROW_STRIDE = ROW_HEIGHT + ROW_GAP

CHANNEL_LEFT = 24
CHANNEL_WIDTH = 490

WINDOW_SECONDS = 4 * 3600
STEP_SMALL = 1800
STEP_BIG = 7200
MIN_EVENT_WIDTH = 36
VERTICAL_DIVIDER_WIDTH = 2




def _calc_progress(start_ts, stop_ts):
    try:
        now = time.time()
        if not start_ts or not stop_ts or stop_ts <= start_ts:
            return 0
        val = int(((now - start_ts) / (stop_ts - start_ts)) * 100)
        return max(0, min(100, val))
    except:
        return 0


def _find_epg_events(raw_epg, display_name):
    norm_name = common.clean_channel_name(display_name)
    now = time.time()

    events = []
    if norm_name in raw_epg:
        events = raw_epg.get(norm_name, [])
    elif display_name.lower() in raw_epg:
        events = raw_epg.get(display_name.lower(), [])
    else:
        for key in raw_epg.keys():
            if norm_name in key or key in norm_name:
                events = raw_epg.get(key, [])
                if events:
                    break

    if not events:
        return []

    events = sorted(events, key=lambda x: x.get('start', 0))

    result = []
    for e in events:
        stop_ts = e.get('stop', 0)
        if stop_ts > now - WINDOW_SECONDS:
            result.append(e)

    return result


def _format_event_time(ev):
    s = ev.get('start', 0)
    t = ev.get('stop', 0)
    if s and t:
        return f"{time.strftime('%H:%M', time.localtime(s))}-{time.strftime('%H:%M', time.localtime(t))}"
    return ''


def _format_event_date_time(ev):
    s = ev.get('start', 0)
    t = ev.get('stop', 0)
    if s and t:
        return (
            f"{time.strftime('%d.%m.%Y', time.localtime(s))}   "
            f"{time.strftime('%H:%M', time.localtime(s))}-{time.strftime('%H:%M', time.localtime(t))}"
        )
    return ''


def _build_channel_item(idx, title, cmd, logo_url, plot_desc, events, start_ts=0, stop_ts=0):
    return {
        'number': idx + 1,
        'title': title,
        'cmd': cmd,
        'logo_url': logo_url or common.icon0,
        'plot': plot_desc or '',
        'progress': _calc_progress(start_ts, stop_ts),
        'start_ts': start_ts,
        'stop_ts': stop_ts,
        'events': events,
    }


def _build_from_channel_state(portal):
    state = common.read_json_safe(common.channel_state_file)
    channels = state.get('channels', [])
    state_portal = state.get('portal', {})

    if not channels or not state_portal:
        return []

    if common.get_portal_key(state_portal) != common.get_portal_key(portal):
        return []

    raw_epg = common.read_json_safe(common.epg_raw_file)
    result = []
    bad_hosts = ['103.176.90.95']

    for idx, ch in enumerate(channels):
        title = ch.get('title', '')
        if not title:
            continue

        epg_events = _find_epg_events(raw_epg, title)
        plot_desc = ch.get('plot', '')
        if epg_events and epg_events[0].get('desc'):
            plot_desc = epg_events[0].get('desc', '')

        logo_url = ch.get('logo_url', common.icon0)

        if epg_events:
            epg_logo = epg_events[0].get('chan_logo') or epg_events[0].get('logo') or epg_events[0].get('icon')
            if epg_logo and str(epg_logo).startswith('http'):
                if not any(host in str(epg_logo) for host in bad_hosts):
                    logo_url = str(epg_logo)

        result.append(
            _build_channel_item(
                idx=idx,
                title=title,
                cmd=ch.get('cmd', ''),
                logo_url=logo_url,
                plot_desc=plot_desc,
                events=epg_events,
                start_ts=ch.get('start_ts', 0),
                stop_ts=ch.get('stop_ts', 0),
            )
        )

    return result


def _build_full(portal):
    sorting.reload_config()
    provider = provider_api.get_provider(portal)

    genre_name = str(common.args.get('genre_name', [''])[0])
    selected_genre_id = str(common.args.get('genre_id', [None])[0])
    use_custom_order = str(common.args.get('custom_order', ['false'])[0]) == 'true'
    filter_group = str(common.args.get('filter_group', [None])[0])

    portal_key = common.get_portal_key(portal)
    custom_names = common.read_json_safe(common.custom_names_file).get(portal_key, {})
    hidden_channels = common.read_json_safe(common.hidden_channels_file).get(portal_key, [])
    raw_epg = common.read_json_safe(common.epg_raw_file)

    genre_lower = (genre_name or '').lower()
    is_adult_genre = any(w in genre_lower for w in provider.ADULT_KEYWORDS)
    if is_adult_genre and not is_adult_visible(portal):
        return []

    if use_custom_order:
        if portal.get('type') in ['xtream', 'm3u']:
            sorted_all = sorting.get_smart_sorted_list(provider, portal, None, None, common.addondir)
        else:
            sorted_all = sorting.get_smart_sorted_list(
                provider, portal['mac'], portal['url'], portal['serial'], common.addondir
            )

        if filter_group == 'ALL_POLISH':
            saved_data = common.read_json_safe(common.selected_groups_file)
            default_groups = [g[0] for g in sorting.ORDERED_GROUPS] + ['POZOSTAŁE']
            allowed_groups = saved_data.get('pl_supergroup', default_groups)
            final_list = [
                ch for ch in sorted_all
                if ch.get('_my_group_name') in allowed_groups
            ]
        elif filter_group and filter_group != 'None':
            final_list = [
                ch for ch in sorted_all
                if ch.get('_my_group_name') == filter_group and not ch.get('is_header')
            ]
        else:
            final_list = sorted_all
    else:
        if portal.get('type') in ['xtream', 'm3u']:
            data = provider.getAllChannels(portal, common.addondir)
        else:
            data = provider.getAllChannels(portal['mac'], portal['url'], portal['serial'], common.addondir)

        raw_channels = data.get('channels', [])
        unique_channels = {}

        for ch in raw_channels:
            if selected_genre_id != 'None' and selected_genre_id != '*' and str(ch.get('genre_id')) != selected_genre_id:
                continue
            clean = str(ch.get('name', 'Nieznany')).replace('PL:', '').strip()
            for suffix in [' FHD', ' HD', ' VIP', ' (NOCONN)', ' RAW']:
                clean = clean.replace(suffix, '')
            clean = clean.strip()
            if clean not in unique_channels:
                ch['display_name'] = clean
                unique_channels[clean] = ch

        final_list = list(unique_channels.values())
        final_list.sort(key=lambda x: x.get('display_name', '').lower())

    filtered = []
    for item in final_list:
        if item.get('is_header'):
            continue
        base_name = str(item.get('display_name', item.get('name', '')))
        if base_name in hidden_channels:
            continue
        if base_name in custom_names:
            item['display_name'] = custom_names[base_name]
        filtered.append(item)

    result = []

    for idx, item in enumerate(filtered):
        display_name = item.get('display_name', 'Nieznany')
        cmd = str(item.get('cmd') or '')
        logo = item.get('logo', '')
        logo_url = common.icon0
        bad_hosts = ['103.176.90.95']

        epg_events = _find_epg_events(raw_epg, display_name)

        if epg_events:
            epg_logo = epg_events[0].get('chan_logo') or epg_events[0].get('logo') or epg_events[0].get('icon')
            if epg_logo and str(epg_logo).startswith('http'):
                if not any(host in str(epg_logo) for host in bad_hosts):
                    logo_url = str(epg_logo)

        if logo_url == common.icon0 and logo:
            if str(logo).startswith('http'):
                if not any(host in str(logo) for host in bad_hosts):
                    logo_url = str(logo)
            elif portal.get('type') != 'm3u':
                base = portal['url'].split('/c/')[0] if '/c/' in portal['url'] else portal['url'].rstrip('/')
                logo_url = f"{base}/stalker_portal/misc/logos/320/{logo}"

        current_event = None
        now_ts = time.time()

        for ev in epg_events:
            ev_start = ev.get('start', 0)
            ev_stop = ev.get('stop', 0)
            if ev_start <= now_ts < ev_stop:
                current_event = ev
                break

        if not current_event and epg_events:
            current_event = epg_events[0]

        plot_desc = current_event.get('desc', '') if current_event else ''
        start_ts = current_event.get('start', 0) if current_event else 0
        stop_ts = current_event.get('stop', 0) if current_event else 0

        result.append(
            _build_channel_item(
                idx=idx,
                title=display_name,
                cmd=cmd,
                logo_url=logo_url,
                plot_desc=plot_desc,
                events=epg_events,
                start_ts=start_ts,
                stop_ts=stop_ts,
            )
        )

    return result


def _build_guide_state(portal):
    cached = _build_from_channel_state(portal)
    if cached:
        xbmc.log('[Iskierek IPTV Full] timeline guide loaded from cache', xbmc.LOGINFO)
        return cached

    xbmc.log('[Iskierek IPTV Full] timeline guide fallback to full build', xbmc.LOGINFO)
    return _build_full(portal)

def _build_guide_source(portal, filter_group='ALL_POLISH'):
    sorting.reload_config()
    provider = provider_api.get_provider(portal)

    portal_key = common.get_portal_key(portal)
    custom_names = common.read_json_safe(common.custom_names_file).get(portal_key, {})
    hidden_channels = common.read_json_safe(common.hidden_channels_file).get(portal_key, [])
    raw_epg = common.read_json_safe(common.epg_raw_file)

    try:
        if portal.get('type') in ['xtream', 'm3u']:
            sorted_all = sorting.get_smart_sorted_list(provider, portal, None, None, common.addondir)
        else:
            sorted_all = sorting.get_smart_sorted_list(
                provider,
                portal['mac'],
                portal['url'],
                portal['serial'],
                common.addondir
            )
    except Exception as e:
        xbmc.log(f'[TVGuide] _build_guide_source sorting error: {e}', xbmc.LOGERROR)
        return {'full_channels': [], 'view_channels': []}

    if not sorted_all:
        return {'full_channels': [], 'view_channels': []}

    saved_data = common.read_json_safe(common.selected_groups_file)
    default_groups = [g[0] for g in sorting.ORDERED_GROUPS]
    allowed_groups = saved_data.get('pl_supergroup', default_groups)

    prepared = []
    for item in sorted_all:
        if item.get('is_header'):
            continue

        group_name = str(item.get('_my_group_name', '')).strip()
        if group_name not in allowed_groups:
            continue

        base_name = str(item.get('display_name', item.get('name', '')))
        if base_name in hidden_channels:
            continue

        item = dict(item)
        if base_name in custom_names:
            item['display_name'] = custom_names[base_name]
        else:
            item['display_name'] = base_name

        display_name = item.get('display_name', 'Nieznany')
        cmd = str(item.get('cmd') or '')
        logo = item.get('logo', '')
        logo_url = common.icon0
        bad_hosts = ['103.176.90.95']

        norm_name = common.clean_channel_name(display_name)
        e = None

        if norm_name in raw_epg:
            epg_list = raw_epg.get(norm_name, [])
            if epg_list:
                e = epg_list[0]
        elif display_name.lower() in raw_epg:
            epg_list = raw_epg.get(display_name.lower(), [])
            if epg_list:
                e = epg_list[0]
        else:
            epg_list = []
            for key in raw_epg.keys():
                if norm_name in key or key in norm_name:
                    epg_list = raw_epg.get(key, [])
                    if epg_list:
                        e = epg_list[0]
                        break

        epg_events = _find_epg_events(raw_epg, display_name)

        current_event = None
        now_ts = time.time()

        for ev in epg_events:
            ev_start = ev.get('start', 0)
            ev_stop = ev.get('stop', 0)
            if ev_start <= now_ts < ev_stop:
                current_event = ev
                break

        if not current_event and epg_events:
            current_event = epg_events[0]

        if e:
            epg_logo = e.get('chan_logo') or e.get('logo') or e.get('icon')
            if epg_logo and str(epg_logo).startswith('http'):
                if not any(host in str(epg_logo) for host in bad_hosts):
                    logo_url = str(epg_logo)

        if logo_url == common.icon0 and logo:
            if str(logo).startswith('http'):
                if not any(host in str(logo) for host in bad_hosts):
                    logo_url = str(logo)
            elif portal.get('type') != 'm3u':
                base = portal['url'].split('/c/')[0] if '/c/' in portal['url'] else portal['url'].rstrip('/')
                logo_url = f"{base}/stalker_portal/misc/logos/320/{logo}"

        plot_desc = current_event.get('desc', '') if current_event else ''
        start_ts = current_event.get('start', 0) if current_event else 0
        stop_ts = current_event.get('stop', 0) if current_event else 0



        plot_desc = current_event.get('desc', '') if current_event else ''
        start_ts = current_event.get('start', 0) if current_event else 0
        stop_ts = current_event.get('stop', 0) if current_event else 0

        prepared.append(
            _build_channel_item(
                idx=len(prepared),
                title=display_name,
                cmd=cmd,
                logo_url=logo_url,
                plot_desc=plot_desc,
                events=epg_events,
                start_ts=start_ts,
                stop_ts=stop_ts,
            )
        )
        prepared[-1]['group_name'] = group_name

    if filter_group and filter_group not in ['', 'None', 'ALL_POLISH']:
        view_channels = [ch for ch in prepared if str(ch.get('group_name', '')).strip() == filter_group]
    else:
        view_channels = prepared[:]

    return {
        'full_channels': prepared,
        'view_channels': view_channels
    }

class TVGuideWindow(xbmcgui.WindowXMLDialog):

    def _handle_refresh_request(self):
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty('IskierekGuideRefresh') != '1':
                return False

            win.clearProperty('IskierekGuideRefresh')

            guide_source = _build_guide_source(
                self.portal,
                self.filter_group if self.use_custom_order else 'ALL_POLISH'
            )

            self.full_channels = guide_source.get('full_channels', [])
            self.channels = guide_source.get('view_channels', []) if self.use_custom_order else self.full_channels[:]

            self.group_names = self._build_group_names()
            self.group_index = self._detect_group_index()

            if self.row_offset >= len(self.channels):
                self.row_offset = max(0, len(self.channels) - VISIBLE_ROWS)

            if self.row_offset < 0:
                self.row_offset = 0

            visible = self._visible_channels()
            if self.active_row >= len(visible):
                self.active_row = max(0, len(visible) - 1)

            if self.active_row < 0:
                self.active_row = 0

            self.active_btn_id = None
            self._clear_dynamic_caches()
            self.render()
            xbmc.sleep(50)
            self._focus_initial()

            return True

        except Exception as e:
            xbmc.log(f'[TVGuide] refresh request error: {e}', xbmc.LOGERROR)
            return False

    def _refresh_guide_state(self):
        try:
            guide_source = _build_guide_source(
                self.portal,
                self.filter_group if self.use_custom_order else 'ALL_POLISH'
            )

            self.full_channels = guide_source.get('full_channels', [])
            self.channels = guide_source.get('view_channels', []) if self.use_custom_order else self.full_channels[:]

            if self.row_offset >= len(self.channels):
                self.row_offset = max(0, len(self.channels) - VISIBLE_ROWS)

            if self.active_row >= len(self._visible_channels()):
                self.active_row = max(0, len(self._visible_channels()) - 1)

            self._clear_dynamic_caches()
            self.render()
        except Exception as e:
            xbmc.log(f'[TVGuide] refresh guide state error: {e}', xbmc.LOGERROR)

    def _refresh_schedule_state(self):
        try:
            self._refresh_guide_state()
            xbmc.sleep(200)
            self._refresh_guide_state()
        except Exception as e:
            xbmc.log(f'[TVGuide] refresh schedule state error: {e}', xbmc.LOGERROR)

    def _poll_recording_state(self):
        try:
            now_ts = time.time()
            if now_ts - self._last_record_state_check < 2.0:
                return

            self._last_record_state_check = now_ts

            rec_state = recorder.get_recording_status()
            is_active = bool(rec_state.get('active', False))

            if is_active != self._last_record_active:
                self._last_record_active = is_active
                self._refresh_guide_state()
        except Exception as e:
            xbmc.log(f'[TVGuide] poll recording state error: {e}', xbmc.LOGERROR)

    def _get_current_channel_index_from_state(self):
        try:
            state = common.read_json_safe(common.channel_state_file)
            state_portal = state.get('portal', {})
            current_index = int(state.get('current_index', -1))

            if current_index < 0:
                return -1

            if common.get_portal_key(state_portal) != common.get_portal_key(self.portal):
                return -1

            return current_index
        except Exception:
            return -1

    def _set_initial_position_to_current_channel(self):
        idx = self._get_current_channel_index_from_state()
        if idx < 0 or idx >= len(self.channels):
            self.row_offset = 0
            self.active_row = 0
            return

        if idx < VISIBLE_ROWS:
            self.row_offset = 0
            self.active_row = idx
        else:
            self.row_offset = max(0, idx - 2)
            if self.row_offset + VISIBLE_ROWS > len(self.channels):
                self.row_offset = max(0, len(self.channels) - VISIBLE_ROWS)
            self.active_row = idx - self.row_offset

    def __init__(self, *args, **kwargs):
        super().__init__()
        self.portal = kwargs.get('portal', {})
        self.full_channels = []
        self.channels = []

        self.row_offset = 0
        self.active_row = 0
        self.active_btn_id = None

        self.event_map = {}
        self._busy = False

        self.time_start = self._initial_time_start()

        self.use_custom_order = str(common.args.get('custom_order', ['false'])[0]) == 'true'
        self.filter_group = str(common.args.get('filter_group', [''])[0])
        self.genre_name = str(common.args.get('genre_name', [''])[0])
        self.return_to = str(common.args.get('return_to', [''])[0])

        self._last_focus_area = 'events'
        self._last_action_ts = 0
        self._last_record_state_check = 0
        self._last_record_active = False

        # cache kontrolek i wyliczeń
        self._control_cache = {}
        self._scheduled_cache = {}
        self._window_events_cache = {}
        self._rect_cache = {}

        guide_source = _build_guide_source(self.portal, self.filter_group if self.use_custom_order else 'ALL_POLISH')
        self.full_channels = guide_source.get('full_channels', [])
        self.channels = guide_source.get('view_channels', []) if self.use_custom_order else self.full_channels[:]

        self._set_initial_position_to_current_channel()

        self.group_names = self._build_group_names()
        self.group_index = self._detect_group_index()
        self._apply_guide_target_from_property()

    def _apply_guide_target_from_property(self):
        try:
            win = xbmcgui.Window(10000)

            target_channel = win.getProperty('IskierekGuideTargetChannel')
            target_start = win.getProperty('IskierekGuideTargetProgramStart')
            target_stop = win.getProperty('IskierekGuideTargetProgramStop')

            if not target_channel:
                return

            win.clearProperty('IskierekGuideTargetChannel')
            win.clearProperty('IskierekGuideTargetProgramTitle')
            win.clearProperty('IskierekGuideTargetProgramStart')
            win.clearProperty('IskierekGuideTargetProgramStop')

            try:
                target_start = int(target_start or 0)
            except Exception:
                target_start = 0

            try:
                target_stop = int(target_stop or 0)
            except Exception:
                target_stop = 0

            # Znajdź indeks kanału po tytule
            channel_index = -1
            target_norm = str(target_channel).strip().lower()

            for i, item in enumerate(self.channels):
                item_title = str(item.get('title', '')).strip().lower()
                if item_title == target_norm:
                    channel_index = i
                    break

            if channel_index < 0:
                return

            # Ustaw wiersze tak, żeby kanał był widoczny
            if channel_index < VISIBLE_ROWS:
                self.row_offset = 0
                self.active_row = channel_index
            else:
                self.row_offset = max(0, channel_index - 2)
                if self.row_offset + VISIBLE_ROWS > len(self.channels):
                    self.row_offset = max(0, len(self.channels) - VISIBLE_ROWS)
                self.active_row = channel_index - self.row_offset

            # Ustaw time_start tak, żeby program był widoczny w oknie
            if target_start > 0:
                self.time_start = target_start - (target_start % STEP_SMALL)

        except Exception as e:
            xbmc.log(f'[TVGuide] _apply_guide_target_from_property error: {e}', xbmc.LOGERROR)

    def _allow_action(self, delay=0.08):
        now = time.time()
        if now - self._last_action_ts < delay:
            return False
        self._last_action_ts = now
        return True

    def _initial_time_start(self):
        now = int(time.time())
        return now - (now % STEP_SMALL)

    def _go_back(self):
        try:
            win = xbmcgui.Window(10000)
            return_owner = win.getProperty('IskierekReturnOwner')
            return_live_active = win.getProperty('IskierekReturnLiveActive')

            for r in range(VISIBLE_ROWS):
                win.clearProperty(f'IskierekTVGuideRow{r}Progress')
        except Exception:
            return_owner = ''
            return_live_active = ''

        self.close()
        xbmc.sleep(150)

        try:
            if self.return_to != 'overlay' and return_owner == 'live_window' and return_live_active == '1':
                portal_raw = win.getProperty('IskierekLivePortal') or '{}'
                custom_order_raw = win.getProperty('IskierekLiveCustomOrder') or 'true'
                filter_group = win.getProperty('IskierekLiveFilterGroup') or 'ALL_POLISH'
                genre_id = win.getProperty('IskierekLiveGenreId') or ''
                genre_name = win.getProperty('IskierekLiveGenreName') or ''

                portal = json.loads(portal_raw)
                custom_order = str(custom_order_raw).lower() == 'true'

                url = common.build_url({
                    'mode': 'open_live_window',
                    'portal': json.dumps(portal),
                    'custom_order': 'true' if custom_order else 'false',
                    'filter_group': filter_group,
                    'genre_id': genre_id,
                    'genre_name': genre_name
                })

                xbmc.executebuiltin(f'RunPlugin({url})')
                return
        except Exception as e:
            xbmc.log(f'[TVGuide] live window return error: {e}', xbmc.LOGERROR)

        try:
            player = xbmc.Player()
            is_playing = player.isPlaying() or player.isPlayingVideo()
        except Exception:
            is_playing = False

        if is_playing:
            try:
                xbmc.executebuiltin('Dialog.Close(all,true)')
                xbmc.sleep(100)
                xbmc.executebuiltin('Action(Back)')
                xbmc.sleep(100)
                xbmc.executebuiltin('Action(FullScreen)')
                return
            except Exception as e:
                xbmc.log(f'[TVGuide] fullscreen return error: {e}', xbmc.LOGERROR)

    def onInit(self):
        # Ukryj bordowe tło PRZED renderem
        try:
            self.getControl(700).setVisible(False)
        except Exception:
            pass

        # Wyczyść caches (mogą być stare dane z __init__)
        self._clear_dynamic_caches()
        self._control_cache = {}  # <-- dodaj to! wymuś pełny re-render

        self.render()
        xbmc.sleep(50)
        self._focus_initial()

        # Pokaż bordowe tło dopiero po wyrenderowaniu
        try:
            self.getControl(700).setVisible(True)
        except Exception:
            pass

    def _focus_initial(self):
        # Spróbuj wybrać event w aktywnym wierszu (najbliższy w czasie do time_start)
        btn = self._first_event_in_row(self.active_row)
        if btn:
            self._focus_event_button(btn)
            return

        visible = self._visible_channels()
        if visible:
            self._focus_channel_row(self.active_row)
            return

        try:
            self.setFocusId(BOTTOM_CHANNEL_ID)
        except:
            pass

    def _handle_reopen_request(self):
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty('IskierekGuideReopen') != '1':
                return False

            win.clearProperty('IskierekGuideReopen')

            portal = self.portal
            custom_order = self.use_custom_order
            filter_group = self.filter_group or 'ALL_POLISH'
            genre_name = self.genre_name or 'WSZYSTKIE'
            return_to = self.return_to

            self.close()
            xbmc.sleep(150)

            open_guide_with_params(
                portal=portal,
                custom_order=custom_order,
                filter_group=filter_group,
                genre_name=genre_name,
                return_to=return_to
            )
            return True

        except Exception as e:
            xbmc.log(f'[TVGuide] reopen request error: {e}', xbmc.LOGERROR)
            return False

    def _build_group_names(self):
        groups = ['WSZYSTKIE']

        try:
            if self.use_custom_order:
                found_groups = []
                for ch in self.full_channels:
                    grp = str(ch.get('group_name', '')).strip()
                    if grp and grp not in found_groups:
                        found_groups.append(grp)

                if found_groups:
                    groups = ['WSZYSTKIE'] + found_groups

            elif self.filter_group and self.filter_group not in ['', 'None', 'ALL_POLISH']:
                groups = ['WSZYSTKIE', self.filter_group]

        except Exception as e:
            xbmc.log(f'[TVGuide] _build_group_names error: {e}', xbmc.LOGERROR)

        return groups

    def _detect_group_index(self):
        if not self.group_names:
            return 0

        if self.filter_group in ['', 'None', 'ALL_POLISH']:
            return 0

        try:
            return self.group_names.index(self.filter_group)
        except Exception:
            return 0

    def _update_group_label(self):
        label = 'WSZYSTKIE'

        if self.group_names and 0 <= self.group_index < len(self.group_names):
            label = self.group_names[self.group_index]

        try:
            self.getControl(HEADER_GROUP_LABEL_ID).setLabel(f'[B]{label}[/B]')
        except Exception as e:
            xbmc.log(f'[TVGuide] group label update error: {e}', xbmc.LOGERROR)

    def _reload_current_group(self):
        guide_source = _build_guide_source(self.portal, self.filter_group if self.use_custom_order else 'ALL_POLISH')
        self.full_channels = guide_source.get('full_channels', [])
        self.channels = guide_source.get('view_channels', []) if self.use_custom_order else self.full_channels[:]
        self.row_offset = 0
        self.active_row = 0
        self.active_btn_id = None
        self._clear_dynamic_caches()
        self.render()
        xbmc.sleep(50)
        self._focus_initial()

    def _switch_group_left(self):
        if not self.group_names or len(self.group_names) <= 1:
            return

        if self.group_index > 0:
            self.group_index -= 1

            if self.group_index == 0:
                self.filter_group = 'ALL_POLISH'
                self.genre_name = 'WSZYSTKIE'
            else:
                self.filter_group = self.group_names[self.group_index]
                self.genre_name = self.filter_group

            common.args['filter_group'] = [self.filter_group]
            common.args['genre_name'] = [self.genre_name]
            self._reload_current_group()

    def _switch_group_right(self):
        if not self.group_names or len(self.group_names) <= 1:
            return

        if self.group_index < len(self.group_names) - 1:
            self.group_index += 1

            if self.group_index == 0:
                self.filter_group = 'ALL_POLISH'
                self.genre_name = 'WSZYSTKIE'
            else:
                self.filter_group = self.group_names[self.group_index]
                self.genre_name = self.filter_group

            common.args['filter_group'] = [self.filter_group]
            common.args['genre_name'] = [self.genre_name]
            self._reload_current_group()

    def _clear_dynamic_caches(self):
        self._scheduled_cache = {}
        self._window_events_cache = {}
        self._rect_cache = {}

    def _safe_control(self, cid):
        try:
            return self.getControl(cid)
        except:
            return None

    def _set_visible(self, cid, visible):
        key = ('visible', cid)
        if self._control_cache.get(key) == bool(visible):
            return
        self._control_cache[key] = bool(visible)

        ctrl = self._safe_control(cid)
        if ctrl:
            try:
                ctrl.setVisible(visible)
            except:
                pass

    def _set_label(self, cid, text):
        text = text or ''
        key = ('label', cid)
        if self._control_cache.get(key) == text:
            return
        self._control_cache[key] = text

        ctrl = self._safe_control(cid)
        if ctrl:
            try:
                ctrl.setLabel(text)
            except:
                try:
                    ctrl.setText(text)
                except:
                    pass

    def _set_image(self, cid, path):
        path = path or common.icon0
        key = ('image', cid)
        if self._control_cache.get(key) == path:
            return
        self._control_cache[key] = path

        ctrl = self._safe_control(cid)
        if ctrl:
            try:
                ctrl.setImage(path)
            except:
                pass

    def _set_progress(self, cid, value):
        try:
            value = float(value)
        except:
            value = 0.0

        key = ('progress', cid)
        if self._control_cache.get(key) == value:
            return
        self._control_cache[key] = value

        ctrl = self._safe_control(cid)
        if ctrl:
            try:
                ctrl.setPercent(value)
            except:
                pass

    def _set_pos_size(self, cid, left, top, width, height):
        geom = (int(left), int(top), int(width), int(height))
        key = ('geom', cid)
        if self._control_cache.get(key) == geom:
            return
        self._control_cache[key] = geom

        ctrl = self._safe_control(cid)
        if not ctrl:
            return

        try:
            ctrl.setPosition(geom[0], geom[1])
        except:
            pass

        try:
            ctrl.setWidth(geom[2])
        except:
            pass

        try:
            ctrl.setHeight(geom[3])
        except:
            pass

    def _visible_channels(self):
        return self.channels[self.row_offset:self.row_offset + VISIBLE_ROWS]

    def _window_end(self):
        return self.time_start + WINDOW_SECONDS

    def _event_overlaps_window(self, ev):
        s = int(ev.get('start', 0) or 0)
        t = int(ev.get('stop', 0) or 0)
        return t > self.time_start and s < self._window_end()

    def _get_events_for_window(self, ch):
        cache_key = (ch.get('cmd', ''), ch.get('title', ''), self.time_start)
        if cache_key in self._window_events_cache:
            return self._window_events_cache[cache_key]

        result = [ev for ev in ch.get('events', []) if self._event_overlaps_window(ev)]
        self._window_events_cache[cache_key] = result
        return result

    def _event_ids(self, row, col):
        base = row * 100 + col
        return (
            BASE_EVENT_BTN_ID + base,
            BASE_EVENT_TIME_ID + base,
            BASE_EVENT_TITLE_ID + base,
        )

    def _bg_normal_id(self, row, col):
        return BASE_EVENT_BG_NORMAL_ID + row * 100 + col

    def _bg_scheduled_id(self, row, col):
        return BASE_EVENT_BG_SCHEDULED_ID + row * 100 + col

    def _border_ids(self, row, col):
        base = row * 100 + col
        return (
            BASE_EVENT_BORDER_TOP_ID + base,
            BASE_EVENT_BORDER_BOTTOM_ID + base,
            BASE_EVENT_BORDER_LEFT_ID + base,
            BASE_EVENT_BORDER_RIGHT_ID + base,
        )

    def _is_scheduled(self, ch, ev):
        try:
            key = (
                str(ch.get('cmd', '')),
                int(ev.get('start', 0)),
                int(ev.get('stop', 0)),
            )
            if key in self._scheduled_cache:
                return self._scheduled_cache[key]

            val = recorder.has_scheduled_recording(
                ch.get('cmd', ''),
                ev.get('start', 0),
                ev.get('stop', 0),
            )

            if not val:
                try:
                    rec_state = recorder.get_recording_status()
                    if rec_state.get('active'):
                        rec_title = str(rec_state.get('title', '')).strip().lower()
                        ch_title = str(ch.get('title', '')).strip().lower()
                        ev_start = int(ev.get('start', 0) or 0)
                        ev_stop = int(ev.get('stop', 0) or 0)
                        now_ts = int(time.time())

                        if rec_title and ch_title and rec_title == ch_title:
                            if ev_start <= now_ts < ev_stop:
                                val = True
                except Exception:
                    pass

            self._scheduled_cache[key] = bool(val)
            return self._scheduled_cache[key]
        except:
            return False

    def _get_event_image(self, ch, ev):
        if ev:
            for key in [
                'image', 'icon', 'poster', 'thumb', 'cover', 'logo', 'pic',
                'screenshot', 'img', 'image_url', 'picture', 'preview'
            ]:
                val = ev.get(key)
                if val and str(val).startswith('http'):
                    return val

        desc = (ev.get('desc', '') if ev else '') or ''
        if 'http' in desc:
            for p in desc.split():
                if p.startswith('http') and ('.jpg' in p or '.jpeg' in p or '.png' in p or '.webp' in p):
                    return p

        return ch.get('logo_url', '') or common.icon0

    def _build_program_data(self, ch, ev):
        if not ch:
            return None

        nxt = {}
        events = ch.get('events', [])
        if ev and ev in events:
            idx = events.index(ev)
            if idx + 1 < len(events):
                nxt = events[idx + 1]

        return {
            'title': ch.get('title', ''),
            'cmd': ch.get('cmd', ''),
            'logo_url': ch.get('logo_url', ''),
            'image_url': self._get_event_image(ch, ev),
            'plot': (ev.get('desc', '') if ev else '') or (ev.get('plot', '') if ev else '') or ch.get('plot', ''),
            'program_now': ev.get('title', '') if ev else '',
            'program_date_time': _format_event_date_time(ev) if ev else '',
            'program_next': nxt.get('title', ''),
            'program_next_time': _format_event_time(nxt) if nxt else '',
        }

    def _show_event_dialog(self):
        selected = self.event_map.get(self.active_btn_id)
        if not selected:
            return

        ch = selected.get('channel')
        ev = selected.get('event')
        if not ch or not ev:
            return

        channel_index = -1
        selected_cmd = str(ch.get('cmd', ''))
        selected_title = str(ch.get('title', ''))

        for i, item in enumerate(self.full_channels):
            if str(item.get('cmd', '')) == selected_cmd and str(item.get('title', '')) == selected_title:
                channel_index = i
                break

        if channel_index < 0:
            for i, item in enumerate(self.full_channels):
                if str(item.get('cmd', '')) == selected_cmd:
                    channel_index = i
                    break

        events = ch.get('events', [])
        program_next = ''
        program_next_time = ''

        if ev in events:
            try:
                idx = events.index(ev)
                if idx + 1 < len(events):
                    nxt = events[idx + 1]
                    program_next = nxt.get('title', '')
                    program_next_time = _format_event_time(nxt)
            except Exception:
                pass

        channel_data = {
            'title': ch.get('title', ''),
            'cmd': ch.get('cmd', ''),
            'logo_url': ch.get('logo_url', ''),
            'plot': ev.get('desc', '') or ev.get('plot', '') or ch.get('plot', ''),
            'program_now': ev.get('title', ''),
            'program_now_time': _format_event_time(ev),
            'program_next': program_next,
            'program_next_time': program_next_time,
            'start_ts': ev.get('start', 0),
            'stop_ts': ev.get('stop', 0)
        }

        program_info.open_program_info(channel_data, self.portal, channel_index)
        self._refresh_schedule_state()

        try:
            win = xbmcgui.Window(10000)
            if win.getProperty('IskierekGuideCloseAfterDialog') == '1':
                win.clearProperty('IskierekGuideCloseAfterDialog')
                self.close()
        except Exception:
            pass

    def _update_bottom_from_selection(self):
        # 1. Jeśli aktywny event istnieje - pokazujemy info eventu
        selected = self.event_map.get(self.active_btn_id)
        if selected and selected.get('event'):
            data = self._build_program_data(selected['channel'], selected['event'])
            if data:
                self._set_label(40, data.get('title', ''))
                self._set_label(41, data.get('program_date_time', ''))
                self._set_label(42, data.get('program_now', ''))

                next_line = ''
                if data.get('program_next_time') or data.get('program_next'):
                    next_line = f"Następny: {data.get('program_next_time', '')}  {data.get('program_next', '')}".strip()
                self._set_label(43, next_line)

                try:
                    text_val = data.get('plot', '') or 'Brak opisu programu.'
                    key = ('text', 44)
                    if self._control_cache.get(key) != text_val:
                        self._control_cache[key] = text_val
                        self.getControl(44).setText(text_val)
                except:
                    pass

                img = data.get('image_url', '') or data.get('logo_url', '') or common.icon0
                self._set_image(45, img)
                return

        # 2. Brak widocznych kanałów - czyścimy panel
        visible = self._visible_channels()
        if not visible:
            self._set_label(40, '')
            self._set_label(41, '')
            self._set_label(42, '')
            self._set_label(43, '')
            try:
                key = ('text', 44)
                if self._control_cache.get(key) != '':
                    self._control_cache[key] = ''
                    self.getControl(44).setText('')
            except:
                pass
            self._set_image(45, common.icon0)
            return

        # 3. Hover na kanale - pokazujemy AKTUALNY program tego kanału
        ch = visible[min(self.active_row, len(visible) - 1)]
        events = ch.get('events', [])

        current_event = None
        next_event = None
        now_ts = time.time()

        for idx, ev in enumerate(events):
            ev_start = int(ev.get('start', 0) or 0)
            ev_stop = int(ev.get('stop', 0) or 0)

            if ev_start <= now_ts < ev_stop:
                current_event = ev
                if idx + 1 < len(events):
                    next_event = events[idx + 1]
                break

        # Jeśli nic nie leci teraz, weź pierwszy przyszły
        if not current_event:
            for idx, ev in enumerate(events):
                ev_stop = int(ev.get('stop', 0) or 0)
                if ev_stop > now_ts:
                    current_event = ev
                    if idx + 1 < len(events):
                        next_event = events[idx + 1]
                    break

        # Wypełnij panel
        self._set_label(40, ch.get('title', ''))

        if current_event:
            self._set_label(41, _format_event_date_time(current_event))
            self._set_label(42, current_event.get('title', ''))

            next_line = ''
            if next_event:
                next_time = _format_event_time(next_event)
                next_title = next_event.get('title', '')
                if next_time or next_title:
                    next_line = f"Następny: {next_time}  {next_title}".strip()
            self._set_label(43, next_line)

            text_val = current_event.get('desc', '') or current_event.get('plot', '') or ch.get('plot', '') or 'Brak opisu programu.'

            img = self._get_event_image(ch, current_event)
        else:
            self._set_label(41, '')
            self._set_label(42, '')
            self._set_label(43, '')
            text_val = ch.get('plot', '') or 'Brak opisu programu.'
            img = ch.get('logo_url', '') or common.icon0

        try:
            key = ('text', 44)
            if self._control_cache.get(key) != text_val:
                self._control_cache[key] = text_val
                self.getControl(44).setText(text_val)
        except:
            pass

        self._set_image(45, img or common.icon0)


    def _update_time_headers(self):
        hour_width = int(GRID_WIDTH / 4.0)
        for i, cid in enumerate([60, 61, 62, 63]):
            ts = self.time_start + (i * 3600)
            self._set_pos_size(cid, GRID_LEFT + i * hour_width, 83, hour_width, 28)  # ← top 84 → 83
            self._set_label(cid, f"[B]{time.strftime('%H:%M', time.localtime(ts))}[/B]")

        page = int((self.time_start - self._initial_time_start()) / STEP_BIG) + 1
        if page < 1:
            page = 1
        self._set_label(46, f"Strona {page}")
        self._update_group_label()

    def _event_rect(self, ev):
        try:
            cache_key = (int(ev.get('start', 0) or 0), int(ev.get('stop', 0) or 0), self.time_start)
            if cache_key in self._rect_cache:
                return self._rect_cache[cache_key]

            s = int(ev.get('start', 0) or 0)
            t = int(ev.get('stop', 0) or 0)

            vis_start = max(s, self.time_start)
            vis_stop = min(t, self._window_end())

            if vis_stop <= vis_start:
                self._rect_cache[cache_key] = None
                return None

            rel_start = float(vis_start - self.time_start) / float(WINDOW_SECONDS)
            rel_stop = float(vis_stop - self.time_start) / float(WINDOW_SECONDS)

            left = GRID_LEFT + int(rel_start * GRID_WIDTH)
            right = GRID_LEFT + int(rel_stop * GRID_WIDTH)
            width = max(MIN_EVENT_WIDTH, right - left)

            if left + width > GRID_RIGHT:
                width = GRID_RIGHT - left

            if width <= 0:
                self._rect_cache[cache_key] = None
                return None

            self._rect_cache[cache_key] = (left, width)
            return self._rect_cache[cache_key]
        except:
            return None

    def render(self):
        if self._busy:
            return

        t0 = time.time()
        self._busy = True
        try:
            self.event_map = {}
            visible = self._visible_channels()
            self._update_time_headers()

            if self.active_row >= len(visible):
                self.active_row = max(0, len(visible) - 1)

            first_visible_btn = None
            for row in range(VISIBLE_ROWS):
                channel_id = BASE_CHANNEL_ID + row
                icon_id = BASE_CHANNEL_ICON_ID + row
                label_id = BASE_CHANNEL_LABEL_ID + row
                prog_id = BASE_CHANNEL_PROGRESS_ID + row

                top = GRID_TOP + row * ROW_STRIDE

                if row >= len(visible):
                    self._set_visible(channel_id, False)
                    self._set_visible(icon_id, False)
                    self._set_visible(label_id, False)
                    self._set_visible(prog_id, False)
                    self._set_visible(900 + row, False)

                    try:
                        xbmcgui.Window(10000).setProperty(f'IskierekTVGuideRow{row}Progress', '0')
                    except Exception:
                        pass

                    for col in range(VISIBLE_PROGRAMS):
                        bg_normal_id = self._bg_normal_id(row, col)
                        bg_sched_id = self._bg_scheduled_id(row, col)
                        btn_id, time_id, title_id = self._event_ids(row, col)

                        self._set_visible(bg_normal_id, False)
                        self._set_visible(bg_sched_id, False)
                        self._set_visible(btn_id, False)
                        self._set_visible(time_id, False)
                        self._set_visible(title_id, False)
                    continue

                ch = visible[row]
                abs_row = self.row_offset + row

                self._set_pos_size(channel_id, CHANNEL_LEFT, top, CHANNEL_WIDTH, ROW_HEIGHT)
                self._set_pos_size(icon_id, CHANNEL_LEFT + 10, top + 21, 120, 60)
                self._set_pos_size(label_id, CHANNEL_LEFT + 144, top, CHANNEL_WIDTH - 160, ROW_HEIGHT)
                self._set_pos_size(prog_id, 0, 0, 0, 0)

                self._set_visible(channel_id, True)
                self._set_visible(icon_id, True)
                self._set_visible(label_id, True)
                self._set_visible(prog_id, True)

                self._set_label(channel_id, '')
                self._set_image(icon_id, ch.get('logo_url', common.icon0))
                self._set_label(label_id, f"{ch.get('number', abs_row + 1)}. {ch.get('title', 'Kanał')}")
                self._set_progress(prog_id, ch.get('progress', 0))

                # progress jako property dla XML segmentów cienia
                try:
                    progress_val = int(ch.get('progress', 0) or 0)
                except Exception:
                    progress_val = 0
                if progress_val < 0:
                    progress_val = 0
                if progress_val > 100:
                    progress_val = 100
                xbmcgui.Window(10000).setProperty(f'IskierekTVGuideRow{row}Progress', str(progress_val))

                window_events = self._get_events_for_window(ch)
                current_right = GRID_LEFT

                for col in range(VISIBLE_PROGRAMS):
                    bg_normal_id = self._bg_normal_id(row, col)
                    bg_sched_id = self._bg_scheduled_id(row, col)
                    btn_id, time_id, title_id = self._event_ids(row, col)

                    if col >= len(window_events):
                        self._set_visible(bg_normal_id, False)
                        self._set_visible(bg_sched_id, False)
                        self._set_visible(btn_id, False)
                        self._set_visible(time_id, False)
                        self._set_visible(title_id, False)
                        continue

                    ev = window_events[col]
                    rect = self._event_rect(ev)
                    if not rect:
                        self._set_visible(bg_normal_id, False)
                        self._set_visible(bg_sched_id, False)
                        self._set_visible(btn_id, False)
                        self._set_visible(time_id, False)
                        self._set_visible(title_id, False)
                        continue

                    left, width = rect

                    if left < current_right + VERTICAL_DIVIDER_WIDTH:
                        left = current_right + VERTICAL_DIVIDER_WIDTH

                    if left >= GRID_RIGHT:
                        self._set_visible(bg_normal_id, False)
                        self._set_visible(bg_sched_id, False)
                        self._set_visible(btn_id, False)
                        self._set_visible(time_id, False)
                        self._set_visible(title_id, False)
                        continue

                    if left + width > GRID_RIGHT:
                        width = GRID_RIGHT - left

                    if width < MIN_EVENT_WIDTH:
                        self._set_visible(bg_normal_id, False)
                        self._set_visible(bg_sched_id, False)
                        self._set_visible(btn_id, False)
                        self._set_visible(time_id, False)
                        self._set_visible(title_id, False)
                        continue

                    self._set_pos_size(bg_normal_id, left, top, width, ROW_HEIGHT)
                    self._set_pos_size(bg_sched_id, left, top, width, ROW_HEIGHT)
                    self._set_pos_size(btn_id, left, top, width, ROW_HEIGHT)
                    self._set_pos_size(time_id, left + 14, top + 18, max(10, width - 28), 18)
                    self._set_pos_size(title_id, left + 14, top + 46, max(10, width - 28), 48)

                    scheduled = self._is_scheduled(ch, ev)

                    self._set_visible(bg_normal_id, not scheduled)
                    self._set_visible(bg_sched_id, scheduled)
                    self._set_visible(btn_id, True)
                    self._set_visible(time_id, True)
                    self._set_visible(title_id, True)

                    self._set_label(time_id, _format_event_time(ev))
                    self._set_label(title_id, ev.get('title', ''))

                    self.event_map[btn_id] = {
                        'row': row,
                        'col': col,
                        'channel': ch,
                        'event': ev,
                    }

                    current_right = left + width
                    if first_visible_btn is None:
                        first_visible_btn = btn_id

                # WYPEŁNIACZ pustej końcówki (kontrolka 900-904)
                filler_id = 900 + row
                if current_right < GRID_RIGHT:
                    filler_left = current_right + VERTICAL_DIVIDER_WIDTH
                    if filler_left < GRID_RIGHT:
                        filler_width = GRID_RIGHT - filler_left
                        self._set_pos_size(filler_id, filler_left, top, filler_width, ROW_HEIGHT)
                        self._set_visible(filler_id, True)
                    else:
                        self._set_visible(filler_id, False)
                else:
                    self._set_visible(filler_id, False)

            if self.active_btn_id not in self.event_map:
                self.active_btn_id = first_visible_btn

            self._update_bottom_from_selection()

        finally:
            self._busy = False
            xbmc.log(f'[TVGuide] render took {time.time() - t0:.3f}s', xbmc.LOGINFO)

    def _current_focus_id(self):
        try:
            return self.getFocusId()
        except:
            return -1

    def _is_side_control(self, cid):
        return cid in [
            SIDE_LEFT_UP_ID,
            SIDE_LEFT_DOWN_ID,
            SIDE_RIGHT_UP_ID,
            SIDE_RIGHT_DOWN_ID,
        ]

    def _focus_area(self, cid):
        if cid in self.event_map:
            return 'event'
        if self._is_channel_control(cid):
            return 'channel'
        if self._is_bottom_control(cid):
            return 'bottom'
        if self._is_side_control(cid):
            return 'side'
        if cid in [HEADER_GROUP_LEFT_ID, HEADER_GROUP_RIGHT_ID]:  # ← bez HEADER_HOME_ID
            return 'header'
        return 'other'

    def _is_channel_control(self, cid):
        return BASE_CHANNEL_ID <= cid < BASE_CHANNEL_ID + VISIBLE_ROWS

    def _is_bottom_control(self, cid):
        return cid in [
            HEADER_HOME_ID,
            BOTTOM_RECINFO_ID,
            BOTTOM_SCHEDULE_ID,
            BOTTOM_SETTINGS_ID,
            BOTTOM_SEARCH_ID,
            BOTTOM_NOW_ID,
            BOTTOM_BIG_LEFT_ID,
            BOTTOM_LEFT_ID,
            BOTTOM_RIGHT_ID,
            BOTTOM_BIG_RIGHT_ID,
            TEXTBOX_SCROLL_ID,
        ]

    def _visible_event_buttons_in_row(self, row):
        btns = []
        for btn_id, data in self.event_map.items():
            if data.get('row') == row:
                btns.append((data.get('col', 0), btn_id))
        btns.sort(key=lambda x: x[0])
        return [b for _, b in btns]

    def _first_event_in_row(self, row):
        btns = self._visible_event_buttons_in_row(row)
        return btns[0] if btns else None

    def _last_event_in_row(self, row):
        btns = self._visible_event_buttons_in_row(row)
        return btns[-1] if btns else None

    def _focus_last_event_in_active_row(self):
        btn = self._last_event_in_row(self.active_row)
        if btn:
            self._focus_event_button(btn)
            return True
        return False

    def _focus_channel_in_active_row(self):
        visible = self._visible_channels()
        if not visible:
            return False

        row = max(0, min(self.active_row, len(visible) - 1))
        self._focus_channel_row(row)
        return True

    def _neighbor_event_left(self, btn_id):
        data = self.event_map.get(btn_id)
        if not data:
            return None

        row = data['row']
        col = data['col']
        candidates = []

        for other_id, other in self.event_map.items():
            if other['row'] == row and other['col'] < col:
                candidates.append((other['col'], other_id))

        if not candidates:
            return None

        candidates.sort(key=lambda x: x[0])
        return candidates[-1][1]

    def _neighbor_event_right(self, btn_id):
        data = self.event_map.get(btn_id)
        if not data:
            return None

        row = data['row']
        col = data['col']
        candidates = []

        for other_id, other in self.event_map.items():
            if other['row'] == row and other['col'] > col:
                candidates.append((other['col'], other_id))

        if not candidates:
            return None

        candidates.sort(key=lambda x: x[0])
        return candidates[0][1]

    def _nearest_event_in_row(self, target_row, from_btn_id=None):
        btns = self._visible_event_buttons_in_row(target_row)
        if not btns:
            return None

        if not from_btn_id or from_btn_id not in self.event_map:
            return btns[0]

        from_col = self.event_map[from_btn_id].get('col', 0)

        best_btn = btns[0]
        best_diff = 999999

        for btn_id in btns:
            diff = abs(self.event_map[btn_id].get('col', 0) - from_col)
            if diff < best_diff:
                best_diff = diff
                best_btn = btn_id

        return best_btn

    def _focus_channel_row(self, row):
        visible = self._visible_channels()
        if not visible:
            return

        row = max(0, min(row, len(visible) - 1))
        self.active_row = row
        self._last_focus_area = 'channel'

        cid = BASE_CHANNEL_ID + row
        try:
            self.setFocusId(cid)
        except:
            pass

        self._update_bottom_from_selection()

    def _focus_event_button(self, btn_id):
        if btn_id not in self.event_map:
            return

        self.active_btn_id = btn_id
        self.active_row = self.event_map[btn_id]['row']
        self._last_focus_area = 'events'

        try:
            self.setFocusId(btn_id)
        except:
            pass

        self._update_bottom_from_selection()

    def _focus_bottom_default(self):
        self._last_focus_area = 'bottom'
        try:
            self.setFocusId(BOTTOM_SCHEDULE_ID)
        except:
            pass

    def _bottom_right_column(self):
        # Stara prawa kolumna nie istnieje. Stopka jest w jednym rzędzie.
        return self._bottom_action_row()

    def _bottom_action_row(self):
        return [
            HEADER_HOME_ID,
            BOTTOM_BIG_LEFT_ID,
            BOTTOM_LEFT_ID,
            BOTTOM_RIGHT_ID,
            BOTTOM_BIG_RIGHT_ID,
            BOTTOM_SCHEDULE_ID,
            BOTTOM_RECINFO_ID,
            BOTTOM_SEARCH_ID,
            BOTTOM_NOW_ID,
            BOTTOM_SETTINGS_ID,
        ]

    def _bottom_time_row(self):
        return [BOTTOM_BIG_LEFT_ID, BOTTOM_LEFT_ID, BOTTOM_RIGHT_ID, BOTTOM_BIG_RIGHT_ID]

    def _is_top_grid_row(self, row):
        """Wiersze 0, 1, 2 - górna część gridu (idą do bocznych górnych: 81/83)."""
        return 0 <= row <= 2

    def _is_bottom_grid_row(self, row):
        """Wiersze 3, 4 - dolna część gridu (idą do bocznych dolnych: 82/84)."""
        return 3 <= row <= 4

    def _side_left_for_row(self, row):
        """Zwraca ID bocznej strzałki LEWEJ dla danego wiersza."""
        return SIDE_LEFT_DOWN_ID if self._is_bottom_grid_row(row) else SIDE_LEFT_UP_ID

    def _side_right_for_row(self, row):
        """Zwraca ID bocznej strzałki PRAWEJ dla danego wiersza."""
        return SIDE_RIGHT_DOWN_ID if self._is_bottom_grid_row(row) else SIDE_RIGHT_UP_ID

    def _nav_left(self):
        focus_id = self._current_focus_id()

        # Pasek grup - lewa strzałka grup [<]
        if focus_id == HEADER_GROUP_RIGHT_ID:
            try:
                self.setFocusId(HEADER_GROUP_LEFT_ID)
            except:
                pass
            return True

        if focus_id == HEADER_GROUP_LEFT_ID:
            # Z lewej strzałki grup nigdzie - to skrajna lewa pozycja
            return True

        # Boczne strzałki LEWE (81, 82) - skok na kolumnę kanałów
        if focus_id in [SIDE_LEFT_UP_ID, SIDE_LEFT_DOWN_ID]:
            self._focus_channel_in_active_row()
            return True

        # Boczne strzałki PRAWE (83, 84) - skok na ostatni event w aktywnym wierszu
        if focus_id in [SIDE_RIGHT_UP_ID, SIDE_RIGHT_DOWN_ID]:
            if self._focus_last_event_in_active_row():
                return True
            return True

        # Event w gridzie
        if focus_id in self.event_map:
            left_btn = self._neighbor_event_left(focus_id)
            if left_btn:
                self._focus_event_button(left_btn)
            else:
                # Pierwszy event w wierszu - skok na boczną LEWĄ (81 lub 82)
                row = self.event_map[focus_id]['row']
                target = self._side_left_for_row(row)
                try:
                    self.setFocusId(target)
                except:
                    pass
            return True

        # Kanał - przesuwa oś czasu w lewo
        if self._is_channel_control(focus_id):
            row = focus_id - BASE_CHANNEL_ID
            self._move_left()
            xbmc.sleep(10)

            visible = self._visible_channels()
            if visible:
                row = max(0, min(row, len(visible) - 1))
                self._focus_channel_row(row)
            return True

        # Reszta (stopka, textbox, scrollbar) - obsługuje XML
        return False

    def _nav_right(self):
        focus_id = self._current_focus_id()

        # Pasek grup
        if focus_id == HEADER_GROUP_LEFT_ID:
            try:
                self.setFocusId(HEADER_GROUP_RIGHT_ID)
            except:
                pass
            return True

        if focus_id == HEADER_GROUP_RIGHT_ID:
            # Skrajnie prawa pozycja w pasku grup
            return True

        # Boczne strzałki LEWE (81, 82) - skok na pierwszy event w aktywnym wierszu
        if focus_id in [SIDE_LEFT_UP_ID, SIDE_LEFT_DOWN_ID]:
            btn = self._first_event_in_row(self.active_row)
            if btn:
                self._focus_event_button(btn)
            return True

        # Kanał - skok na pierwszy event tego wiersza
        if self._is_channel_control(focus_id):
            row = focus_id - BASE_CHANNEL_ID
            btn = self._first_event_in_row(row)
            if btn:
                self._focus_event_button(btn)
            else:
                # Brak eventu - skok na boczną LEWĄ
                target = self._side_left_for_row(row)
                try:
                    self.setFocusId(target)
                except:
                    pass
            return True

        # Event w gridzie
        if focus_id in self.event_map:
            right_btn = self._neighbor_event_right(focus_id)
            if right_btn:
                self._focus_event_button(right_btn)
            else:
                # Ostatni event w wierszu - skok na boczną PRAWĄ (83 lub 84)
                row = self.event_map[focus_id]['row']
                target = self._side_right_for_row(row)
                try:
                    self.setFocusId(target)
                except:
                    pass
            return True

        # Boczne strzałki PRAWE (83, 84) - przesuwa oś czasu w prawo
        if focus_id in [SIDE_RIGHT_UP_ID, SIDE_RIGHT_DOWN_ID]:
            self._move_right()
            xbmc.sleep(10)
            try:
                self.setFocusId(focus_id)
            except:
                pass
            return True

        # Reszta (stopka, textbox, scrollbar) - obsługuje XML
        return False

    def _nav_up(self):
        focus_id = self._current_focus_id()
        visible = self._visible_channels()

        # Event w gridzie
        if focus_id in self.event_map:
            row = self.event_map[focus_id]['row']
            if row > 0:
                btn = self._nearest_event_in_row(row - 1, focus_id)
                if btn:
                    self._focus_event_button(btn)
                else:
                    self._focus_channel_row(row - 1)
            elif self.row_offset > 0:
                self.row_offset -= 1
                self.render()
                btn = self._nearest_event_in_row(0, focus_id)
                if btn:
                    self._focus_event_button(btn)
                else:
                    self._focus_channel_row(0)
            else:
                # Pierwszy wiersz - wyjście do paska grup (lewa strzałka)
                try:
                    self.setFocusId(HEADER_GROUP_LEFT_ID)
                except:
                    pass
            return True

        # Kanał
        if self._is_channel_control(focus_id):
            row = focus_id - BASE_CHANNEL_ID
            if row > 0:
                self._focus_channel_row(row - 1)
            elif self.row_offset > 0:
                self.row_offset -= 1
                self.render()
                self._focus_channel_row(0)
            else:
                try:
                    self.setFocusId(HEADER_GROUP_LEFT_ID)
                except:
                    pass
            return True

        # Pasek grup w górę - nic
        if focus_id in [HEADER_GROUP_LEFT_ID, HEADER_GROUP_RIGHT_ID]:
            return True

        # Reszta (stopka, textbox, scrollbar) - obsługuje XML
        return False

    def _nav_down(self):
        focus_id = self._current_focus_id()
        visible = self._visible_channels()

        # Pasek grup w dół -> boczne strzałki górne
        if focus_id == HEADER_GROUP_LEFT_ID:
            try:
                self.setFocusId(SIDE_LEFT_UP_ID)
            except:
                pass
            return True

        if focus_id == HEADER_GROUP_RIGHT_ID:
            # W dół z prawej strzałki grup -> pierwszy event w wierszu 0 albo kanał 0
            btn = self._first_event_in_row(0)
            if btn:
                self._focus_event_button(btn)
            elif visible:
                self._focus_channel_row(0)
            return True

        # Event w gridzie
        if focus_id in self.event_map:
            row = self.event_map[focus_id]['row']
            if row < len(visible) - 1:
                btn = self._nearest_event_in_row(row + 1, focus_id)
                if btn:
                    self._focus_event_button(btn)
                else:
                    self._focus_channel_row(row + 1)
            elif self.row_offset + VISIBLE_ROWS < len(self.channels):
                self.row_offset += 1
                self.render()
                target_row = min(len(self._visible_channels()) - 1, row)
                btn = self._nearest_event_in_row(target_row, focus_id)
                if btn:
                    self._focus_event_button(btn)
                else:
                    self._focus_channel_row(target_row)
            else:
                # Ostatni wiersz - przejście do textboxa opisu
                try:
                    self.setFocusId(TEXTBOX_PROXY_ID)
                except:
                    pass

        # Kanał
        if self._is_channel_control(focus_id):
            row = focus_id - BASE_CHANNEL_ID
            if row < len(visible) - 1:
                self._focus_channel_row(row + 1)
            elif self.row_offset + VISIBLE_ROWS < len(self.channels):
                self.row_offset += 1
                self.render()
                self._focus_channel_row(min(len(self._visible_channels()) - 1, row))
            else:
                # Ostatni kanał - przejście do textboxa opisu
                try:
                    self.setFocusId(66)
                except:
                    pass
            return True

        # Reszta (stopka, textbox, scrollbar) - obsługuje XML
        return False

    def _move_left(self):
        self.time_start -= STEP_SMALL
        self._window_events_cache = {}
        self._rect_cache = {}
        self.render()

    def _move_right(self):
        self.time_start += STEP_SMALL
        self._window_events_cache = {}
        self._rect_cache = {}
        self.render()

    def _move_big_left(self):
        self.time_start -= STEP_BIG
        self._window_events_cache = {}
        self._rect_cache = {}
        self.render()

    def _move_big_right(self):
        self.time_start += STEP_BIG
        self._window_events_cache = {}
        self._rect_cache = {}
        self.render()

    def _go_to_start(self):
        self.time_start = self._initial_time_start()
        self._window_events_cache = {}
        self._rect_cache = {}
        self.render()

    def _scroll_rows(self, delta):
        if delta < 0:
            if self.row_offset + VISIBLE_ROWS < len(self.channels):
                self.row_offset += 1
                self.render()
        elif delta > 0:
            if self.row_offset > 0:
                self.row_offset -= 1
                self.render()

    def _get_current_and_next_event_for_state(self, events):
        now_ts = time.time()

        if not events:
            return {}, {}

        for idx, ev in enumerate(events):
            ev_start = int(ev.get('start', 0) or 0)
            ev_stop = int(ev.get('stop', 0) or 0)

            if ev_start <= now_ts < ev_stop:
                next_event = events[idx + 1] if idx + 1 < len(events) else {}
                return ev, next_event

        for idx, ev in enumerate(events):
            ev_stop = int(ev.get('stop', 0) or 0)
            if ev_stop > now_ts:
                next_event = events[idx + 1] if idx + 1 < len(events) else {}
                return ev, next_event

        first = events[0]
        second = events[1] if len(events) > 1 else {}
        return first, second

    def _play_channel(self, abs_row):
        if abs_row < 0 or abs_row >= len(self.channels):
            return

        try:
            selected = self.channels[abs_row]
            selected_cmd = str(selected.get('cmd', ''))
            selected_title = str(selected.get('title', ''))

            play_index = -1
            for i, item in enumerate(self.full_channels):
                if str(item.get('cmd', '')) == selected_cmd and str(item.get('title', '')) == selected_title:
                    play_index = i
                    break

            if play_index < 0:
                for i, item in enumerate(self.full_channels):
                    if str(item.get('cmd', '')) == selected_cmd:
                        play_index = i
                        break

            if play_index < 0:
                xbmcgui.Dialog().notification(common.addonname, 'Nie znaleziono kanału w pełnej liście przewodnika', xbmcgui.NOTIFICATION_ERROR)
                return

            state_channels = []
            for item in self.full_channels:
                evs = item.get('events', [])
                current_event, next_event = self._get_current_and_next_event_for_state(evs)
                start_ts = current_event.get('start', 0)
                stop_ts = current_event.get('stop', 0)

                state_channels.append(
                    {
                        'title': item.get('title', ''),
                        'cmd': item.get('cmd', ''),
                        'logo_url': item.get('logo_url', ''),
                        'plot': current_event.get('desc', '') or item.get('plot', ''),
                        'program': current_event.get('title', ''),
                        'next_program': next_event.get('title', ''),
                        'progress': _calc_progress(start_ts, stop_ts) if current_event else item.get('progress', 0),
                        'start_ts': start_ts,
                        'stop_ts': stop_ts,
                        'group_name': item.get('group_name', ''),
                    }
                )

            channel_switch.save_channel_state(state_channels, play_index, self.portal)
            channel_switch.play_index(play_index)

            try:
                state = common.read_json_safe(common.channel_state_file)

                if self.use_custom_order:
                    state['state_kind'] = 'tv_sorted'
                    state['state_refresh_enabled'] = True
                    state['state_refresh_custom_order'] = True
                    state['state_refresh_group'] = 'ALL_POLISH'
                    state['state_refresh_genre_id'] = ''
                    state['state_refresh_genre_name'] = 'Wszystkie Polskie'
                    state['start_group'] = 'WSZYSTKIE'
                else:
                    state['state_kind'] = 'tv_provider'
                    state['state_refresh_enabled'] = False
                    state['state_refresh_custom_order'] = False
                    state['state_refresh_group'] = ''
                    state['state_refresh_genre_id'] = common.args.get('genre_id', [''])[0]
                    state['state_refresh_genre_name'] = self.genre_name or ''
                    state['start_group'] = 'WSZYSTKIE'

                common.write_json_safe(common.channel_state_file, state)
                xbmc.log(
                    f"[TVGuide] saved state_kind={state.get('state_kind')} refresh_enabled={state.get('state_refresh_enabled')} group={state.get('state_refresh_group')}",
                    xbmc.LOGINFO
                )
            except Exception as e:
                xbmc.log(f'[TVGuide] save start_group error: {e}', xbmc.LOGERROR)

            self.close()

        except Exception as e:
            xbmc.log(f'[TVGuide] _play_channel error: {e}', xbmc.LOGERROR)
            xbmcgui.Dialog().notification(common.addonname, f'Błąd odtwarzania kanału: {e}', xbmcgui.NOTIFICATION_ERROR)


    def _toggle_active_record(self):
        selected = self.event_map.get(self.active_btn_id)
        if not selected:
            return

        ch = selected['channel']
        ev = selected['event']

        cmd = ch.get('cmd', '')
        title = ch.get('title', 'Kanał')
        logo = ch.get('logo_url', '')
        start_ts = ev.get('start', 0)
        stop_ts = ev.get('stop', 0)

        is_future = False
        try:
            is_future = int(float(start_ts)) > int(time.time())
        except:
            is_future = False

        if is_future:
            if recorder.has_scheduled_recording(cmd, start_ts, stop_ts):
                xbmc.executebuiltin(
                    f'RunPlugin({common.build_url({"mode":"record_tv_schedule_delete","cmd":cmd,"start_ts":start_ts,"stop_ts":stop_ts})})'
                )
            else:
                xbmc.executebuiltin(
                    f'RunPlugin({common.build_url({"mode":"record_tv_schedule","cmd":cmd,"title":title,"logo_url":logo,"portal":json.dumps(self.portal),"start_ts":start_ts,"stop_ts":stop_ts})})'
                )
        else:
            xbmc.executebuiltin(
                f'RunPlugin({common.build_url({"mode":"record_tv_program","cmd":cmd,"title":title,"logo_url":logo,"portal":json.dumps(self.portal),"start_ts":start_ts,"stop_ts":stop_ts})})'
            )

        xbmc.sleep(150)
        self._scheduled_cache = {}
        self.render()

        xbmc.sleep(400)
        self._scheduled_cache = {}
        self.render()

    def _open_search(self):
        # placeholder - na razie tylko notyfikacja
        xbmcgui.Dialog().notification(common.addonname, 'Wyszukiwarka - wkrótce', xbmcgui.NOTIFICATION_INFO)

    def _open_now_on_tv(self):
        # placeholder - na razie tylko notyfikacja
        xbmcgui.Dialog().notification(common.addonname, 'Co leci teraz - wkrótce', xbmcgui.NOTIFICATION_INFO)

    def onFocus(self, controlId):
        self._poll_recording_state()
        if self._busy:
            return

        if controlId in [TEXTBOX_ID, TEXTBOX_SCROLL_ID, TEXTBOX_PROXY_ID]:
            self._last_focus_area = 'description'
            return

        if controlId in self.event_map:
            self.active_btn_id = controlId
            self.active_row = self.event_map[controlId]['row']
            self._last_focus_area = 'events'
            self._update_bottom_from_selection()
            return

        if BASE_CHANNEL_ID <= controlId < BASE_CHANNEL_ID + VISIBLE_ROWS:
            self.active_row = controlId - BASE_CHANNEL_ID
            self._last_focus_area = 'channel'
            self.active_btn_id = None
            self._update_bottom_from_selection()
            return

        if self._is_side_control(controlId):
            self._last_focus_area = 'side'
            return

        if self._is_bottom_control(controlId):
            self._last_focus_area = 'bottom'
            return

        if controlId in [HEADER_GROUP_LEFT_ID, HEADER_GROUP_RIGHT_ID, HEADER_HOME_ID]:
            self._last_focus_area = 'header'
            return

        # NOWE — obsługa textboxa i scrollbara
        if controlId in [TEXTBOX_ID, TEXTBOX_SCROLL_ID]:
            self._last_focus_area = 'description'
            return

        if controlId in self.event_map:
            self.active_btn_id = controlId
            self.active_row = self.event_map[controlId]['row']
            self._last_focus_area = 'events'
            self._update_bottom_from_selection()
            return

        if BASE_CHANNEL_ID <= controlId < BASE_CHANNEL_ID + VISIBLE_ROWS:
            self.active_row = controlId - BASE_CHANNEL_ID
            self._last_focus_area = 'channel'
            self.active_btn_id = None
            self._update_bottom_from_selection()
            return

        if self._is_side_control(controlId):
            self._last_focus_area = 'side'
            return

        if self._is_bottom_control(controlId):
            self._last_focus_area = 'bottom'
            return

        if controlId in [HEADER_GROUP_LEFT_ID, HEADER_GROUP_RIGHT_ID, HEADER_HOME_ID]:
            self._last_focus_area = 'header'
            return

    def onClick(self, controlId):

        if controlId == SIDE_LEFT_UP_ID:
            self._focus_channel_in_active_row()
            return

        if controlId == SIDE_LEFT_DOWN_ID:
            self._focus_channel_in_active_row()
            return

        if controlId == SIDE_RIGHT_UP_ID:
            self._move_right()
            return

        if controlId == SIDE_RIGHT_DOWN_ID:
            self._move_right()
            return

        if controlId == HEADER_HOME_ID:
            self._go_to_start()
            return

        if controlId == HEADER_GROUP_LEFT_ID:
            self._switch_group_left()
            return

        if controlId == HEADER_GROUP_RIGHT_ID:
            self._switch_group_right()
            return

        if controlId == BOTTOM_BIG_LEFT_ID:
            self._move_big_left()
            return

        if controlId == BOTTOM_LEFT_ID:
            self._move_left()
            return

        if controlId == BOTTOM_RIGHT_ID:
            self._move_right()
            return

        if controlId == BOTTOM_BIG_RIGHT_ID:
            self._move_big_right()
            return

        if BASE_CHANNEL_ID <= controlId < BASE_CHANNEL_ID + VISIBLE_ROWS:
            row = controlId - BASE_CHANNEL_ID
            abs_row = self.row_offset + row
            self._play_channel(abs_row)
            return

        if controlId in self.event_map:
            self.active_btn_id = controlId
            self.active_row = self.event_map[controlId]['row']
            self._show_event_dialog()
            return

        if controlId == BOTTOM_RECINFO_ID:
            guide_overlay.open_guide_overlay(self.portal, 'recording_info')
            self._handle_reopen_request()
            return

        if controlId == BOTTOM_SCHEDULE_ID:
            guide_overlay.open_guide_overlay(self.portal, 'schedule_manager')
            self._handle_reopen_request()
            return

        if controlId == BOTTOM_SETTINGS_ID:
            guide_overlay.open_guide_overlay(self.portal, 'provider_settings')
            self._handle_reopen_request()
            return

        if controlId == BOTTOM_SEARCH_ID:
            self._open_search()
            return

        if controlId == BOTTOM_NOW_ID:
            self._open_now_on_tv()
            return

    def onAction(self, action):
        aid = action.getId()
        self._handle_refresh_request()
        self._poll_recording_state()

        try:
            current_focus = self.getFocusId()
        except:
            current_focus = -1

        focus_id = current_focus

        XML_NAV_IDS = {
            33, 71, 72, 73, 74,
            52, 53, 54, 55, 56,
            44, 65, 66,
            TEXTBOX_ID, TEXTBOX_SCROLL_ID
        }   

        if focus_id in XML_NAV_IDS:
            if aid in [9, 10, 92]:
                self._go_back()
                return
            return

        if aid == 117:
            if self.active_btn_id in self.event_map:
                self._show_event_dialog()
                return

        if aid == 104:
            if focus_id not in [44, 61]:
                self._scroll_rows(1)
            return

        if aid == 105:
            if focus_id not in [44, 61]:
                self._scroll_rows(-1)
            return

        if aid in [9, 10, 13, 92]:
            self._go_back()
            return

        if not self._allow_action():
            return

        if aid in [1, 169, 521]:
            if self._nav_left():
                return

        if aid in [2, 168, 520]:
            if self._nav_right():
                return

        if aid in [3, 166, 522]:
            if self._nav_up():
                return

        if aid in [4, 167, 523]:
            if self._nav_down():
                return

        if aid in [5, 186]:
            self._move_big_left()
            return

        if aid in [6, 185]:
            self._move_big_right()
            return

        if aid in [7, 25]:
            self._move_left()
            return

        if aid in [11, 24]:
            self._move_right()
            return

def get_live_view_channels(portal, use_custom_order=True, filter_group='ALL_POLISH'):
    try:
        guide_source = _build_guide_source(
            portal,
            filter_group if use_custom_order else 'ALL_POLISH'
        )

        full_channels = guide_source.get('full_channels', [])
        view_channels = guide_source.get('view_channels', []) if use_custom_order else full_channels[:]

        return {
            'full_channels': full_channels,
            'view_channels': view_channels
        }
    except Exception as e:
        xbmc.log(f'[TVGuide] get_live_view_channels error: {e}', xbmc.LOGERROR)
        return {
            'full_channels': [],
            'view_channels': []
        }

def open_guide_with_params(portal, custom_order=True, filter_group='ALL_POLISH', genre_name='WSZYSTKIE', return_to=''):
    # Ustaw args PRZED utworzeniem obiektu, żeby __init__ użył właściwych wartości
    common.args['custom_order'] = ['true' if custom_order else 'false']
    common.args['filter_group'] = [filter_group]
    common.args['genre_name'] = [genre_name]
    common.args['return_to'] = [return_to]

    win = TVGuideWindow(
        'tv_guide.xml',
        common.addon_path,
        'Default',
        '1080i',
        portal=portal
    )

    win.doModal()
    del win

def open_guide():
    portal = common.get_current_portal()

    portal_arg = common.args.get('portal', [None])[0]
    if portal_arg:
        try:
            portal = json.loads(portal_arg)
        except Exception:
            pass

    if not portal:
        xbmcgui.Dialog().notification(common.addonname, 'Brak aktywnego dostawcy', xbmcgui.NOTIFICATION_ERROR)
        try:
            xbmcplugin.endOfDirectory(common.addon_handle, succeeded=False, cacheToDisc=False)
        except Exception:
            pass
        return

    win = TVGuideWindow('tv_guide.xml', common.addon_path, 'Default', '1080i', portal=portal)
    win.doModal()
    del win

    try:
        xbmcplugin.endOfDirectory(common.addon_handle, succeeded=False, cacheToDisc=False)
    except Exception:
        pass



def get_upcoming_events_for_channel(channel_name, limit=6):
    try:
        raw_name = str(channel_name or '').strip()
        if not raw_name:
            return []

        raw_epg = common.read_json_safe(common.epg_raw_file)
        events = _find_epg_events(raw_epg, raw_name)

        if not events:
            return []

        now_ts = time.time()
        result = []

        for ev in events:
            ev_stop = int(ev.get('stop', 0) or 0)
            if ev_stop <= now_ts:
                continue

            result.append({
                'start_ts': ev.get('start', 0),
                'stop_ts': ev.get('stop', 0),
                'title': ev.get('title', ''),
                'desc': ev.get('desc', ''),
                'img': ev.get('img', '')
            })

            if len(result) >= limit:
                break

        return result

    except Exception as e:
        xbmc.log(f'[TVGuide] get_upcoming_events_for_channel error: {e}', xbmc.LOGERROR)
        return []