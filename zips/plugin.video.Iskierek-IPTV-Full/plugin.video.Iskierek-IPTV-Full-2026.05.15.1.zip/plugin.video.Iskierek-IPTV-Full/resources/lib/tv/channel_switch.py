# -*- coding: utf-8 -*-
import json
import xbmc
import xbmcgui

from resources.lib import common
from resources.lib import timeshift


# =========================
# Persist state
# =========================
def save_channel_state(channels, current_index, portal):
    existing = common.read_json_safe(common.channel_state_file)
    if not isinstance(existing, dict):
        existing = {}

    existing['channels'] = channels
    existing['current_index'] = current_index
    existing['portal'] = portal

    common.write_json_safe(common.channel_state_file, existing)


def load_channel_state():
    data = common.read_json_safe(common.channel_state_file)
    if not isinstance(data, dict):
        return {'channels': [], 'current_index': -1, 'portal': {}}
    return data


# =========================
# Playback/UI helpers
# =========================
def set_channel_switch_in_progress(active):
    try:
        win = xbmcgui.Window(10000)
        if active:
            win.setProperty('IskierekChannelSwitchInProgress', '1')
        else:
            win.clearProperty('IskierekChannelSwitchInProgress')
    except Exception:
        pass


def force_close_live_window():
    try:
        win = xbmcgui.Window(10000)
        if win.getProperty('IskierekReturnLiveActive') == '1':
            win.setProperty('IskierekLiveForceClose', '1')
            xbmc.sleep(200)
    except Exception:
        pass


def stop_active_timeshift_if_needed():
    try:
        if timeshift.is_timeshift_active():
            xbmc.log('[channel_switch] stopping active timeshift before channel play', xbmc.LOGINFO)
            timeshift.stop_timeshift_buffer()
            xbmc.sleep(200)
    except Exception as e:
        xbmc.log(f'[channel_switch] stop_active_timeshift_if_needed error: {e}', xbmc.LOGERROR)


def can_use_channel_switch():
    try:
        win = xbmcgui.Window(10000)

        if win.getProperty('IskierekPlaybackPlugin') != 'plugin.video.Iskierek-IPTV-Full':
            return False

        if win.getProperty('IskierekTvPlaybackActive') != '1':
            return False

        return True
    except Exception:
        return False


# =========================
# Core: play by index
# =========================
def play_index(idx):
    state = load_channel_state()
    channels = state.get('channels', [])
    portal = state.get('portal', {})

    if not channels:
        xbmcgui.Dialog().notification(common.addonname, 'Brak listy kanałów', xbmcgui.NOTIFICATION_ERROR)
        return

    if idx < 0 or idx >= len(channels):
        xbmcgui.Dialog().notification(common.addonname, 'Błędny indeks kanału', xbmcgui.NOTIFICATION_ERROR)
        return

    ch = channels[idx]
    save_channel_state(channels, idx, portal)

    set_channel_switch_in_progress(True)

    try:
        stop_active_timeshift_if_needed()
    except Exception:
        pass

    try:
        force_close_live_window()
    except Exception:
        pass

    try:
        use_timeshift = timeshift.is_timeshift_enabled()
    except Exception:
        use_timeshift = False

    mode_name = 'play_tv_ts' if use_timeshift else 'play_tv'

    url = common.build_url({
        'mode': mode_name,
        'cmd': ch.get('cmd', ''),
        'title': ch.get('title', ''),
        'logo_url': ch.get('logo_url', ''),
        'portal': json.dumps(portal),
        'plot': ch.get('plot', ''),
        'program': ch.get('program', ''),
        'stop_ts': ch.get('stop_ts', 0),
        'channel_index': idx
    })

    xbmc.log(f"[channel_switch] play_index idx={idx} title={ch.get('title', '')} mode={mode_name}", xbmc.LOGINFO)

    if use_timeshift:
        xbmc.executebuiltin(f'RunPlugin({url})')
    else:
        xbmc.executebuiltin(f'PlayMedia({url})')


# =========================
# Old sequential switching (optional)
# =========================
def play_next_channel():
    if not can_use_channel_switch():
        return
    state = load_channel_state()
    idx = state.get('current_index', -1)
    if idx < 0:
        xbmcgui.Dialog().notification(common.addonname, 'Nieznany aktualny kanał', xbmcgui.NOTIFICATION_ERROR)
        return
    play_index(idx + 1)


def play_prev_channel():
    if not can_use_channel_switch():
        return
    state = load_channel_state()
    idx = state.get('current_index', -1)
    if idx < 0:
        xbmcgui.Dialog().notification(common.addonname, 'Nieznany aktualny kanał', xbmcgui.NOTIFICATION_ERROR)
        return
    play_index(idx - 1)


# =========================
# Zapper preview API (Window properties)
# =========================
_ZP_TARGET = 'Iskierek.ChannelSwitch.TargetIndex'
_ZP_TITLE  = 'Iskierek.ChannelSwitch.PreviewTitle'
_ZP_LOGO   = 'Iskierek.ChannelSwitch.PreviewLogo'
_ZP_NUM    = 'Iskierek.ChannelSwitch.PreviewNumber'
_ZP_TOTAL  = 'Iskierek.ChannelSwitch.PreviewTotal'
_ZP_EPG_NOW = 'Iskierek.ChannelSwitch.PreviewEpgNow'
_ZP_EPG_PLOT = 'Iskierek.ChannelSwitch.PreviewEpgPlot'


def _zp_win():
    return xbmcgui.Window(10000)


def _zp_set(k, v):
    try:
        _zp_win().setProperty(k, str(v))
    except Exception:
        pass


def _zp_get(k, default=''):
    try:
        return _zp_win().getProperty(k) or default
    except Exception:
        return default


def _zp_clear(k):
    try:
        _zp_win().clearProperty(k)
    except Exception:
        pass


def _zp_set_preview_props(channels, idx):
    if not channels or idx < 0 or idx >= len(channels):
        return
    ch = channels[idx]
    _zp_set(_ZP_TITLE, ch.get('title', ''))
    _zp_set(_ZP_LOGO, ch.get('logo_url', ''))
    _zp_set(_ZP_NUM, str(idx + 1))
    _zp_set(_ZP_TOTAL, str(len(channels)))

    # EPG (to co już masz w danych kanału)
    epg_now = ch.get('program', '') or ''
    epg_plot = ch.get('plot', '') or ''
    _zp_set(_ZP_EPG_NOW, epg_now)
    _zp_set(_ZP_EPG_PLOT, epg_plot)


def _zp_set_target(idx):
    _zp_set(_ZP_TARGET, str(int(idx)))


def _zp_get_target():
    v = _zp_get(_ZP_TARGET, '')
    if v == '':
        return None
    try:
        return int(v)
    except Exception:
        return None


def preview_cancel():
    _zp_clear(_ZP_TARGET)
    _zp_clear(_ZP_TITLE)
    _zp_clear(_ZP_LOGO)
    _zp_clear(_ZP_NUM)
    _zp_clear(_ZP_TOTAL)
    _zp_clear(_ZP_EPG_NOW)
    _zp_clear(_ZP_EPG_PLOT)


def preview_init_to_current():
    state = load_channel_state()
    channels = state.get('channels', [])
    cur = state.get('current_index', -1)

    xbmc.log(f'[zapper] init_to_current cur={cur} channels={len(channels)}', xbmc.LOGINFO)

    if not channels:
        return
    if cur < 0 or cur >= len(channels):
        cur = 0

    _zp_set_target(cur)
    _zp_set_preview_props(channels, cur)


def preview_step(direction):
    """
    direction: +1 następny, -1 poprzedni (w liście)
    """
    state = load_channel_state()
    channels = state.get('channels', [])
    if not channels:
        return

    base = _zp_get_target()
    if base is None:
        base = state.get('current_index', 0)
        if base < 0 or base >= len(channels):
            base = 0

    new_index = (base + int(direction)) % len(channels)

    _zp_set_target(new_index)
    _zp_set_preview_props(channels, new_index)

    xbmc.log(
        f'[zapper] step dir={direction} base={base} -> new={new_index} title={channels[new_index].get("title","")}',
        xbmc.LOGINFO
    )


def preview_commit_now():
    idx = _zp_get_target()
    xbmc.log(f'[zapper] commit idx={idx}', xbmc.LOGINFO)
    if idx is None:
        return
    play_index(int(idx))

# Kompatybilność wsteczna (jeśli gdzieś jeszcze wołasz preview_channel_up/down)
def preview_channel_up():
    preview_step(1)

def preview_channel_down():
    preview_step(-1)