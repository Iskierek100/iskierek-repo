# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import json
import time
from resources.lib import common
from resources.lib.tv import channel_switch
from resources.lib.recording import recorder


class ProgramInfoDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__()
        self.channel = kwargs.get('channel', {})
        self.portal = kwargs.get('portal', {})
        self.channel_index = kwargs.get('channel_index', -1)

    def _is_future_program(self):
        try:
            start_ts = int(float(self.channel.get('start_ts', 0)))
            return start_ts > int(time.time())
        except:
            return False

    def _has_timer(self):
        return recorder.has_scheduled_recording(
            self.channel.get('cmd', ''),
            self.channel.get('start_ts', 0),
            self.channel.get('stop_ts', 0)
        )

    def onInit(self):
        title = self.channel.get('title', 'Kanał')
        program_now = self.channel.get('program_now', '')
        program_now_time = self.channel.get('program_now_time', '')
        program_next = self.channel.get('program_next', '')
        program_next_time = self.channel.get('program_next_time', '')
        plot = self.channel.get('plot', 'Brak opisu.')
        logo = self.channel.get('logo_url', '')

        try:
            self.getControl(10).setLabel(title)
        except:
            pass

        try:
            now_label = f"{program_now_time}  {program_now}".strip()
            self.getControl(11).setLabel(now_label if now_label else 'Brak danych programu')
        except:
            pass

        try:
            next_label = f"{program_next_time}  {program_next}".strip()
            self.getControl(12).setLabel(next_label if next_label else 'Brak danych o następnym programie')
        except:
            pass

        try:
            self.getControl(13).setText(plot or 'Brak opisu.')
        except:
            pass

        try:
            self.getControl(14).setImage(logo)
        except:
            pass

        try:
            if self._is_future_program():
                if self._has_timer():
                    self.getControl(22).setLabel('Usuń nagranie')
                else:
                    self.getControl(22).setLabel('Ustaw nagranie')
            else:
                self.getControl(22).setLabel('Nagrywaj teraz')
        except:
            pass

        try:
            similar_count = len(_find_similar_programs(self.channel.get('program_now', '') or self.channel.get('title', '')))
            if similar_count > 1:
                self.getControl(25).setLabel(f'Podobne ({similar_count})')
            else:
                self.getControl(25).setLabel('Pokaż podobne')
        except:
            pass

    def onAction(self, action):
        aid = action.getId()

        if aid in [9, 10, 13, 92]:
            self.close()
            return

        try:
            focus_id = self.getFocusId()
        except:
            focus_id = -1

        if aid in [3, 166]:
            if focus_id in [21, 22, 23, 24]:
                try:
                    self.setFocusId(13)
                    return
                except:
                    pass

        if aid in [4, 167]:
            if focus_id == 13:
                try:
                    self.setFocusId(21)
                    return
                except:
                    pass

    def onClick(self, controlId):
        if controlId == 21:
            if self.channel_index >= 0:
                try:
                    xbmcgui.Window(10000).setProperty('IskierekGuideCloseAfterDialog', '1')
                except Exception:
                    pass

                channel_switch.save_channel_state(
                    common.read_json_safe(common.channel_state_file).get('channels', []),
                    self.channel_index,
                    self.portal
                )
                self.close()
                xbmc.sleep(150)
                channel_switch.play_index(self.channel_index)
            else:
                self.close()

        elif controlId == 22:
            cmd = self.channel.get('cmd', '')
            title = self.channel.get('title', 'Kanał')
            logo = self.channel.get('logo_url', '')
            start_ts = self.channel.get('start_ts', 0)
            stop_ts = self.channel.get('stop_ts', 0)

            if self._is_future_program():
                if self._has_timer():
                    xbmc.executebuiltin(
                        f'RunPlugin({common.build_url({"mode":"record_tv_schedule_delete","cmd":cmd,"start_ts":start_ts,"stop_ts":stop_ts})})'
                    )
                    xbmcgui.Dialog().notification(common.addonname, 'Usunięto nagranie z programatora', xbmcgui.NOTIFICATION_INFO)
                else:
                    xbmc.executebuiltin(
                        f'RunPlugin({common.build_url({"mode":"record_tv_schedule","cmd":cmd,"title":title,"logo_url":logo,"portal":json.dumps(self.portal),"start_ts":start_ts,"stop_ts":stop_ts})})'
                    )
                    xbmcgui.Dialog().notification(common.addonname, 'Ustawiono nagranie programu', xbmcgui.NOTIFICATION_INFO)
            else:
                xbmc.executebuiltin(
                    f'RunPlugin({common.build_url({"mode":"record_tv_program","cmd":cmd,"title":title,"logo_url":logo,"portal":json.dumps(self.portal),"start_ts":start_ts,"stop_ts":stop_ts})})'
                )
                xbmcgui.Dialog().notification(common.addonname, 'Wysłano polecenie nagrywania programu', xbmcgui.NOTIFICATION_INFO)

            self.close()
            xbmc.sleep(300)
            xbmc.executebuiltin('Container.Refresh')

        elif controlId == 23:
            xbmc.executebuiltin(
                f'RunPlugin({common.build_url({"mode":"recording_info","portal":json.dumps(self.portal)})})'
            )

        elif controlId == 24:
            self.close()

        elif controlId == 25:
            self._show_similar_programs()
            return

    def _show_similar_programs(self):
        title = self.channel.get('program_now', '') or self.channel.get('title', '')
        if not title:
            xbmcgui.Dialog().notification(common.addonname, 'Brak tytułu programu', xbmcgui.NOTIFICATION_WARNING)
            return

        results = _find_similar_programs(title)

        if not results:
            xbmcgui.Dialog().notification(common.addonname, f'Nie znaleziono podobnych programów do: {title}', xbmcgui.NOTIFICATION_INFO)
            return

        # Lista do wyświetlenia
        labels = []
        for r in results:
            ch_name = r.get('channel_name', '?')
            start_ts = r.get('start_ts', 0)
            stop_ts = r.get('stop_ts', 0)
            prog_title = r.get('title', '')

            day = time.strftime('%d.%m', time.localtime(start_ts)) if start_ts else ''
            time_range = ''
            if start_ts and stop_ts:
                time_range = f"{time.strftime('%H:%M', time.localtime(start_ts))}-{time.strftime('%H:%M', time.localtime(stop_ts))}"

            labels.append(f"[{ch_name}] {day} {time_range}  -  {prog_title}")

        idx = xbmcgui.Dialog().select(f'Podobne programy: {title}', labels)
        if idx < 0:
            return

        # Po wyborze otwórz info o tym programie
        chosen = results[idx]
        new_channel_data = {
            'title': chosen.get('channel_name', ''),
            'cmd': chosen.get('cmd', ''),
            'logo_url': chosen.get('logo_url', '') or self.channel.get('logo_url', ''),
            'plot': chosen.get('desc', ''),
            'program_now': chosen.get('title', ''),
            'program_now_time': f"{time.strftime('%H:%M', time.localtime(chosen.get('start_ts', 0)))}-{time.strftime('%H:%M', time.localtime(chosen.get('stop_ts', 0)))}" if chosen.get('start_ts') else '',
            'program_next': '',
            'program_next_time': '',
            'start_ts': chosen.get('start_ts', 0),
            'stop_ts': chosen.get('stop_ts', 0),
        }

        self.close()
        xbmc.sleep(150)
        open_program_info(new_channel_data, self.portal, chosen.get('channel_index', -1))

def _normalize_title(t):
    t = str(t or '').lower().strip()
    # usuń częste sufiksy odcinków typu " (1)", " odc. 5", " s2e3"
    import re
    t = re.sub(r'\s*\(\d+\)\s*$', '', t)
    t = re.sub(r'\s*odc\.?\s*\d+.*$', '', t)
    t = re.sub(r'\s*s\d+e\d+.*$', '', t)
    t = re.sub(r'\s*-\s*odcinek\s*\d+.*$', '', t)
    t = re.sub(r'\s+', ' ', t).strip()
    return t


def _find_similar_programs(query_title, limit=200):
    """
    Przeszukuje cały EPG i znajduje wszystkie programy o pasującym tytule.
    """
    try:
        raw_epg = common.read_json_safe(common.epg_raw_file)
        if not raw_epg:
            return []

        # Spróbuj załadować listę kanałów z aktualnego stanu, żeby mieć cmd/logo
        state = common.read_json_safe(common.channel_state_file)
        state_channels = state.get('channels', [])

        # mapa: znormalizowana nazwa kanału EPG -> dane kanału
        channel_meta_map = {}
        for idx, ch in enumerate(state_channels):
            ch_name = ch.get('title', '')
            if not ch_name:
                continue
            norm = common.clean_channel_name(ch_name)
            channel_meta_map[norm] = {
                'cmd': ch.get('cmd', ''),
                'logo_url': ch.get('logo_url', ''),
                'channel_name': ch_name,
                'channel_index': idx,
            }

        query_norm = _normalize_title(query_title)
        if not query_norm:
            return []

        now_ts = time.time()
        results = []

        for epg_key, events in raw_epg.items():
            # spróbuj dopasować kanał do listy state'a
            meta = channel_meta_map.get(epg_key, {})
            ch_name = meta.get('channel_name', epg_key)

            for ev in events or []:
                ev_title = ev.get('title', '')
                ev_norm = _normalize_title(ev_title)
                if not ev_norm:
                    continue

                # Dopasowanie: identyczny lub jeden zawiera drugi
                if ev_norm == query_norm or query_norm in ev_norm or ev_norm in query_norm:
                    # pomijamy programy które już się skończyły dawno (>2h temu)
                    stop_ts = int(ev.get('stop', 0) or 0)
                    if stop_ts and stop_ts < now_ts - 7200:
                        continue

                    results.append({
                        'channel_name': ch_name,
                        'cmd': meta.get('cmd', ''),
                        'logo_url': meta.get('logo_url', ''),
                        'channel_index': meta.get('channel_index', -1),
                        'title': ev_title,
                        'desc': ev.get('desc', ''),
                        'start_ts': int(ev.get('start', 0) or 0),
                        'stop_ts': stop_ts,
                    })

                    if len(results) >= limit:
                        break

            if len(results) >= limit:
                break

        # sortuj po czasie startu
        results.sort(key=lambda x: x.get('start_ts', 0))
        return results

    except Exception as e:
        xbmc.log(f'[ProgramInfo] _find_similar_programs error: {e}', xbmc.LOGERROR)
        return []

def open_program_info(channel, portal, channel_index):
    win = ProgramInfoDialog(
        'program_info.xml',
        common.addon_path,
        'Default',
        '1080i',
        channel=channel,
        portal=portal,
        channel_index=channel_index
    )
    win.doModal()
    del win