# -*- coding: utf-8 -*-
import json
import time
import threading
import os
import xbmc
import xbmcgui

from resources.lib import common
from resources.lib.tv import channel_switch
from resources.lib.recording import recorder
from resources.lib.tv import live as tv_live
from resources.lib.tv import guide as tv_guide
from resources.lib import timeshift


class LiveWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__()

        self.portal = kwargs.get('portal', {})
        self.custom_order = kwargs.get('custom_order', True)
        self.filter_group = kwargs.get('filter_group', 'ALL_POLISH')
        self.genre_id = kwargs.get('genre_id', '')
        self.genre_name = kwargs.get('genre_name', '')

        self.full_channels = []
        self.channels = []
        self.groups = []
        self.group_index = 0
        self.visible_channels = []

        self.list = None
        self.selected_pos = 0
        self.last_right_image = ''
        self.last_list_pos = -1
        self._closed = False
        self._monitor = xbmc.Monitor()
        self._focus_worker = None

        self.allow_list_click = True
        self.play_started = False
        self._last_click_ts = 0.0

        self._returning_from_110_to_11 = False
        self._last_focus_11_pos = 0
        self._state_mtime = self._get_state_mtime()
        self._last_program_check_ts = 0.0
        self._last_nav_context_ts = 0.0
        self._suppress_play_until = 0.0
        self._pending_mini_guide_refresh_at = 0.0

    def onInit(self):
        try:
            try:
                win = xbmcgui.Window(10000)
                win.clearProperty('IskierekLiveLoaded')
                win.clearProperty('IskierekLiveForceClose')
                win.setProperty('IskierekDetailProgressInt', '0')
                win.setProperty('IskierekReturnOwner', 'live_window')
                win.setProperty('IskierekReturnLiveActive', '1')
                win.setProperty('IskierekLivePortal', json.dumps(self.portal))
                win.setProperty('IskierekLiveCustomOrder', 'true' if self.custom_order else 'false')
                win.setProperty('IskierekLiveFilterGroup', self.filter_group or 'ALL_POLISH')
                win.setProperty('IskierekLiveGenreId', self.genre_id or '')
                win.setProperty('IskierekLiveGenreName', self.genre_name or '')
                win.clearProperty('IskierekChannelSwitchInProgress')
            except Exception:
                pass

            self.list = self.getControl(11)

            # POPRAWKA: _load_data() tylko raz, potem fill_list_no_reload()
            self._load_data()
            self._init_group()
            self._apply_group_filter()

            tv_live.rebuild_tv_channel_state_from_live_cache(
                portal=self.portal,
                custom_order=self.custom_order,
                filter_group=self.filter_group,
                genre_id=self.genre_id,
                genre_name=self.genre_name
            )

            self._state_mtime = self._get_state_mtime()
            self._last_program_check_ts = time.time()

            # Wypełnij listę BEZ ponownego ładowania danych
            self._fill_list_ui()
            self._sync_selected_channel_with_state()
            self.update_right_panel(force=True)
            self._update_timeshift_icon()

            try:
                xbmcgui.Window(10000).setProperty('IskierekLiveLoaded', '1')
            except Exception:
                pass

            xbmc.sleep(300)

            try:
                if self.list and self.visible_channels:
                    self.last_list_pos = self.list.getSelectedPosition()
            except Exception:
                pass

            try:
                if self.list and self.list.size() > 0:
                    self.setFocus(self.list)
            except Exception:
                pass

            self._start_focus_watcher()

        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] onInit error: {e}', xbmc.LOGERROR)
            xbmcgui.Dialog().notification(
                common.addonname,
                f'Błąd okna live: {e}',
                xbmcgui.NOTIFICATION_ERROR,
                3000
            )
            self.close()

    def _handle_external_refresh(self):
        try:
            win = xbmcgui.Window(10000)

            if win.getProperty('IskierekLiveForceClose') == '1':
                win.clearProperty('IskierekLiveForceClose')
                self.close()
                return True

            if win.getProperty('IskierekLiveRefresh') != '1':
                return False

            win.clearProperty('IskierekLiveRefresh')
            self._hard_refresh()
            return True

        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] external refresh error: {e}', xbmc.LOGERROR)
            return False

    def _get_state_mtime(self):
        try:
            return os.path.getmtime(common.channel_state_file)
        except Exception:
            return 0

    def _state_file_changed(self):
        try:
            new_mtime = self._get_state_mtime()
            if new_mtime != self._state_mtime:
                self._state_mtime = new_mtime
                return True
            return False
        except Exception:
            return False

    def _check_current_program_finished(self):
        try:
            now_ts = time.time()

            if now_ts - self._last_program_check_ts < 30.0:
                return False

            self._last_program_check_ts = now_ts

            if not self.visible_channels:
                return False

            for ch in self.visible_channels:
                events = ch.get('events', [])
                if not events:
                    continue

                current_event = None
                for ev in events:
                    ev_start = int(ev.get('start', 0) or 0)
                    ev_stop = int(ev.get('stop', 0) or 0)
                    if ev_start <= now_ts < ev_stop:
                        current_event = ev
                        break

                if not current_event and events:
                    first_stop = int(events[0].get('stop', 0) or 0)
                    if first_stop and first_stop <= now_ts:
                        return True

            return False

        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] _check_current_program_finished error: {e}', xbmc.LOGERROR)
            return False

    def _refresh_for_program_change(self):
        try:
            xbmc.log('[LIVE WINDOW] program ended - rebuilding live cache and refreshing list', xbmc.LOGINFO)

            try:
                tv_live.rebuild_tv_channel_state_from_live_cache(
                    portal=self.portal,
                    custom_order=self.custom_order,
                    filter_group=self.filter_group,
                    genre_id=self.genre_id,
                    genre_name=self.genre_name
                )
            except Exception as e:
                xbmc.log(f'[LIVE WINDOW] rebuild cache error: {e}', xbmc.LOGERROR)

            self._hard_refresh()

        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] _refresh_for_program_change error: {e}', xbmc.LOGERROR)

    def _hard_refresh(self):
        try:
            old_selected_cmd = ''
            old_selected_title = ''
            old_selected_orig_title = ''

            ch = self.get_selected_channel()
            if ch:
                old_selected_cmd = str(ch.get('cmd', '')).strip()
                old_selected_title = str(ch.get('title', '')).strip()
                old_selected_orig_title = str(ch.get('orig_title', ch.get('title', ''))).strip()

            old_group = ''
            if self.groups and 0 <= self.group_index < len(self.groups):
                old_group = self.groups[self.group_index]

            old_visible_ids = [self._channel_identity(item) for item in self.visible_channels]

            self._load_data()

            if old_group and old_group in self.groups:
                self.group_index = self.groups.index(old_group)
            else:
                self._init_group()

            self._apply_group_filter()

            self.selected_pos = 0
            if old_selected_cmd or old_selected_title or old_selected_orig_title:
                for i, item in enumerate(self.visible_channels):
                    item_cmd = str(item.get('cmd', '')).strip()
                    item_title = str(item.get('title', '')).strip()
                    item_orig_title = str(item.get('orig_title', item.get('title', ''))).strip()

                    if old_selected_cmd and item_cmd == old_selected_cmd:
                        self.selected_pos = i
                        break

                    if old_selected_orig_title and item_orig_title == old_selected_orig_title:
                        self.selected_pos = i
                        break

                    if old_selected_title and item_title == old_selected_title:
                        self.selected_pos = i
                        break

            new_visible_ids = [self._channel_identity(item) for item in self.visible_channels]

            same_structure = (old_visible_ids == new_visible_ids)
            xbmc.log(
                f'[LIVE WINDOW] refresh compare: old_count={len(old_visible_ids)}, new_count={len(new_visible_ids)}, same_structure={same_structure}',
                xbmc.LOGINFO
            )

            refreshed_in_place = False
            if same_structure and self.list:
                refreshed_in_place = self._refresh_list_items_in_place()
                xbmc.log(
                    f'[LIVE WINDOW] refresh in place result={refreshed_in_place}',
                    xbmc.LOGINFO
                )

            if not refreshed_in_place:
                xbmc.log('[LIVE WINDOW] refresh fallback to full rebuild', xbmc.LOGINFO)
                self._fill_list_ui()

            self._sync_selected_channel_with_state()

            if self.list and self.visible_channels:
                if self.selected_pos >= len(self.visible_channels):
                    self.selected_pos = 0
                self.list.selectItem(self.selected_pos)

            self.last_right_image = ''
            self.update_right_panel(force=True)
            self._update_timeshift_icon()

            self._state_mtime = self._get_state_mtime()

        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] hard refresh error: {e}', xbmc.LOGERROR)

    def close(self):
        self._closed = True
        try:
            win = xbmcgui.Window(10000)
            win.clearProperty('IskierekLiveLoaded')
            win.clearProperty('IskierekLiveForceClose')
            win.clearProperty('IskierekDetailProgressInt')
        except Exception:
            pass

        try:
            super().close()
        except Exception:
            xbmcgui.WindowXMLDialog.close(self)

    def _begin_play_once(self):
        if self.play_started:
            return False
        self.play_started = True
        return True

    def _start_focus_watcher(self):
        if self._focus_worker:
            return

        def _worker():
            last_ts_state = None
            last_focus = -1
            last_pos_11 = -1
            last_pos_110 = -1

            while not self._closed and not self._monitor.abortRequested():
                try:
                    if self._handle_external_refresh():
                        break

                    if self._state_file_changed():
                        try:
                            xbmc.log('[LIVE WINDOW] channel_state_file changed - refreshing data', xbmc.LOGINFO)
                            self._hard_refresh()
                        except Exception as e:
                            xbmc.log(f'[LIVE WINDOW] state file refresh error: {e}', xbmc.LOGERROR)

                    if self._check_current_program_finished():
                        self._refresh_for_program_change()

                    current_ts_state = timeshift.is_timeshift_enabled()
                    if current_ts_state != last_ts_state:
                        last_ts_state = current_ts_state
                        self._update_timeshift_icon()

                    focus_id = -1
                    try:
                        focus_id = self.getFocusId()
                    except Exception:
                        pass

                    if focus_id != last_focus:
                        last_focus = focus_id

                    if self.list:
                        pos = self.list.getSelectedPosition()
                        if pos != last_pos_11:
                            last_pos_11 = pos
                            self.last_list_pos = pos
                            self._last_focus_11_pos = pos

                            if focus_id == 11:
                                self.update_right_panel(force=False, update_mini_guide=False)
                                self._pending_mini_guide_refresh_at = time.time() + 0.25

                    try:
                        guide_ctrl = self.getControl(110)
                        pos_110 = guide_ctrl.getSelectedPosition()
                        if pos_110 != last_pos_110:
                            last_pos_110 = pos_110
                            if focus_id == 110:
                                self._update_right_panel_from_mini_guide()
                    except Exception:
                        pass

                    if self._pending_mini_guide_refresh_at:
                        if time.time() >= self._pending_mini_guide_refresh_at:
                            self._pending_mini_guide_refresh_at = 0.0
                            if focus_id == 11:
                                self._refresh_mini_guide_for_current_selection()

                except Exception:
                    pass

                if self._monitor.waitForAbort(0.12):
                    break

        self._focus_worker = threading.Thread(target=_worker)
        self._focus_worker.daemon = True
        self._focus_worker.start()

    def _load_data(self):
        """Ładuje dane z cache/sieci - wywołuj tylko gdy naprawdę potrzeba świeżych danych."""
        source = tv_guide.get_live_view_channels(
            portal=self.portal,
            use_custom_order=self.custom_order,
            filter_group=self.filter_group
        )

        self.full_channels = source.get('full_channels', [])
        self.channels = source.get('view_channels', [])

        if not self.full_channels:
            xbmcgui.Dialog().notification(
                common.addonname,
                'Brak kanałów',
                xbmcgui.NOTIFICATION_INFO,
                2500
            )
            self.close()
            return

        for ch in self.full_channels:
            if '_original_key' not in ch:
                ch['_original_key'] = ch.get('title', '')

        for ch in self.channels:
            if '_original_key' not in ch:
                ch['_original_key'] = ch.get('title', '')

        self.groups = ['WSZYSTKIE']
        found_groups = []

        for ch in self.full_channels:
            grp = str(ch.get('group_name', '')).strip()
            if grp and grp not in found_groups:
                found_groups.append(grp)

        self.groups.extend(found_groups)

        if not self.channels:
            self.channels = self.full_channels[:]

    def _init_group(self):
        if not self.groups:
            self.group_index = 0
            return

        if self.filter_group and self.filter_group not in ['', 'None', 'ALL_POLISH']:
            if self.filter_group in self.groups:
                self.group_index = self.groups.index(self.filter_group)
                return

        self.group_index = 0

    def _apply_group_filter(self):
        if not self.channels:
            self.visible_channels = []
            return

        if not self.groups:
            self.visible_channels = self.channels[:]
            return

        if self.group_index < 0 or self.group_index >= len(self.groups):
            self.group_index = 0

        current_group = self.groups[self.group_index]

        if current_group == 'WSZYSTKIE':
            self.visible_channels = self.full_channels[:]
            return

        self.visible_channels = [
            ch for ch in self.full_channels
            if str(ch.get('group_name', '')).strip() == current_group
        ]

    def _channel_identity(self, ch):
        cmd = str(ch.get('cmd', '')).strip()
        if cmd:
            return f'cmd:{cmd}'

        orig_title = str(ch.get('orig_title', ch.get('_original_key', ''))).strip()
        if orig_title:
            return f'orig:{orig_title}'

        title = str(ch.get('title', '')).strip()
        return f'title:{title}'

    def _build_listitem_data(self, ch, rec_ch_title='', now_ts=None):
        if now_ts is None:
            now_ts = time.time()

        num = ch.get('number', 0)
        title = ch.get('title', 'Kanał')

        if rec_ch_title and str(title).strip().lower() == rec_ch_title:
            label = f"[COLOR red]REC[/COLOR]  {title}"
        else:
            label = f"{num}. {title}" if num else title

        current_event = {}
        next_event = {}

        events = ch.get('events', [])

        for idx, ev in enumerate(events):
            ev_start = int(ev.get('start', 0) or 0)
            ev_stop = int(ev.get('stop', 0) or 0)

            if ev_start <= now_ts < ev_stop:
                current_event = ev
                if idx + 1 < len(events):
                    next_event = events[idx + 1]
                break

        if not current_event and events:
            current_event = events[0]
            if len(events) > 1:
                next_event = events[1]

        program = current_event.get('title', '') if current_event else ''
        next_title = next_event.get('title', '') if next_event else ''
        progress = ch.get('progress', 0)

        try:
            progress_val = int(progress)
        except Exception:
            progress_val = 0

        progress_val = max(0, min(100, progress_val))

        return {
            'label': label,
            'logo': ch.get('logo_url', ''),
            'program': program,
            'next_title': next_title,
            'progress': progress_val
        }

    def _refresh_list_items_in_place(self):
        if not self.list:
            return False

        try:
            if self.list.size() != len(self.visible_channels):
                return False
        except Exception:
            return False

        now_ts = time.time()
        rec_ch_title = ''

        try:
            rec_state = recorder.get_recording_status()
            if rec_state.get('active'):
                rec_ch_title = str(rec_state.get('title', '')).strip().lower()
        except Exception:
            pass

        try:
            for i, ch in enumerate(self.visible_channels):
                li = self.list.getListItem(i)
                if not li:
                    return False

                data = self._build_listitem_data(
                    ch,
                    rec_ch_title=rec_ch_title,
                    now_ts=now_ts
                )

                li.setLabel(data['label'])
                li.setArt({
                    'icon': data['logo'],
                    'thumb': data['logo']
                })
                li.setProperty('Program', data['program'])
                li.setProperty('NextTitle', data['next_title'])
                li.setProperty('Progress', str(data['progress']))
                li.setProperty('ProgressInt', str(data['progress']))
        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] _refresh_list_items_in_place error: {e}', xbmc.LOGERROR)
            return False

        self._update_group_label()
        return True


    def fill_list(self):
        """
        Publiczne API - ładuje świeże dane I odświeża UI.
        Używaj tylko gdy potrzebujesz pobrać nowe dane z sieci/cache.
        Wewnętrznie używaj _fill_list_ui() jeśli dane są już załadowane.
        """
        self._load_data()
        self._apply_group_filter()
        self._fill_list_ui()

    def _fill_list_ui(self):
        if not self.list:
            return



        self.list.reset()
        items = []
        now_ts = time.time()

        rec_ch_title = ''
        try:
            rec_state = recorder.get_recording_status()
            if rec_state.get('active'):
                rec_ch_title = str(rec_state.get('title', '')).strip().lower()
        except Exception:
            pass

        for ch in self.visible_channels:
            data = self._build_listitem_data(
                ch,
                rec_ch_title=rec_ch_title,
                now_ts=now_ts
            )

            li = xbmcgui.ListItem(data['label'])
            li.setArt({
                'icon': data['logo'],
                'thumb': data['logo']
            })
            li.setProperty('Program', data['program'])
            li.setProperty('NextTitle', data['next_title'])
            li.setProperty('Progress', str(data['progress']))
            li.setProperty('ProgressInt', str(data['progress']))
            items.append(li)

        self.list.addItems(items)

        if items:
            self.selected_pos = max(0, min(self.selected_pos, len(items) - 1))

            try:
                self.list.selectItem(self.selected_pos)
            except Exception:
                pass

            try:
                self.last_list_pos = self.selected_pos
            except Exception:
                pass
        else:
            self.selected_pos = 0
            self.last_list_pos = -1



        self._update_group_label()

    def _restore_selected_position(self):
        try:
            win = xbmcgui.Window(10000)
            saved_pos = win.getProperty('IskierekLiveSelectedPos')

            if not saved_pos or not str(saved_pos).isdigit():
                return

            saved_pos = int(saved_pos)

            if not self.visible_channels:
                return

            saved_pos = max(0, min(saved_pos, len(self.visible_channels) - 1))
            self.selected_pos = saved_pos

            if self.list:
                self.list.selectItem(saved_pos)

        except Exception:
            pass

    def _update_group_label(self):
        try:
            if self.groups and 0 <= self.group_index < len(self.groups):
                label = self.groups[self.group_index]
            else:
                label = 'BRAK GRUP'
            self.getControl(21).setLabel(label)
        except Exception:
            pass

    def get_selected_channel(self):
        if not self.list:
            return None

        pos = self.list.getSelectedPosition()
        if pos < 0 or pos >= len(self.visible_channels):
            return None

        self.selected_pos = pos
        return self.visible_channels[pos]

    def _clean_plot_for_details(self, text):
        try:
            val = str(text or '').strip()
            if not val:
                return 'Brak opisu programu.'

            markers = [
                '\n[COLOR blue]Następnie:[/COLOR]\n',
                '[COLOR blue]Następnie:[/COLOR]',
                '\nNastępnie:\n',
                'Następnie:'
            ]

            for marker in markers:
                if marker in val:
                    val = val.split(marker, 1)[0].strip()

            return val or 'Brak opisu programu.'
        except Exception:
            return 'Brak opisu programu.'

    def update_right_panel(self, force=False, update_mini_guide=True):
        ch = self.get_selected_channel()
        if not ch:
            return

        events = ch.get('events', [])
        current_event = {}
        now_ts = time.time()

        for ev in events:
            ev_start = int(ev.get('start', 0) or 0)
            ev_stop = int(ev.get('stop', 0) or 0)
            if ev_start <= now_ts < ev_stop:
                current_event = ev
                break

        if not current_event and events:
            current_event = events[0]

        program = current_event.get('title', '') if current_event else ''
        plot = self._clean_plot_for_details(
            current_event.get('desc', '') if current_event else ch.get('plot', '')
        )
        image = (
            current_event.get('img', '') if current_event else ''
        ) or ch.get('logo_url', '') or common.fanart

        start_ts = current_event.get('start', 0) if current_event else ch.get('start_ts', 0)
        stop_ts = current_event.get('stop', 0) if current_event else ch.get('stop_ts', 0)

        progress = 0
        try:
            if start_ts and stop_ts and stop_ts > start_ts:
                progress = int(((time.time() - start_ts) / float(stop_ts - start_ts)) * 100)
                progress = max(0, min(100, progress))
        except Exception:
            progress = 0

        time_label = ''
        try:
            if start_ts and stop_ts:
                time_label = (
                    f"{time.strftime('%H:%M', time.localtime(start_ts))}"
                    f" - "
                    f"{time.strftime('%H:%M', time.localtime(stop_ts))}"
                )
        except Exception:
            time_label = ''

        try:
            if force or image != self.last_right_image:
                self.getControl(101).setImage(image)
                self.last_right_image = image
        except Exception:
            pass

        try:
            self.getControl(104).setLabel(program)
        except Exception:
            pass

        try:
            self.getControl(105).setLabel(time_label)
        except Exception:
            pass

        try:
            xbmcgui.Window(10000).setProperty('IskierekDetailProgressInt', str(int(progress)))
        except Exception:
            pass

        try:
            self.getControl(108).setText(plot)
        except Exception:
            pass

        if update_mini_guide:
            try:
                self._fill_mini_guide_list(ch)
            except Exception:
                pass

    def _refresh_mini_guide_for_current_selection(self):
        try:
            ch = self.get_selected_channel()
            if ch:
                self._fill_mini_guide_list(ch)
        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] _refresh_mini_guide_for_current_selection error: {e}', xbmc.LOGERROR)

    def _day_section_label(self, ev_start, now_ts):
        try:
            now_date = time.localtime(now_ts)
            ev_date = time.localtime(ev_start)

            now_day = int(time.strftime('%Y%j', now_date))
            ev_day = int(time.strftime('%Y%j', ev_date))
            diff = ev_day - now_day

            if diff <= 0:
                return 'Dziś', 'today'
            if diff == 1:
                return 'Jutro', 'tomorrow'
            if diff == 2:
                return 'Pojutrze', 'later'
            return time.strftime('%d.%m', ev_date), 'later'
        except Exception:
            return 'Dziś', 'today'

    def _build_state_channels_from_full(self):
        result = []
        now_ts = time.time()

        for item in self.full_channels:
            events = item.get('events', [])
            current_event = {}
            next_event = {}

            for idx, ev in enumerate(events):
                ev_start = int(ev.get('start', 0) or 0)
                ev_stop = int(ev.get('stop', 0) or 0)

                if ev_start <= now_ts < ev_stop:
                    current_event = ev
                    if idx + 1 < len(events):
                        next_event = events[idx + 1]
                    break

            if not current_event and events:
                current_event = events[0]
                if len(events) > 1:
                    next_event = events[1]

            start_ts = current_event.get('start', 0) if current_event else item.get('start_ts', 0)
            stop_ts = current_event.get('stop', 0) if current_event else item.get('stop_ts', 0)

            progress = 0
            try:
                if start_ts and stop_ts and stop_ts > start_ts:
                    progress = int(((now_ts - start_ts) / float(stop_ts - start_ts)) * 100)
                    progress = max(0, min(100, progress))
            except Exception:
                progress = 0

            result.append({
                'title': item.get('title', ''),
                'orig_title': item.get('_original_key', item.get('title', '')),
                'cmd': item.get('cmd', ''),
                'logo_url': item.get('logo_url', ''),
                'plot': current_event.get('desc', '') if current_event else item.get('plot', ''),
                'program': current_event.get('title', '') if current_event else '',
                'next_program': next_event.get('title', '') if next_event else '',
                'progress': progress,
                'start_ts': start_ts,
                'stop_ts': stop_ts,
                'group_name': item.get('group_name', '')
            })

        return result

    def play_selected_channel(self):
        if not self._begin_play_once():
            return

        ch = self.get_selected_channel()
        if not ch:
            self.play_started = False
            return

        selected_title = ch.get('title', '')
        selected_cmd = ch.get('cmd', '')

        state_channels = self._build_state_channels_from_full()

        current_index = int(ch.get('_global_index', -1))

        if current_index < 0 or current_index >= len(state_channels):
            current_index = -1

            for i, item in enumerate(state_channels):
                item_cmd = str(item.get('cmd', '')).strip()
                item_title = str(item.get('title', '')).strip()

                if selected_cmd and item_cmd == selected_cmd:
                    current_index = i
                    break

                if selected_title and item_title == selected_title:
                    current_index = i
                    break

        if current_index < 0:
            xbmc.log(
                f"[LIVE WINDOW] play_selected_channel could not resolve current_index for title={selected_title}, cmd={selected_cmd}",
                xbmc.LOGERROR
            )
            self.play_started = False
            return

        try:
            channel_switch.save_channel_state(state_channels, current_index, self.portal)
        except Exception as e:
            xbmc.log(f"[LIVE WINDOW] save_channel_state error: {e}", xbmc.LOGERROR)

        try:
            win = xbmcgui.Window(10000)
            win.setProperty('IskierekLiveSelectedPos', str(self.selected_pos))
        except Exception:
            pass

        self.close()
        xbmc.sleep(150)

        try:
            channel_switch.play_index(current_index)
        except Exception as e:
            xbmc.log(f"[LIVE WINDOW] play_selected_channel play_index error: {e}", xbmc.LOGERROR)
            self.play_started = False

    def _group_left(self):
        if not self.groups:
            return False

        if self.group_index <= 0:
            return False

        try:
            old_focus = self.getFocusId()
        except Exception:
            old_focus = 11

        self.allow_list_click = False
        self.group_index -= 1

        if self.group_index == 0:
            self.filter_group = 'ALL_POLISH'
        else:
            self.filter_group = self.groups[self.group_index]

        self.selected_pos = 0

        # POPRAWKA: tylko filtruj i odśwież UI, nie ładuj ponownie danych
        self._apply_group_filter()
        self._fill_list_ui()

        xbmc.sleep(50)

        try:
            if old_focus in [11, 31, 32]:
                self.setFocusId(old_focus)
            else:
                self.setFocusId(11)
        except Exception:
            pass

        self.update_right_panel(force=True)
        self._suppress_play_until = time.time() + 0.40
        return True

    def _group_right(self):
        if not self.groups:
            return False

        if self.group_index >= len(self.groups) - 1:
            return False

        try:
            old_focus = self.getFocusId()
        except Exception:
            old_focus = 11

        self.allow_list_click = False
        self.group_index += 1

        if self.group_index == 0:
            self.filter_group = 'ALL_POLISH'
        else:
            self.filter_group = self.groups[self.group_index]

        self.selected_pos = 0

        # POPRAWKA: tylko filtruj i odśwież UI, nie ładuj ponownie danych
        self._apply_group_filter()
        self._fill_list_ui()

        xbmc.sleep(50)

        try:
            if old_focus in [11, 31, 32]:
                self.setFocusId(old_focus)
            else:
                self.setFocusId(11)
        except Exception:
            pass

        self.update_right_panel(force=True)
        self._suppress_play_until = time.time() + 0.40
        return True

    def _show_info(self):
        ch = self.get_selected_channel()
        if not ch:
            return

        events = ch.get('events', [])
        current_event = {}
        now_ts = time.time()

        for ev in events:
            ev_start = int(ev.get('start', 0) or 0)
            ev_stop = int(ev.get('stop', 0) or 0)
            if ev_start <= now_ts < ev_stop:
                current_event = ev
                break

        if not current_event and events:
            current_event = events[0]

        title = current_event.get('title', '') if current_event else ch.get('title', 'Kanał')
        plot = self._clean_plot_for_details(
            current_event.get('desc', '') if current_event else ch.get('plot', '')
        )

        xbmcgui.Dialog().textviewer(title, plot)

    def _open_tv_guide(self):
        try:
            if not self.portal:
                xbmcgui.Dialog().notification(
                    common.addonname,
                    'Brak danych portalu dla przewodnika',
                    xbmcgui.NOTIFICATION_ERROR,
                    2000
                )
                return

            self.close()
            xbmc.sleep(200)

            url = common.build_url({
                'mode': 'tv_guide',
                'custom_order': 'true' if self.custom_order else 'false',
                'filter_group': self.filter_group,
                'genre_id': self.genre_id,
                'genre_name': self.genre_name,
                'portal': json.dumps(self.portal)
            })

            xbmc.executebuiltin(f'RunPlugin({url})')

        except Exception as e:
            xbmcgui.Dialog().notification(
                common.addonname,
                f'Błąd przewodnika TV: {e}',
                xbmcgui.NOTIFICATION_ERROR,
                2500
            )

    def _resolve_original_key(self, title):
        try:
            portal_key = common.get_portal_key(self.portal)
            custom_names = common.read_json_safe(common.custom_names_file).get(portal_key, {})

            current_title = str(title or '').strip()

            for original_key, custom_value in custom_names.items():
                if str(custom_value).strip() == current_title:
                    return str(original_key).strip()

            return current_title
        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] _resolve_original_key error: {e}', xbmc.LOGERROR)
            return str(title or '').strip()

    def _context_menu(self):
        ch = self.get_selected_channel()
        if not ch:
            return

        portal = self.portal
        title = ch.get('title', 'Kanał')
        cmd = ch.get('cmd', '')
        logo = ch.get('logo_url', '')
        orig_key = self._resolve_original_key(title)

        events = ch.get('events', [])
        current_event = {}
        now_ts = time.time()

        for ev in events:
            ev_start = int(ev.get('start', 0) or 0)
            ev_stop = int(ev.get('stop', 0) or 0)
            if ev_start <= now_ts < ev_stop:
                current_event = ev
                break

        if not current_event and events:
            current_event = events[0]

        start_ts = current_event.get('start', 0) if current_event else 0
        stop_ts = current_event.get('stop', 0) if current_event else 0

        record_unlimited_params = {
            'mode': 'record_tv_start',
            'cmd': cmd,
            'title': title,
            'logo_url': logo,
            'portal': json.dumps(portal),
            'stop_ts': stop_ts,
            'record_mode': 'unlimited'
        }

        record_program_params = {
            'mode': 'record_tv_program',
            'cmd': cmd,
            'title': title,
            'logo_url': logo,
            'portal': json.dumps(portal),
            'start_ts': start_ts,
            'stop_ts': stop_ts
        }

        record_custom_params = {
            'mode': 'record_tv_start',
            'cmd': cmd,
            'title': title,
            'logo_url': logo,
            'portal': json.dumps(portal),
            'stop_ts': stop_ts,
            'record_mode': 'custom'
        }

        record_stop_params = {
            'mode': 'record_tv_stop',
            'portal': json.dumps(portal)
        }

        record_info_params = {
            'mode': 'recording_info',
            'portal': json.dumps(portal)
        }

        rename_params = {
            'mode': 'rename_channel',
            'id_key': orig_key,
            'current_name': title,
            'portal': json.dumps(portal)
        }

        hide_params = {
            'mode': 'hide_channel',
            'id_key': orig_key,
            'portal': json.dumps(portal)
        }

        settings_params = {
            'mode': 'provider_settings',
            'portal': json.dumps(portal)
        }

        guide_params = {
            'mode': 'tv_guide',
            'custom_order': 'true' if self.custom_order else 'false',
            'filter_group': self.filter_group,
            'genre_id': self.genre_id,
            'genre_name': self.genre_name,
            'portal': json.dumps(portal)
        }

        timeshift_toggle_params = {
            'mode': 'toggle_timeshift'
        }

        items = [
            ('Pokaż szczegóły programu', lambda: self._show_info()),
            ('Pełny przewodnik TV', lambda: xbmc.executebuiltin(f'RunPlugin({common.build_url(guide_params)})')),
            ('Włącz/Wyłącz timeshift', lambda: (
                xbmc.executebuiltin(f'RunPlugin({common.build_url(timeshift_toggle_params)})'),
                xbmc.sleep(300),
                self._update_timeshift_icon()
            )),
            ('Nagraj bez limitu', lambda: (
                xbmc.executebuiltin(f'RunPlugin({common.build_url(record_unlimited_params)})'),
                xbmc.sleep(300),
                self._hard_refresh()
            )),
            ('Nagraj do końca programu', lambda: (
                xbmc.executebuiltin(f'RunPlugin({common.build_url(record_program_params)})'),
                xbmc.sleep(300),
                self._hard_refresh()
            )),
            ('Nagraj własny czas', lambda: (
                xbmc.executebuiltin(f'RunPlugin({common.build_url(record_custom_params)})'),
                xbmc.sleep(300),
                self._hard_refresh()
            )),
            ('Zmień nazwę', lambda: (
                xbmc.executebuiltin(f'RunPlugin({common.build_url(rename_params)})'),
                xbmc.sleep(300),
                self._hard_refresh()
            )),
            ('Ukryj kanał', lambda: (
                xbmc.executebuiltin(f'RunPlugin({common.build_url(hide_params)})'),
                xbmc.sleep(300),
                self._hard_refresh()
            )),
            ('Ustawienia', lambda: (
                self.close(),
                xbmc.sleep(200),
                xbmc.executebuiltin(f'ActivateWindow(Videos,{common.build_url(settings_params)},return)')
            )),
            ('Odśwież listę', lambda: self._refresh())
        ]

        if recorder.is_recording_active():
            items.append((
                'Info o nagrywaniu',
                lambda: xbmc.executebuiltin(f'RunPlugin({common.build_url(record_info_params)})')
            ))
            items.append((
                'Stop nagrywania',
                lambda: (
                    xbmc.executebuiltin(f'RunPlugin({common.build_url(record_stop_params)})'),
                    xbmc.sleep(300),
                    self._hard_refresh()
                )
            ))

        labels = [x[0] for x in items]
        choice = xbmcgui.Dialog().select(title, labels)
        if choice < 0:
            return

        try:
            items[choice][1]()
        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] context menu error: {e}', xbmc.LOGERROR)

    def _open_context_menu_from_navigation(self):
        try:
            now_ts = time.time()
            if now_ts - self._last_nav_context_ts < 0.35:
                return

            self._last_nav_context_ts = now_ts
            self._context_menu()

        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] _open_context_menu_from_navigation error: {e}', xbmc.LOGERROR)

    def _refresh(self):
        self._hard_refresh()

    def onAction(self, action):
        aid = action.getId()

        if aid in [9, 10, 13, 92]:
            try:
                win = xbmcgui.Window(10000)
                win.clearProperty('IskierekReturnOwner')
                win.clearProperty('IskierekReturnLiveActive')
                win.clearProperty('IskierekLivePortal')
                win.clearProperty('IskierekLiveCustomOrder')
                win.clearProperty('IskierekLiveFilterGroup')
                win.clearProperty('IskierekLiveGenreId')
                win.clearProperty('IskierekLiveGenreName')
                win.clearProperty('IskierekLiveSelectedPos')
                win.clearProperty('IskierekChannelSwitchInProgress')
                win.clearProperty('IskierekLiveForceClose')
                win.clearProperty('IskierekDetailProgressInt')
            except Exception:
                pass

            self.close()
            return

        try:
            focus_id = self.getFocusId()
        except Exception:
            focus_id = 0

        if focus_id == 11:
            if self._returning_from_110_to_11:
                self._returning_from_110_to_11 = False

            if aid in [1, 169, 521]:
                if self._group_left():
                    return
                if self._focus_first_program_in_mini_guide():
                    return
                return

            if aid in [2, 168, 520]:
                if self._group_right():
                    return
                if self._focus_first_program_in_mini_guide():
                    return
                return

        if focus_id == 110:
            # Blokuj klasyczne menu kontekstowe / PPM na mini-guide
            if aid == 117:
                return

            # LEWO -> wróć do listy kanałów
            if aid in [1, 169, 521]:
                if self._focus_back_to_channel_list():
                    return

            # PRAWO -> otwórz menu kontekstowe kanału
            if aid in [2, 168, 520]:
                self._open_context_menu_from_navigation()
                return

            if aid in [3, 166, 522]:
                try:
                    control = self.getControl(110)
                    pos = control.getSelectedPosition()
                    first_program = self._get_first_program_index_in_mini_guide()

                    if first_program >= 0 and pos <= first_program:
                        self.setFocusId(37)
                        return
                except Exception:
                    pass

        if aid == 102:
            self._show_info()
            return

        if aid == 117:
            self._context_menu()
            return

        if aid in [7, 100]:
            try:
                if self.getFocusId() == 11:
                    now_ts = time.time()
                    if now_ts < self._suppress_play_until:
                        return
                    if now_ts - self._last_click_ts < 0.35:
                        return
                    self.play_selected_channel()
                    return
            except Exception:
                pass

    def onClick(self, controlId):
        if controlId == 31:
            self._group_left()
            return

        if controlId == 32:
            self._group_right()
            return

        if controlId == 37:
            self._open_tv_guide()
            return

        if controlId in [38, 39]:
            xbmc.executebuiltin(f'RunPlugin({common.build_url({"mode": "toggle_timeshift"})})')
            xbmc.sleep(500)
            self._update_timeshift_icon()

            try:
                self.setFocusId(39)
            except Exception:
                try:
                    self.setFocusId(38)
                except Exception:
                    pass
            return

        if controlId == 11:
            now_ts = time.time()
            if now_ts < self._suppress_play_until:
                return
            self._last_click_ts = now_ts
            self.play_selected_channel()
            return

        if controlId == 110:
            self._open_tv_guide_at_selected_program()
            return

    def onFocus(self, controlId):
        pass

    def _fill_mini_guide_list(self, ch):
        try:

            control = self.getControl(110)
            control.reset()

            events = ch.get('events', [])
            if not events:
                li = xbmcgui.ListItem('[COLOR FFAAAAAA]Brak dalszych pozycji w EPG.[/COLOR]')
                li.setProperty('ItemType', 'program')
                li.setProperty('DayLabel', '')
                li.setProperty('EvTitle', '')
                li.setProperty('EvDesc', '')
                li.setProperty('EvStart', '0')
                li.setProperty('EvStop', '0')
                li.setProperty('EvImg', '')
                control.addItem(li)
                return

            now_ts = time.time()
            max_future_ts = now_ts + (120 * 3600)
            current_found = False
            last_section = None
            items = []

            for ev in events:
                ev_start = int(ev.get('start', 0) or 0)
                ev_stop = int(ev.get('stop', 0) or 0)
                ev_title = str(ev.get('title', '')).strip()

                if not ev_title:
                    continue

                if ev_start <= now_ts < ev_stop:
                    current_found = True
                    continue

                if not current_found and ev_stop <= now_ts:
                    continue

                if ev_start > max_future_ts:
                    break

                section_label, section_kind = self._day_section_label(ev_start, now_ts)

                if section_label != last_section:
                    li_sep = xbmcgui.ListItem('')
                    li_sep.setProperty('ItemType', 'separator')
                    li_sep.setProperty('DayLabel', section_label)
                    li_sep.setProperty('EvTitle', '')
                    li_sep.setProperty('EvDesc', '')
                    li_sep.setProperty('EvStart', '0')
                    li_sep.setProperty('EvStop', '0')
                    li_sep.setProperty('EvImg', '')
                    items.append(li_sep)
                    last_section = section_label

                hhmm = time.strftime('%H:%M', time.localtime(ev_start)) if ev_start else '--:--'

                if section_kind == 'today':
                    title_color = 'FFFFCC33'
                elif section_kind == 'tomorrow':
                    title_color = 'FFFFFFFF'
                else:
                    title_color = 'FF888888'

                label = (
                    f'[COLOR FF00FF00]{hhmm}[/COLOR]  '
                    f'[COLOR {title_color}]{ev_title}[/COLOR]'
                )

                ev_image = ''
                for key in ['img', 'image', 'icon', 'poster', 'thumb', 'cover',
                            'screenshot', 'pic', 'image_url', 'picture', 'preview']:
                    val = ev.get(key)
                    if val and str(val).startswith('http'):
                        ev_image = str(val)
                        break

                if not ev_image:
                    desc_text = str(ev.get('desc', '') or '')
                    if 'http' in desc_text:
                        for p in desc_text.split():
                            if p.startswith('http') and any(
                                ext in p for ext in ('.jpg', '.jpeg', '.png', '.webp')
                            ):
                                ev_image = p
                                break

                li = xbmcgui.ListItem(label)
                li.setProperty('ItemType', 'program')
                li.setProperty('DayLabel', '')
                li.setProperty('EvTitle', str(ev.get('title', '') or ''))
                li.setProperty('EvDesc', str(ev.get('desc', '') or ev.get('plot', '') or ''))
                li.setProperty('EvStart', str(ev_start))
                li.setProperty('EvStop', str(ev_stop))
                li.setProperty('EvImg', ev_image)

                items.append(li)

            if not items:
                li = xbmcgui.ListItem('[COLOR FFAAAAAA]Brak dalszych pozycji w EPG.[/COLOR]')
                li.setProperty('ItemType', 'program')
                li.setProperty('DayLabel', '')
                li.setProperty('EvTitle', '')
                li.setProperty('EvDesc', '')
                li.setProperty('EvStart', '0')
                li.setProperty('EvStop', '0')
                li.setProperty('EvImg', '')
                items.append(li)

            control.addItems(items)
            control.selectItem(0)

        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] fill mini guide list error: {e}', xbmc.LOGERROR)

    def _update_timeshift_icon(self):
        try:
            ts_off = self.getControl(38)
            ts_on = self.getControl(39)

            if timeshift.is_timeshift_enabled():
                ts_off.setVisible(False)
                ts_on.setVisible(True)
            else:
                ts_off.setVisible(True)
                ts_on.setVisible(False)

        except Exception:
            pass

    def _update_right_panel_from_mini_guide(self):
        try:
            control = self.getControl(110)
            pos = control.getSelectedPosition()
            item = control.getListItem(pos)

            if not item:
                return

            item_type = item.getProperty('ItemType')

            if item_type == 'separator':
                return

            title = str(item.getProperty('EvTitle') or '').strip()
            desc = str(item.getProperty('EvDesc') or '').strip()
            ev_image = str(item.getProperty('EvImg') or '').strip()

            try:
                start_ts = int(item.getProperty('EvStart') or 0)
            except Exception:
                start_ts = 0

            try:
                stop_ts = int(item.getProperty('EvStop') or 0)
            except Exception:
                stop_ts = 0

            plot = self._clean_plot_for_details(desc or 'Brak opisu programu.')

            time_label = ''
            try:
                if start_ts and stop_ts:
                    time_label = (
                        f"{time.strftime('%H:%M', time.localtime(start_ts))}"
                        f" - "
                        f"{time.strftime('%H:%M', time.localtime(stop_ts))}"
                    )
            except Exception:
                time_label = ''

            image = ev_image
            if not image:
                ch = self.get_selected_channel()
                if ch:
                    image = ch.get('logo_url', '') or common.fanart

            try:
                if image and image != self.last_right_image:
                    self.getControl(101).setImage(image)
                    self.last_right_image = image
            except Exception:
                pass

            try:
                self.getControl(104).setLabel(title)
            except Exception:
                pass

            try:
                self.getControl(105).setLabel(time_label)
            except Exception:
                pass

            try:
                xbmcgui.Window(10000).setProperty('IskierekDetailProgressInt', '0')
            except Exception:
                pass

            try:
                self.getControl(108).setText(plot)
            except Exception:
                pass

        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] _update_right_panel_from_mini_guide error: {e}', xbmc.LOGERROR)

    def _open_tv_guide_at_selected_program(self):
        try:
            if not self.portal:
                xbmcgui.Dialog().notification(
                    common.addonname,
                    'Brak danych portalu dla przewodnika',
                    xbmcgui.NOTIFICATION_ERROR,
                    2000
                )
                return

            ch = self.get_selected_channel()
            if not ch:
                return

            channel_title = str(ch.get('title', '')).strip()

            program_start_ts = 0
            program_stop_ts = 0
            program_title = ''

            try:
                control = self.getControl(110)
                pos = control.getSelectedPosition()
                item = control.getListItem(pos)

                if item and item.getProperty('ItemType') == 'program':
                    program_title = str(item.getProperty('EvTitle') or '').strip()
                    try:
                        program_start_ts = int(item.getProperty('EvStart') or 0)
                    except Exception:
                        program_start_ts = 0
                    try:
                        program_stop_ts = int(item.getProperty('EvStop') or 0)
                    except Exception:
                        program_stop_ts = 0
            except Exception:
                pass

            try:
                win = xbmcgui.Window(10000)
                win.setProperty('IskierekGuideTargetChannel', channel_title)
                win.setProperty('IskierekGuideTargetProgramTitle', program_title)
                win.setProperty('IskierekGuideTargetProgramStart', str(program_start_ts))
                win.setProperty('IskierekGuideTargetProgramStop', str(program_stop_ts))
            except Exception:
                pass

            self.close()
            xbmc.sleep(200)

            url = common.build_url({
                'mode': 'tv_guide',
                'custom_order': 'true' if self.custom_order else 'false',
                'filter_group': self.filter_group,
                'genre_id': self.genre_id,
                'genre_name': self.genre_name,
                'portal': json.dumps(self.portal)
            })

            xbmc.executebuiltin(f'RunPlugin({url})')

        except Exception as e:
            xbmcgui.Dialog().notification(
                common.addonname,
                f'Błąd przewodnika TV: {e}',
                xbmcgui.NOTIFICATION_ERROR,
                2500
            )

    def _get_first_program_index_in_mini_guide(self):
        try:
            control = self.getControl(110)
            size = control.size()

            for i in range(size):
                item = control.getListItem(i)
                if item and item.getProperty('ItemType') == 'program':
                    return i

        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] _get_first_program_index_in_mini_guide error: {e}', xbmc.LOGERROR)

        return -1

    def _focus_first_program_in_mini_guide(self):
        try:
            control = self.getControl(110)
            first_program = self._get_first_program_index_in_mini_guide()

            if first_program < 0:
                return False

            control.selectItem(first_program)
            self.setFocusId(110)
            self._update_right_panel_from_mini_guide()
            return True

        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] _focus_first_program_in_mini_guide error: {e}', xbmc.LOGERROR)

        return False

    def _focus_back_to_channel_list(self):
        try:
            if not self.list:
                return False

            target_pos = self._last_focus_11_pos

            if target_pos < 0:
                target_pos = 0

            if self.visible_channels:
                if target_pos >= len(self.visible_channels):
                    target_pos = len(self.visible_channels) - 1
            else:
                target_pos = 0

            try:
                self.list.selectItem(target_pos)
            except Exception:
                pass

            self.selected_pos = target_pos
            self.last_list_pos = target_pos
            self._last_focus_11_pos = target_pos
            self._returning_from_110_to_11 = True

            self.setFocusId(11)
            self.update_right_panel(force=False)
            return True

        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] _focus_back_to_channel_list error: {e}', xbmc.LOGERROR)

        return False

    def _get_current_channel_index_from_state(self):
        try:
            state = common.read_json_safe(common.channel_state_file)
            return int(state.get('current_index', -1))
        except Exception:
            return -1

    def _sync_selected_channel_with_state(self):
        try:
            state = common.read_json_safe(common.channel_state_file)
            current_index = int(state.get('current_index', -1))
            channels = state.get('channels', [])

            if current_index < 0 or current_index >= len(channels):
                return

            st_item = channels[current_index]
            st_cmd = str(st_item.get('cmd', '')).strip()
            st_title = str(st_item.get('title', '')).strip()

            target_pos = -1

            for i, item in enumerate(self.visible_channels):
                item_cmd = str(item.get('cmd', '')).strip()
                item_title = str(item.get('title', '')).strip()

                if st_cmd and item_cmd == st_cmd:
                    target_pos = i
                    break

                if st_title and item_title == st_title:
                    target_pos = i
                    break

            if target_pos >= 0:
                self.selected_pos = target_pos
                self.last_list_pos = target_pos
                self._last_focus_11_pos = target_pos

                if self.list:
                    self.list.selectItem(target_pos)

        except Exception as e:
            xbmc.log(f'[LIVE WINDOW] _sync_selected_channel_with_state error: {e}', xbmc.LOGERROR)


def open_live_window_with_params(portal, custom_order=True, filter_group='ALL_POLISH',
                                  genre_id='', genre_name=''):
    try:
        win = LiveWindow(
            'live_window.xml',
            common.addon_path,
            'Default',
            '1080i',
            portal=portal,
            custom_order=custom_order,
            filter_group=filter_group,
            genre_id=genre_id,
            genre_name=genre_name
        )
        win.doModal()
        del win

    except Exception as e:
        xbmc.log(f'[LIVE WINDOW] open_live_window_with_params error: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            common.addonname,
            f'Błąd otwierania live: {e}',
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )


def open_live_window():
    try:
        portal = json.loads(common.args.get('portal', ['{}'])[0])
        custom_order = str(common.args.get('custom_order', ['true'])[0]).lower() == 'true'
        filter_group = str(common.args.get('filter_group', ['ALL_POLISH'])[0])
        genre_id = str(common.args.get('genre_id', [''])[0])
        genre_name = str(common.args.get('genre_name', [''])[0])

        open_live_window_with_params(
            portal=portal,
            custom_order=custom_order,
            filter_group=filter_group,
            genre_id=genre_id,
            genre_name=genre_name
        )

    except Exception as e:
        xbmc.log(f'[LIVE WINDOW] open_live_window error: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            common.addonname,
            f'Błąd otwierania live: {e}',
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )