# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,json
from resources.lib import common
import resources.lib.core.sorting as sorting

def PolishGroupsLevel(portal):
    sorting.reload_config()
    xbmcplugin.setContent(common.addon_handle, 'files')

    for group_name, _ in sorting.ORDERED_GROUPS:
        url = common.build_url({
            'mode': 'channels',
            'custom_order': 'true',
            'filter_group': group_name,
            'portal': json.dumps(portal),
            'genre_name': group_name
        })

        my_icon = _icon_for_group(group_name)

        li = xbmcgui.ListItem(group_name)
        li.setArt({'icon': my_icon, 'fanart': common.fanart})

        export_params = {
            'mode': 'export_group_m3u',
            'group_name': group_name,
            'portal': json.dumps(portal)
        }
        li.addContextMenuItems([
            ('Eksportuj grupę do M3U', f'RunPlugin({common.build_url(export_params)})')
        ])

        xbmcplugin.addDirectoryItem(
            handle=common.addon_handle,
            url=url,
            listitem=li,
            isFolder=True
        )

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)

def _icon_for_group(group_name):
    g = str(group_name).upper()

    if g == 'PODSTAWOWE':
        return common.icon44

    elif g == 'LIFESTYLE I ROZRYWKA':
        return common.icon49

    elif g == 'FILMOWE':
        return common.icon47

    elif g == 'FILMOWE VOD':
        return common.icon47

    elif g == 'NAUKOWE':
        return common.icon48

    elif g == 'MUZYCZNE':
        return common.icon50

    elif g == 'DLA DZIECI':
        return common.icon45

    elif g == 'INFORMACYJNE':
        return common.icon51

    elif g == 'SPORTOWE':
        return common.icon55

    elif g == 'EUROSPORT':
        return common.icon55

    elif g == 'CANAL+ EXTRA':
        return common.icon55

    elif g == 'WALKA (PPV)':
        return common.icon46

    elif g == 'TVN PLAYER':
        return common.icon56

    elif g == 'REGIONALNE':
        return common.icon54

    elif g == 'RADIO':
        return common.icon53

    elif g == 'POZOSTAŁE':
        return common.icon52

    return common.icon52

def PolishGroupsLevel(portal):
    sorting.reload_config()
    xbmcplugin.setContent(common.addon_handle,'files')

    for group_name,_ in sorting.ORDERED_GROUPS:
        url = common.build_url({
            'mode':'channels',
            'custom_order':'true',
            'filter_group':group_name,
            'portal':json.dumps(portal),
            'genre_name':group_name
        })

        li = xbmcgui.ListItem(group_name)
        li.setArt({'icon':_icon_for_group(group_name),'fanart':common.fanart})

        export_params = {
            'mode':'export_group_m3u',
            'group_name':group_name,
            'portal':json.dumps(portal)
        }
        li.addContextMenuItems([
            ('[COLOR yellow]Zapisz grupę do pliku M3U[/COLOR]',f'RunPlugin({common.build_url(export_params)})')
        ])

        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=True)

    # osobna grupa POZOSTAŁE
    extra_group = 'POZOSTAŁE'
    extra_url = common.build_url({
        'mode':'channels',
        'custom_order':'true',
        'filter_group':extra_group,
        'portal':json.dumps(portal),
        'genre_name':extra_group
    })

    li_extra = xbmcgui.ListItem(extra_group)
    li_extra.setArt({'icon':_icon_for_group(extra_group),'fanart':common.fanart})

    export_extra_params = {
        'mode':'export_group_m3u',
        'group_name':extra_group,
        'portal':json.dumps(portal)
    }
    li_extra.addContextMenuItems([
        ('[COLOR yellow]Eksportuj grupę do M3U[/COLOR]',f'RunPlugin({common.build_url(export_extra_params)})')
    ])

    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=extra_url,listitem=li_extra,isFolder=True)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)