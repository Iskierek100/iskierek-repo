# -*- coding: utf-8 -*-
import json
import time
import os
import threading
import xbmc
import xbmcgui

from resources.lib import common
from resources.lib.tv import channel_switch
from resources.lib.recording import recorder
from resources.lib import timeshift


def _calc_progress(start_ts, stop_ts):
    try:
        now = time.time()
        if not start_ts or not stop_ts or stop_ts <= start_ts:
            return 0
        val = int(((now - start_ts) / (stop_ts - start_ts)) * 100)
        if val < 0:
            val = 0
        if val > 100:
            val = 100
        return val
    except Exception:
        return 0


class ChannelInfoDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__()
        self.heading = kwargs.get('heading', 'Informacje')
        self.text = kwargs.get('text', '')
        self.image = kwargs.get('image', '')

    def onInit(self):
        try:
            self.getControl(100).setLabel(self.heading)
        except Exception:
            pass

        try:
            self.getControl(101).setImage(self.image)
        except Exception:
            pass

        try:
            self.getControl(102).setText(self.text)
        except Exception:
            pass

        try:
            self.setFocusId(103)
        except Exception:
            pass

    def onAction(self, action):
        aid = action.getId()
        if aid in [9, 10, 13, 92]:
            self.close()

    def onClick(self, controlId):
        if controlId == 103:
            self.close()


class ChannelOverlay(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__()
        self.state = common.read_json_safe(common.channel_state_file)
        self.channels = self.state.get('channels', [])
        self.current_index = self.state.get('current_index', -1)

        self.groups = ['WSZYSTKIE']
        self._build_groups()

        self.saved_group = common.addon.getSetting('overlay_group') or 'WSZYSTKIE'
        self.group_mode = common.addon.getSetting('overlay_group_mode') or 'remember'

        self.group_index = 0
        self.visible_channels = self.channels[:]
        self.sticky = common.addon.getSetting('overlay_sticky') == 'true'
        self.list = None

        self._monitor = xbmc.Monitor()
        self._closed = False
        self._refresh_worker = None
        self._state_mtime = self._get_state_mtime()
        self._last_nav_context_ts = 0.0

    def _get_state_mtime(self):
        try:
            return os.path.getmtime(common.channel_state_file)
        except Exception:
            return 0

    def _state_file_changed(self):
        try:
            new_mtime = self._get_state_mtime()
            if new_mtime != self._state_mtime:
                self._state_mtime = new_mtime
                return True
            return False
        except Exception:
            return False

    def _refresh_overlay_data(self):
        try:
            old_selected_global_index = self._get_selected_global_index()

            old_group_name = 'WSZYSTKIE'
            try:
                if self.groups and 0 <= self.group_index < len(self.groups):
                    old_group_name = self.groups[self.group_index]
            except Exception:
                pass

            try:
                old_focus_id = self.getFocusId()
            except Exception:
                old_focus_id = -1

            old_visible_ids = [self._visible_channel_id(ch) for ch in self.visible_channels]

            self._reload_state()

            if self.group_mode == 'current_channel':
                self._sync_group_to_current_channel()
            else:
                if old_group_name in self.groups:
                    self.group_index = self.groups.index(old_group_name)
                else:
                    self.group_index = 0

            self._apply_group_filter()
            new_visible_ids = [self._visible_channel_id(ch) for ch in self.visible_channels]

            refreshed_in_place = False
            if old_visible_ids == new_visible_ids and self.list:
                refreshed_in_place = self._refresh_list_items_in_place()

            if refreshed_in_place:
                if old_selected_global_index >= 0:
                    self._select_visible_channel_by_global_index(old_selected_global_index, focus_list=False)
                elif self.current_index >= 0:
                    self._select_visible_channel_by_global_index(self.current_index, focus_list=False)
            else:
                preferred_index = old_selected_global_index if old_selected_global_index >= 0 else self.current_index
                self._fill_list_ui(
                    preferred_global_index=preferred_index,
                    focus_list=(old_focus_id == 11)
                )

        except Exception as e:
            xbmc.log(f'[ChannelOverlay] _refresh_overlay_data error: {e}', xbmc.LOGERROR)


    def _manual_refresh_current_state(self):
        try:
            from resources.lib.tv import live as tv_live
            ok = tv_live.refresh_existing_channel_state_epg()
            xbmc.log(f'[ChannelOverlay] manual refresh current state result={ok}', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f'[ChannelOverlay] manual refresh error: {e}', xbmc.LOGERROR)

        self._refresh_overlay_data()

    def _start_refresh_watcher(self):
        if self._refresh_worker:
            return

        def _worker():
            while not self._closed and not self._monitor.abortRequested():
                try:
                    if self._state_file_changed():
                        self._refresh_overlay_data()
                except Exception as e:
                    xbmc.log(f'[ChannelOverlay] refresh watcher error: {e}', xbmc.LOGERROR)

                if self._monitor.waitForAbort(5):
                    break

        self._refresh_worker = threading.Thread(target=_worker)
        self._refresh_worker.daemon = True
        self._refresh_worker.start()

    def close(self):
        self._closed = True
        try:
            super().close()
        except Exception:
            xbmcgui.WindowXMLDialog.close(self)

    def _sync_current_index_with_player(self):
        try:
            try:
                if timeshift.is_timeshift_active():
                    state = common.read_json_safe(common.channel_state_file)
                    idx = int(state.get('current_index', -1))
                    if idx >= 0:
                        self.current_index = idx
                        self.state['current_index'] = idx
                        return
            except Exception:
                pass

            if not xbmc.Player().isPlaying():
                return

            playing_title = xbmc.getInfoLabel('VideoPlayer.Title') or ''
            playing_title = playing_title.strip()

            if not playing_title:
                return

            if ' : ' in playing_title:
                playing_title = playing_title.split(' : ', 1)[0].strip()

            for i, ch in enumerate(self.channels):
                ch_title = str(ch.get('title', '')).strip()
                if ch_title == playing_title:
                    self.current_index = i
                    self.state['current_index'] = i
                    common.write_json_safe(common.channel_state_file, self.state)
                    self._state_mtime = self._get_state_mtime()
                    return
        except Exception:
            pass

    def _ensure_current_channel_selected(self):
        try:
            self._reload_state()

            if self.group_mode == 'current_channel':
                self._sync_group_to_current_channel()

            self.fill_list(
                reload_state=False,
                preferred_global_index=self.current_index,
                focus_list=True
            )
        except Exception:
            pass

    def _reload_state(self):
        old_state = dict(self.state or {})
        old_channels = list(self.channels or [])
        old_current_index = self.current_index

        try:
            new_state = common.read_json_safe(common.channel_state_file)
        except Exception:
            new_state = {}

        new_channels = new_state.get('channels', [])

        if not new_channels:
            if old_channels:
                xbmc.log('[ChannelOverlay] _reload_state got empty channels - keeping previous snapshot', xbmc.LOGWARNING)
                self.state = old_state
                self.channels = old_channels
                self.current_index = old_current_index
                return False

            self.state = new_state
            self.channels = []
            self.current_index = new_state.get('current_index', -1)
            self._build_groups()
            return False

        self.state = new_state
        self.channels = new_channels
        self.current_index = self.state.get('current_index', -1)
        self._build_groups()
        return True

    def _build_groups(self):
        group_names = []
        for ch in self.channels:
            group_name = ch.get('group_name', 'POZOSTAŁE').strip()
            if group_name and group_name not in group_names:
                group_names.append(group_name)

        if len(group_names) <= 1:
            self.groups = group_names[:] if group_names else ['WSZYSTKIE']
        else:
            self.groups = ['WSZYSTKIE'] + group_names

    def onInit(self):
        self.list = self.getControl(11)
        self._reload_state()
        self._sync_current_index_with_player()
        self._restore_group_mode()
        self.fill_list(
            reload_state=False,
            preferred_global_index=self.current_index,
            focus_list=True
        )
        self._update_pin()
        self._update_group_icon()
        self._start_refresh_watcher()

    def _restore_group_mode(self):
        if self.group_mode == 'current_channel':
            self._sync_group_to_current_channel()
        else:
            self._restore_saved_group()

    def _restore_saved_group(self):
        try:
            if self.saved_group in self.groups:
                self.group_index = self.groups.index(self.saved_group)
            else:
                self.group_index = 0
        except Exception:
            self.group_index = 0

    def _save_current_group(self):
        try:
            common.addon.setSetting('overlay_group', self.groups[self.group_index])
        except Exception:
            pass

    def _sync_group_to_current_channel(self):
        try:
            if self.current_index < 0 or self.current_index >= len(self.channels):
                self.group_index = 0
                return

            current_channel = self.channels[self.current_index]
            current_group = current_channel.get('group_name', 'POZOSTAŁE').strip()

            if current_group in self.groups:
                self.group_index = self.groups.index(current_group)
            else:
                self.group_index = 0
        except Exception:
            self.group_index = 0

    def _update_group_icon(self):
        try:
            group_off = self.getControl(35)
            group_on = self.getControl(36)

            if self.group_mode == 'current_channel':
                group_on.setVisible(True)
                group_off.setVisible(False)
            else:
                group_on.setVisible(False)
                group_off.setVisible(True)
        except Exception:
            pass

    def _toggle_group_mode(self):
        if self.group_mode == 'remember':
            self.group_mode = 'current_channel'
        else:
            self.group_mode = 'remember'

        common.addon.setSetting('overlay_group_mode', self.group_mode)

        self._restore_group_mode()
        self._update_group_icon()
        self.fill_list(
            reload_state=False,
            preferred_global_index=self.current_index,
            focus_list=True
        )

        mode_label = (
            '[COLOR lime]wg aktualnego kanału[/COLOR]'
            if self.group_mode == 'current_channel'
            else '[COLOR red]zapamiętaj ostatnią grupę[/COLOR]'
        )

        xbmcgui.Dialog().notification(
            common.addonname,
            f'Ustawianie grupy: {mode_label}',
            xbmcgui.NOTIFICATION_INFO,
            2000
        )

    def _update_pin(self):
        try:
            red_pin = self.getControl(30)
            white_pin = self.getControl(34)

            if self.sticky:
                red_pin.setVisible(True)
                white_pin.setVisible(False)
            else:
                red_pin.setVisible(False)
                white_pin.setVisible(True)
        except Exception:
            pass

    def _toggle_sticky(self):
        self.sticky = not self.sticky
        common.addon.setSetting('overlay_sticky', 'true' if self.sticky else 'false')
        self._update_pin()

        status = '[COLOR lime]WŁ[/COLOR]' if self.sticky else '[COLOR red]WYŁ[/COLOR]'
        xbmcgui.Dialog().notification(
            common.addonname,
            f'Pinezka: {status}',
            xbmcgui.NOTIFICATION_INFO,
            2000
        )

    def _open_tv_guide(self):
        try:
            portal = self.state.get('portal', {})
            if not portal:
                xbmcgui.Dialog().notification(
                    common.addonname,
                    'Brak danych portalu dla przewodnika',
                    xbmcgui.NOTIFICATION_ERROR,
                    2000
                )
                return

            self.close()
            xbmc.sleep(200)

            url = common.build_url({
                'mode': 'tv_guide',
                'custom_order': 'true',
                'filter_group': 'ALL_POLISH',
                'portal': json.dumps(portal),
                'genre_name': 'Wszystkie Polskie',
                'return_to': 'overlay'
            })

            xbmc.executebuiltin(f'RunPlugin({url})')

        except Exception as e:
            xbmcgui.Dialog().notification(
                common.addonname,
                f'Błąd przewodnika TV: {e}',
                xbmcgui.NOTIFICATION_ERROR,
                2500
            )

    def _show_channel_info_by_position(self, pos):
        if pos < 0 or pos >= len(self.visible_channels):
            return

        ch = self.visible_channels[pos]

        title = ch.get('title', 'Kanał')
        program = ch.get('program', '')
        next_program = ch.get('next_program', '')
        plot = ch.get('plot', '') or ch.get('desc', '') or 'Brak opisu programu.'
        start_ts = ch.get('start_ts', 0)
        stop_ts = ch.get('stop_ts', 0)

        image = (
            ch.get('image', '') or
            ch.get('thumb', '') or
            ch.get('poster', '') or
            ch.get('cover', '') or
            ch.get('icon', '') or
            ch.get('logo_url', '')
        )

        time_line = ''
        try:
            if start_ts and stop_ts:
                time_line = (
                    f"{time.strftime('%d.%m.%Y %H:%M', time.localtime(start_ts))}"
                    f" - "
                    f"{time.strftime('%H:%M', time.localtime(stop_ts))}"
                )
        except Exception:
            pass

        lines = []
        if time_line:
            lines.append(time_line)
        if program:
            lines.append(program)
        if next_program:
            lines.append(f'Następny: {next_program}')
        if plot:
            lines.append('')
            lines.append(plot)

        text = '\n'.join(lines).strip()
        if not text:
            text = 'Brak danych programu.'

        dlg = ChannelInfoDialog(
            'channel_info.xml',
            common.addon_path,
            'Default',
            '1080i',
            heading=title,
            text=text,
            image=image
        )
        dlg.doModal()
        del dlg

    def _show_channel_info(self):
        if not self.list:
            return

        pos = self.list.getSelectedPosition()
        if pos < 0 or pos >= len(self.visible_channels):
            return

        self._show_channel_info_by_position(pos)

    def _apply_group_filter(self):
        self.visible_channels = []

        if not self.groups:
            self.groups = ['WSZYSTKIE']

        if self.group_index < 0 or self.group_index >= len(self.groups):
            self.group_index = 0

        if self.group_index == 0:
            for gi, ch in enumerate(self.channels):
                item = dict(ch)
                item['_global_index'] = gi
                self.visible_channels.append(item)
        else:
            gname = self.groups[self.group_index]
            for gi, ch in enumerate(self.channels):
                if ch.get('group_name', 'POZOSTAŁE').strip() == gname:
                    item = dict(ch)
                    item['_global_index'] = gi
                    self.visible_channels.append(item)

    def _find_global_index(self, channel_item):
        return int(channel_item.get('_global_index', -1))

    def _visible_channel_id(self, channel_item):
        try:
            gi = int(channel_item.get('_global_index', -1))
            if gi >= 0:
                return f'gi:{gi}'
        except Exception:
            pass

        cmd = str(channel_item.get('cmd', '')).strip()
        if cmd:
            return f'cmd:{cmd}'

        title = str(channel_item.get('title', '')).strip()
        return f'title:{title}'

    def _get_selected_global_index(self):
        try:
            if not self.list:
                return -1

            pos = self.list.getSelectedPosition()
            if pos < 0 or pos >= len(self.visible_channels):
                return -1

            return self._find_global_index(self.visible_channels[pos])
        except Exception:
            return -1

    def _select_visible_channel_by_global_index(self, global_index, focus_list=False):
        try:
            if not self.list:
                return False

            for pos, ch in enumerate(self.visible_channels):
                if self._find_global_index(ch) == global_index:
                    self.list.selectItem(pos)

                    if focus_list and self.list.size() > 0:
                        try:
                            self.setFocus(self.list)
                        except Exception:
                            pass

                    return True
        except Exception:
            pass

        return False

    def _build_overlay_item_data(self, ch, rec_title=''):
        title = ch.get('title', 'Kanał')
        program = ch.get('program', '')
        next_program = ch.get('next_program', '')
        logo = ch.get('logo_url', '')
        global_index = self._find_global_index(ch)

        try:
            start_ts = int(ch.get('start_ts', 0) or 0)
            stop_ts = int(ch.get('stop_ts', 0) or 0)

            if start_ts and stop_ts:
                progress_val = _calc_progress(start_ts, stop_ts)
            else:
                progress_val = int(float(ch.get('progress', 0)))
        except Exception:
            progress_val = 0

        if progress_val < 0:
            progress_val = 0
        elif progress_val > 100:
            progress_val = 100

        rec_label = ''
        try:
            ch_title = str(title).strip().lower()
            if rec_title and ch_title and rec_title == ch_title:
                rec_label = '[COLOR red]REC[/COLOR]'
        except Exception:
            rec_label = ''

        if rec_label:
            label = f"{rec_label}  {title}"
        else:
            label = f"{global_index + 1}. {title}" if global_index >= 0 else title

        return {
            'label': label,
            'program': program,
            'next_program': next_program,
            'logo': logo,
            'progress_val': progress_val,
            'progress': str(progress_val),
            'global_index': global_index,
            'is_playing': 'true' if global_index == self.current_index else ''
        }

    def _fill_list_ui(self, preferred_global_index=None, focus_list=True):
        if not self.list:
            return

        self.list.reset()
        items = []

        selected_pos = 0
        preferred_pos = -1
        current_pos = -1

        rec_title = ''
        try:
            rec_state = recorder.get_recording_status()
            if rec_state.get('active'):
                rec_title = str(rec_state.get('title', '')).strip().lower()
        except Exception:
            rec_title = ''

        for idx, ch in enumerate(self.visible_channels):
            data = self._build_overlay_item_data(ch, rec_title=rec_title)

            if preferred_global_index is not None and data['global_index'] == preferred_global_index:
                preferred_pos = idx

            if data['global_index'] == self.current_index:
                current_pos = idx

            li = xbmcgui.ListItem(data['label'])
            li.setArt({
                'icon': data['logo'],
                'thumb': data['logo']
            })
            li.setProperty('Program', data['program'])
            li.setProperty('NextTitle', data['next_program'])
            li.setProperty('Progress', data['progress'])
            li.setProperty('ProgressInt', str(data['progress_val']))
            li.setProperty('GlobalIndex', str(data['global_index']))
            li.setProperty('IsPlaying', data['is_playing'])
            items.append(li)

        self.list.addItems(items)

        if items:
            if preferred_pos >= 0:
                selected_pos = preferred_pos
            elif current_pos >= 0:
                selected_pos = current_pos
            else:
                selected_pos = 0

            try:
                self.list.selectItem(selected_pos)
            except Exception:
                pass

        xbmc.sleep(50)

        if focus_list and items:
            try:
                self.setFocus(self.list)
            except Exception:
                pass

        try:
            self.getControl(21).setLabel(self.groups[self.group_index])
        except Exception:
            pass

    def _refresh_list_items_in_place(self):
        if not self.list:
            return False

        try:
            if self.list.size() != len(self.visible_channels):
                return False
        except Exception:
            return False

        rec_title = ''
        try:
            rec_state = recorder.get_recording_status()
            if rec_state.get('active'):
                rec_title = str(rec_state.get('title', '')).strip().lower()
        except Exception:
            rec_title = ''

        try:
            for i, ch in enumerate(self.visible_channels):
                li = self.list.getListItem(i)
                if not li:
                    return False

                data = self._build_overlay_item_data(ch, rec_title=rec_title)

                li.setLabel(data['label'])
                li.setArt({
                    'icon': data['logo'],
                    'thumb': data['logo']
                })
                li.setProperty('Program', data['program'])
                li.setProperty('NextTitle', data['next_program'])
                li.setProperty('Progress', data['progress'])
                li.setProperty('ProgressInt', str(data['progress_val']))
                li.setProperty('GlobalIndex', str(data['global_index']))
                li.setProperty('IsPlaying', data['is_playing'])
        except Exception as e:
            xbmc.log(f'[ChannelOverlay] _refresh_list_items_in_place error: {e}', xbmc.LOGERROR)
            return False

        try:
            self.getControl(21).setLabel(self.groups[self.group_index])
        except Exception:
            pass

        return True

    def fill_list(self, reload_state=True, preferred_global_index=None, focus_list=True):
        if reload_state:
            self._reload_state()

        self._apply_group_filter()
        self._fill_list_ui(
            preferred_global_index=preferred_global_index,
            focus_list=focus_list
        )


    def _group_left(self):
        if self.group_index > 0:
            self.group_index -= 1
            self._save_current_group()
            self.fill_list(
                reload_state=False,
                focus_list=True
            )

    def _group_right(self):
        if self.group_index < len(self.groups) - 1:
            self.group_index += 1
            self._save_current_group()
            self.fill_list(
                reload_state=False,
                focus_list=True
            )

    def onAction(self, action):
        aid = action.getId()

        if aid == 102:
            self._show_channel_info()
            return

        if aid in [9, 10, 13, 92]:
            self.close()
            return

        if aid in [1, 169, 521]:
            if self.group_index > 0:
                self._group_left()
            else:
                self._open_context_menu_from_navigation()
            return

        if aid in [2, 168, 520]:
            self._group_right()
            return

        if aid == 117:
            self._context_menu()
            return


    def onClick(self, controlId):
        if controlId in [30, 34]:
            self._toggle_sticky()
            return

        if controlId in [35, 36]:
            self._toggle_group_mode()
            return

        if controlId == 37:
            self._open_tv_guide()
            return

        if controlId == 31:
            self._group_left()
            return

        if controlId == 32:
            self._group_right()
            return

        if controlId != 11:
            return

        pos = self.list.getSelectedPosition()
        if pos < 0 or pos >= len(self.visible_channels):
            return

        ch = self.visible_channels[pos]
        global_index = self._find_global_index(ch)

        if global_index < 0:
            return

        channel_switch.play_index(global_index)

        if self.sticky:
            self.current_index = global_index

            if self.group_mode == 'current_channel':
                self._sync_group_to_current_channel()

            self.fill_list(
                reload_state=False,
                preferred_global_index=global_index,
                focus_list=True
            )
        else:
            self.close()

    def _context_menu(self): 
        pos = self.list.getSelectedPosition()
        if pos < 0 or pos >= len(self.visible_channels):
            return

        ch = self.visible_channels[pos]
        portal = self.state.get('portal', {})
        title = ch.get('title', 'Kanał')
        cmd = ch.get('cmd', '')
        logo = ch.get('logo_url', '')

        group_mode_status = (
            '[COLOR lime]WŁ[/COLOR]'
            if self.group_mode == 'current_channel'
            else '[COLOR red]WYŁ[/COLOR]'
        )

        sticky_status = '[COLOR lime]WŁ[/COLOR]' if self.sticky else '[COLOR red]WYŁ[/COLOR]'



        record_unlimited_params = {
            "mode": "record_tv_start",
            "cmd": cmd,
            "title": title,
            "logo_url": logo,
            "portal": json.dumps(portal),
            "stop_ts": ch.get("stop_ts", 0),
            "record_mode": "unlimited"
        }

        record_program_params = {
            "mode": "record_tv_program",
            "cmd": cmd,
            "title": title,
            "logo_url": logo,
            "portal": json.dumps(portal),
            "start_ts": ch.get("start_ts", 0),
            "stop_ts": ch.get("stop_ts", 0)
        }

        record_custom_params = {
            "mode": "record_tv_start",
            "cmd": cmd,
            "title": title,
            "logo_url": logo,
            "portal": json.dumps(portal),
            "stop_ts": ch.get("stop_ts", 0),
            "record_mode": "custom"
        }

        record_stop_params = {
            "mode": "record_tv_stop",
            "portal": json.dumps(portal)
        }

        record_info_params = {
            "mode": "recording_info",
            "portal": json.dumps(portal)
        }

        provider_settings_params = {
            "mode": "provider_settings",
            "portal": json.dumps(portal)
        }

        media_manager_params = {
            "mode": "media_manager"
        }

        menu_items = [
            (
                'Pokaż szczegóły programu',
                lambda: self._show_channel_info()
            ),
            (
                f'Ustawianie grupy wg kanału: {group_mode_status}',
                lambda: self._toggle_group_mode()
            ),
            (
                f'Pinezka: {sticky_status}',
                lambda: self._toggle_sticky()
            ),
            (
                'Przewodnik TV',
                lambda: self._open_tv_guide()
            ),

            (
                'Nagraj bez limitu',
                lambda: (
                    xbmc.executebuiltin(
                        'RunPlugin({})'.format(common.build_url(record_unlimited_params))
                    ),
                    xbmc.sleep(300),
                    self.fill_list()
                )
            ),
            (
                'Nagraj do końca programu',
                lambda: (
                    xbmc.executebuiltin(
                        'RunPlugin({})'.format(common.build_url(record_program_params))
                    ),
                    xbmc.sleep(300),
                    self.fill_list()
                )
            ),
            (
                'Nagraj własny czas',
                lambda: (
                    xbmc.executebuiltin(
                        'RunPlugin({})'.format(common.build_url(record_custom_params))
                    ),
                    xbmc.sleep(300),
                    self.fill_list()
                )
            ),
            (
                'Stop nagrywania',
                lambda: (
                    xbmc.executebuiltin(
                        'RunPlugin({})'.format(common.build_url(record_stop_params))
                    ),
                    xbmc.sleep(300),
                    self.fill_list()
                )
            ),
            (
                'Info o nagrywaniu',
                lambda: xbmc.executebuiltin(
                    'RunPlugin({})'.format(common.build_url(record_info_params))
                )
            ),
            (
                'Pobrane i nagrane',
                lambda: (
                    self.close(),
                    xbmc.sleep(200),
                    xbmc.executebuiltin(
                        'ActivateWindow(Videos,{},return)'.format(
                            common.build_url(media_manager_params)
                        )
                    )
                )
            ),
            (
                'Odśwież listę',
                lambda: self._manual_refresh_current_state()
            ),
            (
                'Ustawienia',
                lambda: (
                    self.close(),
                    xbmc.sleep(200),
                    xbmc.executebuiltin(
                        'ActivateWindow(Videos,{},return)'.format(
                            common.build_url(provider_settings_params)
                        )
                    )
                )
            )
        ]

        labels = [item[0] for item in menu_items]
        choice = xbmcgui.Dialog().select(title, labels)
        if choice < 0:
            return

        try:
            action = menu_items[choice][1]
            action()
        except Exception as e:
            xbmc.log(f'[ChannelOverlay] context menu action error: {e}', xbmc.LOGERROR)

    def _open_context_menu_from_navigation(self):
        try:
            now_ts = time.time()
            if now_ts - self._last_nav_context_ts < 0.35:
                return

            self._last_nav_context_ts = now_ts
            self._context_menu()

        except Exception as e:
            xbmc.log(f'[ChannelOverlay] _open_context_menu_from_navigation error: {e}', xbmc.LOGERROR)

def _can_open_channel_overlay():
    try:
        win = xbmcgui.Window(10000)

        if win.getProperty('IskierekPlaybackPlugin') == 'plugin.video.Iskierek-IPTV-Full':
            if win.getProperty('IskierekTvPlaybackActive') == '1':
                return True

        try:
            if timeshift.is_timeshift_active():
                return True
        except Exception:
            pass

        return False
    except Exception:
        return False

def open_overlay():
    if not _can_open_channel_overlay():
        return

    state = common.read_json_safe(common.channel_state_file)
    channels = state.get('channels', [])

    if not channels:
        xbmcgui.Dialog().notification(
            common.addonname,
            'Brak zapisanej listy kanałów',
            xbmcgui.NOTIFICATION_ERROR
        )
        return

    win = ChannelOverlay('channel_overlay.xml', common.addon_path, 'Default', '1080i')
    win.doModal()
    del win