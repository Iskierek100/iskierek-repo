# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcplugin
import json

from resources.lib import common
from resources.lib.providers import provider_api
from resources.lib.tv import live as tv_live
import resources.lib.core.sorting as sorting
from resources.lib.tv import live


def refresh_gui():
    xbmc.executebuiltin('Container.Refresh')


def renameChannel(portal):
    key_id = common.args.get('id_key', [None])[0]
    current_name = common.args.get('current_name', [''])[0]
    if not key_id:
        return

    kb = xbmc.Keyboard(current_name, 'Nowa nazwa')
    kb.doModal()
    if kb.isConfirmed():
        new_name = kb.getText()
        full_db = common.read_json_safe(common.custom_names_file)
        pkey = common.get_portal_key(portal)

        if pkey not in full_db:
            full_db[pkey] = {}

        if new_name == "" or new_name == key_id:
            if key_id in full_db[pkey]:
                del full_db[pkey][key_id]
        else:
            full_db[pkey][key_id] = new_name

        common.write_json_safe(common.custom_names_file, full_db)

        try:
            live.clear_live_window_cache()
        except Exception:
            pass

        try:
            xbmcgui.Window(10000).setProperty('IskierekLiveRefresh', '1')
        except Exception:
            pass

        refresh_gui()


def hideChannel(portal):
    id_key = common.args.get('id_key', [None])[0]
    if not id_key:
        return

    db = common.read_json_safe(common.hidden_channels_file)
    pkey = common.get_portal_key(portal)

    if pkey not in db:
        db[pkey] = []

    if id_key not in db[pkey]:
        db[pkey].append(id_key)
        common.write_json_safe(common.hidden_channels_file, db)

        try:
            live.clear_live_window_cache()
        except Exception:
            pass

        try:
            xbmcgui.Window(10000).setProperty('IskierekLiveRefresh', '1')
        except Exception:
            pass

        refresh_gui()


def restoreChannel(portal):
    id_key = common.args.get('id_key', [None])[0]
    if not id_key:
        return

    db = common.read_json_safe(common.hidden_channels_file)
    pkey = common.get_portal_key(portal)

    if pkey in db and id_key in db[pkey]:
        db[pkey].remove(id_key)
        common.write_json_safe(common.hidden_channels_file, db)

        try:
            live.clear_live_window_cache()
        except Exception:
            pass

        try:
            xbmcgui.Window(10000).setProperty('IskierekLiveRefresh', '1')
        except Exception:
            pass

        refresh_gui()


def HiddenManagerLevel(portal):
    xbmcplugin.setContent(common.addon_handle, 'files')
    db = common.read_json_safe(common.hidden_channels_file)
    hidden_list = db.get(common.get_portal_key(portal), [])

    if not hidden_list:
        li = xbmcgui.ListItem("[COLOR grey]Brak ukrytych kanałów[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=common.addon_handle, url="", listitem=li, isFolder=False)
    else:
        for name in hidden_list:
            url = common.build_url({'mode': 'restore_channel', 'id_key': name, 'portal': json.dumps(portal)})
            li = xbmcgui.ListItem(f"Przywróć kanał: [COLOR gold]{name}[/COLOR]")
            li.setArt({'icon': common.icon36, 'fanart': common.fanart})
            xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)


def OpenGroupSelectDialog(portal):
    provider = provider_api.get_provider(portal)
    g_type = common.args.get('g_type', ['tv'])[0]

    try:
        pd = xbmcgui.DialogProgressBG()
        pd.create(common.addonname, "Pobieranie listy grup...")

        if g_type == 'vod':
            data = provider.getVoDgenres(portal, common.addondir) if portal.get('type') in ['xtream', 'm3u'] else provider.getVoDgenres(portal['mac'], portal['url'], portal['serial'], common.addondir)
            genres = data['vodgenres']
        elif g_type == 'ser':
            data = provider.getSergenres(portal, common.addondir) if portal.get('type') in ['xtream', 'm3u'] else provider.getSergenres(portal['mac'], portal['url'], portal['serial'], common.addondir)
            genres = data['sergenres']
        else:
            data = provider.getGenres(portal, common.addondir) if portal.get('type') in ['xtream', 'm3u'] else provider.getGenres(portal['mac'], portal['url'], portal['serial'], common.addondir)
            genres = data['genres']

        pd.close()
    except:
        try:
            pd.close()
        except:
            pass
        return

    sorted_items = sorted(genres.items(), key=lambda x: x[1]['title'])
    dialog_list = [item[1]['title'] for item in sorted_items]
    ids_list = [item[0] for item in sorted_items]

    saved_data = common.read_json_safe(common.selected_groups_file)
    user_key = common.get_portal_key(portal)
    mac_data = saved_data.get(user_key, {})

    if isinstance(mac_data, list):
        mac_data = {'tv': mac_data, 'vod': [], 'ser': []}

    my_selected = mac_data.get(g_type, [])
    preselect = []

    for idx, gid in enumerate(ids_list):
        if gid in my_selected:
            preselect.append(idx)

    selected_indices = xbmcgui.Dialog().multiselect(
        f"Wybierz grupy ({g_type.upper()})",
        dialog_list,
        preselect=preselect
    )

    if selected_indices is not None:
        new_selected_ids = [ids_list[i] for i in selected_indices]

        if user_key not in saved_data:
            saved_data[user_key] = {'tv': [], 'vod': [], 'ser': []}

        if not isinstance(saved_data[user_key], dict):
            saved_data[user_key] = {'tv': [], 'vod': [], 'ser': []}

        saved_data[user_key][g_type] = new_selected_ids
        common.write_json_safe(common.selected_groups_file, saved_data)

        xbmcgui.Dialog().notification(common.addonname, "Zapisano grupy", common.icon0)
        refresh_gui()


def OpenPolishGroupSelectDialog(portal):
    sorting.reload_config()

    all_groups = [g[0] for g in sorting.ORDERED_GROUPS] + ['POZOSTAŁE']
    saved_data = common.read_json_safe(common.selected_groups_file)

    # domyślnie POZOSTAŁE wyłączone
    default_groups = [g[0] for g in sorting.ORDERED_GROUPS]
    selected_names = saved_data.get('pl_supergroup', default_groups)

    preselect = []
    for idx, name in enumerate(all_groups):
        if name in selected_names:
            preselect.append(idx)

    selected_indices = xbmcgui.Dialog().multiselect(
        "Wybierz grupy do Wszystkie Polskie",
        all_groups,
        preselect=preselect
    )

    if selected_indices is not None:
        new_selected_names = [all_groups[i] for i in selected_indices]
        saved_data['pl_supergroup'] = new_selected_names
        common.write_json_safe(common.selected_groups_file, saved_data)

        tv_live.rebuild_all_polish_channel_state(portal)

        xbmcgui.Dialog().notification(common.addonname, "Zapisano układ PL", common.icon0)
        refresh_gui()


def MyGroupsLevel(portal):
    provider = provider_api.get_provider(portal)
    xbmcplugin.setContent(common.addon_handle, 'files')

    try:
        if portal.get('type') in ['xtream', 'm3u']:
            data = provider.getGenres(portal, common.addondir)
        else:
            data = provider.getGenres(portal['mac'], portal['url'], portal['serial'], common.addondir)

        genres = data['genres']
    except Exception as e:
        xbmc.log(f"[MY GROUPS ERROR] {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(common.addonname, f"Błąd grup TV:\n{str(e)}")
        return

    saved_data = common.read_json_safe(common.selected_groups_file)
    user_key = common.get_portal_key(portal)
    mac_data = saved_data.get(user_key, {})

    if isinstance(mac_data, list):
        mac_data = {'tv': mac_data}

    my_selected = mac_data.get('tv', [])

    if not my_selected:
        li = xbmcgui.ListItem("[COLOR yellow]Brak grup TV. Kliknij, aby wybrać.[/COLOR]")
        url = common.build_url({'mode': 'open_group_select', 'g_type': 'tv', 'portal': json.dumps(portal)})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)
        return

    sorted_items = sorted(genres.items(), key=lambda x: x[1]['title'])
    for gid, item in sorted_items:
        if gid in my_selected:
            title = item["title"]
            url = common.build_url({'mode': 'channels', 'genre_id': gid, 'genre_name': title.title(), 'portal': json.dumps(portal)})
            li = xbmcgui.ListItem(title.title())
            li.setArt({'icon': common.icon10, 'fanart': common.fanart})
            xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)


def ManageGroupsMenu(portal):
    OpenGroupSelectDialog(portal)