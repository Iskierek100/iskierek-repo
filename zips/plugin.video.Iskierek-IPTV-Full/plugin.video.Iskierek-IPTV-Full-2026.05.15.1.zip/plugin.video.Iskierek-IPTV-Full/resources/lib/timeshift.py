# -*- coding: utf-8 -*-
import os
import time
import signal
import subprocess
import threading
import urllib.request
import ssl
import uuid
import shutil

import xbmc
import xbmcgui

from resources.lib import common
from resources.lib.providers import provider_api
from resources.lib.tv.epg import load_epg_cache_fast, get_epg_cache_item


_watchdog_stop = False
_timeshift_player_monitor = None
_timeshift_refresh_lock = threading.Lock()


_WATCHDOG_COOLDOWN_SECONDS = 3.0
_REFRESH_SEEK_DELAY = 0.15

_CAPTURE_START_MAX_WAIT_SECONDS = 5.0     # docelowo max
_CAPTURE_READY_MIN_BYTES = 32 * 1024      # było 128KB
_PLAYBACK_WAIT_FOR_START_SECONDS = 3.0    # żeby ACE nie czekało 10s
_SEEK_TOLERANCE_SECONDS = 0.7
_SEEK_RETRIES = 2


# ---------------------------------------------------------
# STATE
# ---------------------------------------------------------

def _is_ace_cmd(cmd=''):
    try:
        c = str(cmd or '').lower()
        if '127.0.0.1:6878/ace/' in c:
            return True
        if '/ace/getstream' in c and ('infohash=' in c or 'id=' in c):
            return True
        return False
    except Exception:
        return False


def _ace_smart_start_play(file_path, title, max_tries=3):
    # ACE: startujemy prosto + czekamy aż player faktycznie ruszy,
    # bez sprawdzania totalTime.
    li = xbmcgui.ListItem(label=title or 'Timeshift')
    li.setPath(file_path)
    _configure_timeshift_playback_item(li, file_path)

    try:
        safe_path = file_path.replace('\\', '\\\\').replace('"', '\\"')
    except Exception:
        safe_path = file_path

    for attempt in range(1, int(max_tries or 3) + 1):
        xbmc.log(f"[Timeshift][ACE] play attempt {attempt}/{max_tries}", xbmc.LOGINFO)

        try:
            xbmc.Player().play(file_path, li)
        except Exception as e:
            xbmc.log(f"[Timeshift][ACE] Player().play error: {e}", xbmc.LOGERROR)
            try:
                xbmc.executebuiltin(f'PlayMedia("{safe_path}")')
            except Exception:
                pass

        # podobnie jak w starym kodzie: do 10s czekamy aż ruszy
        if _wait_for_playback_start(_safe_get_player(), timeout=10.0):
            return True

        xbmc.sleep(300)

    return False


def _load_state():
    data = common.read_json_safe(common.timeshift_state_file)
    if isinstance(data, dict):
        return data
    return {}


def _save_state(data):
    if not isinstance(data, dict):
        data = {}
    common.write_json_safe(common.timeshift_state_file, data)


def _set_state_field(key, value):
    try:
        state = _load_state()
        state[key] = value
        _save_state(state)
    except Exception:
        pass


# ---------------------------------------------------------
# HELPERS
# ---------------------------------------------------------




def _safe_get_player():
    try:
        return xbmc.Player()
    except Exception:
        return None

def _is_local_proxy_stream(url):
    u = str(url or '').lower()
    return (
        '127.0.0.1' in u or
        'localhost' in u or
        ':6878/' in u or
        'acestream' in u
    )


def _format_duration(seconds):
    try:
        sec = max(0, int(seconds))
        h = sec // 3600
        m = (sec % 3600) // 60
        s = sec % 60
        if h > 0:
            return f"{h:02d}:{m:02d}:{s:02d}"
        return f"{m:02d}:{s:02d}"
    except Exception:
        return "00:00"


def _show_timeshift_busy():
    try:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    except Exception:
        pass


def _hide_timeshift_busy():
    try:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmc.executebuiltin('Dialog.Close(busydialog)')
    except Exception:
        pass


def _configure_timeshift_playback_item(li, play_path=''):
    try:
        li.setProperty('IsPlayable', 'true')
        li.setContentLookup(False)
        li.setMimeType('video/mp2t')
    except Exception:
        pass


def _wait_for_playback_start(player=None, timeout=4.0, poll_ms=150):
    start_wait = time.time()
    timeout = float(timeout or 0.0)
    poll_ms = int(poll_ms or 150)

    while time.time() - start_wait < timeout:
        try:
            p = player if player is not None else _safe_get_player()
            if p and p.isPlaying():
                return True
        except Exception:
            pass

        xbmc.sleep(poll_ms)

    return False


def _get_playback_times(player):
    current_time = 0.0
    total_time = 0.0

    try:
        current_time = float(player.getTime())
    except Exception:
        current_time = 0.0

    try:
        total_time = float(player.getTotalTime())
    except Exception:
        total_time = 0.0

    return current_time, total_time


def _seek_player_to_time(player, target_time, tolerance=0.7, max_retries=3, base_delay_ms=120):
    """
    Próbuje zaszyć w przybliżeniu dokładny czas.
    tolerance: akceptowalna różnica w sekundach.
    """
    if not player:
        return False

    try:
        target = max(0.0, float(target_time or 0.0))
    except Exception:
        target = 0.0

    for r in range(int(max_retries or 1)):
        try:
            if player.isPlaying():
                player.seekTime(target)
        except Exception:
            pass

        xbmc.sleep(int(base_delay_ms + r * 120))

        try:
            cur = float(player.getTime() or 0.0)
        except Exception:
            cur = 0.0

        if abs(cur - target) <= float(tolerance or 0.0):
            return True

    return False

def _is_current_timeshift_playback(player=None):
    try:
        if not player:
            player = _safe_get_player()
        if not player or not player.isPlaying():
            return False

        try:
            current_file = player.getPlayingFile()
        except Exception:
            current_file = ''

        if not current_file:
            return False

        current_file_l = str(current_file).replace('\\', '/').lower()

        state = _load_state()
        ts_file = state.get('file', '')
        if not ts_file:
            return False

        ts_file_l = str(ts_file).replace('\\', '/').lower()
        return ts_file_l in current_file_l
    except Exception:
        return False


# ---------------------------------------------------------
# STATUS
# ---------------------------------------------------------

def get_timeshift_status():
    state = _load_state()

    enabled = bool(state.get('enabled', False))
    active = bool(state.get('active', False))
    backend = state.get('backend', '')
    pid = int(state.get('pid', 0) or 0)

    if active and backend == 'ffmpeg' and pid:
        try:
            os.kill(pid, 0)
        except Exception:
            state['active'] = False
            state['pid'] = 0
            _save_state(state)
            active = False

    return {
        'enabled': enabled,
        'active': active,
        'backend': backend,
        'title': state.get('title', ''),
        'file': state.get('file', ''),
        'pid': pid,
        'session_id': state.get('session_id', ''),
        'started': int(state.get('started', 0) or 0),
        'seek_monitor_enabled': bool(state.get('seek_monitor_enabled', False)),
        'last_observed_time': float(state.get('last_observed_time', 0.0) or 0.0),
        'last_refresh_ts': float(state.get('last_refresh_ts', 0.0) or 0.0),
        'last_pause_position': float(state.get('last_pause_position', 0.0) or 0.0),
        'refresh_in_progress': bool(state.get('refresh_in_progress', False)),
        'technical_stop_in_progress': bool(state.get('technical_stop_in_progress', False)),
        'epg_start_ts': int(state.get('epg_start_ts', 0) or 0),
        'epg_stop_ts': int(state.get('epg_stop_ts', 0) or 0),
        'timeshift_start_ts': int(state.get('timeshift_start_ts', 0) or 0),
        'program': state.get('program', ''),
        'mode': state.get('mode', '')
    }


def is_timeshift_enabled():
    return bool(get_timeshift_status().get('enabled', False))


def is_timeshift_active():
    return bool(get_timeshift_status().get('active', False))


def is_technical_stop_in_progress():
    try:
        state = _load_state()
        return bool(state.get('technical_stop_in_progress', False))
    except Exception:
        return False


def _set_technical_stop_in_progress(value):
    _set_state_field('technical_stop_in_progress', bool(value))


def _set_refresh_in_progress(value):
    _set_state_field('refresh_in_progress', bool(value))


# ---------------------------------------------------------
# EPG / STREAM HELPERS
# ---------------------------------------------------------

def _get_current_channel_state_item():
    try:
        state = common.read_json_safe(common.channel_state_file)
        if not isinstance(state, dict):
            return {}

        channels = state.get('channels', [])
        current_index = int(state.get('current_index', -1))

        if isinstance(channels, list) and 0 <= current_index < len(channels):
            item = channels[current_index]
            if isinstance(item, dict):
                return item
    except Exception:
        pass

    return {}


def _get_epg_bounds_for_timeshift(title=''):
    start_ts = 0
    stop_ts = 0
    program = ''

    try:
        arg_stop_ts = common.args.get('stop_ts', [''])[0]
        if str(arg_stop_ts).strip().isdigit():
            stop_ts = int(arg_stop_ts)
    except Exception:
        pass

    try:
        item = _get_current_channel_state_item()
        if item:
            item_title = str(item.get('title', '')).strip()
            req_title = str(title or '').strip()

            same_title = False
            if req_title and item_title and req_title == item_title:
                same_title = True
            elif req_title and item_title and common.clean_channel_name(req_title) == common.clean_channel_name(item_title):
                same_title = True

            if same_title or not req_title:
                start_ts = int(item.get('start_ts', 0) or 0)
                if not stop_ts:
                    stop_ts = int(item.get('stop_ts', 0) or 0)
                program = str(item.get('program', '') or '')
    except Exception:
        pass

    if not start_ts or not stop_ts:
        try:
            epg_cache = load_epg_cache_fast()
            epg_item = get_epg_cache_item(epg_cache, title)
            if epg_item:
                if not start_ts:
                    start_ts = int(epg_item.get('start_ts', 0) or 0)
                if not stop_ts:
                    stop_ts = int(epg_item.get('stop_ts', 0) or 0)
                if not program:
                    program = str(epg_item.get('epg_current', '') or '')
        except Exception:
            pass

    return start_ts, stop_ts, program


def _get_stream_url(portal, cmd):
    provider = provider_api.get_provider(portal)

    if portal.get('type') == 'm3u':
        return cmd

    if portal.get('type') == 'xtream':
        return provider.getLinkTV(portal, cmd)

    return provider.getLinkTV(portal['mac'], portal['url'], portal['serial'], cmd)


def _get_stream_url_with_retry(portal, cmd, retries=3):
    last_error = None

    for attempt in range(1, retries + 1):
        try:
            stream_url = _get_stream_url(portal, cmd)
            if stream_url:
                xbmc.log(f"[Timeshift] stream url ok attempt {attempt}/{retries}", xbmc.LOGINFO)
                return stream_url
        except Exception as e:
            last_error = e
            xbmc.log(f"[Timeshift] stream url attempt {attempt}/{retries} error: {e}", xbmc.LOGERROR)

        if attempt < retries:
            xbmc.sleep(500)

    if last_error:
        raise last_error

    return ''


# ---------------------------------------------------------
# PATHS / FILES
# ---------------------------------------------------------

def _build_timeshift_title(title):
    safe_title = "".join(c if c.isalnum() or c in "._- " else "_" for c in str(title or "timeshift"))
    safe_title = safe_title.strip() or "timeshift"
    return safe_title


def get_timeshift_dir():
    path = common.addon.getSetting('recordings_dir').strip()
    if path and os.path.exists(path):
        ts_dir = os.path.join(path, 'timeshift')
        try:
            os.makedirs(ts_dir, exist_ok=True)
        except Exception:
            pass
        return ts_dir
    return None

def purge_timeshift_dir():
    try:
        ts_dir = get_timeshift_dir()
        if not ts_dir or not os.path.isdir(ts_dir):
            return

        # usuń wszystko co jest plikiem (timeshift i snapshoty)
        for name in os.listdir(ts_dir):
            full = os.path.join(ts_dir, name)
            if os.path.isfile(full):
                _safe_remove_file(full, retries=6, delay_ms=200)
    except Exception as e:
        xbmc.log(f"[Timeshift] purge_timeshift_dir error: {e}", xbmc.LOGERROR)

def get_ffmpeg_binary():
    custom_path = common.addon.getSetting('ffmpeg_path').strip()
    if custom_path:
        if os.path.exists(custom_path):
            return custom_path
        return None
    return shutil.which('ffmpeg')


def _build_buffer_path(title):
    ts_dir = get_timeshift_dir()
    if not ts_dir:
        return None

    safe_title = _build_timeshift_title(title)
    return os.path.join(ts_dir, f"{safe_title}_timeshift.ts")


def _safe_remove_file(path, retries=10, delay_ms=300):
    if not path:
        return False

    for _ in range(retries):
        try:
            if os.path.exists(path):
                os.remove(path)
            if not os.path.exists(path):
                return True
        except Exception:
            pass
        xbmc.sleep(delay_ms)

    return not os.path.exists(path)


def _wait_until_buffer_ready(file_path, timeout=20, min_bytes=1024 * 128):
    if not file_path:
        return False

    try:
        timeout = float(timeout or 0.0)
    except Exception:
        timeout = 20.0

    try:
        min_bytes = int(min_bytes if min_bytes is not None else (1024 * 128))
    except Exception:
        min_bytes = 1024 * 128

    end_ts = time.time() + timeout

    while time.time() < end_ts:
        try:
            if os.path.exists(file_path):
                size = os.path.getsize(file_path)
                if size > int(min_bytes):
                    return True
        except Exception:
            pass

        try:
            part_path = file_path + '.part'
            if os.path.exists(part_path):
                size = os.path.getsize(part_path)
                if size > int(min_bytes):
                    return True
        except Exception:
            pass

        xbmc.sleep(250)

    return False


def _get_timeshift_max_mb():
    try:
        val = common.addon.getSetting('timeshift_max_mb').strip()
        if not val:
            return 2048
        return max(256, int(val))
    except Exception:
        return 2048


def _list_timeshift_files():
    ts_dir = get_timeshift_dir()
    if not ts_dir or not os.path.isdir(ts_dir):
        return []

    result = []
    try:
        for name in os.listdir(ts_dir):
            full = os.path.join(ts_dir, name)
            if not os.path.isfile(full):
                continue

            try:
                result.append({
                    'path': full,
                    'name': name,
                    'size': os.path.getsize(full),
                    'mtime': os.path.getmtime(full)
                })
            except Exception:
                pass
    except Exception:
        pass

    return result

def _get_timeshift_dir_size_bytes():
    ts_dir = get_timeshift_dir()
    if not ts_dir or not os.path.isdir(ts_dir):
        return 0

    total = 0
    try:
        for name in os.listdir(ts_dir):
            full = os.path.join(ts_dir, name)
            if os.path.isfile(full):
                try:
                    total += os.path.getsize(full)
                except Exception:
                    pass
    except Exception:
        pass

    return total

def _stop_capture_if_timeshift_limit_exceeded():
    try:
        max_mb = _get_timeshift_max_mb()  # bierze z settingu użytkownika
        max_bytes = max(256, int(max_mb)) * 1024 * 1024

        total_bytes = _get_timeshift_dir_size_bytes()
        if total_bytes <= max_bytes:
            return False

        xbmc.log(f"[Timeshift] limit exceeded during playback: dir={total_bytes/(1024*1024):.1f}MB > max={max_mb}MB -> stopping capture",
                 xbmc.LOGWARNING)

        # NIE usuwamy pliku — tylko zatrzymujemy zapis, żeby nie dobić do full dysku
        stop_timeshift_buffer(remove_files=False)
        return True
    except Exception as e:
        xbmc.log(f"[Timeshift] _stop_capture_if_timeshift_limit_exceeded error: {e}", xbmc.LOGERROR)
        return False

def cleanup_timeshift_dir_by_limit():
    try:
        ts_dir = get_timeshift_dir()
        if not ts_dir or not os.path.isdir(ts_dir):
            return

        max_mb = _get_timeshift_max_mb()
        max_bytes = max(256, int(max_mb)) * 1024 * 1024

        files = _list_timeshift_files()
        if not files:
            return

        total_size = sum(x.get('size', 0) for x in files)
        if total_size <= max_bytes:
            return

        state = _load_state()
        protected = set()

        # 1) chronimy plik z state (jeśli jest sensowny)
        try:
            sf = state.get('file', '') or ''
            if sf and os.path.exists(sf):
                protected.add(os.path.abspath(sf))
        except Exception:
            pass

        # 2) chronimy plik aktualnie odtwarzany w Kodi (ważne po crashu)
        try:
            p = _safe_get_player()
            if p and p.isPlaying():
                playing = p.getPlayingFile() or ''
                if playing:
                    protected.add(os.path.abspath(playing))
        except Exception:
            pass

        files.sort(key=lambda x: x.get('mtime', 0))  # najstarsze pierwsze

        for item in files:
            if total_size <= max_bytes:
                break

            path = os.path.abspath(item.get('path', ''))
            if not path or path in protected:
                continue

            size = int(item.get('size', 0) or 0)
            if _safe_remove_file(path, retries=8, delay_ms=250):
                total_size -= size
                xbmc.log(f"[Timeshift] removed old file due to limit: {path}", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[Timeshift] cleanup_timeshift_dir_by_limit error: {e}", xbmc.LOGERROR)


# ---------------------------------------------------------
# CAPTURE
# ---------------------------------------------------------

def _python_timeshift_worker(stream_url, output_path, session_id):
    temp_path = output_path + '.part'
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    try:
        req = urllib.request.Request(stream_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, context=ctx, timeout=30) as response:
            with open(temp_path, 'wb') as f:
                while True:
                    state_now = _load_state()

                    if not state_now.get('active', False):
                        break
                    if not state_now.get('enabled', False):
                        break
                    if state_now.get('session_id', '') != session_id:
                        break

                    chunk = response.read(1024 * 512)
                    if not chunk:
                        time.sleep(0.25)
                        continue

                    f.write(chunk)
                    f.flush()

                    if not os.path.exists(output_path):
                        try:
                            os.rename(temp_path, output_path)
                            temp_path = output_path
                        except Exception:
                            temp_path = output_path

    except Exception as e:
        xbmc.log(f"[Timeshift Python] worker error: {e}", xbmc.LOGERROR)

    finally:
        xbmc.log("[Timeshift Python] worker finished", xbmc.LOGINFO)


def _start_ffmpeg_timeshift(ffmpeg_bin, stream_url, output_path, title, cmd, portal, session_id):
    cmdline = [
        ffmpeg_bin,
        '-y',
        '-i', stream_url,
        '-c', 'copy',
        output_path
    ]

    xbmc.log(f"[Timeshift] FFmpeg cmd: {' '.join(cmdline)}", xbmc.LOGINFO)

    proc = subprocess.Popen(
        cmdline,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    epg_start_ts, epg_stop_ts, program = _get_epg_bounds_for_timeshift(title)

    state = _load_state()
    state['enabled'] = True
    state['active'] = True
    state['backend'] = 'ffmpeg'
    state['pid'] = proc.pid
    state['title'] = title
    state['cmd'] = cmd
    state['portal'] = portal
    state['file'] = output_path
    state['session_id'] = session_id
    state['started'] = int(time.time())
    state['timeshift_start_ts'] = int(time.time())
    state['epg_start_ts'] = int(epg_start_ts or 0)
    state['epg_stop_ts'] = int(epg_stop_ts or 0)
    state['program'] = program
    state['seek_monitor_enabled'] = False
    state['last_observed_time'] = 0.0
    state['last_refresh_ts'] = 0.0
    state['last_pause_position'] = 0.0
    state['refresh_in_progress'] = False
    state['technical_stop_in_progress'] = False
    _save_state(state)


def _start_capture_process_only():
    try:
        state = _load_state()
        pid = int(state.get('pid', 0) or 0)
        backend = state.get('backend', '')

        if backend == 'ffmpeg' and pid:
            try:
                os.kill(pid, signal.SIGTERM)
            except Exception:
                pass

            xbmc.sleep(1000)

            try:
                os.kill(pid, 0)
                os.kill(pid, signal.SIGKILL)
            except Exception:
                pass

        state = _load_state()
        state['active'] = False
        state['pid'] = 0
        state['backend'] = ''
        state['mode'] = ''
        state['file'] = ''
        state['session_id'] = ''
        state['started'] = 0
        state['timeshift_start_ts'] = 0
        state['epg_start_ts'] = 0
        state['epg_stop_ts'] = 0
        state['program'] = ''
        state['technical_stop_in_progress'] = False
        _save_state(state)

    except Exception as e:
        xbmc.log(f"[Timeshift] _start_capture_process_only error: {e}", xbmc.LOGERROR)


def _start_timeshift_capture_with_retry(portal, title, cmd, retries=5):
    output_path = _build_buffer_path(title)
    if not output_path:
        return False, 'Brak ustawionego folderu nagrań'

    ffmpeg_bin = get_ffmpeg_binary()

    for attempt in range(1, retries + 1):
        xbmc.log(f"[Timeshift] capture start attempt {attempt}/{retries}", xbmc.LOGINFO)

        try:
            stream_url = _get_stream_url_with_retry(portal, cmd, retries=2)
        except Exception as e:
            xbmc.log(f"[Timeshift] stream url fetch error attempt {attempt}: {e}", xbmc.LOGERROR)
            xbmc.sleep(500)
            continue

        if not stream_url:
            xbmc.sleep(500)
            continue

        local_proxy = _is_local_proxy_stream(stream_url)

        # czyść pliki przed startem (legacy)
        try:
            if os.path.exists(output_path):
                os.remove(output_path)
        except Exception:
            pass

        try:
            part_path = output_path + '.part'
            if os.path.exists(part_path):
                os.remove(part_path)
        except Exception:
            pass

        session_id = str(uuid.uuid4())

        try:
            if ffmpeg_bin:
                _start_ffmpeg_timeshift(ffmpeg_bin, stream_url, output_path, title, cmd, portal, session_id)
            else:
                _start_python_timeshift(stream_url, output_path, title, cmd, portal, session_id)
        except Exception as e:
            xbmc.log(f"[Timeshift] capture process start error attempt {attempt}: {e}", xbmc.LOGERROR)
            _start_capture_process_only()
            xbmc.sleep(500)
            continue

        # klucz: 3s dla lokalnego proxy (ACE), 20s dla reszty
        ready = _wait_until_buffer_ready(output_path, timeout=3 if local_proxy else 20)
        if ready:
            xbmc.log(f"[Timeshift] capture ready on attempt {attempt}", xbmc.LOGINFO)
            return True, output_path

        xbmc.log(f"[Timeshift] capture not ready on attempt {attempt}", xbmc.LOGERROR)

        _start_capture_process_only()

        # legacy czyści po porażce
        try:
            if os.path.exists(output_path):
                os.remove(output_path)
        except Exception:
            pass

        try:
            part_path = output_path + '.part'
            if os.path.exists(part_path):
                os.remove(part_path)
        except Exception:
            pass

        xbmc.sleep(500)

    return False, 'Nie udało się uruchomić bufora timeshift po kilku szybkich próbach'

# ---------------------------------------------------------
# PLAYBACK / MANUAL REFRESH ON PAUSE->PLAY
# ---------------------------------------------------------


def _play_timeshift_file(
    file_path,
    title='Timeshift',
    seek_time=None,
    wait_timeout=4.0,
    seek_tolerance=0.7,
    seek_retries=2
):
    li = xbmcgui.ListItem(label=title)
    li.setPath(file_path)
    _configure_timeshift_playback_item(li, file_path)

    try:
        xbmc.Player().play(file_path, li)
    except Exception as e:
        xbmc.log(f"[Timeshift] play error: {e}", xbmc.LOGERROR)
        try:
            safe_path = file_path.replace('\\', '\\\\').replace('"', '\\"')
            xbmc.executebuiltin(f'PlayMedia("{safe_path}")')
        except Exception:
            return False

    player = _safe_get_player()
    if not _wait_for_playback_start(player, timeout=wait_timeout):
        return False

    # SEEK robimy TYLKO, gdy mamy target_time (czyli pauza->play / refresh)
    if seek_time is not None:
        try:
            target = max(0.0, float(seek_time or 0.0))
        except Exception:
            target = 0.0

        delay_s = float(_REFRESH_SEEK_DELAY or 0.15)
        xbmc.sleep(int(delay_s * 1000))

        tol = float(seek_tolerance or 0.7)

        for r in range(int(seek_retries or 1)):
            try:
                p = _safe_get_player()
                if p and p.isPlaying():
                    p.seekTime(target)
            except Exception:
                pass

            xbmc.sleep(180)

            try:
                p = _safe_get_player()
                cur = float(p.getTime() or 0.0) if p else 0.0
            except Exception:
                cur = 0.0

            xbmc.log(
                f"[Timeshift] seek retry {r+1}: cur={cur:.2f}s target={target:.2f}s",
                xbmc.LOGINFO
            )

            if abs(cur - target) <= tol:
                break

    return True


def _restart_timeshift_playback(target_time=None):
    try:
        state = _load_state()
        file_path = state.get('file', '')
        if not file_path or not os.path.exists(file_path):
            return False

        title = state.get('title', 'Timeshift')

        li = xbmcgui.ListItem(label=title)
        li.setPath(file_path)
        li.setProperty('IsPlayable', 'true')
        li.setContentLookup(False)
        li.setMimeType('video/mp2t')
        _configure_timeshift_playback_item(li, file_path)

        player = _safe_get_player()

        # start TS (bez czekania 400ms)
        try:
            if player:
                player.play(file_path, li)
            else:
                xbmc.Player().play(file_path, li)
        except Exception as e:
            xbmc.log(f"[Timeshift] restart play error: {e}", xbmc.LOGERROR)
            try:
                safe_path = file_path.replace('\\', '\\\\').replace('"', '\\"')
                xbmc.executebuiltin(f'PlayMedia("{safe_path}")')
            except Exception:
                return False

        # jeśli to pause->play: po prostu szybko poczekaj aż Kodi rzeczywiście gra
        if target_time is not None:
            _wait_for_playback_start(_safe_get_player(), timeout=1.2, poll_ms=100)

            try:
                target = max(0.0, float(target_time or 0.0))
            except Exception:
                target = 0.0

            tol = float(_SEEK_TOLERANCE_SECONDS or 0.7)

            # krótki seek-retry, ale bez długich timerów
            for _ in range(int(_SEEK_RETRIES or 2)):
                p = _safe_get_player()
                if p and p.isPlaying():
                    try:
                        p.seekTime(target)
                    except Exception:
                        pass

                    xbmc.sleep(120)

                    try:
                        cur = float(p.getTime() or 0.0)
                        if abs(cur - target) <= tol:
                            break
                    except Exception:
                        pass

        return True

    except Exception as e:
        xbmc.log(f"[Timeshift] _restart_timeshift_playback error: {e}", xbmc.LOGERROR)
        return False


class TimeshiftPausePlayMonitor(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.was_paused = False
        self.pause_pos = 0.0
        self.last_refresh_ts = 0.0

    def onPlayBackPaused(self):
        try:
            # jeśli timeshift aktywny, traktuj to jako pauzę timeshiftu
            st = _load_state()
            if not st.get('active', False):
                return

            self.was_paused = True
            self.pause_pos = float(self.getTime() or 0.0)
            xbmc.log(f"[Timeshift] paused at {self.pause_pos:.2f}s", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Timeshift] onPlayBackPaused error: {e}", xbmc.LOGERROR)

    def onPlayBackResumed(self):
        try:
            if not self.was_paused:
                return

            self.was_paused = False

            now = time.time()
            if now - self.last_refresh_ts < _WATCHDOG_COOLDOWN_SECONDS:
                return

            self.last_refresh_ts = now
            pos = self.pause_pos

            xbmc.log(f"[Timeshift] resumed -> refresh at {pos:.2f}s", xbmc.LOGINFO)

            threading.Thread(
                target=_timeshift_restart_after_pause,
                args=(pos,),
                daemon=True
            ).start()
        except Exception as e:
            xbmc.log(f"[Timeshift] onPlayBackResumed error: {e}", xbmc.LOGERROR)

    def onPlayBackStopped(self):
        self.was_paused = False

    def onPlayBackEnded(self):
        self.was_paused = False


def _timeshift_restart_after_pause(target_time):
    if not _timeshift_refresh_lock.acquire(False):
        return

    try:
        state = _load_state()
        if not state.get('active', False):
            return

        _restart_timeshift_playback(target_time=target_time)

    except Exception as e:
        xbmc.log(f"[Timeshift] _timeshift_restart_after_pause error: {e}", xbmc.LOGERROR)

    finally:
        try:
            _timeshift_refresh_lock.release()
        except Exception:
            pass


def _ensure_pause_play_monitor():
    global _timeshift_player_monitor
    try:
        if _timeshift_player_monitor is None:
            _timeshift_player_monitor = TimeshiftPausePlayMonitor()
    except Exception as e:
        xbmc.log(f"[Timeshift] _ensure_pause_play_monitor error: {e}", xbmc.LOGERROR)


def _start_pause_play_watchdog():
    _ensure_pause_play_monitor()


def _start_seek_watchdog():
    # kompatybilność ze starymi wywołaniami z main.py
    _ensure_pause_play_monitor()


# ---------------------------------------------------------
# PUBLIC PLAYBACK API
# ---------------------------------------------------------

def play_timeshift():
    state = _load_state()
    if not state.get('active'):
        xbmcgui.Dialog().ok(common.addonname, 'Timeshift nie jest aktywny')
        return

    file_path = state.get('file', '')
    if not file_path:
        xbmcgui.Dialog().ok(common.addonname, 'Brak pliku bufora timeshift')
        return

    title = state.get('title', 'Timeshift')
    cmd = state.get('cmd', '')

    # Klucz: dla ACE nie odpalaj gdy plik jest jeszcze "prawie pusty"
    if _is_ace_cmd(cmd):
        ready = _wait_until_buffer_ready(file_path, timeout=10.0, min_bytes=128 * 1024)
    else:
        ready = _wait_until_buffer_ready(file_path, timeout=2.0, min_bytes=0)

    if not ready:
        xbmcgui.Dialog().ok(common.addonname, 'Bufor timeshift nie jest jeszcze gotowy')
        return

    xbmc.log(f"[Timeshift] play direct ts: {file_path}", xbmc.LOGINFO)

    # ważne: monitor musi istnieć przed startem playbacku
    _ensure_pause_play_monitor()

    if _is_ace_cmd(cmd):
        if not _ace_smart_start_play(file_path, title, max_tries=3):
            xbmcgui.Dialog().notification(
                common.addonname,
                'Nie udało się uruchomić timeshift (ACE)',
                xbmcgui.NOTIFICATION_ERROR,
                3500
            )
            return
    else:
        if not _play_timeshift_file(file_path, title=title):
            xbmcgui.Dialog().notification(
                common.addonname,
                'Nie udało się uruchomić timeshift',
                xbmcgui.NOTIFICATION_ERROR,
                3500
            )
            return

    _hide_timeshift_busy()

    try:
        state = _load_state()
        state['seek_monitor_enabled'] = False
        state['last_refresh_ts'] = 0.0
        state['last_pause_position'] = 0.0
        _save_state(state)
    except Exception:
        pass

    overlay = xbmcgui.DialogProgressBG()
    try:
        overlay.create(common.addonname, 'Timeshift aktywny')
        overlay.update(0, 'Uruchamianie timeshift...', ' ')
    except Exception:
        overlay = None

    monitor = xbmc.Monitor()
    last_limit_check_ts = 0.0
    limit_stopped = False

    # co ile sprawdzać limit (w sek)
    LIMIT_CHECK_INTERVAL_SECONDS = 20.0

    while not monitor.abortRequested():
        try:
            player = _safe_get_player()
            if not player or not player.isPlaying():
                break

            now_ts = time.time()

            # prosta kontrola limitu folderu timeshift (bez automatu usuwania w locie)
            if (not limit_stopped) and ((now_ts - float(last_limit_check_ts or 0.0)) >= LIMIT_CHECK_INTERVAL_SECONDS):
                last_limit_check_ts = now_ts
                if _stop_capture_if_timeshift_limit_exceeded():
                    limit_stopped = True

            current_time, total_time = 0.0, 0.0
            try:
                current_time, total_time = _get_playback_times(player)
            except Exception:
                pass

            paused = False
            try:
                paused = bool(player.isPaused())
            except Exception:
                paused = False

            if overlay:
                try:
                    started = int(state.get('started', 0) or 0)
                    elapsed = max(0, int(now_ts - started)) if started else 0

                    file_size_mb = 0.0
                    try:
                        if os.path.exists(file_path):
                            file_size_mb = os.path.getsize(file_path) / (1024.0 * 1024.0)
                    except Exception:
                        pass

                    overlay.update(
                        100,
                        'Timeshift aktywny',
                        f'Kanał: {state.get("title", "Timeshift")}',
                        f'Teraz: {time.strftime("%H:%M:%S", time.localtime(now_ts))}   '
                        f'Start: {time.strftime("%H:%M:%S", time.localtime(started)) if started else "--:--:--"}',
                        f'Bufor: {_format_duration(elapsed)}   '
                        f'Plik: {file_size_mb:.1f} MB   '
                        f'Kodi: {_format_duration(current_time)} / {_format_duration(total_time)}   '
                        f'{"PAUZA" if paused else ""}'
                    )
                except Exception:
                    pass

        except Exception:
            break

        xbmc.sleep(1000)

    try:
        if overlay:
            overlay.close()
    except Exception:
        pass

    try:
        stop_timeshift_buffer(remove_files=True)
    except Exception as e:
        xbmc.log(f"[Timeshift] cleanup after playback error: {e}", xbmc.LOGERROR)








def refresh_timeshift_to_live_edge(offset_seconds=0.0):
    # manual helper; nie używany automatycznie
    try:
        player = _safe_get_player()
        if not player or not player.isPlaying():
            return False

        try:
            total_time = float(player.getTotalTime())
        except Exception:
            total_time = 0.0

        if total_time <= 0:
            return False

        target_time = max(0.0, total_time - float(offset_seconds or 0.0) - 5.0)
        return _restart_timeshift_playback(target_time=target_time)
    except Exception as e:
        xbmc.log(f"[Timeshift] refresh_timeshift_to_live_edge error: {e}", xbmc.LOGERROR)
        return False


# ---------------------------------------------------------
# STOP / CLEANUP
# ---------------------------------------------------------

def stop_timeshift_on_play():
    try:
        player = _safe_get_player()
        if not player or not player.isPlaying():
            return False

        try:
            current_file = player.getPlayingFile()
        except Exception:
            current_file = ''

        if not current_file:
            return False

        current_file_l = str(current_file).replace('\\', '/').lower()

        state = _load_state()
        ts_file = state.get('file', '')

        if ts_file:
            ts_file_l = str(ts_file).replace('\\', '/').lower()
            if ts_file_l in current_file_l:
                stop_timeshift_buffer(remove_files=True)
                return True

        return False

    except Exception as e:
        xbmc.log(f"[Timeshift] stop_timeshift_on_play error: {e}", xbmc.LOGERROR)
        return False


def _remove_timeshift_related_files(base_path):
    try:
        if not base_path:
            return

        base_dir = os.path.dirname(base_path)
        base_name = os.path.splitext(os.path.basename(base_path))[0]

        _safe_remove_file(base_path, retries=10, delay_ms=200)
        _safe_remove_file(base_path + '.part', retries=10, delay_ms=200)

        if os.path.isdir(base_dir):
            for p in os.listdir(base_dir):
                if base_name in p and (p.endswith('.ts') or p.endswith('.part')):
                    _safe_remove_file(os.path.join(base_dir, p), retries=10, delay_ms=200)

    except Exception as e:
        xbmc.log(f"[Timeshift] _remove_timeshift_related_files error: {e}", xbmc.LOGERROR)


def stop_timeshift_buffer(remove_files=True):
    global _timeshift_player_monitor
    _timeshift_player_monitor = None

    state = _load_state()

    pid = int(state.get('pid', 0) or 0)
    backend = state.get('backend', '')
    file_path = state.get('file', '')

    try:
        if backend == 'ffmpeg' and pid:
            try:
                os.kill(pid, signal.SIGTERM)
            except Exception:
                pass

            xbmc.sleep(1000)

            try:
                os.kill(pid, 0)
                os.kill(pid, signal.SIGKILL)
            except Exception:
                pass
    except Exception:
        pass

    if remove_files:
        _safe_remove_file(file_path, retries=12, delay_ms=300)
        _safe_remove_file(file_path + '.part' if file_path else '', retries=12, delay_ms=300)

        try:
            _remove_timeshift_related_files(file_path)
        except Exception:
            pass

    state = _load_state()
    state['active'] = False
    state['pid'] = 0
    state['backend'] = ''
    state['mode'] = ''
    state['title'] = ''
    state['cmd'] = ''
    state['portal'] = {}
    state['file'] = '' if remove_files else file_path
    state['session_id'] = ''
    state['started'] = 0
    state['timeshift_start_ts'] = 0
    state['epg_start_ts'] = 0
    state['epg_stop_ts'] = 0
    state['program'] = ''
    state['seek_monitor_enabled'] = False
    state['last_observed_time'] = 0.0
    state['last_refresh_ts'] = 0.0
    state['last_pause_position'] = 0.0
    state['refresh_in_progress'] = False
    state['technical_stop_in_progress'] = False
    _save_state(state)

    xbmc.sleep(200)

    if remove_files:
        cleanup_timeshift_dir_by_limit()


# ---------------------------------------------------------
# WRAPPERS / ROUTES
# ---------------------------------------------------------

def toggle_timeshift():
    state = _load_state()
    enabled = bool(state.get('enabled', False))

    if enabled:
        # zatrzymaj i usuń aktywny bufor
        stop_timeshift_buffer(remove_files=True)

        # dodatkowo: wyczyść cały folder timeshift (żeby nie zostały stare ts/snapshot)
        purge_timeshift_dir()

        state = _load_state()
        state['enabled'] = False
        _save_state(state)

        xbmcgui.Dialog().notification(common.addonname, 'Timeshift wyłączony', xbmcgui.NOTIFICATION_INFO)

    else:
        state['enabled'] = True
        state['active'] = False
        state['pid'] = 0
        state['backend'] = ''
        state['mode'] = ''
        state['title'] = ''
        state['cmd'] = ''
        state['portal'] = {}
        state['file'] = ''
        state['session_id'] = ''
        state['started'] = 0
        state['seek_monitor_enabled'] = False
        state['last_observed_time'] = 0.0
        state['last_refresh_ts'] = 0.0
        state['last_pause_position'] = 0.0
        state['refresh_in_progress'] = False
        state['technical_stop_in_progress'] = False
        state['epg_start_ts'] = 0
        state['epg_stop_ts'] = 0
        state['timeshift_start_ts'] = 0
        state['program'] = ''
        _save_state(state)

        xbmcgui.Dialog().notification(common.addonname, 'Timeshift włączony', xbmcgui.NOTIFICATION_INFO)

    xbmc.executebuiltin('Container.Refresh')

def is_timeshift_enabled():
    state = _load_state()
    return bool(state.get('enabled', False))

def ToggleTimeshift():
    toggle_timeshift()
    enabled = common.addon.getSetting('toggle_on_timeshift') == 'true'
    common.addon.setSetting('toggle_timeshift', 'false' if enabled else 'true')
    xbmc.executebuiltin('Container.Refresh')


def RefreshTimeshiftPlayback():
    try:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        ok = refresh_timeshift_playback()
        if not ok:
            xbmcgui.Dialog().notification(
                common.addonname,
                'Nie udało się odświeżyć timeshift',
                xbmcgui.NOTIFICATION_INFO,
                2500
            )
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmc.executebuiltin('Dialog.Close(busydialog)')


def RefreshTimeshiftToLiveEdge():
    try:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        ok = refresh_timeshift_to_live_edge(offset_seconds=5.0)
        if not ok:
            xbmcgui.Dialog().notification(
                common.addonname,
                'Nie udało się odświeżyć do końca timeshift',
                xbmcgui.NOTIFICATION_INFO,
                2500
            )
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmc.executebuiltin('Dialog.Close(busydialog)')





def StopTimeshiftOnPlay():
    return stop_timeshift_on_play()


def start_timeshift_buffer(portal):
    if not is_timeshift_enabled():
        return False

    cleanup_timeshift_dir_by_limit()

    if is_timeshift_active():
        stop_timeshift_buffer(remove_files=True)
        xbmc.sleep(1000)

    title = common.args.get('title', ['Kanał TV'])[0]
    cmd = common.args.get('cmd', [''])[0]

    if not cmd:
        xbmcgui.Dialog().ok(common.addonname, 'Brak komendy kanału')
        return False

    ok, info = _start_timeshift_capture_with_retry(portal, title, cmd, retries=5)
    if not ok:
        xbmcgui.Dialog().ok(common.addonname, info)
        return False

    cleanup_timeshift_dir_by_limit()
    return True


def play_channel_with_timeshift(portal):
    if not is_timeshift_enabled():
        return False

    _show_timeshift_busy()
    try:
        started = start_timeshift_buffer(portal)
        if not started:
            return False

        play_timeshift()
        return True
    finally:
        _hide_timeshift_busy()


def play_timeshift_snapshot_copy_legacy():
    return play_timeshift()

