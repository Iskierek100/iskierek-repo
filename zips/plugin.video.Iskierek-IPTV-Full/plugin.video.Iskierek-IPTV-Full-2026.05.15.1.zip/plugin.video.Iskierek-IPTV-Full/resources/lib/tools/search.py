# -*- coding: utf-8 -*-
import json, os, re, xbmc, xbmcgui, xbmcplugin
from resources.lib import common, config
from resources.lib.providers import provider_api
from resources.lib.navigation import is_adult_visible


def _portal_label(portal):
    ptype = portal.get('type', 'iptv').upper()
    name = portal.get('name', 'Dostawca')
    return f'[{ptype}] {name}'


def _normalize_text(text):
    text = str(text or '').lower()
    repl = {
        'ą': 'a', 'ć': 'c', 'ę': 'e', 'ł': 'l', 'ń': 'n',
        'ó': 'o', 'ś': 's', 'ź': 'z', 'ż': 'z'
    }
    for a, b in repl.items():
        text = text.replace(a, b)
    text = re.sub(r'[^a-z0-9]+', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def _matches(text, query):
    raw_text = str(text or '').lower()
    raw_query = str(query or '').lower().strip()

    if not raw_query:
        return False

    if raw_query in raw_text:
        return True

    norm_text = _normalize_text(text)
    norm_query = _normalize_text(query)

    if norm_query and norm_query in norm_text:
        return True

    q_words = [w for w in norm_query.split() if len(w) >= 2]
    if q_words and all(w in norm_text for w in q_words):
        return True

    return False


def _score_match(name, plot, genre, query):
    raw_name = str(name or '').lower()
    raw_plot = str(plot or '').lower()
    raw_genre = str(genre or '').lower()
    raw_query = str(query or '').lower().strip()

    norm_name = _normalize_text(name)
    norm_plot = _normalize_text(plot)
    norm_genre = _normalize_text(genre)
    norm_query = _normalize_text(query)
    q_words = [w for w in norm_query.split() if len(w) >= 2]

    score = 0

    if raw_query and raw_name == raw_query:
        score += 1000
    if norm_query and norm_name == norm_query:
        score += 900

    if raw_query and raw_query in raw_name:
        score += 700
    if norm_query and norm_query in norm_name:
        score += 600

    if q_words and all(w in norm_name for w in q_words):
        score += 500

    if raw_query and raw_query in raw_genre:
        score += 150
    if norm_query and norm_query in norm_genre:
        score += 120

    if raw_query and raw_query in raw_plot:
        score += 80
    if norm_query and norm_query in norm_plot:
        score += 60

    return score


def _safe_logo(portal, logo):
    if not logo:
        return 'DefaultVideo.png'
    if str(logo).startswith('http'):
        return logo
    if portal.get('type') == 'stalker':
        base = portal['url'].split('/c/')[0] if '/c/' in portal['url'] else portal['url'].rstrip('/')
        return f"{base}/stalker_portal/misc/logos/320/{logo}"
    return logo


def _get_selected_ids(portal, gtype):
    saved_data = common.read_json_safe(common.selected_groups_file)
    portal_key = common.get_portal_key(portal)
    mac_data = saved_data.get(portal_key, {})

    if isinstance(mac_data, list):
        if gtype == 'tv':
            return mac_data
        return []

    return mac_data.get(gtype, [])


def _stalker_cache_base(url):
    return "_".join(re.findall("[a-zA-Z0-9]+", url))


def _xtream_cache_base(url):
    return re.sub(r'[^a-zA-Z0-9]', '', url)


def _load_vod_from_cache_or_provider(portal, cat):
    provider = provider_api.get_provider(portal)

    try:
        if portal.get('type') == 'xtream':
            safe_host = _xtream_cache_base(portal.get('url', ''))
            cache_file = os.path.join(common.cachedir, f"xtream_{safe_host}_vod_{cat}.json")
            data = common.read_json_safe(cache_file)
            if data and data.get('vod' + str(cat)) is not None:
                return data.get('vod' + str(cat), [])
            data = provider.getVoD(portal, cat)
            return data.get('vod' + str(cat), [])

        if portal.get('type') == 'stalker':
            cache_file = os.path.join(common.cachedir, _stalker_cache_base(portal['url']) + '-vod' + str(cat))
            data = common.read_json_safe(cache_file)
            if data and data.get('vod' + str(cat)) is not None:
                return data.get('vod' + str(cat), [])
            old_cat = common.args.get('cat', [''])
            try:
                common.args['cat'] = [str(cat)]
                data = provider.getVoD(portal['mac'], portal['url'], portal['serial'], common.addondir)
                return data.get('vod' + str(cat), [])
            finally:
                common.args['cat'] = old_cat
    except:
        pass

    return []


def _load_series_from_cache_or_provider(portal, cat):
    provider = provider_api.get_provider(portal)

    try:
        if portal.get('type') == 'xtream':
            safe_host = _xtream_cache_base(portal.get('url', ''))
            cache_file = os.path.join(common.cachedir, f"xtream_{safe_host}_ser_{cat}.json")
            data = common.read_json_safe(cache_file)
            if data and data.get('ser' + str(cat)) is not None:
                return data.get('ser' + str(cat), [])
            data = provider.getSeries(portal, cat)
            return data.get('ser' + str(cat), [])

        if portal.get('type') == 'stalker':
            cache_file = os.path.join(common.cachedir, _stalker_cache_base(portal['url']) + '-ser' + str(cat))
            data = common.read_json_safe(cache_file)
            if data and data.get('ser' + str(cat)) is not None:
                return data.get('ser' + str(cat), [])
            old_cat = common.args.get('cat', [''])
            try:
                common.args['cat'] = [str(cat)]
                data = provider.getSeries(portal['mac'], portal['url'], portal['serial'], common.addondir)
                return data.get('ser' + str(cat), [])
            finally:
                common.args['cat'] = old_cat
    except:
        pass

    return []


def _get_vod_genres_map(portal):
    provider = provider_api.get_provider(portal)
    try:
        if portal.get('type') == 'xtream':
            data = provider.getVoDgenres(portal, common.addondir)
        elif portal.get('type') == 'stalker':
            data = provider.getVoDgenres(portal['mac'], portal['url'], portal['serial'], common.addondir)
        else:
            return {}
        return data.get('vodgenres', {})
    except:
        return {}


def _get_series_genres_map(portal):
    provider = provider_api.get_provider(portal)
    try:
        if portal.get('type') == 'xtream':
            data = provider.getSergenres(portal, common.addondir)
        elif portal.get('type') == 'stalker':
            data = provider.getSergenres(portal['mac'], portal['url'], portal['serial'], common.addondir)
        else:
            return {}
        return data.get('sergenres', {})
    except:
        return {}


def _is_adult_text(text, provider):
    title = str(text or '').lower()
    return any(w in title for w in getattr(provider, 'ADULT_KEYWORDS', []))


def _load_search_history():
    data = common.read_json_safe(common.search_history_file)
    if isinstance(data, list):
        return data
    return []


def _save_search_history(items):
    common.write_json_safe(common.search_history_file, items[:20])


def _add_to_search_history(query):
    query = str(query or '').strip()
    if not query:
        return
    history = _load_search_history()
    history = [x for x in history if str(x).strip().lower() != query.lower()]
    history.insert(0, query)
    _save_search_history(history)


def _clear_search_history():
    common.write_json_safe(common.search_history_file, [])


def _search_vod_in_portal(portal, query):
    results = []
    selected_ids = _get_selected_ids(portal, 'vod')
    if not selected_ids:
        return results

    genres = _get_vod_genres_map(portal)
    provider = provider_api.get_provider(portal)

    for gid in selected_ids:
        genre_item = genres.get(gid, {})
        cat = genre_item.get('cat', gid)
        genre_title = genre_item.get('title', str(gid))

        if _is_adult_text(genre_title, provider) and not is_adult_visible(portal):
            continue

        vod_list = _load_vod_from_cache_or_provider(portal, cat)

        for i in vod_list:
            name = i.get('name', '')
            plot = i.get('plot', '')
            genre = i.get('genre', '')

            if (_is_adult_text(name, provider) or _is_adult_text(plot, provider) or _is_adult_text(genre, provider)) and not is_adult_visible(portal):
                continue

            score = _score_match(name, plot, genre, query)
            if score > 0:
                logo_url = _safe_logo(portal, i.get('logo', ''))
                ext = i.get('extension', 'mp4')
                url = common.build_url({
                    'mode': 'play_vod',
                    'cmd': i.get('cmd', ''),
                    'title': name,
                    'logo_url': logo_url,
                    'portal': json.dumps(portal),
                    'ext': ext
                })
                results.append({
                    'label': f'[FILM] {name}',
                    'plot': f'{_portal_label(portal)}  |  {genre_title}',
                    'url': url,
                    'logo': logo_url,
                    'folder': False,
                    'score': score
                })

    return results


def _search_series_in_portal(portal, query):
    results = []
    selected_ids = _get_selected_ids(portal, 'ser')
    if not selected_ids:
        return results

    genres = _get_series_genres_map(portal)
    provider = provider_api.get_provider(portal)

    for gid in selected_ids:
        genre_item = genres.get(gid, {})
        cat = genre_item.get('cat', gid)
        genre_title = genre_item.get('title', str(gid))

        if _is_adult_text(genre_title, provider) and not is_adult_visible(portal):
            continue

        ser_list = _load_series_from_cache_or_provider(portal, cat)

        for i in ser_list:
            name = i.get('name', '')
            plot = i.get('plot', '')
            genre = i.get('genre', '')

            if (_is_adult_text(name, provider) or _is_adult_text(plot, provider) or _is_adult_text(genre, provider)) and not is_adult_visible(portal):
                continue

            score = _score_match(name, plot, genre, query)
            if score > 0:
                logo_url = _safe_logo(portal, i.get('logo', ''))

                if portal.get('type') == 'xtream':
                    # dla xtream musimy przekazać ID serialu, a nie ID kategorii
                    series_id = str(
                        i.get('cmd')
                        or i.get('id')
                        or i.get('series_id')
                        or i.get('cat')
                        or ''
                    )

                    if not series_id:
                        continue

                    url = common.build_url({
                        'mode': 'season',
                        'cat': series_id,
                        'cmd': series_id,
                        'name': name,
                        'genre_name': genre_title,
                        'logo_url': logo_url,
                        'portal': json.dumps(portal)
                    })
                else:
                    url = common.build_url({
                        'mode': 'season',
                        'cat': i.get('cat', ''),
                        'name': name,
                        'cmd': i.get('cmd') or i.get('cat', ''),
                        'category': i.get('category') or i.get('cat', ''),
                        'genre_name': genre_title,
                        'logo_url': logo_url,
                        'portal': json.dumps(portal)
                    })

                results.append({
                    'label': f'[SERIAL] {name}',
                    'plot': f'{_portal_label(portal)}  |  {genre_title}',
                    'url': url,
                    'logo': logo_url,
                    'folder': True,
                    'score': score
                })

    return results
    

def GlobalSearchMenu():
    history = _load_search_history()
    options = ['Nowe wyszukiwanie', 'Wyczyść historię']
    options.extend(history)

    choice = xbmcgui.Dialog().select('Szukaj globalnie', options)
    if choice < 0:
        return

    if choice == 1:
        confirm = xbmcgui.Dialog().yesno(common.addonname, 'Czy wyczyścić historię wyszukiwania?')
        if confirm:
            _clear_search_history()
            xbmcgui.Dialog().notification(common.addonname, 'Historia wyczyszczona', xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin(f'Container.Update({common.build_url({"mode":"global_search"})})')
        return

    if choice == 0:
        kb = xbmc.Keyboard('', 'Szukaj globalnie')
        kb.doModal()
        if not kb.isConfirmed():
            xbmc.executebuiltin('Action(Back)')
            return
        query = kb.getText().strip()
    else:
        query = options[choice].strip()

    if not query:
        xbmc.executebuiltin('Action(Back)')
        return

    _add_to_search_history(query)
    xbmc.executebuiltin(f'Container.Update({common.build_url({"mode":"global_search_results","query":query})})')


def GlobalSearchResults():
    query = common.args.get('query', [''])[0].strip().lower()
    if not query:
        li = xbmcgui.ListItem('[COLOR grey]Brak frazy wyszukiwania[/COLOR]')
        xbmcplugin.addDirectoryItem(handle=common.addon_handle, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)
        return

    dp = xbmcgui.DialogProgressBG()
    dp.create(common.addonname, f'Szukanie: {query}')

    xbmcplugin.setContent(common.addon_handle, 'videos')
    xbmcplugin.setPluginCategory(common.addon_handle, f'Szukaj: {query}')

    portals = config.get_all_portals()
    all_results = []
    total = len(portals) if portals else 1

    for idx, portal in enumerate(portals):
        try:
            percent = int(((idx + 1) / float(total)) * 100)
            dp.update(percent, f"Przeszukiwanie: {portal.get('name', 'Dostawca')}")
            if portal.get('type') != 'm3u':
                all_results.extend(_search_vod_in_portal(portal, query))
                all_results.extend(_search_series_in_portal(portal, query))
        except:
            continue

    dp.close()

    if not all_results:
        li = xbmcgui.ListItem('[COLOR grey]Brak wyników[/COLOR]')
        xbmcplugin.addDirectoryItem(handle=common.addon_handle, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)
        return

    all_results.sort(key=lambda x: (-x.get('score', 0), x['label'].lower()))

    for item in all_results:
        li = xbmcgui.ListItem(item['label'])
        li.setInfo('video', {'title': item['label'], 'plot': item['plot']})
        li.setArt({'icon': item['logo'], 'thumb': item['logo'], 'fanart': common.fanart})

        if not item['folder']:
            li.setProperty('IsPlayable', 'true')

        xbmcplugin.addDirectoryItem(
            handle=common.addon_handle,
            url=item['url'],
            listitem=li,
            isFolder=item['folder']
        )

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)
