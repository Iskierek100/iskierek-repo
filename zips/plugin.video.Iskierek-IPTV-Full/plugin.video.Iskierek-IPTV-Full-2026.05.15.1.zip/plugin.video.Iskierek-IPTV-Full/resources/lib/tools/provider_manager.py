# -*- coding: utf-8 -*-
import xbmc,xbmcplugin,xbmcgui,json
from resources.lib import common

def ProvidersManagerLevel():
    xbmcplugin.setContent(common.addon_handle, 'files')



    #url_dummy = common.build_url({'mode': 'refresh_list'})
    #li_sep = xbmcgui.ListItem('')
    #li_sep.setArt({'fanart': common.fanart})
    #xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_dummy, listitem=li_sep, isFolder=False)

    providers = common.read_providers()
    if not providers:
        li = xbmcgui.ListItem('Brak zapisanych dostawców')
        li.setArt({'icon': common.icon17, 'fanart': common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle, url='', listitem=li, isFolder=False)
    else:
        for p in providers:
            ptype = p.get('type', 'unknown').upper()
            name = p.get('name', 'Bez nazwy')
            label = f'[{ptype}] {name}'
            url = common.build_url({'mode': 'provider_edit_menu', 'provider_id': p.get('id', '')})

            state_icon = common.icon25 if p.get('enabled', True) else common.icon26

            li = xbmcgui.ListItem(label)
            li.setArt({'icon': state_icon, 'thumb': state_icon, 'fanart': common.fanart})

            context_items = [
                ('[COLOR yellow]Info o koncie[/COLOR]', f'ActivateWindow(Videos,{common.build_url({"mode":"account_info","portal":json.dumps(p)})},return)'),
                ('[COLOR yellow]Włącz/Wyłącz[/COLOR]', f'RunPlugin({common.build_url({"mode":"provider_toggle_enabled","provider_id":p.get("id","")})})'),
                ('[COLOR yellow]Edytuj dostawcę[/COLOR]', f'ActivateWindow(Videos,{common.build_url({"mode":"provider_edit_menu","provider_id":p.get("id","")})},return)'),
                ('[COLOR red]Usuń dostawcę[/COLOR]', f'RunPlugin({common.build_url({"mode":"provider_delete","provider_id":p.get("id","")})})')
            ]
            li.addContextMenuItems(context_items)

            xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url, listitem=li, isFolder=True)

    export_url = common.build_url({'mode': 'providers_export'})
    li_export = xbmcgui.ListItem('Zapisz dostawców')
    li_export.setArt({'icon': common.icon22, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=export_url, listitem=li_export, isFolder=False)

    import_url = common.build_url({'mode': 'providers_import'})
    li_import = xbmcgui.ListItem('Wczytaj dostawców')
    li_import.setArt({'icon': common.icon21, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=import_url, listitem=li_import, isFolder=False)

    parental_url = common.build_url({'mode': 'parental_manager'})
    li_parental = xbmcgui.ListItem('Kontrola rodzicielska')
    li_parental.setArt({'icon': common.icon18, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=parental_url, listitem=li_parental, isFolder=True)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=False)


def _save_provider(updated_provider):
    providers=common.read_providers()
    new_list=[]
    for p in providers:
        new_list.append(updated_provider if p.get('id')==updated_provider.get('id') else p)
    common.write_providers(new_list)

def AddProvider():
    providers=common.read_providers()
    ptype_idx=xbmcgui.Dialog().select('Wybierz typ dostawcy',['Stalker','Xtream','M3U'])
    if ptype_idx<0: return
    ptype='stalker' if ptype_idx==0 else 'xtream' if ptype_idx==1 else 'm3u'

    kb=xbmc.Keyboard('','Nazwa dostawcy lub listy')
    kb.doModal()
    if not kb.isConfirmed(): return
    name=kb.getText().strip()
    if not name: return

    provider={
        'id':common.generate_provider_id(),
        'enabled':True,
        'type':ptype,
        'name':name,
        'use_f4m':False
    }

    if ptype=='stalker':
        kb=xbmc.Keyboard('','Adres URL')
        kb.doModal()
        if not kb.isConfirmed(): return
        provider['url']=kb.getText().strip()

        kb=xbmc.Keyboard('','Adres MAC')
        kb.doModal()
        if not kb.isConfirmed(): return
        provider['mac']=kb.getText().strip()
        provider['serial']=None

        send_serial=xbmcgui.Dialog().yesno('Serial','Czy wysyłać Serial Number?')
        if send_serial:
            custom_serial=xbmcgui.Dialog().yesno('Custom Serial','Czy użyć własnego seriala?')
            if custom_serial:
                kb=xbmc.Keyboard('','Serial Number')
                kb.doModal()
                if not kb.isConfirmed(): return
                sn=kb.getText().strip()

                kb=xbmc.Keyboard('','Device ID 1')
                kb.doModal()
                if not kb.isConfirmed(): return
                device_id=kb.getText().strip()

                kb=xbmc.Keyboard('','Device ID 2')
                kb.doModal()
                if not kb.isConfirmed(): return
                device_id2=kb.getText().strip()

                kb=xbmc.Keyboard('','Signature')
                kb.doModal()
                if not kb.isConfirmed(): return
                signature=kb.getText().strip()

                if sn and device_id and device_id2 and signature:
                    provider['serial']={'custom':True,'sn':sn,'device_id':device_id,'device_id2':device_id2,'signature':signature}
            else:
                provider['serial']={'custom':False}

    elif ptype=='xtream':
        kb=xbmc.Keyboard('','Adres URL')
        kb.doModal()
        if not kb.isConfirmed(): return
        provider['url']=kb.getText().strip()

        kb=xbmc.Keyboard('','Username')
        kb.doModal()
        if not kb.isConfirmed(): return
        provider['username']=kb.getText().strip()

        kb=xbmc.Keyboard('','Password')
        kb.setHiddenInput(True)
        kb.doModal()
        if not kb.isConfirmed(): return
        provider['password']=kb.getText()

    else:
        source_idx=xbmcgui.Dialog().select('Źródło listy M3U',['URL','Plik lokalny'])
        if source_idx<0: return
        if source_idx==0:
            provider['source_type']='url'
            kb=xbmc.Keyboard('','Adres URL listy M3U')
            kb.doModal()
            if not kb.isConfirmed(): return
            provider['url']=kb.getText().strip()
        else:
            provider['source_type']='file'
            selected=xbmcgui.Dialog().browseSingle(1,'Wybierz plik M3U','files','.m3u|.m3u8')
            if not selected: return
            provider['file_path']=selected

    providers.append(provider)
    common.write_providers(providers)
    xbmc.executebuiltin('Container.Refresh')

def ProviderEditMenu():
    provider_id = common.args.get('provider_id', [''])[0]
    provider = common.get_provider_by_id(provider_id)
    if not provider:
        return

    xbmcplugin.setContent(common.addon_handle, 'files')

    enabled_icon = common.icon25 if provider.get('enabled', True) else common.icon26
    f4m_icon = common.icon25 if provider.get('use_f4m', False) else common.icon26

    entries = []


    entries.append(('provider_edit_name', 'Zmień nazwę', common.icon34))
    entries.append(('provider_edit_url', 'Zmień URL', common.icon34))

    if provider.get('type') == 'stalker':
        entries.append(('provider_edit_mac', 'Zmień MAC', common.icon34))
        entries.append(('provider_edit_serial', 'Edytuj Serial', common.icon34))
    elif provider.get('type') == 'xtream':
        entries.append(('provider_edit_username', 'Zmień Nazwę Użytkownika', common.icon34))
        entries.append(('provider_edit_password', 'Zmień Hasło', common.icon34))
    else:
        source_label = provider.get('source_type', 'url').upper()
        entries.append(('provider_edit_m3u_source_type', f'Źródło M3U: {source_label}', common.icon34))
        entries.append(('provider_edit_m3u_path', 'Edytuj URL lub plik M3U', common.icon34))

    entries.append(('account_info', 'Info o koncie', common.icon15))
#   xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=account_info, listitem=li_sep, isFolder=False)
    entries.append(('provider_toggle_enabled', 'Włącz lub wyłącz dostwcę', enabled_icon))
    entries.append(('provider_edit_f4m', 'f4mTester', f4m_icon))
    entries.append(('provider_delete', 'Usuń dostawcę', common.icon29))

    for mode_key, label, icon in entries:
        if mode_key == 'account_info':
            url = common.build_url({'mode': 'account_info', 'portal': json.dumps(provider)})
        else:
            url = common.build_url({'mode': mode_key, 'provider_id': provider_id})

        li = xbmcgui.ListItem(label)
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=False)


def ToggleProviderEnabled():
    provider_id = common.args.get('provider_id', [''])[0]
    provider = common.get_provider_by_id(provider_id)
    if not provider: return

    provider['enabled'] = not provider.get('enabled', True)
    _save_provider(provider)

    state = 'włączony' if provider.get('enabled', True) else 'wyłączony'
    xbmcgui.Dialog().notification(
        common.addonname,
        f'Dostawca {state}',
        xbmcgui.NOTIFICATION_INFO
    )
    xbmc.sleep(300)
    # Container.Update wymusza pełne przeładowanie bez cache
    xbmc.executebuiltin('Container.Update(%s,replace)' % common.build_url({'mode': 'providers_manager'}))

def EditProviderName():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    kb=xbmc.Keyboard(provider.get('name',''),'Nazwa dostawcy')
    kb.doModal()
    if kb.isConfirmed():
        provider['name']=kb.getText().strip()
        _save_provider(provider)
        xbmc.executebuiltin('Container.Refresh')

def EditProviderUrl():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    kb=xbmc.Keyboard(provider.get('url',''),'Adres URL')
    kb.doModal()
    if kb.isConfirmed():
        provider['url']=kb.getText().strip()
        _save_provider(provider)
        xbmc.executebuiltin('Container.Refresh')

def EditProviderMac():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    kb=xbmc.Keyboard(provider.get('mac',''),'Adres MAC')
    kb.doModal()
    if kb.isConfirmed():
        provider['mac']=kb.getText().strip()
        _save_provider(provider)
        xbmc.executebuiltin('Container.Refresh')

def EditProviderUsername():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    kb=xbmc.Keyboard(provider.get('username',''),'Username')
    kb.doModal()
    if kb.isConfirmed():
        provider['username']=kb.getText().strip()
        _save_provider(provider)
        xbmc.executebuiltin('Container.Refresh')

def EditProviderPassword():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    kb=xbmc.Keyboard(provider.get('password',''),'Password')
    kb.setHiddenInput(True)
    kb.doModal()
    if kb.isConfirmed():
        provider['password']=kb.getText()
        _save_provider(provider)
        xbmc.executebuiltin('Container.Refresh')

def EditProviderF4M():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    provider['use_f4m']=not provider.get('use_f4m',False)
    _save_provider(provider)

    state='ON' if provider.get('use_f4m',False) else 'OFF'
    xbmcgui.Dialog().notification(common.addonname,f'f4mTester: {state}',xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')

def EditProviderSerial():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    send_serial=xbmcgui.Dialog().yesno('Serial','Czy wysyłać Serial Number?')
    if not send_serial:
        provider['serial']=None
        _save_provider(provider)
        xbmc.executebuiltin('Container.Refresh')
        return

    custom_serial=xbmcgui.Dialog().yesno('Custom Serial','Czy użyć własnego seriala?')
    if not custom_serial:
        provider['serial']={'custom':False}
        _save_provider(provider)
        xbmc.executebuiltin('Container.Refresh')
        return

    kb=xbmc.Keyboard('','Serial Number')
    kb.doModal()
    if not kb.isConfirmed(): return
    sn=kb.getText().strip()

    kb=xbmc.Keyboard('','Device ID 1')
    kb.doModal()
    if not kb.isConfirmed(): return
    device_id=kb.getText().strip()

    kb=xbmc.Keyboard('','Device ID 2')
    kb.doModal()
    if not kb.isConfirmed(): return
    device_id2=kb.getText().strip()

    kb=xbmc.Keyboard('','Signature')
    kb.doModal()
    if not kb.isConfirmed(): return
    signature=kb.getText().strip()

    provider['serial']={'custom':True,'sn':sn,'device_id':device_id,'device_id2':device_id2,'signature':signature}
    _save_provider(provider)
    xbmc.executebuiltin('Container.Refresh')

def EditProviderM3UPath():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    source_type=provider.get('source_type','url')
    if source_type=='file':
        selected=xbmcgui.Dialog().browseSingle(1,'Wybierz plik M3U','files','.m3u|.m3u8')
        if selected:
            provider['file_path']=selected
            _save_provider(provider)
            xbmc.executebuiltin('Container.Refresh')
    else:
        kb=xbmc.Keyboard(provider.get('url',''),'Adres URL listy M3U')
        kb.doModal()
        if kb.isConfirmed():
            provider['url']=kb.getText().strip()
            _save_provider(provider)
            xbmc.executebuiltin('Container.Refresh')

def EditProviderM3USourceType():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    idx=xbmcgui.Dialog().select('Źródło listy M3U',['URL','Plik lokalny'])
    if idx<0: return
    if idx==0:
        provider['source_type']='url'
        provider.pop('file_path',None)
        provider.setdefault('url','')
    else:
        provider['source_type']='plik'
        provider.pop('url',None)
        provider.setdefault('file_path','')

    _save_provider(provider)
    xbmc.executebuiltin('Container.Refresh')

def DeleteProvider():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    confirm=xbmcgui.Dialog().yesno('Usuń dostawcę',f"Czy usunąć: {provider.get('name','Bez nazwy')}?")
    if not confirm: return

    providers=common.read_providers()
    providers=[p for p in providers if p.get('id')!=provider_id]
    common.write_providers(providers)
    xbmc.sleep(300)
    xbmc.executebuiltin('Container.Refresh')

def ParentalManagerLevel():
    from resources.lib import navigation

    xbmcplugin.setContent(common.addon_handle, 'files')

    global_icon = common.icon25 if common.is_parental_enabled() else common.icon26
    pin_icon = common.icon23 if common.has_parental_pin() else common.icon24

    url_toggle = common.build_url({'mode': 'parental_toggle_global'})
    li_toggle = xbmcgui.ListItem('Globalna kontrola rodzicielska')
    li_toggle.setArt({'icon': global_icon, 'thumb': global_icon, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_toggle, listitem=li_toggle, isFolder=False)

    url_pin = common.build_url({'mode': 'parental_change_pin'})
    li_pin = xbmcgui.ListItem('Zmień PIN rodzicielski')
    li_pin.setArt({'icon': pin_icon, 'thumb': pin_icon, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url_pin, listitem=li_pin, isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)

def ToggleGlobalParental():
    from resources.lib import navigation

    if common.is_parental_enabled():
        if not navigation.verify_parental_access():
            return
        common.set_parental_enabled(False)
        xbmcgui.Dialog().notification(common.addonname, 'Kontrola rodzicielska: Wył.', xbmcgui.NOTIFICATION_INFO)
    else:
        if not navigation.ensure_parental_pin():
            return
        common.set_parental_enabled(True)
        xbmcgui.Dialog().notification(common.addonname, 'Kontrola rodzicielska: Wł.', xbmcgui.NOTIFICATION_INFO)

    xbmc.executebuiltin('Container.Refresh')