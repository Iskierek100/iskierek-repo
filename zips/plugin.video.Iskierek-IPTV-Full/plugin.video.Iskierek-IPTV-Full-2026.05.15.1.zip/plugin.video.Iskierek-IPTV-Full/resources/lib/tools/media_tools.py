# -*- coding: utf-8 -*-
import os,xbmc,xbmcgui,xbmcplugin  # noqa: E401
from resources.lib import common

def get_media_dir():
    media_dir=common.addon.getSetting('recordings_dir').strip()
    if media_dir and os.path.exists(media_dir): return media_dir
    return None

def MediaManagerLevel():
    xbmcplugin.setContent(common.addon_handle,'videos')
    media_dir=get_media_dir()
    if not media_dir or not os.path.exists(media_dir):
        li=xbmcgui.ListItem('Brak ustawionego katalogu nagrań i pobrań')
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url='',listitem=li,isFolder=False);xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True);return
    files=[]
    for name in os.listdir(media_dir):
        full=os.path.join(media_dir,name)
        if os.path.isfile(full): files.append((name,full))
    files.sort(key=lambda x:x[0].lower())
    if not files:
        li=xbmcgui.ListItem('Brak plików w katalogu')
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url='',listitem=li,isFolder=False);xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True);return
    for name,full_path in files:
        play_url=common.build_url({'mode':'play_local_file','file_path':full_path})
        li=xbmcgui.ListItem(name);li.setArt({'icon':common.icon0,'thumb':common.icon0,'fanart':common.fanart});li.setProperty('IsPlayable','true')
        delete_params={'mode':'delete_local_file','file_path':full_path}
        li.addContextMenuItems([('[COLOR red]Usuń plik[/COLOR]',f'RunPlugin({common.build_url(delete_params)})')])
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=play_url,listitem=li,isFolder=False)
    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def OpenExportsDir():
    exports_dir = os.path.join(common.addondir, 'exports')

    if not os.path.exists(exports_dir):
        try:
            os.makedirs(exports_dir)
        except:  # noqa: E722
            xbmcgui.Dialog().ok(common.addonname, 'Nie udało się utworzyć folderu eksportów')
            return

    xbmc.executebuiltin(f'ActivateWindow(Videos,{exports_dir},return)')

def PlayLocalFile():
    file_path=common.args.get('file_path',[''])[0]
    if not file_path or not os.path.exists(file_path):
        li=xbmcgui.ListItem('Plik nie istnieje');xbmcplugin.setResolvedUrl(handle=common.addon_handle,succeeded=False,listitem=li);return
    li=xbmcgui.ListItem(os.path.basename(file_path));li.setPath(file_path);li.setProperty('IsPlayable','true')
    xbmcplugin.setResolvedUrl(handle=common.addon_handle,succeeded=True,listitem=li)

def DeleteLocalFile():
    file_path=common.args.get('file_path',[''])[0]
    if not file_path or not os.path.exists(file_path): return
    confirm=xbmcgui.Dialog().yesno(common.addonname,f"Czy usunąć plik?\n{os.path.basename(file_path)}")
    if not confirm: return
    try:
        os.remove(file_path);xbmcgui.Dialog().notification(common.addonname,'Plik usunięty',xbmcgui.NOTIFICATION_INFO)
    except Exception as e:
        xbmcgui.Dialog().notification(common.addonname,f'Błąd usuwania: {e}',xbmcgui.NOTIFICATION_ERROR)
    xbmc.executebuiltin('Container.Refresh')
