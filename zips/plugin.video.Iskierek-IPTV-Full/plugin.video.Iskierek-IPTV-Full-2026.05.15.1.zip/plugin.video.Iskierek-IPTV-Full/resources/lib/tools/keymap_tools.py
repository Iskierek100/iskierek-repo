# -*- coding: utf-8 -*-
import os
import xbmc
import xbmcgui
import xbmcplugin  # noqa: F401
import xbmcvfs
import xbmcaddon

from resources.lib import common

ADDON = xbmcaddon.Addon("plugin.video.Iskierek-IPTV-Full")


def _get_setting(name, default=""):
    try:
        res = ADDON.getSetting(name)
        return res if res != "" else default
    except Exception:
        return default


def _set_setting(name, value):
    try:
        ADDON.setSetting(name, str(value))
    except Exception:
        pass


def _get_keymap_dir():
    return xbmcvfs.translatePath("special://profile/keymaps/")


def _get_keymap_file():
    return os.path.join(_get_keymap_dir(), "iskierek-IPTV-Full.xml")


def install_keymap():
    portal = common.args.get("portal", [None])[0]
    ToolsSettingsLevel(portal)  # noqa: F821


def set_keymap_overlay():
    keys = [
        ("F8", "f8"),
        ("F12", "f12"),
        ("O", "o"),
        ("0", "zero"),
        ("L", "l"),
        ("C", "c"),
        ("X", "x"),
        ("TAB", "tab"),
        ("MENU (pilot)", "menu"),
        ("INFO (pilot)", "info"),
        ("TELETEXT / TEXT (pilot)", "teletext"),
        ("GUIDE / EPG (pilot)", "guide"),
    ]
    idx = xbmcgui.Dialog().select("Wybierz klawisz listy:", [k[0] for k in keys])
    if idx >= 0:
        _set_setting("kv_overlay_name", keys[idx][0])
        _set_setting("kv_overlay_tag", keys[idx][1])
        xbmc.executebuiltin("Container.Refresh")


def set_keymap_switches():
    groups = [
        ("Kółko myszki GÓRA / DÓŁ", "mw_v"),
        ("Kółko myszki LEWO / PRAWO", "mw_h"),
        ("Page UP / Page DOWN", "pg"),
        ("Strzałki LEWO / PRAWO", "arr"),
        ("Klawisze PLUS / MINUS", "pm"),
        ("Klawisze A / D", "ad"),
        ("Klawisze W / S", "ws"),
        ("Pilot: Skip Next / Previous (>>|  |<<)", "skip"),
        ("Pilot: CH+ / CH- (kanały)", "chan"),
    ]

    current = _get_setting("kv_active_switches", "")
    current_tags = current.split(",") if current else []
    preselect = [i for i, g in enumerate(groups) if g[1] in current_tags]

    idx_list = xbmcgui.Dialog().multiselect(
        "Zaznacz klawisze do przełączania:", [g[0] for g in groups], preselect=preselect
    )
    if idx_list is not None:
        selected_tags = ",".join([groups[i][1] for i in idx_list])
        _set_setting("kv_active_switches", selected_tags)
        xbmc.executebuiltin("Container.Refresh")


def set_keymap_volctrl():
    current = _get_setting("kv_vol_ctrl", "false")
    _set_setting("kv_vol_ctrl", "true" if current == "false" else "false")
    xbmc.executebuiltin("Container.Refresh")


def set_keymap_mouselock():
    current = _get_setting("kv_mouse_lock", "false")
    _set_setting("kv_mouse_lock", "true" if current == "false" else "false")
    xbmc.executebuiltin("Container.Refresh")


def apply_keymap():
    ov_tag = _get_setting("kv_overlay_tag", "o")
    switches = _get_setting("kv_active_switches", "").split(",")
    m_lock = _get_setting("kv_mouse_lock", "false") == "true"

    # Overlay (lista kanałów / overlay)
    cmd_ov_plugin = (
        "RunPlugin(plugin://plugin.video.Iskierek-IPTV-Full/?mode=open_channel_overlay)"
    )

    # ZAPPER: jeden trigger – reszta nawigacji dzieje się w oknie zappera (onAction),
    # dzięki temu nie ma laga od RunPlugin na każde kliknięcie.
    cmd_zap_plugin = (
        "RunPlugin(plugin://plugin.video.Iskierek-IPTV-Full/?mode=open_zapper)"
    )

    # PVR (FullScreenLiveTV) zostaje jak było
    cmd_nx_pvr = "ChannelDown"
    cmd_pv_pvr = "ChannelUp"

    fullscreen_live_tv_keyboard = []
    fullscreen_video_keyboard = [f"<{ov_tag}>{cmd_ov_plugin}</{ov_tag}>"]

    if "pg" in switches:
        fullscreen_live_tv_keyboard.append(f"<pageup>{cmd_pv_pvr}</pageup>")
        fullscreen_live_tv_keyboard.append(f"<pagedown>{cmd_nx_pvr}</pagedown>")
        fullscreen_video_keyboard.append(f"<pageup>{cmd_zap_plugin}</pageup>")
        fullscreen_video_keyboard.append(f"<pagedown>{cmd_zap_plugin}</pagedown>")

    if "arr" in switches:
        fullscreen_live_tv_keyboard.append(f"<left>{cmd_nx_pvr}</left>")
        fullscreen_live_tv_keyboard.append(f"<right>{cmd_pv_pvr}</right>")
        fullscreen_video_keyboard.append(f"<left>{cmd_zap_plugin}</left>")
        fullscreen_video_keyboard.append(f"<right>{cmd_zap_plugin}</right>")

    if "pm" in switches:
        fullscreen_live_tv_keyboard.append(f"<plus>{cmd_nx_pvr}</plus>")
        fullscreen_live_tv_keyboard.append(f"<minus>{cmd_pv_pvr}</minus>")
        fullscreen_video_keyboard.append(f"<plus>{cmd_zap_plugin}</plus>")
        fullscreen_video_keyboard.append(f"<minus>{cmd_zap_plugin}</minus>")

    if "ad" in switches:
        fullscreen_live_tv_keyboard.append(f"<a>{cmd_pv_pvr}</a>")
        fullscreen_live_tv_keyboard.append(f"<d>{cmd_nx_pvr}</d>")
        fullscreen_video_keyboard.append(f"<a>{cmd_zap_plugin}</a>")
        fullscreen_video_keyboard.append(f"<d>{cmd_zap_plugin}</d>")

    if "ws" in switches:
        fullscreen_live_tv_keyboard.append(f"<w>{cmd_pv_pvr}</w>")
        fullscreen_live_tv_keyboard.append(f"<s>{cmd_nx_pvr}</s>")
        fullscreen_video_keyboard.append(f"<w>{cmd_zap_plugin}</w>")
        fullscreen_video_keyboard.append(f"<s>{cmd_zap_plugin}</s>")

    # NOWE: Skip Next / Skip Previous (przyciski przewijania na pilotach typu Fire TV)
    if "skip" in switches:
        fullscreen_live_tv_keyboard.append(f"<skipnext>{cmd_nx_pvr}</skipnext>")
        fullscreen_live_tv_keyboard.append(f"<skipprevious>{cmd_pv_pvr}</skipprevious>")
        fullscreen_video_keyboard.append(f"<skipnext>{cmd_zap_plugin}</skipnext>")
        fullscreen_video_keyboard.append(f"<skipprevious>{cmd_zap_plugin}</skipprevious>")

    # NOWE: CH+ / CH- (przyciski kanałów na pilocie Philips/TV)
    if "chan" in switches:
        fullscreen_live_tv_keyboard.append(f"<channelup>{cmd_pv_pvr}</channelup>")
        fullscreen_live_tv_keyboard.append(f"<channeldown>{cmd_nx_pvr}</channeldown>")
        fullscreen_video_keyboard.append(f"<channelup>{cmd_zap_plugin}</channelup>")
        fullscreen_video_keyboard.append(f"<channeldown>{cmd_zap_plugin}</channeldown>")

    fullscreen_live_tv_mouse = ["<middleclick>Playlist</middleclick>"]

    fullscreen_video_mouse = [f"<middleclick>{cmd_ov_plugin}</middleclick>"]

    if m_lock:
        fullscreen_video_mouse.insert(0, "<mousemove>noop</mousemove>")
        fullscreen_video_mouse.insert(0, "<mousedrag>noop</mousedrag>")

    if "mw_v" in switches:
        fullscreen_live_tv_mouse.append(f"<wheelup>{cmd_pv_pvr}</wheelup>")
        fullscreen_live_tv_mouse.append(f"<wheeldown>{cmd_nx_pvr}</wheeldown>")
        fullscreen_video_mouse.append(f"<wheelup>{cmd_zap_plugin}</wheelup>")
        fullscreen_video_mouse.append(f"<wheeldown>{cmd_zap_plugin}</wheeldown>")

    if "mw_h" in switches:
        fullscreen_live_tv_mouse.append(f"<wheelleft>{cmd_nx_pvr}</wheelleft>")
        fullscreen_live_tv_mouse.append(f"<wheelright>{cmd_pv_pvr}</wheelright>")
        fullscreen_video_mouse.append(f"<wheelleft>{cmd_zap_plugin}</wheelleft>")
        fullscreen_video_mouse.append(f"<wheelright>{cmd_zap_plugin}</wheelright>")

    video_menu_mouse = []
    video_osd_mouse = []
    visualisation_mouse = []
    music_osd_mouse = []

    if m_lock:
        video_menu_mouse = [
            "<mousedrag>noop</mousedrag>",
            "<mousemove>noop</mousemove>",
        ]
        video_osd_mouse = [
            "<mousedrag>mousedrag</mousedrag>",
            "<mousemove>mousemove</mousemove>",
        ]
        visualisation_mouse = [
            "<mousedrag>noop</mousedrag>",
            "<mousemove>noop</mousemove>",
        ]
        music_osd_mouse = [
            "<mousedrag>mousedrag</mousedrag>",
            "<mousemove>mousemove</mousemove>",
        ]

    xml_lines = ['<?xml version="1.0" encoding="UTF-8"?>', "<keymap>"]

    xml_lines.append("    <FullScreenLiveTV>")
    if fullscreen_live_tv_keyboard:
        xml_lines.append("        <keyboard>")
        for line in fullscreen_live_tv_keyboard:
            xml_lines.append(f"            {line}")
        xml_lines.append("        </keyboard>")
    xml_lines.append("        <mouse>")
    for line in fullscreen_live_tv_mouse:
        xml_lines.append(f"            {line}")
    xml_lines.append("        </mouse>")
    xml_lines.append("    </FullScreenLiveTV>")

    xml_lines.append("")
    xml_lines.append("    <FullScreenVideo>")
    if fullscreen_video_keyboard:
        xml_lines.append("        <keyboard>")
        for line in fullscreen_video_keyboard:
            xml_lines.append(f"            {line}")
        xml_lines.append("        </keyboard>")
    xml_lines.append("        <mouse>")
    for line in fullscreen_video_mouse:
        xml_lines.append(f"            {line}")
    xml_lines.append("        </mouse>")
    xml_lines.append("    </FullScreenVideo>")

    if video_menu_mouse:
        xml_lines.append("")
        xml_lines.append("    <VideoMenu>")
        xml_lines.append("        <mouse>")
        for line in video_menu_mouse:
            xml_lines.append(f"            {line}")
        xml_lines.append("        </mouse>")
        xml_lines.append("    </VideoMenu>")

    if video_osd_mouse:
        xml_lines.append("")
        xml_lines.append("    <VideoOSD>")
        xml_lines.append("        <mouse>")
        for line in video_osd_mouse:
            xml_lines.append(f"            {line}")
        xml_lines.append("        </mouse>")
        xml_lines.append("    </VideoOSD>")

    if visualisation_mouse:
        xml_lines.append("")
        xml_lines.append("    <Visualisation>")
        xml_lines.append("        <mouse>")
        for line in visualisation_mouse:
            xml_lines.append(f"            {line}")
        xml_lines.append("        </mouse>")
        xml_lines.append("    </Visualisation>")

    if music_osd_mouse:
        xml_lines.append("")
        xml_lines.append("    <MusicOSD>")
        xml_lines.append("        <mouse>")
        for line in music_osd_mouse:
            xml_lines.append(f"            {line}")
        xml_lines.append("        </mouse>")
        xml_lines.append("    </MusicOSD>")

    xml_lines.append("</keymap>")

    xml_final = "\n".join(xml_lines)

    try:
        path = _get_keymap_file()
        keymap_dir = os.path.dirname(path)

        if not os.path.exists(keymap_dir):
            os.makedirs(keymap_dir)

        with open(path, "w", encoding="utf-8") as f:
            f.write(xml_final)

        xbmc.executebuiltin("Action(reloadkeymaps)")
        xbmcgui.Dialog().ok(common.addonname, "Zastosowano własne skróty!")
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, f"Błąd zapisu: {str(e)}")


def remove_keymap():
    try:
        path = _get_keymap_file()
        if os.path.exists(path):
            os.remove(path)
            xbmc.executebuiltin("Action(reloadkeymaps)")
        xbmcgui.Dialog().ok(common.addonname, "Usunięto wszystkie skróty.")
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, f"Błąd usuwania: {str(e)}")