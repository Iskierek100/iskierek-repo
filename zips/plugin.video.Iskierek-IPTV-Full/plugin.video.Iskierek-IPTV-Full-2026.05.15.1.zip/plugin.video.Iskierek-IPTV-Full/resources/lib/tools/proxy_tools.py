# -*- coding: utf-8 -*-
import os
import time
import socket
import urllib.request
import xbmc
import xbmcgui
from resources.lib import common

PROXY_CACHE_TIME = 300  # 5 minut

COUNTRY_NAMES = {
    'PL': 'Polska', 'DE': 'Niemcy', 'US': 'USA', 'GB': 'Wielka Brytania',
    'FR': 'Francja', 'NL': 'Holandia', 'CZ': 'Czechy', 'SK': 'Słowacja',
    'AT': 'Austria', 'CH': 'Szwajcaria', 'IT': 'Włochy', 'ES': 'Hiszpania',
    'SE': 'Szwecja', 'NO': 'Norwegia', 'DK': 'Dania', 'FI': 'Finlandia',
    'BE': 'Belgia', 'PT': 'Portugalia', 'IE': 'Irlandia', 'RO': 'Rumunia',
    'HU': 'Węgry', 'BG': 'Bułgaria', 'HR': 'Chorwacja', 'LT': 'Litwa',
    'LV': 'Łotwa', 'EE': 'Estonia', 'UA': 'Ukraina', 'RU': 'Rosja',
    'CA': 'Kanada', 'BR': 'Brazylia', 'AU': 'Australia', 'JP': 'Japonia',
    'KR': 'Korea Płd.', 'IN': 'Indie', 'CN': 'Chiny', 'SG': 'Singapur',
    'HK': 'Hongkong', 'TW': 'Tajwan', 'TR': 'Turcja', 'IL': 'Izrael',
    'ZA': 'RPA', 'MX': 'Meksyk', 'AR': 'Argentyna', 'CL': 'Chile',
    'CO': 'Kolumbia', 'TH': 'Tajlandia', 'VN': 'Wietnam', 'ID': 'Indonezja',
    'MY': 'Malezja', 'PH': 'Filipiny', 'BD': 'Bangladesz', 'PK': 'Pakistan',
}
_ORIGINAL_SOCKET_CLASS = socket.socket

# ── KONFIGURACJA ─────────────────────────────────────────────

def get_proxy_config():
    data = common.read_json_safe(common.proxy_config_file)
    if not isinstance(data, dict):
        return {
            'enabled': False,
            'type': 'http',
            'host': '',
            'port': '',
            'username': '',
            'password': '',
            'use_for_streams': True,
            'use_for_api': True,
            'use_for_epg': True
        }
    return data


def save_proxy_config(data):
    common.write_json_safe(common.proxy_config_file, data)


def is_proxy_enabled():
    cfg = get_proxy_config()
    return bool(cfg.get('enabled', False))


def should_use_proxy_for(usage_type):
    cfg = get_proxy_config()
    if not cfg.get('enabled'):
        return False
    if usage_type == 'api':
        return bool(cfg.get('use_for_api', True))
    if usage_type == 'streams':
        return bool(cfg.get('use_for_streams', True))
    if usage_type == 'epg':
        return bool(cfg.get('use_for_epg', True))
    return False


# ── URL PROXY ────────────────────────────────────────────────

def get_proxy_url():
    cfg = get_proxy_config()
    if not cfg.get('enabled'):
        return None

    ptype = cfg.get('type', 'http').lower()
    host = cfg.get('host', '').strip()
    port = cfg.get('port', '').strip()
    username = cfg.get('username', '').strip()
    password = cfg.get('password', '').strip()

    if not host or not port:
        return None

    auth = f'{username}:{password}@' if username and password else ''

    if ptype == 'socks5':
        return f'socks5://{auth}{host}:{port}'
    elif ptype == 'socks4':
        return f'socks4://{auth}{host}:{port}'
    elif ptype == 'https':
        return f'https://{auth}{host}:{port}'
    else:
        return f'http://{auth}{host}:{port}'


def get_stream_proxy_url():
    cfg = get_proxy_config()
    if not cfg.get('enabled', False):
        return ''
    if not cfg.get('use_for_streams', True):
        return ''

    ptype = cfg.get('type', 'http').lower()
    if ptype not in ('http', 'https'):
        return ''

    host = cfg.get('host', '').strip()
    port = cfg.get('port', '').strip()
    username = cfg.get('username', '').strip()
    password = cfg.get('password', '').strip()

    if not host or not port:
        return ''

    scheme = 'https' if ptype == 'https' else 'http'
    if username and password:
        return f'{scheme}://{username}:{password}@{host}:{port}'
    return f'{scheme}://{host}:{port}'


def _stream_proxy_config_is_usable(cfg):
    if not isinstance(cfg, dict):
        return False

    if not cfg.get('enabled', False):
        return False

    if not cfg.get('use_for_streams', True):
        return False

    ptype = str(cfg.get('type', 'http')).lower()
    host = str(cfg.get('host', '')).strip()
    port = str(cfg.get('port', '')).strip()

    # relay dla streamów wspiera tylko HTTP/HTTPS proxy
    if ptype not in ('http', 'https'):
        return False

    if not host or not port:
        return False

    return True


def stream_proxy_is_required():
    cfg = get_proxy_config()
    return _stream_proxy_config_is_usable(cfg)


def is_local_or_plugin_url(url):
    u = str(url or '').split('|', 1)[0].strip().lower()
    if not u:
        return False

    return (
        u.startswith('plugin://') or
        u.startswith('acestream://') or
        '127.0.0.1' in u or
        'localhost' in u or
        '[::1]' in u or
        '::1' in u
    )


def should_use_stream_proxy_for_url(url):
    clean = str(url or '').split('|', 1)[0].strip().lower()

    if not clean.startswith(('http://', 'https://')):
        return False

    if is_local_or_plugin_url(clean):
        return False

    return stream_proxy_is_required()


# ── OPENERY ──────────────────────────────────────────────────

def get_proxy_opener():
    cfg = get_proxy_config()
    if not cfg.get('enabled'):
        return None

    host = cfg.get('host', '').strip()
    port = cfg.get('port', '').strip()
    if not host or not port:
        return None

    ptype = cfg.get('type', 'http').lower()
    username = cfg.get('username', '').strip()
    password = cfg.get('password', '').strip()

    if ptype in ('socks4', 'socks5'):
        try:
            import socks
            import socket
            socks_type = socks.SOCKS5 if ptype == 'socks5' else socks.SOCKS4
            socks.set_default_proxy(socks_type, host, int(port),
                                    username=username or None, password=password or None)
            socket.socket = socks.socksocket
            xbmc.log(f'[Iskierek Proxy] SOCKS aktywne: {host}:{port}', xbmc.LOGINFO)
            return None
        except ImportError:
            xbmc.log('[Iskierek Proxy] Brak PySocks', xbmc.LOGERROR)
            return None
        except Exception as e:
            xbmc.log(f'[Iskierek Proxy] SOCKS error: {e}', xbmc.LOGERROR)
            return None

    import ssl
    scheme = 'https' if ptype == 'https' else 'http'
    if username and password:
        proxy_url = f'{scheme}://{username}:{password}@{host}:{port}'
    else:
        proxy_url = f'{scheme}://{host}:{port}'

    proxy_handler = urllib.request.ProxyHandler({'http': proxy_url, 'https': proxy_url})
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    ssl_handler = urllib.request.HTTPSHandler(context=ctx)
    opener = urllib.request.build_opener(proxy_handler, ssl_handler)
    opener.addheaders = [('User-Agent', 'Mozilla/5.0')]
    xbmc.log(f'[Iskierek Proxy] {ptype.upper()} proxy aktywne: {host}:{port}', xbmc.LOGINFO)
    return opener


def get_enforced_opener():
    cfg = get_proxy_config()
    if not cfg.get('enabled'):
        return None

    host = cfg.get('host', '').strip()
    port = cfg.get('port', '').strip()
    if not host or not port:
        return 'block'

    ptype = cfg.get('type', 'http').lower()
    username = cfg.get('username', '').strip()
    password = cfg.get('password', '').strip()

    if ptype in ('socks4', 'socks5'):
        try:
            import socks
            import socket
            socks_type = socks.SOCKS5 if ptype == 'socks5' else socks.SOCKS4
            socks.set_default_proxy(socks_type, host, int(port),
                                    username=username or None, password=password or None)
            socket.socket = socks.socksocket
            xbmc.log(f'[Iskierek Proxy] SOCKS wymuszone: {host}:{port}', xbmc.LOGINFO)
            return None
        except ImportError:
            xbmc.log('[Iskierek Proxy] Brak PySocks - blokowanie', xbmc.LOGERROR)
            return 'block'
        except Exception as e:
            xbmc.log(f'[Iskierek Proxy] SOCKS error: {e}', xbmc.LOGERROR)
            return 'block'

    import ssl
    scheme = 'https' if ptype == 'https' else 'http'
    if username and password:
        proxy_url = f'{scheme}://{username}:{password}@{host}:{port}'
    else:
        proxy_url = f'{scheme}://{host}:{port}'

    proxy_handler = urllib.request.ProxyHandler({'http': proxy_url, 'https': proxy_url})
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    ssl_handler = urllib.request.HTTPSHandler(context=ctx)
    opener = urllib.request.build_opener(proxy_handler, ssl_handler)
    opener.addheaders = [('User-Agent', 'Mozilla/5.0')]
    xbmc.log(f'[Iskierek Proxy] {ptype.upper()} wymuszone: {host}:{port}', xbmc.LOGINFO)
    return opener


def build_opener_with_proxy():
    handler = get_proxy_handler()
    if handler:
        return urllib.request.build_opener(handler)
    return None


def get_proxy_handler():
    proxy_url = get_proxy_url()
    if not proxy_url:
        return None

    cfg = get_proxy_config()
    ptype = cfg.get('type', 'http').lower()

    if ptype in ('socks4', 'socks5'):
        try:
            import socks
            import socket
            socks_type = socks.SOCKS5 if ptype == 'socks5' else socks.SOCKS4
            host = cfg.get('host', '').strip()
            port = int(cfg.get('port', '0').strip())
            username = cfg.get('username', '').strip() or None
            password = cfg.get('password', '').strip() or None
            socks.set_default_proxy(socks_type, host, port, username=username, password=password)
            socket.socket = socks.socksocket
            return None
        except ImportError:
            xbmcgui.Dialog().notification(common.addonname, 'Brak PySocks', xbmcgui.NOTIFICATION_ERROR, 4000)
            return None

    handler = urllib.request.ProxyHandler({'http': proxy_url, 'https': proxy_url})
    return handler


def install_proxy():
    cfg = get_proxy_config()
    if not cfg.get('enabled'):
        return False

    ptype = cfg.get('type', 'http').lower()
    if ptype in ('socks4', 'socks5'):
        get_proxy_handler()
        return True

    handler = get_proxy_handler()
    if handler:
        opener = urllib.request.build_opener(handler)
        urllib.request.install_opener(opener)
        return True
    return False


def uninstall_proxy():
    try:
        urllib.request.install_opener(None)
    except Exception:
        pass

    try:
        socket.socket = _ORIGINAL_SOCKET_CLASS
    except Exception:
        pass

def begin_temporary_api_proxy():
    """
    Włącza proxy tylko na czas resolve linku API.
    Zwraca:
        (ok, applied, message)
    """
    cfg = get_proxy_config()

    if not should_use_proxy_for('api'):
        return True, False, 'Proxy dla API wyłączone.'

    host = cfg.get('host', '').strip()
    port = cfg.get('port', '').strip()
    if not host or not port:
        return False, False, 'Proxy dla API włączone, ale brak hosta lub portu.'

    ptype = cfg.get('type', 'http').lower()
    username = cfg.get('username', '').strip()
    password = cfg.get('password', '').strip()

    try:
        if ptype in ('socks4', 'socks5'):
            try:
                import socks
            except ImportError:
                return False, False, 'Brak biblioteki PySocks dla proxy SOCKS.'

            socks_type = socks.SOCKS5 if ptype == 'socks5' else socks.SOCKS4
            socks.set_default_proxy(
                socks_type,
                host,
                int(port),
                username=username or None,
                password=password or None
            )
            socket.socket = socks.socksocket

            xbmc.log(f'[Iskierek Proxy] Tymczasowe proxy API {ptype.upper()} aktywne: {host}:{port}', xbmc.LOGINFO)
            return True, True, f'{ptype.upper()} {host}:{port}'

        import ssl

        scheme = 'https' if ptype == 'https' else 'http'
        if username and password:
            proxy_url = f'{scheme}://{username}:{password}@{host}:{port}'
        else:
            proxy_url = f'{scheme}://{host}:{port}'

        proxy_handler = urllib.request.ProxyHandler({
            'http': proxy_url,
            'https': proxy_url
        })

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        https_handler = urllib.request.HTTPSHandler(context=ctx)
        opener = urllib.request.build_opener(proxy_handler, https_handler)
        opener.addheaders = [('User-Agent', 'Mozilla/5.0')]
        urllib.request.install_opener(opener)

        xbmc.log(f'[Iskierek Proxy] Tymczasowe proxy API {ptype.upper()} aktywne: {host}:{port}', xbmc.LOGINFO)
        return True, True, f'{ptype.upper()} {host}:{port}'

    except Exception as e:
        uninstall_proxy()
        xbmc.log(f'[Iskierek Proxy] begin_temporary_api_proxy error: {e}', xbmc.LOGERROR)
        return False, False, str(e)


def end_temporary_api_proxy():
    uninstall_proxy()

def enforce_proxy():
    cfg = get_proxy_config()
    if not cfg.get('enabled'):
        return None

    opener = get_enforced_opener()

    if opener == 'block':
        xbmcgui.Dialog().notification(
            common.addonname,
            'Proxy włączone ale źle skonfigurowane! Brak połączenia.',
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )

        class BlockAllHandler(urllib.request.BaseHandler):
            def default_open(self, req):
                raise urllib.error.URLError('Proxy włączone ale nie skonfigurowane')

        blocker = urllib.request.build_opener(BlockAllHandler())
        urllib.request.install_opener(blocker)
        return False

    if opener is not None:
        urllib.request.install_opener(opener)

    return True


# ── WERYFIKACJA STRUMIENIA ────────────────────────────────────

def verify_stream_proxy_ready(stream_url, headers_text=''):
    import ssl
    import urllib.parse

    cfg = get_proxy_config()

    if not stream_proxy_is_required():
        return True, 'Proxy dla strumieni wyłączone.'

    proxy_type = cfg.get('type', 'http').lower()
    if proxy_type not in ('http', 'https'):
        return False, 'Dla strumieni TV obsługiwane jest tylko HTTP/HTTPS proxy. SOCKS nie jest wspierany dla odtwarzacza.'

    proxy_url = get_stream_proxy_url()
    if not proxy_url:
        return False, 'Proxy dla strumieni jest włączone, ale nie ma poprawnego adresu proxy.'

    clean_url = str(stream_url).split('|', 1)[0].strip()
    if not clean_url:
        return False, 'Brak adresu strumienia do testu proxy.'

    req_headers = {
        'User-Agent': 'Mozilla/5.0',
        'Accept': '*/*',
        'Connection': 'close'
    }

    if headers_text:
        for part in headers_text.split('&'):
            if '=' in part:
                k, v = part.split('=', 1)
                try:
                    req_headers[urllib.parse.unquote_plus(k)] = urllib.parse.unquote_plus(v)
                except Exception:
                    req_headers[k] = v

    xbmc.log(f'[Iskierek Proxy] verify_stream_proxy_ready: url={clean_url}', xbmc.LOGINFO)
    xbmc.log(f'[Iskierek Proxy] verify_stream_proxy_ready: proxy={proxy_url}', xbmc.LOGINFO)

    try:
        proxy_handler = urllib.request.ProxyHandler({
            'http': proxy_url,
            'https': proxy_url
        })

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        https_handler = urllib.request.HTTPSHandler(context=ctx)
        opener = urllib.request.build_opener(proxy_handler, https_handler)

        req = urllib.request.Request(clean_url, headers=req_headers)

        lower_url = clean_url.lower()

        # dla zwykłych plików próbujemy mały range
        if '.m3u8' not in lower_url:
            req.add_header('Range', 'bytes=0-4096')

        with opener.open(req, timeout=20) as response:
            data = response.read(4096)
            content_type = ''
            try:
                content_type = response.headers.get('Content-Type', '')
            except Exception:
                pass

            xbmc.log(f'[Iskierek Proxy] verify_stream_proxy_ready: content-type={content_type}', xbmc.LOGINFO)
            xbmc.log(f'[Iskierek Proxy] verify_stream_proxy_ready: bytes={len(data) if data else 0}', xbmc.LOGINFO)

            if data is None:
                return False, 'Proxy nie zwróciło danych dla strumienia.'

            if '.m3u8' in lower_url:
                try:
                    txt = data.decode('utf-8', errors='ignore')
                    xbmc.log(f'[Iskierek Proxy] verify_stream_proxy_ready: m3u8 sample={txt[:200]}', xbmc.LOGINFO)

                    if '#EXTM3U' in txt or '#EXTINF' in txt or '#EXT-X-' in txt:
                        return True, f'Proxy gotowe dla strumienia: {proxy_url}'

                    if txt.strip():
                        # niektóre serwery oddają playlistę trochę inaczej
                        return True, f'Proxy odpowiedziało dla HLS: {proxy_url}'

                except Exception as e:
                    xbmc.log(f'[Iskierek Proxy] verify_stream_proxy_ready m3u8 decode error: {e}', xbmc.LOGWARNING)

                return False, 'Proxy połączyło się, ale playlista HLS nie została poprawnie odczytana.'

            # dla ts/mp4 wystarczy że przyszły dane
            if len(data) > 0:
                return True, f'Proxy gotowe dla strumienia: {proxy_url}'

    except Exception as e:
        xbmc.log(f'[Iskierek Proxy] verify_stream_proxy_ready error: {e}', xbmc.LOGERROR)
        return False, f'Proxy dla strumienia nie działa: {e}'

    return False, 'Nie udało się zweryfikować proxy dla strumienia.'


# ── POMOCNICZE ───────────────────────────────────────────────

def _extract_ip(text):
    import re
    if not text:
        return ''
    m = re.search(r'(\d{1,3}(?:\.\d{1,3}){3})', text)
    return m.group(1) if m else ''


def _fetch_public_ip_direct():
    import ssl
    urls = [
        'http://api.ipify.org',
        'http://ipv4.icanhazip.com',
        'http://ifconfig.me/ip'
    ]
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    for url in urls:
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=12, context=ctx) as response:
                ip = _extract_ip(response.read().decode('utf-8', errors='ignore').strip())
                if ip:
                    return ip
        except Exception:
            continue
    return ''


def _fetch_public_ip_via_proxy():
    import ssl
    import socket

    cfg = get_proxy_config()
    if not cfg.get('enabled'):
        return ''

    host = cfg.get('host', '').strip()
    port = cfg.get('port', '').strip()
    ptype = cfg.get('type', 'http').lower()
    username = cfg.get('username', '').strip() or None
    password = cfg.get('password', '').strip() or None

    if not host or not port:
        return ''

    urls = [
        'http://api.ipify.org',
        'http://ipv4.icanhazip.com',
        'http://ifconfig.me/ip'
    ]

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    if ptype in ('socks4', 'socks5'):
        try:
            import socks
            original_socket = socket.socket
            socks_type = socks.SOCKS5 if ptype == 'socks5' else socks.SOCKS4
            socks.set_default_proxy(socks_type, host, int(port),
                                    username=username, password=password)
            socket.socket = socks.socksocket
            try:
                for url in urls:
                    try:
                        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                        with urllib.request.urlopen(req, timeout=12, context=ctx) as response:
                            ip = _extract_ip(response.read().decode('utf-8', errors='ignore').strip())
                            if ip:
                                return ip
                    except Exception:
                        continue
            finally:
                socket.socket = original_socket
        except Exception as e:
            xbmc.log(f'[Iskierek Proxy] SOCKS test error: {e}', xbmc.LOGERROR)
        return ''

    try:
        scheme = 'https' if ptype == 'https' else 'http'
        if username and password:
            proxy_url = f'{scheme}://{username}:{password}@{host}:{port}'
        else:
            proxy_url = f'{scheme}://{host}:{port}'

        proxy_handler = urllib.request.ProxyHandler({'http': proxy_url, 'https': proxy_url})
        opener = urllib.request.build_opener(proxy_handler)
        opener.addheaders = [('User-Agent', 'Mozilla/5.0')]

        for url in urls:
            try:
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                with opener.open(req, timeout=12) as response:
                    ip = _extract_ip(response.read().decode('utf-8', errors='ignore').strip())
                    if ip:
                        return ip
            except Exception:
                continue
    except Exception as e:
        xbmc.log(f'[Iskierek Proxy] HTTP/HTTPS test error: {e}', xbmc.LOGERROR)

    return ''


def _lookup_country(ip):
    import ssl
    import json as json_lib

    apis = [
        f'http://ip-api.com/json/{ip}?fields=countryCode,country',
        f'https://ipapi.co/{ip}/json/',
    ]

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    for api_url in apis:
        try:
            req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, context=ctx, timeout=8) as response:
                data = json_lib.loads(response.read().decode('utf-8', errors='ignore'))
                code = data.get('countryCode', data.get('country_code', ''))
                name = data.get('country', data.get('country_name', ''))
                if code:
                    return code.upper(), name
        except Exception:
            continue

    return '', ''


# ── TEST PROXY ────────────────────────────────────────────────

def test_proxy():
    import ssl
    import json as json_lib

    cfg = get_proxy_config()
    if not cfg.get('enabled'):
        xbmcgui.Dialog().ok(common.addonname, 'Proxy nie jest włączone.\n\nWłącz proxy w ustawieniach.')
        return

    host = cfg.get('host', '').strip()
    port = cfg.get('port', '').strip()
    if not host or not port:
        xbmcgui.Dialog().ok(common.addonname, 'Proxy nie jest poprawnie skonfigurowane.\n\nUstaw adres i port.')
        return

    pd = xbmcgui.DialogProgressBG()
    pd.create(common.addonname, 'Testowanie proxy...')

    pd.update(20, common.addonname, 'Sprawdzanie prawdziwego IP...')
    real_ip = _fetch_public_ip_direct()

    if not real_ip:
        pd.close()
        xbmcgui.Dialog().ok(common.addonname, 'Nie udało się sprawdzić prawdziwego IP.\n\nSprawdź połączenie internetowe.')
        return

    pd.update(60, common.addonname, 'Łączenie przez proxy...')
    proxy_ip = _fetch_public_ip_via_proxy()

    pd.update(100, common.addonname, 'Analiza wyników...')
    pd.close()

    ptype = cfg.get('type', 'http').upper()

    if not proxy_ip:
        xbmcgui.Dialog().ok(
            common.addonname,
            f'Proxy NIE działa!\n\n'
            f'Proxy: {host}:{port} ({ptype})\n'
            f'Twoje IP: {real_ip}\n\n'
            f'Sprawdź adres, port i dane logowania.'
        )
        return

    if proxy_ip == real_ip:
        xbmcgui.Dialog().ok(
            common.addonname,
            f'UWAGA: Proxy prawdopodobnie NIE działa!\n\n'
            f'IP przez proxy: {proxy_ip}\n'
            f'Twoje prawdziwe IP: {real_ip}\n\n'
            f'Oba adresy IP są takie same!\n'
            f'Proxy: {host}:{port} ({ptype})'
        )
        return

    xbmcgui.Dialog().ok(
        common.addonname,
        f'Proxy działa poprawnie!\n\n'
        f'Twoje prawdziwe IP: {real_ip}\n'
        f'IP przez proxy: {proxy_ip}\n\n'
        f'Proxy: {host}:{port} ({ptype})'
    )


def check_current_ip():
    cfg = get_proxy_config()
    proxy_enabled = cfg.get('enabled', False)

    direct_ip = _fetch_public_ip_direct()
    proxy_ip = _fetch_public_ip_via_proxy() if proxy_enabled else ''

    player_active = False
    try:
        player_active = xbmc.Player().isPlayingVideo()
    except Exception:
        pass

    win = xbmcgui.Window(10000)
    stream_proxy_enabled = win.getProperty('IskierekCurrentStreamProxyEnabled') == '1'
    stream_proxy_value = win.getProperty('IskierekCurrentStreamProxyValue') or ''
    stream_proxy_note = win.getProperty('IskierekCurrentStreamProxyNote') or ''

    lines = []
    lines.append(f'Odtwarzanie aktywne: {"TAK" if player_active else "NIE"}')
    lines.append(f'Proxy w ustawieniach: {"WŁĄCZONE" if proxy_enabled else "WYŁĄCZONE"}')

    if direct_ip:
        lines.append(f'Twoje IP bez proxy: {direct_ip}')
    else:
        lines.append('Twoje IP bez proxy: nie udało się sprawdzić')

    if proxy_enabled:
        host = cfg.get('host', '')
        port = cfg.get('port', '')
        ptype = cfg.get('type', 'http').upper()
        lines.append(f'Skonfigurowane proxy: {host}:{port} ({ptype})')

        if proxy_ip:
            lines.append(f'IP przez proxy: {proxy_ip}')
            if direct_ip and proxy_ip != direct_ip:
                lines.append('Test potwierdza: proxy zmienia IP.')
            else:
                lines.append('Uwaga: proxy nie zmienia IP.')
        else:
            lines.append('IP przez proxy: nie udało się sprawdzić')

    lines.append('')
    lines.append(f'Proxy w strumieniu: {"TAK" if stream_proxy_enabled else "NIE"}')

    if stream_proxy_value:
        lines.append(f'Wartość: {stream_proxy_value}')
    if stream_proxy_note:
        lines.append(stream_proxy_note)

    if stream_proxy_enabled and proxy_ip and direct_ip and proxy_ip != direct_ip:
        lines.append('')
        lines.append('Wniosek: proxy działa i jest podpięte do strumienia.')
    elif not stream_proxy_enabled:
        lines.append('')
        lines.append('Wniosek: strumień nie ma podpiętego proxy.')

    xbmcgui.Dialog().ok(common.addonname, '\n'.join(lines))


# ── CACHE LISTY PROXY ─────────────────────────────────────────

def _get_cached_proxy_list():
    try:
        data = common.read_json_safe(common.proxy_list_cache_file)
        if not isinstance(data, dict):
            return None
        proxies = data.get('proxies', [])
        if not proxies:
            return None
        return proxies
    except Exception:
        return None


def _save_proxy_list_cache(proxies):
    try:
        common.write_json_safe(common.proxy_list_cache_file, {
            'timestamp': time.time(),
            'proxies': proxies
        })
    except Exception:
        pass


def _force_refresh_proxy_list():
    try:
        if os.path.exists(common.proxy_list_cache_file):
            os.remove(common.proxy_list_cache_file)
    except Exception:
        pass


def force_refresh_proxy_list():
    _force_refresh_proxy_list()
    xbmcgui.Dialog().notification(
        common.addonname,
        'Cache listy proxy wyczyszczony. Kliknij Pobierz listę.',
        xbmcgui.NOTIFICATION_INFO,
        2000
    )
    xbmc.executebuiltin('Container.Refresh')


# ── POBIERANIE LISTY PROXY ────────────────────────────────────

def fetch_proxy_list():
    cached = _get_cached_proxy_list()
    if cached:
        choice = xbmcgui.Dialog().yesno(
            common.addonname,
            f'Lista proxy jest w pamięci ({len(cached)} proxy).\n\n'
            f'Użyć zapisanej listy?',
            nolabel='Pobierz nową',
            yeslabel='Użyj zapisanej'
        )

        if choice:
            _show_proxy_list_dialog(cached)
            return

    proxies = _download_proxy_list()

    if not proxies:
        xbmcgui.Dialog().ok(
            common.addonname,
            'Nie udało się pobrać żadnego proxy.\n\n'
            'Serwisy mogą być tymczasowo niedostępne.\n'
            'Spróbuj ponownie za chwilę.'
        )
        return

    _save_proxy_list_cache(proxies)
    _show_proxy_list_dialog(proxies)


def _download_proxy_list():
    import ssl
    import json as json_lib

    pd = xbmcgui.DialogProgressBG()
    pd.create(common.addonname, 'Pobieranie listy proxy...')

    all_proxies = []

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    # ŹRÓDŁO 1: ProxyScrape
    pd.update(8, common.addonname, 'ProxyScrape...')
    for ptype in ['http', 'socks5']:
        try:
            api_url = f'https://api.proxyscrape.com/v2/?request=displayproxies&protocol={ptype}&timeout=5000&country=all&ssl=all&anonymity=all'
            req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, context=ctx, timeout=15) as response:
                for line in response.read().decode('utf-8', errors='ignore').strip().splitlines():
                    line = line.strip()
                    if ':' in line:
                        parts = line.split(':', 1)
                        if len(parts) == 2 and parts[1].isdigit():
                            all_proxies.append({
                                'host': parts[0], 'port': parts[1], 'type': ptype,
                                'country_code': '', 'country_name': '', 'source': 'ProxyScrape'
                            })
        except Exception:
            continue

    # ŹRÓDŁO 2: GeoNode
    pd.update(16, common.addonname, 'GeoNode...')
    for ptype_api, ptype_local in [('http', 'http'), ('https', 'https'), ('socks5', 'socks5')]:
        try:
            api_url = f'https://proxylist.geonode.com/api/proxy-list?limit=50&page=1&sort_by=lastChecked&sort_type=desc&protocols={ptype_api}'
            req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, context=ctx, timeout=15) as response:
                result = json_lib.loads(response.read().decode('utf-8', errors='ignore'))
                for item in result.get('data', []):
                    ip = item.get('ip', '')
                    port = str(item.get('port', ''))
                    country = item.get('country', '')
                    if ip and port:
                        all_proxies.append({
                            'host': ip, 'port': port, 'type': ptype_local,
                            'country_code': country.upper() if len(country) == 2 else '',
                            'country_name': country if len(country) > 2 else '',
                            'source': 'GeoNode'
                        })
        except Exception:
            continue

    # ŹRÓDŁO 3: PubProxy
    pd.update(24, common.addonname, 'PubProxy...')
    for ptype_api, ptype_local in [('http', 'http'), ('socks5', 'socks5')]:
        try:
            api_url = f'http://pubproxy.com/api/proxy?limit=20&format=json&type={ptype_api}'
            req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=10) as response:
                result = json_lib.loads(response.read().decode('utf-8', errors='ignore'))
                for item in result.get('data', []):
                    ip = item.get('ip', '')
                    port = str(item.get('port', ''))
                    country = item.get('country', '')
                    if ip and port:
                        all_proxies.append({
                            'host': ip, 'port': port, 'type': ptype_local,
                            'country_code': country.upper() if len(country) == 2 else '',
                            'country_name': country if len(country) > 2 else '',
                            'source': 'PubProxy'
                        })
        except Exception:
            continue

    # ŹRÓDŁO 4: proxy-list.download HTTP PL
    pd.update(32, common.addonname, 'ProxyList PL HTTP...')
    try:
        api_url = 'https://www.proxy-list.download/api/v1/get?type=http&anon=elite&country=PL'
        req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, context=ctx, timeout=10) as response:
            for line in response.read().decode('utf-8', errors='ignore').strip().splitlines():
                line = line.strip()
                if ':' in line:
                    parts = line.split(':', 1)
                    if len(parts) == 2 and parts[1].isdigit():
                        all_proxies.append({
                            'host': parts[0], 'port': parts[1], 'type': 'http',
                            'country_code': 'PL', 'country_name': 'Polska', 'source': 'ProxyList'
                        })
    except Exception:
        pass

    # ŹRÓDŁO 5: proxy-list.download SOCKS5 PL
    pd.update(36, common.addonname, 'ProxyList PL SOCKS5...')
    try:
        api_url = 'https://www.proxy-list.download/api/v1/get?type=socks5&anon=elite&country=PL'
        req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, context=ctx, timeout=10) as response:
            for line in response.read().decode('utf-8', errors='ignore').strip().splitlines():
                line = line.strip()
                if ':' in line:
                    parts = line.split(':', 1)
                    if len(parts) == 2 and parts[1].isdigit():
                        all_proxies.append({
                            'host': parts[0], 'port': parts[1], 'type': 'socks5',
                            'country_code': 'PL', 'country_name': 'Polska', 'source': 'ProxyList'
                        })
    except Exception:
        pass

    # ŹRÓDŁO 6: SpysMe
    pd.update(42, common.addonname, 'SpysMe...')
    try:
        api_url = 'https://spys.me/proxy.txt'
        req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, context=ctx, timeout=15) as response:
            for line in response.read().decode('utf-8', errors='ignore').strip().splitlines():
                line = line.strip()
                if not line or line.startswith('#') or 'proxy' in line.lower():
                    continue
                parts = line.split()
                if parts and ':' in parts[0]:
                    hp = parts[0].split(':', 1)
                    if len(hp) == 2 and hp[1].isdigit():
                        country = parts[1].upper() if len(parts) > 1 and len(parts[1]) == 2 else ''
                        all_proxies.append({
                            'host': hp[0], 'port': hp[1], 'type': 'http',
                            'country_code': country, 'country_name': '', 'source': 'SpysMe'
                        })
    except Exception:
        pass

    # ŹRÓDŁO 7: FreeProxyList scraping
    pd.update(48, common.addonname, 'FreeProxyList...')
    try:
        import re as re_mod
        req = urllib.request.Request('https://free-proxy-list.net/', headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, context=ctx, timeout=15) as response:
            html = response.read().decode('utf-8', errors='ignore')
            for ip, port, cc in re_mod.findall(r'<tr><td>(\d+\.\d+\.\d+\.\d+)</td><td>(\d+)</td><td>(\w+)</td>', html):
                all_proxies.append({
                    'host': ip, 'port': port, 'type': 'http',
                    'country_code': cc.upper() if len(cc) == 2 else '',
                    'country_name': '', 'source': 'FreeProxyList'
                })
    except Exception:
        pass

    # ŹRÓDŁO 8: SSLProxies scraping
    pd.update(54, common.addonname, 'SSLProxies...')
    try:
        import re as re_mod
        req = urllib.request.Request('https://www.sslproxies.org/', headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, context=ctx, timeout=15) as response:
            html = response.read().decode('utf-8', errors='ignore')
            for ip, port, cc in re_mod.findall(r'<tr><td>(\d+\.\d+\.\d+\.\d+)</td><td>(\d+)</td><td>(\w+)</td>', html):
                all_proxies.append({
                    'host': ip, 'port': port, 'type': 'https',
                    'country_code': cc.upper() if len(cc) == 2 else '',
                    'country_name': '', 'source': 'SSLProxies'
                })
    except Exception:
        pass

    # ŹRÓDŁO 9: SocksProxy scraping
    pd.update(60, common.addonname, 'SocksProxy...')
    try:
        import re as re_mod
        req = urllib.request.Request('https://www.socks-proxy.net/', headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, context=ctx, timeout=15) as response:
            html = response.read().decode('utf-8', errors='ignore')
            for ip, port, cc in re_mod.findall(r'<tr><td>(\d+\.\d+\.\d+\.\d+)</td><td>(\d+)</td><td>(\w+)</td>', html):
                all_proxies.append({
                    'host': ip, 'port': port, 'type': 'socks5',
                    'country_code': cc.upper() if len(cc) == 2 else '',
                    'country_name': '', 'source': 'SocksProxy'
                })
    except Exception:
        pass

    # ŹRÓDŁO 10: TheSpeedX GitHub
    pd.update(68, common.addonname, 'TheSpeedX GitHub...')
    for ptype, url_path in [('http', 'http.txt'), ('socks5', 'socks5.txt')]:
        try:
            api_url = f'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/{url_path}'
            req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, context=ctx, timeout=15) as response:
                count = 0
                for line in response.read().decode('utf-8', errors='ignore').strip().splitlines():
                    line = line.strip()
                    if ':' in line and count < 200:
                        parts = line.split(':', 1)
                        if len(parts) == 2 and parts[1].isdigit():
                            all_proxies.append({
                                'host': parts[0], 'port': parts[1], 'type': ptype,
                                'country_code': '', 'country_name': '', 'source': 'TheSpeedX'
                            })
                            count += 1
        except Exception:
            continue

    # ŹRÓDŁO 11: Clarketm GitHub
    pd.update(76, common.addonname, 'Clarketm GitHub...')
    try:
        api_url = 'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt'
        req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, context=ctx, timeout=15) as response:
            count = 0
            for line in response.read().decode('utf-8', errors='ignore').strip().splitlines():
                line = line.strip()
                if ':' in line and count < 150:
                    parts = line.split(':', 1)
                    if len(parts) == 2 and parts[1].isdigit():
                        all_proxies.append({
                            'host': parts[0], 'port': parts[1], 'type': 'http',
                            'country_code': '', 'country_name': '', 'source': 'Clarketm'
                        })
                        count += 1
    except Exception:
        pass

    pd.update(82, common.addonname, 'Usuwanie duplikatów...')

    seen = set()
    unique_proxies = []
    for p in all_proxies:
        key = f"{p['host']}:{p['port']}"
        if key not in seen:
            seen.add(key)
            unique_proxies.append(p)

    pd.update(88, common.addonname, 'Rozpoznawanie krajów...')
    unknown_count = 0
    for p in unique_proxies:
        if not p.get('country_code'):
            if unknown_count >= 50:
                break
            code, name = _lookup_country(p['host'])
            p['country_code'] = code
            p['country_name'] = name
            unknown_count += 1

    for p in unique_proxies:
        code = p.get('country_code', '')
        if code and not p.get('country_name'):
            p['country_name'] = COUNTRY_NAMES.get(code, code)

    for p in unique_proxies:
        if 'test_http' not in p:
            p['test_http'] = '?'
        if 'test_hls' not in p:
            p['test_hls'] = '?'
        if 'test_http_msg' not in p:
            p['test_http_msg'] = ''
        if 'test_hls_msg' not in p:
            p['test_hls_msg'] = ''
        if 'test_ts' not in p:
            p['test_ts'] = 0

    pd.update(100, common.addonname, f'Gotowe: {len(unique_proxies)} proxy')
    pd.close()

    return unique_proxies


def _show_proxy_list_dialog(proxies, start_position=0):
    countries = {}
    for p in proxies:
        code = p.get('country_code', '')
        name = p.get('country_name', '')
        if code:
            if code not in countries:
                countries[code] = name or code

    filter_options = ['Wszystkie kraje']

    pl_count = sum(1 for p in proxies if p.get('country_code') == 'PL')
    if pl_count > 0:
        filter_options.append(f'Polska ({pl_count})')

    pl_hls_ok = sum(1 for p in proxies if p.get('country_code') == 'PL' and p.get('test_hls') == 'OK')
    if pl_hls_ok > 0:
        filter_options.append(f'Polska HLS OK ({pl_hls_ok})')

    hls_ok_count = sum(1 for p in proxies if p.get('test_hls') == 'OK')
    if hls_ok_count > 0:
        filter_options.append(f'Działające HLS ({hls_ok_count})')

    tested_count = sum(1 for p in proxies if p.get('test_http') not in ('?', ''))
    if tested_count > 0:
        filter_options.append(f'Przetestowane ({tested_count})')

    types_available = sorted(set(p.get('type', 'http') for p in proxies))
    for t in types_available:
        count = sum(1 for p in proxies if p.get('type') == t)
        filter_options.append(f'Typ: {t.upper()} ({count})')

    country_counts = {}
    for p in proxies:
        code = p.get('country_code', '')
        if code and code != 'PL':
            country_counts[code] = country_counts.get(code, 0) + 1

    for code, count in sorted(country_counts.items(), key=lambda x: -x[1]):
        name = countries.get(code, code)
        filter_options.append(f'{name} ({count})')

    filter_choice = xbmcgui.Dialog().select(
        f'Lista proxy ({len(proxies)} znalezionych)',
        filter_options
    )

    if filter_choice < 0:
        return

    selected_filter = filter_options[filter_choice]

    if selected_filter == 'Wszystkie kraje':
        filtered = proxies
        filter_label = 'Wszystkie'
    elif selected_filter.startswith('Polska HLS OK'):
        filtered = [p for p in proxies if p.get('country_code') == 'PL' and p.get('test_hls') == 'OK']
        filter_label = 'Polska HLS OK'
    elif selected_filter.startswith('Polska'):
        filtered = [p for p in proxies if p.get('country_code') == 'PL']
        filter_label = 'Polska'
    elif selected_filter.startswith('Działające HLS'):
        filtered = [p for p in proxies if p.get('test_hls') == 'OK']
        filter_label = 'Działające HLS'
    elif selected_filter.startswith('Przetestowane'):
        filtered = [p for p in proxies if p.get('test_http') not in ('?', '')]
        filter_label = 'Przetestowane'
    elif selected_filter.startswith('Typ:'):
        selected_type = selected_filter.split(':', 1)[1].strip().split(' ')[0].lower()
        filtered = [p for p in proxies if p.get('type') == selected_type]
        filter_label = f'Typ {selected_type.upper()}'
    else:
        country_name = selected_filter.rsplit(' (', 1)[0]
        country_code = ''
        for code, name in countries.items():
            if name == country_name or code == country_name:
                country_code = code
                break
        filtered = [p for p in proxies if p.get('country_code') == country_code]
        filter_label = country_name

    if not filtered:
        xbmcgui.Dialog().ok(common.addonname, 'Brak proxy dla tego filtra.')
        return

    def _sort_key(p):
        is_pl = 0 if p.get('country_code') == 'PL' else 1
        hls_ok = 0 if p.get('test_hls') == 'OK' else (1 if p.get('test_hls') == '?' else 2)
        http_ok = 0 if p.get('test_http') == 'OK' else (1 if p.get('test_http') == '?' else 2)
        is_fav = 0 if _is_favorite(p) else 1
        return (is_fav, is_pl, hls_ok, http_ok, p.get('country_code', 'ZZ'), p.get('type', ''), p.get('host', ''))

    filtered.sort(key=_sort_key)

    items = []
    for p in filtered:
        host = p.get('host', '')
        port = p.get('port', '')
        ptype = p.get('type', 'http').upper()
        country_code = p.get('country_code', '')
        country_name = p.get('country_name', '') or COUNTRY_NAMES.get(country_code, country_code)
        source = p.get('source', '')
        status = _proxy_status_text(p)

        fav_mark = '[COLOR gold]*[/COLOR] ' if _is_favorite(p) else ''

        # kolory
        test_http = p.get('test_http', '?')
        test_hls = p.get('test_hls', '?')

        if test_hls == 'OK':
            color_start = '[COLOR lime]'
        elif test_http == 'OK' and test_hls != 'OK':
            color_start = '[COLOR yellow]'
        elif test_http == 'NIE':
            color_start = '[COLOR red]'
        else:
            color_start = ''

        color_end = '[/COLOR]' if color_start else ''

        flag = f'[{country_code}] ' if country_code else ''

        label = f'{fav_mark}{color_start}{flag}{ptype} | {host}:{port} | {country_name or "?"} | {status} | {source}{color_end}'
        items.append(label)

    choice = xbmcgui.Dialog().select(
        f'{filter_label} ({len(filtered)} proxy)',
        items,
        preselect=min(start_position, len(items) - 1) if start_position > 0 else -1
    )

    if choice < 0:
        return

    selected = filtered[choice]
    _proxy_item_actions(selected, proxies, filtered, choice)


def _proxy_item_actions(selected, all_proxies, filtered_list, last_position):
    host = selected.get('host', '')
    port = selected.get('port', '')
    ptype = selected.get('type', 'http')
    country_code = selected.get('country_code', '')
    country_name = selected.get('country_name', '') or COUNTRY_NAMES.get(country_code, country_code)
    source = selected.get('source', '')
    status = _proxy_status_text(selected)
    tested = _format_test_age(selected.get('test_ts', 0))
    is_fav = _is_favorite(selected)

    fav_label = 'Usuń z ulubionych' if is_fav else 'Dodaj do ulubionych'

    actions = [
        'Zastosuj i włącz proxy',
        'Zastosuj i testuj proxy',
        'Testuj (bez zapisywania)',
        fav_label,
        'Wróć do listy'
    ]

    details = f'{host}:{port} ({ptype.upper()}) | {country_name or "?"} | {status} | Test: {tested}'

    action = xbmcgui.Dialog().select(details, actions)

    if action < 0 or action == 4:
        _show_proxy_list_dialog(all_proxies, last_position)
        return

    cfg = get_proxy_config()

    if action == 0:
        cfg['host'] = host
        cfg['port'] = port
        cfg['type'] = ptype
        cfg['username'] = ''
        cfg['password'] = ''
        cfg['enabled'] = True
        save_proxy_config(cfg)
        xbmcgui.Dialog().notification(common.addonname, f'Proxy włączone: {host}:{port} ({ptype.upper()})', xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin('Container.Refresh')

    elif action == 1:
        cfg['host'] = host
        cfg['port'] = port
        cfg['type'] = ptype
        cfg['username'] = ''
        cfg['password'] = ''
        cfg['enabled'] = True
        save_proxy_config(cfg)
        _test_selected_proxy(selected, all_proxies)
        _show_proxy_list_dialog(all_proxies, last_position)

    elif action == 2:
        _test_selected_proxy(selected, all_proxies)
        _show_proxy_list_dialog(all_proxies, last_position)

    elif action == 3:
        if is_fav:
            favs = _get_favorite_proxies()
            key = f"{host}:{port}"
            for i, f in enumerate(favs):
                if f"{f.get('host')}:{f.get('port')}" == key:
                    favs.pop(i)
                    break
            _save_favorite_proxies(favs)
            xbmcgui.Dialog().notification(common.addonname, f'Usunięto z ulubionych: {host}:{port}', xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            added = _add_favorite_proxy(selected)
            if added:
                xbmcgui.Dialog().notification(common.addonname, f'Dodano do ulubionych: {host}:{port}', xbmcgui.NOTIFICATION_INFO, 2000)
            else:
                xbmcgui.Dialog().notification(common.addonname, f'Już w ulubionych: {host}:{port}', xbmcgui.NOTIFICATION_INFO, 2000)

        _show_proxy_list_dialog(all_proxies, last_position)


# ── MENU USTAWIEŃ PROXY ───────────────────────────────────────

def proxy_settings_menu():
    import xbmcplugin
    cfg = get_proxy_config()

    xbmcplugin.setContent(common.addon_handle, 'files')
    xbmcplugin.setPluginCategory(common.addon_handle, 'Proxy / VPN')

    # status proxy
    enabled = cfg.get('enabled', False)
    status_icon = common.icon25 if enabled else common.icon26
    status_label = '[COLOR lime]Status proxy: WŁĄCZONE[/COLOR]' if enabled else '[COLOR red]Status proxy: WYŁĄCZONE[/COLOR]'
    li = xbmcgui.ListItem(status_label)
    li.setArt({'icon': status_icon, 'thumb': status_icon, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, common.build_url({'mode': 'proxy_toggle_enabled'}), li, False)

    # typ
    ptype = cfg.get('type', 'http').upper()
    li = xbmcgui.ListItem(f'Typ: {ptype}')
    li.setArt({'icon': common.icon14, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, common.build_url({'mode': 'proxy_set_type'}), li, False)

    # adres
    host = cfg.get('host', '')
    port = cfg.get('port', '')
    addr = f'{host}:{port}' if host and port else 'nie ustawiono'
    li = xbmcgui.ListItem(f'Adres: {addr}')
    li.setArt({'icon': common.icon14, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, common.build_url({'mode': 'proxy_set_address'}), li, False)

    # użytkownik
    username = cfg.get('username', '') or 'brak'
    li = xbmcgui.ListItem(f'Użytkownik: {username}')
    li.setArt({'icon': common.icon14, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, common.build_url({'mode': 'proxy_set_username'}), li, False)

    # hasło
    has_pass = 'ustawione' if cfg.get('password') else 'brak'
    li = xbmcgui.ListItem(f'Hasło: {has_pass}')
    li.setArt({'icon': common.icon14, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, common.build_url({'mode': 'proxy_set_password'}), li, False)

    # separator
    li = xbmcgui.ListItem('─────────────────────────────')
    li.setArt({'icon': common.icon14, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, '', li, False)

    # dodaj obecne do ulubionych
    if host and port:
        li = xbmcgui.ListItem(f'[COLOR gold]Dodaj obecne proxy do ulubionych ({host}:{port})[/COLOR]')
        li.setArt({'icon': common.icon23, 'fanart': common.fanart})
        xbmcplugin.addDirectoryItem(common.addon_handle, common.build_url({'mode': 'proxy_add_current_to_favorites'}), li, False)

    # ulubione
    fav_count = len(_get_favorite_proxies())
    fav_label = f'Ulubione proxy ({fav_count})' if fav_count else 'Ulubione proxy (puste)'
    li = xbmcgui.ListItem(fav_label)
    li.setArt({'icon': common.icon23, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, common.build_url({'mode': 'proxy_favorites'}), li, False)

    # separator
    li = xbmcgui.ListItem('─────────────────────────────')
    li.setArt({'icon': common.icon14, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, '', li, False)

    # szukaj działających proxy
    li = xbmcgui.ListItem('[COLOR lime]Szukaj działających proxy[/COLOR]')
    li.setArt({'icon': common.icon12, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, common.build_url({'mode': 'proxy_smart_scan'}), li, False)

    # testuj połączenie
    li = xbmcgui.ListItem('Testuj połączenie proxy')
    li.setArt({'icon': common.icon12, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, common.build_url({'mode': 'proxy_test'}), li, False)

    # sprawdź IP
    li = xbmcgui.ListItem('Sprawdź aktualne IP')
    li.setArt({'icon': common.icon15, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, common.build_url({'mode': 'proxy_check_ip'}), li, False)

    # separator
    li = xbmcgui.ListItem('─────────────────────────────')
    li.setArt({'icon': common.icon14, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, '', li, False)

    # reset
    li = xbmcgui.ListItem('[COLOR red]Resetuj ustawienia proxy[/COLOR]')
    li.setArt({'icon': common.icon29, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, common.build_url({'mode': 'proxy_reset'}), li, False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=False)

# ── AKCJE MENU ────────────────────────────────────────────────

def proxy_toggle_enabled():
    cfg = get_proxy_config()
    cfg['enabled'] = not cfg.get('enabled', False)

    # gdy włączamy proxy - ustaw wszystko na True
    if cfg['enabled']:
        cfg['use_for_streams'] = True
        cfg['use_for_api'] = True
        cfg['use_for_epg'] = True

    save_proxy_config(cfg)

    status = 'WŁĄCZONE' if cfg['enabled'] else 'WYŁĄCZONE'

    # start/stop relay
    try:
        from resources.lib.tools import stream_relay
        if cfg['enabled']:
            xbmc.log('[Iskierek Proxy] Włączono proxy - startuję relay', xbmc.LOGINFO)
            stream_relay.start_relay_service()
        else:
            xbmc.log('[Iskierek Proxy] Wyłączono proxy - zatrzymuję relay', xbmc.LOGINFO)
            stream_relay.stop_relay_service()
            uninstall_proxy()
    except Exception as e:
        xbmc.log(f'[Iskierek Proxy] relay toggle error: {e}', xbmc.LOGERROR)

    xbmcgui.Dialog().notification(
        common.addonname,
        f'Proxy: {status}',
        xbmcgui.NOTIFICATION_INFO,
        2000
    )
    xbmc.executebuiltin('Container.Refresh')

def proxy_add_current_to_favorites():
    cfg = get_proxy_config()
    host = cfg.get('host', '').strip()
    port = cfg.get('port', '').strip()

    if not host or not port:
        xbmcgui.Dialog().notification(
            common.addonname,
            'Najpierw ustaw adres proxy.',
            xbmcgui.NOTIFICATION_ERROR,
            2500
        )
        return

    item = {
        'host': host,
        'port': port,
        'type': cfg.get('type', 'http'),
        'username': cfg.get('username', ''),
        'password': cfg.get('password', ''),
        'country_code': '',
        'country_name': '',
        'source': 'ręczne',
        'test_http': '?',
        'test_hls': '?',
        'test_ts': 0
    }

    added = _add_favorite_proxy(item)

    if added:
        xbmcgui.Dialog().notification(
            common.addonname,
            f'Dodano do ulubionych: {host}:{port}',
            xbmcgui.NOTIFICATION_INFO,
            2500
        )
    else:
        xbmcgui.Dialog().notification(
            common.addonname,
            f'Już w ulubionych: {host}:{port}',
            xbmcgui.NOTIFICATION_INFO,
            2500
        )

    xbmc.executebuiltin('Container.Refresh')

def proxy_set_type():
    types = ['HTTP', 'HTTPS', 'SOCKS5', 'SOCKS4']
    sel = xbmcgui.Dialog().select('Typ proxy', types)
    if sel >= 0:
        cfg = get_proxy_config()
        cfg['type'] = types[sel].lower()
        save_proxy_config(cfg)
    xbmc.executebuiltin('Container.Refresh')


def proxy_set_address():
    cfg = get_proxy_config()
    kb = xbmc.Keyboard(cfg.get('host', ''), 'Adres proxy (np. 192.168.1.1)')
    kb.doModal()
    if kb.isConfirmed():
        cfg['host'] = kb.getText().strip()
        save_proxy_config(cfg)

    cfg = get_proxy_config()
    kb2 = xbmc.Keyboard(cfg.get('port', ''), 'Port proxy (np. 1080)')
    kb2.doModal()
    if kb2.isConfirmed():
        cfg['port'] = kb2.getText().strip()
        save_proxy_config(cfg)
    xbmc.executebuiltin('Container.Refresh')


def proxy_set_username():
    cfg = get_proxy_config()
    kb = xbmc.Keyboard(cfg.get('username', ''), 'Użytkownik (zostaw puste jeśli brak)')
    kb.doModal()
    if kb.isConfirmed():
        cfg['username'] = kb.getText().strip()
        save_proxy_config(cfg)
    xbmc.executebuiltin('Container.Refresh')


def proxy_set_password():
    cfg = get_proxy_config()
    kb = xbmc.Keyboard(cfg.get('password', ''), 'Hasło (zostaw puste jeśli brak)')
    kb.doModal()
    if kb.isConfirmed():
        cfg['password'] = kb.getText().strip()
        save_proxy_config(cfg)
    xbmc.executebuiltin('Container.Refresh')


def proxy_toggle_streams():
    cfg = get_proxy_config()
    cfg['use_for_streams'] = not cfg.get('use_for_streams', True)
    save_proxy_config(cfg)
    xbmc.executebuiltin('Container.Refresh')


def proxy_toggle_api():
    cfg = get_proxy_config()
    cfg['use_for_api'] = not cfg.get('use_for_api', True)
    save_proxy_config(cfg)
    xbmc.executebuiltin('Container.Refresh')


def proxy_toggle_epg():
    cfg = get_proxy_config()
    cfg['use_for_epg'] = not cfg.get('use_for_epg', True)
    save_proxy_config(cfg)
    xbmc.executebuiltin('Container.Refresh')


def proxy_reset():
    if xbmcgui.Dialog().yesno(common.addonname, 'Zresetować ustawienia proxy?'):
        save_proxy_config({
            'enabled': False,
            'type': 'http',
            'host': '',
            'port': '',
            'username': '',
            'password': '',
            'use_for_streams': True,
            'use_for_api': True,
            'use_for_epg': True
        })

        # zatrzymaj relay
        try:
            from resources.lib.tools import stream_relay
            stream_relay.stop_relay_service()
        except Exception:
            pass

        uninstall_proxy()

        xbmcgui.Dialog().notification(
            common.addonname,
            'Ustawienia proxy zresetowane',
            xbmcgui.NOTIFICATION_INFO,
            2000
        )
    xbmc.executebuiltin('Container.Refresh')

# ── TESTY JAKOŚCI PROXY Z LISTY ─────────────────────────────────

def _proxy_cfg_from_item(item):
    return {
        'enabled': True,
        'type': item.get('type', 'http'),
        'host': item.get('host', ''),
        'port': str(item.get('port', '')),
        'username': '',
        'password': '',
        'use_for_streams': True,
        'use_for_api': True,
        'use_for_epg': True
    }


def _build_proxy_url_from_cfg(cfg):
    ptype = cfg.get('type', 'http').lower()
    host = cfg.get('host', '').strip()
    port = str(cfg.get('port', '')).strip()
    username = cfg.get('username', '').strip()
    password = cfg.get('password', '').strip()

    if not host or not port:
        return ''

    if ptype == 'https':
        scheme = 'https'
    elif ptype == 'http':
        scheme = 'http'
    elif ptype == 'socks5':
        scheme = 'socks5'
    elif ptype == 'socks4':
        scheme = 'socks4'
    else:
        scheme = 'http'

    if username and password:
        return f'{scheme}://{username}:{password}@{host}:{port}'
    return f'{scheme}://{host}:{port}'


def _fetch_url_via_proxy_cfg(cfg, url, timeout=12, read_bytes=4096):
    import ssl
    import socket

    headers = {
        'User-Agent': 'Mozilla/5.0',
        'Accept': '*/*',
        'Connection': 'close'
    }

    ptype = cfg.get('type', 'http').lower()
    host = cfg.get('host', '').strip()
    port = str(cfg.get('port', '')).strip()
    username = cfg.get('username', '').strip() or None
    password = cfg.get('password', '').strip() or None

    if not host or not port:
        return False, b'', '', 'Brak hosta lub portu'

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    # SOCKS
    if ptype in ('socks4', 'socks5'):
        try:
            import socks

            original_socket = socket.socket
            socks_type = socks.SOCKS5 if ptype == 'socks5' else socks.SOCKS4

            socks.set_default_proxy(
                socks_type,
                host,
                int(port),
                username=username,
                password=password
            )
            socket.socket = socks.socksocket

            try:
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=timeout, context=ctx) as response:
                    data = response.read(read_bytes)
                    ctype = response.headers.get('Content-Type', '')
                    return True, data, ctype, ''
            finally:
                socket.socket = original_socket

        except Exception as e:
            return False, b'', '', str(e)

    # HTTP / HTTPS
    try:
        scheme = 'https' if ptype == 'https' else 'http'
        if username and password:
            proxy_url = f'{scheme}://{username}:{password}@{host}:{port}'
        else:
            proxy_url = f'{scheme}://{host}:{port}'

        proxy_handler = urllib.request.ProxyHandler({
            'http': proxy_url,
            'https': proxy_url
        })

        https_handler = urllib.request.HTTPSHandler(context=ctx)
        opener = urllib.request.build_opener(proxy_handler, https_handler)

        req = urllib.request.Request(url, headers=headers)
        with opener.open(req, timeout=timeout) as response:
            data = response.read(read_bytes)
            ctype = response.headers.get('Content-Type', '')
            return True, data, ctype, ''

    except Exception as e:
        return False, b'', '', str(e)


def _test_proxy_http_basic_cfg(cfg):
    test_urls = [
        'http://api.ipify.org',
        'http://ipv4.icanhazip.com',
        'http://example.com/'
    ]

    last_error = ''
    for url in test_urls:
        ok, data, ctype, err = _fetch_url_via_proxy_cfg(cfg, url, timeout=10, read_bytes=1024)
        if ok and data:
            txt = data.decode('utf-8', errors='ignore').strip()
            if txt:
                return True, 'HTTP działa'
        if err:
            last_error = err

    return False, last_error or 'Brak odpowiedzi HTTP'


def _test_proxy_https_hls_cfg(cfg):
    """
    Test HLS po HTTPS.
    To najważniejszy test dla M3U z .m3u8 po https://
    """

    # SOCKS oznaczamy jako N/D dla relay streamów
    if cfg.get('type', 'http').lower() in ('socks4', 'socks5'):
        return None, 'SOCKS nie jest używany przez relay strumieni'

    test_urls = [
        'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
        'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8'
    ]

    last_error = ''

    for url in test_urls:
        ok, data, ctype, err = _fetch_url_via_proxy_cfg(cfg, url, timeout=15, read_bytes=4096)
        if ok and data:
            txt = data.decode('utf-8', errors='ignore')
            if '#EXTM3U' in txt or '#EXT-X-' in txt or '#EXTINF' in txt:
                return True, 'HTTPS HLS działa'
            if txt.strip():
                # niektóre serwery zwracają nietypowe odpowiedzi, ale jednak playlistę
                return True, 'HTTPS HLS odpowiada'
        if err:
            last_error = err

    return False, last_error or 'Brak poprawnej odpowiedzi HLS po HTTPS'


def _format_test_age(ts_val):
    try:
        ts_val = int(ts_val or 0)
        if ts_val <= 0:
            return 'brak'
        diff = int(time.time() - ts_val)
        if diff < 60:
            return f'{diff}s temu'
        if diff < 3600:
            return f'{diff // 60}m temu'
        return f'{diff // 3600}h temu'
    except Exception:
        return 'brak'


def _proxy_status_text(item):
    http_state = item.get('test_http', '?')
    hls_state = item.get('test_hls', '?')
    return f'HTTP:{http_state} HLS:{hls_state}'


def _test_selected_proxy(proxy_item, all_proxies=None):
    cfg = _proxy_cfg_from_item(proxy_item)

    pd = xbmcgui.DialogProgressBG()
    pd.create(common.addonname, 'Testowanie wybranego proxy...')

    pd.update(30, common.addonname, 'Test HTTP...')
    http_ok, http_msg = _test_proxy_http_basic_cfg(cfg)

    pd.update(75, common.addonname, 'Test HTTPS HLS...')
    hls_ok, hls_msg = _test_proxy_https_hls_cfg(cfg)

    pd.update(100, common.addonname, 'Gotowe')
    pd.close()

    proxy_item['test_http'] = 'OK' if http_ok else 'NIE'

    if hls_ok is None:
        proxy_item['test_hls'] = 'N/D'
    else:
        proxy_item['test_hls'] = 'OK' if hls_ok else 'NIE'

    proxy_item['test_http_msg'] = http_msg
    proxy_item['test_hls_msg'] = hls_msg
    proxy_item['test_ts'] = int(time.time())

    if all_proxies is not None:
        _save_proxy_list_cache(all_proxies)

    lines = [
        f'Proxy: {proxy_item.get("host", "")}:{proxy_item.get("port", "")} ({proxy_item.get("type", "").upper()})',
        f'Kraj: {proxy_item.get("country_name", "") or proxy_item.get("country_code", "") or "nieznany"}',
        '',
        f'Test HTTP: {"OK" if http_ok else "NIE"}',
        f'Szczegóły HTTP: {http_msg}',
        '',
        f'Test HTTPS HLS: {proxy_item["test_hls"]}',
        f'Szczegóły HLS: {hls_msg}',
    ]

    xbmcgui.Dialog().ok(common.addonname, '\n'.join(lines))


def _show_proxy_list_dialog(proxies):
    countries = {}
    for p in proxies:
        code = p.get('country_code', '')
        name = p.get('country_name', '')
        if code:
            if code not in countries:
                countries[code] = name or code

    filter_options = ['Wszystkie kraje']

    pl_count = sum(1 for p in proxies if p.get('country_code') == 'PL')
    if pl_count > 0:
        filter_options.append(f'Polska ({pl_count})')

    pl_hls_ok = sum(1 for p in proxies if p.get('country_code') == 'PL' and p.get('test_hls') == 'OK')
    if pl_hls_ok > 0:
        filter_options.append(f'Polska HLS OK ({pl_hls_ok})')

    hls_ok_count = sum(1 for p in proxies if p.get('test_hls') == 'OK')
    if hls_ok_count > 0:
        filter_options.append(f'Działające HLS ({hls_ok_count})')

    types_available = sorted(set(p.get('type', 'http') for p in proxies))
    for t in types_available:
        count = sum(1 for p in proxies if p.get('type') == t)
        filter_options.append(f'Typ: {t.upper()} ({count})')

    country_counts = {}
    for p in proxies:
        code = p.get('country_code', '')
        if code and code != 'PL':
            country_counts[code] = country_counts.get(code, 0) + 1

    for code, count in sorted(country_counts.items(), key=lambda x: -x[1]):
        name = countries.get(code, code)
        filter_options.append(f'{name} ({count})')

    filter_choice = xbmcgui.Dialog().select(
        f'Lista proxy ({len(proxies)} znalezionych)',
        filter_options
    )

    if filter_choice < 0:
        return

    selected_filter = filter_options[filter_choice]

    if selected_filter == 'Wszystkie kraje':
        filtered = proxies
        filter_label = 'Wszystkie'
    elif selected_filter.startswith('Polska HLS OK'):
        filtered = [p for p in proxies if p.get('country_code') == 'PL' and p.get('test_hls') == 'OK']
        filter_label = 'Polska HLS OK'
    elif selected_filter.startswith('Polska'):
        filtered = [p for p in proxies if p.get('country_code') == 'PL']
        filter_label = 'Polska'
    elif selected_filter.startswith('Działające HLS'):
        filtered = [p for p in proxies if p.get('test_hls') == 'OK']
        filter_label = 'Działające HLS'
    elif selected_filter.startswith('Typ:'):
        selected_type = selected_filter.split(':', 1)[1].strip().split(' ')[0].lower()
        filtered = [p for p in proxies if p.get('type') == selected_type]
        filter_label = f'Typ {selected_type.upper()}'
    else:
        country_name = selected_filter.rsplit(' (', 1)[0]
        country_code = ''
        for code, name in countries.items():
            if name == country_name or code == country_name:
                country_code = code
                break
        filtered = [p for p in proxies if p.get('country_code') == country_code]
        filter_label = country_name

    if not filtered:
        xbmcgui.Dialog().ok(common.addonname, 'Brak proxy dla tego filtra.')
        return

    def _sort_key(p):
        # kolejność:
        # 1. Polska
        # 2. HLS OK
        # 3. HTTP OK
        # 4. kraj
        # 5. typ
        is_pl = 0 if p.get('country_code') == 'PL' else 1
        hls_ok = 0 if p.get('test_hls') == 'OK' else 1
        http_ok = 0 if p.get('test_http') == 'OK' else 1
        return (is_pl, hls_ok, http_ok, p.get('country_code', 'ZZ'), p.get('type', ''), p.get('host', ''))

    filtered.sort(key=_sort_key)

    items = []
    for p in filtered:
        host = p.get('host', '')
        port = p.get('port', '')
        ptype = p.get('type', 'http').upper()
        country_code = p.get('country_code', '')
        country_name = p.get('country_name', '') or COUNTRY_NAMES.get(country_code, country_code)
        source = p.get('source', '')
        status = _proxy_status_text(p)

        flag = f'[{country_code}] ' if country_code else ''
        if country_code == 'PL':
            flag = '[COLOR lime][PL][/COLOR] '

        label = f'{flag}{ptype} | {host}:{port} | {country_name or "?"} | {status} | {source}'
        items.append(label)

    choice = xbmcgui.Dialog().select(f'{filter_label} ({len(filtered)} proxy)', items)

    if choice < 0:
        _show_proxy_list_dialog(proxies)
        return

    selected = filtered[choice]

    host = selected.get('host', '')
    port = selected.get('port', '')
    ptype = selected.get('type', 'http')
    country_code = selected.get('country_code', '')
    country_name = selected.get('country_name', '') or COUNTRY_NAMES.get(country_code, country_code)
    source = selected.get('source', '')
    tested_when = _format_test_age(selected.get('test_ts', 0))

    details = [
        f'{host}:{port} ({ptype.upper()})',
        f'Kraj: {country_name or country_code or "nieznany"}',
        f'Źródło: {source}',
        f'Status: {_proxy_status_text(selected)}',
        f'Ostatni test: {tested_when}'
    ]

    action = xbmcgui.Dialog().select('\n'.join(details), [
        'Zastosuj i włącz proxy',
        'Zastosuj i testuj to proxy',
        'Testuj to proxy (bez zapisywania)',
        'Tylko zastosuj (bez włączania)',
        'Wróć do listy'
    ])

    if action < 0 or action == 4:
        _show_proxy_list_dialog(proxies)
        return

    cfg = get_proxy_config()
    cfg['host'] = host
    cfg['port'] = port
    cfg['type'] = ptype
    cfg['username'] = ''
    cfg['password'] = ''

    if action == 0:
        cfg['enabled'] = True
        save_proxy_config(cfg)
        xbmcgui.Dialog().notification(
            common.addonname,
            f'Proxy włączone: {host}:{port} ({ptype.upper()})',
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
        xbmc.executebuiltin('Container.Refresh')

    elif action == 1:
        cfg['enabled'] = True
        save_proxy_config(cfg)
        _test_selected_proxy(selected, proxies)
        xbmc.executebuiltin('Container.Refresh')

    elif action == 2:
        _test_selected_proxy(selected, proxies)
        _show_proxy_list_dialog(proxies)
        return

    elif action == 3:
        save_proxy_config(cfg)
        xbmcgui.Dialog().notification(
            common.addonname,
            f'Proxy ustawione (wyłączone): {host}:{port}',
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
        xbmc.executebuiltin('Container.Refresh')

def auto_scan_pl_proxies():
    import ssl

    proxies = _get_cached_proxy_list()

    if not proxies:
        xbmcgui.Dialog().notification(common.addonname, 'Pobieram listę proxy...', xbmcgui.NOTIFICATION_INFO, 2000)
        proxies = _download_proxy_list()
        if proxies:
            _save_proxy_list_cache(proxies)

    if not proxies:
        xbmcgui.Dialog().ok(common.addonname, 'Nie udało się pobrać listy proxy.\n\nSpróbuj kliknąć "Pobierz listę darmowych proxy".')
        return

    # wybór kraju
    countries_in_list = {}
    for p in proxies:
        code = p.get('country_code', '')
        if code:
            countries_in_list[code] = countries_in_list.get(code, 0) + 1

    scan_options = ['Wszystkie kraje']

    pl_count = countries_in_list.get('PL', 0)
    if pl_count > 0:
        scan_options.append(f'Tylko Polska ({pl_count})')

    for code, count in sorted(countries_in_list.items(), key=lambda x: -x[1]):
        if code != 'PL':
            name = COUNTRY_NAMES.get(code, code)
            scan_options.append(f'{name} ({count})')

    scan_choice = xbmcgui.Dialog().select('Który kraj skanować?', scan_options)

    if scan_choice < 0:
        return

    if scan_choice == 0:
        to_scan = proxies
        scan_label = 'wszystkie'
    elif scan_options[scan_choice].startswith('Tylko Polska'):
        to_scan = [p for p in proxies if p.get('country_code') == 'PL']
        scan_label = 'Polska'
    else:
        country_name = scan_options[scan_choice].rsplit(' (', 1)[0]
        country_code = ''
        for code, name in COUNTRY_NAMES.items():
            if name == country_name:
                country_code = code
                break
        if not country_code:
            country_code = country_name
        to_scan = [p for p in proxies if p.get('country_code') == country_code]
        scan_label = country_name

    if not to_scan:
        xbmcgui.Dialog().ok(common.addonname, 'Brak proxy do przeskanowania.')
        return

    # testowy URL — publiczny darmowy HLS
    test_url = 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8'

    pd = xbmcgui.DialogProgress()
    pd.create(common.addonname, f'Szybki skan proxy ({scan_label})...')

    found_ok = []
    total = len(to_scan)

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    try:
        for idx, p in enumerate(to_scan):
            if pd.iscanceled():
                break

            host = p.get('host', '')
            port = p.get('port', '')
            ptype = p.get('type', 'http').lower()

            percent = int(((idx + 1) / total) * 100)
            pd.update(
                percent,
                f'Testuję ({idx + 1}/{total}): {host}:{port}\n'
                f'Działające: {len(found_ok)}'
            )

            if ptype in ('socks4', 'socks5'):
                p['test_hls'] = 'N/D'
                continue

            scheme = 'https' if ptype == 'https' else 'http'
            username = p.get('username', '').strip()
            password = p.get('password', '').strip()

            if username and password:
                proxy_url = f'{scheme}://{username}:{password}@{host}:{port}'
            else:
                proxy_url = f'{scheme}://{host}:{port}'

            try:
                proxy_handler = urllib.request.ProxyHandler({
                    'http': proxy_url,
                    'https': proxy_url
                })

                https_handler = urllib.request.HTTPSHandler(context=ctx)
                opener = urllib.request.build_opener(proxy_handler, https_handler)

                req = urllib.request.Request(test_url, headers={
                    'User-Agent': 'Mozilla/5.0',
                    'Accept': '*/*',
                    'Connection': 'close'
                })

                with opener.open(req, timeout=1) as response:
                    data = response.read(4096)

                    if data and len(data) > 0:
                        try:
                            txt = data.decode('utf-8', errors='ignore')
                            if '#EXTM3U' in txt or '#EXT-X-' in txt:
                                p['test_hls'] = 'OK'
                                p['test_http'] = 'OK'
                                p['test_ts'] = int(time.time())
                                found_ok.append(p)
                                continue
                        except Exception:
                            pass

                p['test_hls'] = 'NIE'
                p['test_http'] = 'NIE'
                p['test_ts'] = int(time.time())

            except Exception:
                p['test_hls'] = 'NIE'
                p['test_ts'] = int(time.time())
                continue

        _save_proxy_list_cache(proxies)

    except Exception as e:
        xbmc.log(f'[Iskierek Proxy] Auto scan error: {e}', xbmc.LOGERROR)

    try:
        pd.close()
    except Exception:
        pass

    summary = [
        f'Przeskanowano: {total} proxy ({scan_label})',
        f'Działające HLS: {len(found_ok)}',
    ]

    if found_ok:
        summary.append('')
        summary.append('Pokazać listę działających?')

        if xbmcgui.Dialog().yesno(common.addonname, '\n'.join(summary)):
            _show_proxy_list_dialog(found_ok)
    else:
        xbmcgui.Dialog().ok(common.addonname, '\n'.join(summary))

def smart_proxy_scan():
    import ssl

    # wybór typu testu
    scan_modes = [
        'HLS (Xtream / M3U) - szuka proxy dla .m3u8 po HTTPS',
        'TS (Stalker) - szuka proxy dla zwykłego HTTP streamu',
        'Oba typy - testuje HLS i TS (wolniejsze)'
    ]

    mode_choice = xbmcgui.Dialog().select('Jakiego typu proxy szukasz?', scan_modes)
    if mode_choice < 0:
        return

    test_hls = mode_choice in (0, 2)
    test_ts = mode_choice in (1, 2)

    HLS_TEST_URL = 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8'
    TS_TEST_URLS = [
        'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
        'http://distribution.bbb3d.renderfarming.net/video/mp4/bbb_sunflower_1080p_30fps_normal.mp4'
    ]

    SMART_SOURCES = [
        {
            'name': 'GeoNode HTTP Elite',
            'url': 'https://proxylist.geonode.com/api/proxy-list?limit=100&page=1&sort_by=lastChecked&sort_type=desc&protocols=http%2Chttps&anonymityLevel=elite',
            'parser': 'geonode'
        },
        {
            'name': 'GeoNode HTTP Anonymous',
            'url': 'https://proxylist.geonode.com/api/proxy-list?limit=100&page=1&sort_by=lastChecked&sort_type=desc&protocols=http%2Chttps&anonymityLevel=anonymous',
            'parser': 'geonode'
        },
        {
            'name': 'ProxyScrape HTTP Elite',
            'url': 'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=3000&country=all&ssl=yes&anonymity=elite',
            'parser': 'plain'
        },
        {
            'name': 'ProxyScrape HTTPS Anonymous',
            'url': 'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=3000&country=all&ssl=yes&anonymity=anonymous',
            'parser': 'plain'
        }
    ]

    pd = xbmcgui.DialogProgress()
    pd.create(common.addonname, 'Pobieranie proxy z zaufanych źródeł...')

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    import json as json_lib

    all_proxies = []
    seen = set()

    for src_idx, src in enumerate(SMART_SOURCES):
        if pd.iscanceled():
            break

        pd.update(
            int((src_idx / len(SMART_SOURCES)) * 25),
            f'Pobieram: {src["name"]}...'
        )

        try:
            req = urllib.request.Request(src['url'], headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, context=ctx, timeout=15) as response:
                raw = response.read().decode('utf-8', errors='ignore')

                if src['parser'] == 'geonode':
                    try:
                        data = json_lib.loads(raw)
                        for item in data.get('data', []):
                            ip = item.get('ip', '')
                            port = str(item.get('port', ''))
                            country = item.get('country', '')
                            protocols = item.get('protocols', [])

                            ptype = 'http'
                            if 'https' in protocols:
                                ptype = 'https'
                            elif 'http' in protocols:
                                ptype = 'http'

                            if ip and port:
                                key = f'{ip}:{port}'
                                if key not in seen:
                                    seen.add(key)
                                    all_proxies.append({
                                        'host': ip,
                                        'port': port,
                                        'type': ptype,
                                        'country_code': country.upper() if len(country) == 2 else '',
                                        'country_name': COUNTRY_NAMES.get(country.upper(), '') if len(country) == 2 else country,
                                        'source': src['name']
                                    })
                    except Exception:
                        pass

                elif src['parser'] == 'plain':
                    for line in raw.strip().splitlines():
                        line = line.strip()
                        if ':' in line:
                            parts = line.split(':', 1)
                            if len(parts) == 2 and parts[1].strip().isdigit():
                                ip = parts[0].strip()
                                port = parts[1].strip()
                                key = f'{ip}:{port}'
                                if key not in seen:
                                    seen.add(key)
                                    all_proxies.append({
                                        'host': ip,
                                        'port': port,
                                        'type': 'http',
                                        'country_code': '',
                                        'country_name': '',
                                        'source': src['name']
                                    })

        except Exception as e:
            xbmc.log(f'[Iskierek Proxy] Smart scan source error ({src["name"]}): {e}', xbmc.LOGWARNING)
            continue

    if pd.iscanceled() or not all_proxies:
        pd.close()
        if not all_proxies:
            xbmcgui.Dialog().ok(
                common.addonname,
                'Nie udało się pobrać żadnego proxy.\nSpróbuj ponownie za chwilę.'
            )
        return

    pd.update(25, f'Testuję {len(all_proxies)} proxy...')

    found_ok = []
    total = len(all_proxies)

    for idx, p in enumerate(all_proxies):
        if pd.iscanceled():
            break

        host = p.get('host', '')
        port = p.get('port', '')
        ptype = p.get('type', 'http').lower()
        country = p.get('country_name', '') or p.get('country_code', '') or '?'

        percent = 25 + int(((idx + 1) / total) * 70)
        pd.update(
            percent,
            f'Testuję ({idx + 1}/{total}): {host}:{port} [{country}]\n'
            f'Działające: {len(found_ok)}'
        )

        if ptype in ('socks4', 'socks5'):
            continue

        scheme = 'https' if ptype == 'https' else 'http'
        username = p.get('username', '').strip()
        password = p.get('password', '').strip()

        if username and password:
            proxy_url = f'{scheme}://{username}:{password}@{host}:{port}'
        else:
            proxy_url = f'{scheme}://{host}:{port}'

        hls_ok = False
        ts_ok = False

        # test HLS
        if test_hls:
            try:
                proxy_handler = urllib.request.ProxyHandler({
                    'http': proxy_url,
                    'https': proxy_url
                })
                https_handler = urllib.request.HTTPSHandler(context=ctx)
                opener = urllib.request.build_opener(proxy_handler, https_handler)

                req = urllib.request.Request(HLS_TEST_URL, headers={
                    'User-Agent': 'Mozilla/5.0',
                    'Accept': '*/*',
                    'Connection': 'close'
                })

                with opener.open(req, timeout=5) as response:
                    data = response.read(4096)
                    if data:
                        txt = data.decode('utf-8', errors='ignore')
                        if '#EXTM3U' in txt or '#EXT-X-' in txt:
                            hls_ok = True
            except Exception:
                pass

        # test TS
        if test_ts:
            for ts_url in TS_TEST_URLS:
                if ts_ok:
                    break
                try:
                    proxy_handler = urllib.request.ProxyHandler({
                        'http': proxy_url,
                        'https': proxy_url
                    })
                    opener = urllib.request.build_opener(proxy_handler)

                    req = urllib.request.Request(ts_url, headers={
                        'User-Agent': 'Mozilla/5.0',
                        'Accept': '*/*',
                        'Connection': 'close',
                        'Range': 'bytes=0-4096'
                    })

                    with opener.open(req, timeout=5) as response:
                        data = response.read(4096)
                        if data and len(data) > 100:
                            ts_ok = True
                except Exception:
                    continue

        # wynik
        passed = False

        if test_hls and test_ts:
            passed = hls_ok or ts_ok
        elif test_hls:
            passed = hls_ok
        elif test_ts:
            passed = ts_ok

        p['test_http'] = 'OK' if (hls_ok or ts_ok) else 'NIE'
        p['test_hls'] = 'OK' if hls_ok else ('NIE' if test_hls else '?')
        p['test_ts'] = 'OK' if ts_ok else ('NIE' if test_ts else '?')
        p['test_ts_timestamp'] = int(time.time())

        if passed:
            # oznacz typ
            capabilities = []
            if hls_ok:
                capabilities.append('HLS')
            if ts_ok:
                capabilities.append('TS')
            p['capabilities'] = capabilities

            found_ok.append(p)
            _add_favorite_proxy(p)

    pd.update(98, f'Gotowe: {len(found_ok)} działających z {total}')
    pd.close()

    # podsumowanie
    if found_ok:
        # sortowanie: HLS+TS > HLS > TS
        def _sort_results(p):
            caps = p.get('capabilities', [])
            both = 0 if ('HLS' in caps and 'TS' in caps) else 1
            has_hls = 0 if 'HLS' in caps else 1
            has_ts = 0 if 'TS' in caps else 1
            return (both, has_hls, has_ts, p.get('country_code', 'ZZ'))

        found_ok.sort(key=_sort_results)

        items = []
        for p in found_ok:
            h = p.get('host', '')
            po = p.get('port', '')
            pt = p.get('type', 'http').upper()
            c = p.get('country_name', '') or p.get('country_code', '') or '?'
            caps = p.get('capabilities', [])
            caps_str = '+'.join(caps) if caps else '?'

            if 'HLS' in caps and 'TS' in caps:
                color = 'lime'
            elif 'HLS' in caps:
                color = 'yellow'
            elif 'TS' in caps:
                color = 'cyan'
            else:
                color = 'white'

            items.append(f'[COLOR {color}]{pt} | {h}:{po} | {c} | {caps_str}[/COLOR]')

        items.append('[COLOR yellow]Zamknij[/COLOR]')

        # legenda
        mode_label = scan_modes[mode_choice].split(' - ')[0]

        sel = xbmcgui.Dialog().select(
            f'{mode_label}: {len(found_ok)}/{total} działających (dodane do ulubionych)',
            items
        )

        if sel >= 0 and sel < len(found_ok):
            chosen = found_ok[sel]
            cfg = get_proxy_config()
            cfg['host'] = chosen.get('host', '')
            cfg['port'] = str(chosen.get('port', ''))
            cfg['type'] = chosen.get('type', 'http')
            cfg['username'] = ''
            cfg['password'] = ''
            cfg['enabled'] = True
            cfg['use_for_streams'] = True
            cfg['use_for_api'] = True
            cfg['use_for_epg'] = True
            save_proxy_config(cfg)

            try:
                from resources.lib.tools import stream_relay
                stream_relay.start_relay_service()
            except Exception:
                pass

            caps = chosen.get('capabilities', [])
            caps_str = '+'.join(caps) if caps else ''

            xbmcgui.Dialog().notification(
                common.addonname,
                f'Proxy włączone: {chosen.get("host")}:{chosen.get("port")} [{caps_str}]',
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
            xbmc.executebuiltin('Container.Refresh')
    else:
        mode_label = scan_modes[mode_choice].split(' - ')[0]
        xbmcgui.Dialog().ok(
            common.addonname,
            f'Tryb: {mode_label}\n\n'
            f'Przetestowano {total} proxy.\n\n'
            f'Żadne nie przeszło testu.\n\n'
            f'Spróbuj ponownie za chwilę lub użyj płatnego proxy/VPN.'
        )


# ── ULUBIONE PROXY ───────────────────────────────────────────

def _get_favorite_proxies():
    try:
        fav_file = os.path.join(common.addondir, 'proxy_favorites.json')
        data = common.read_json_safe(fav_file)
        if isinstance(data, list):
            return data
        return []
    except Exception:
        return []


def _save_favorite_proxies(favs):
    try:
        fav_file = os.path.join(common.addondir, 'proxy_favorites.json')
        common.write_json_safe(fav_file, favs)
    except Exception:
        pass


def _add_favorite_proxy(item):
    favs = _get_favorite_proxies()
    key = f"{item.get('host')}:{item.get('port')}"
    for f in favs:
        if f"{f.get('host')}:{f.get('port')}" == key:
            # aktualizuj dane
            f.update(item)
            _save_favorite_proxies(favs)
            return False  # już było
    favs.append(dict(item))
    _save_favorite_proxies(favs)
    return True  # nowe


def _remove_favorite_proxy(index):
    favs = _get_favorite_proxies()
    if 0 <= index < len(favs):
        removed = favs.pop(index)
        _save_favorite_proxies(favs)
        return removed
    return None


def _is_favorite(item):
    key = f"{item.get('host')}:{item.get('port')}"
    for f in _get_favorite_proxies():
        if f"{f.get('host')}:{f.get('port')}" == key:
            return True
    return False


def favorite_proxies_menu():
    while True:
        favs = _get_favorite_proxies()

        if not favs:
            xbmcgui.Dialog().ok(common.addonname, 'Brak ulubionych proxy.\n\nDodaj proxy z listy proxy.')
            return

        items = []
        for idx, p in enumerate(favs):
            host = p.get('host', '')
            port = p.get('port', '')
            ptype = p.get('type', 'http').upper()
            country_code = p.get('country_code', '')
            country_name = p.get('country_name', '') or COUNTRY_NAMES.get(country_code, country_code)
            status = _proxy_status_text(p)
            tested = _format_test_age(p.get('test_ts', 0))

            label = f'{ptype} | {host}:{port} | {country_name or "?"} | {status} | Test: {tested}'

            if p.get('test_hls') == 'OK':
                label = f'[COLOR lime]{label}[/COLOR]'
            elif p.get('test_http') == 'OK' and p.get('test_hls') != 'OK':
                label = f'[COLOR yellow]{label}[/COLOR]'
            elif p.get('test_http') == 'NIE':
                label = f'[COLOR red]{label}[/COLOR]'

            items.append(label)

        items.append('[COLOR red]Wyczyść wszystkie ulubione[/COLOR]')

        choice = xbmcgui.Dialog().select(f'Ulubione proxy ({len(favs)})', items)

        if choice < 0:
            return

        if choice == len(favs):
            if xbmcgui.Dialog().yesno(common.addonname, 'Usunąć wszystkie ulubione proxy?'):
                _save_favorite_proxies([])
                xbmcgui.Dialog().notification(common.addonname, 'Ulubione wyczyszczone', xbmcgui.NOTIFICATION_INFO, 2000)
            continue

        p = favs[choice]
        host = p.get('host', '')
        port = p.get('port', '')
        ptype = p.get('type', 'http')
        status = _proxy_status_text(p)

        actions = [
            'Zastosuj i włącz to proxy',
            'Testuj to proxy',
            'Usuń z ulubionych',
            'Wróć do listy'
        ]

        action = xbmcgui.Dialog().select(f'{host}:{port} ({ptype.upper()}) | {status}', actions)

        if action < 0 or action == 3:
            continue

        if action == 0:
            cfg = get_proxy_config()
            cfg['host'] = host
            cfg['port'] = port
            cfg['type'] = ptype
            cfg['username'] = p.get('username', '')
            cfg['password'] = p.get('password', '')
            cfg['enabled'] = True
            save_proxy_config(cfg)
            xbmcgui.Dialog().notification(common.addonname, f'Proxy włączone: {host}:{port}', xbmcgui.NOTIFICATION_INFO, 3000)
            return

        elif action == 1:
            _test_selected_proxy(p, None)
            favs = _get_favorite_proxies()
            if choice < len(favs):
                favs[choice] = p
                _save_favorite_proxies(favs)
            continue

        elif action == 2:
            _remove_favorite_proxy(choice)
            xbmcgui.Dialog().notification(common.addonname, f'Usunięto: {host}:{port}', xbmcgui.NOTIFICATION_INFO, 2000)
            continue


def favorite_proxy_action():
    idx = common.args.get('fav_index', [''])[0]
    try:
        idx = int(idx)
    except Exception:
        return

    favs = _get_favorite_proxies()
    if idx < 0 or idx >= len(favs):
        return

    p = favs[idx]
    host = p.get('host', '')
    port = p.get('port', '')
    ptype = p.get('type', 'http')
    country_name = p.get('country_name', '') or COUNTRY_NAMES.get(p.get('country_code', ''), '')
    status = _proxy_status_text(p)

    actions = [
        'Zastosuj i włącz to proxy',
        'Testuj to proxy',
        'Usuń z ulubionych',
    ]

    choice = xbmcgui.Dialog().select(
        f'{host}:{port} ({ptype.upper()}) | {country_name} | {status}',
        actions
    )

    if choice < 0:
        return

    if choice == 0:
        cfg = get_proxy_config()
        cfg['host'] = host
        cfg['port'] = port
        cfg['type'] = ptype
        cfg['username'] = p.get('username', '')
        cfg['password'] = p.get('password', '')
        cfg['enabled'] = True
        save_proxy_config(cfg)
        xbmcgui.Dialog().notification(common.addonname, f'Proxy włączone: {host}:{port}', xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin('Container.Refresh')

    elif choice == 1:
        _test_selected_proxy(p, None)
        # zapisz wyniki testu do ulubionych
        favs = _get_favorite_proxies()
        if idx < len(favs):
            favs[idx] = p
            _save_favorite_proxies(favs)
        xbmc.executebuiltin('Container.Refresh')

    elif choice == 2:
        removed = _remove_favorite_proxy(idx)
        if removed:
            xbmcgui.Dialog().notification(common.addonname, f'Usunięto: {host}:{port}', xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin('Container.Refresh')


def favorite_proxy_clear():
    if xbmcgui.Dialog().yesno(common.addonname, 'Usunąć wszystkie ulubione proxy?'):
        _save_favorite_proxies([])
        xbmcgui.Dialog().notification(common.addonname, 'Ulubione proxy wyczyszczone', xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')

def test_proxies_for_channel(stream_url, title=''):
    import ssl

    proxies = _get_cached_proxy_list()

    if not proxies:
        choice = xbmcgui.Dialog().yesno(
            common.addonname,
            'Brak listy proxy w pamięci.\n\nPobrać listę proxy teraz?'
        )
        if not choice:
            return
        proxies = _download_proxy_list()
        if not proxies:
            xbmcgui.Dialog().ok(common.addonname, 'Nie udało się pobrać listy proxy.')
            return
        _save_proxy_list_cache(proxies)

    clean_url = str(stream_url).split('|', 1)[0].strip()
    is_https = clean_url.lower().startswith('https')
    is_hls = '.m3u8' in clean_url.lower()

    # odfiltruj SOCKS dla HTTPS HLS - nie nadają się do relay
    if is_https or is_hls:
        testable = [p for p in proxies if p.get('type', 'http').lower() not in ('socks4', 'socks5')]
    else:
        testable = proxies[:]

    if not testable:
        xbmcgui.Dialog().ok(common.addonname, 'Brak proxy do przetestowania dla tego typu kanału.')
        return

    # sortuj: ulubione i polskie na górze
    def _sort_for_test(p):
        is_fav = 0 if _is_favorite(p) else 1
        is_pl = 0 if p.get('country_code') == 'PL' else 1
        return (is_fav, is_pl)

    testable.sort(key=_sort_for_test)

    url_short = clean_url[:80] + '...' if len(clean_url) > 80 else clean_url
    type_info = f'{"HTTPS" if is_https else "HTTP"} {"HLS" if is_hls else "TS"}'

    choice = xbmcgui.Dialog().yesno(
        common.addonname,
        f'Kanał: {title}\n'
        f'URL: {url_short}\n'
        f'Typ: {type_info}\n\n'
        f'Proxy do testu: {len(testable)}\n\n'
        f'Rozpocząć szybkie testowanie?',
        nolabel='Anuluj',
        yeslabel='Testuj'
    )

    if not choice:
        return

    pd = xbmcgui.DialogProgress()
    pd.create(common.addonname, f'Testowanie proxy dla: {title or "kanał"}...')

    found = []
    total = len(testable)
    tested = 0

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    try:
        for idx, p in enumerate(testable):
            if pd.iscanceled():
                break

            host = p.get('host', '')
            port = p.get('port', '')
            ptype = p.get('type', 'http').upper()
            country = p.get('country_name', '') or COUNTRY_NAMES.get(p.get('country_code', ''), '')

            percent = int(((idx + 1) / total) * 100)
            pd.update(
                percent,
                f'Testuję ({idx + 1}/{total}): {host}:{port} [{ptype}] {country}\n'
                f'Działa: {len(found)}'
            )

            tested += 1

            # buduj proxy URL
            scheme = 'https' if ptype == 'HTTPS' else 'http'
            username = p.get('username', '').strip()
            password = p.get('password', '').strip()

            if username and password:
                proxy_url = f'{scheme}://{username}:{password}@{host}:{port}'
            else:
                proxy_url = f'{scheme}://{host}:{port}'

            # testuj — max 5 sekund
            try:
                proxy_handler = urllib.request.ProxyHandler({
                    'http': proxy_url,
                    'https': proxy_url
                })

                https_handler = urllib.request.HTTPSHandler(context=ctx)
                opener = urllib.request.build_opener(proxy_handler, https_handler)

                req = urllib.request.Request(clean_url, headers={
                    'User-Agent': 'Mozilla/5.0',
                    'Accept': '*/*',
                    'Connection': 'close'
                })

                if not is_hls:
                    req.add_header('Range', 'bytes=0-4096')

                with opener.open(req, timeout=5) as response:
                    data = response.read(4096)

                    if not data or len(data) == 0:
                        p['test_channel_result'] = 'NIE'
                        continue

                    if is_hls:
                        try:
                            txt = data.decode('utf-8', errors='ignore')
                            if '#EXTM3U' not in txt and '#EXT-X-' not in txt and '#EXTINF' not in txt:
                                p['test_channel_result'] = 'NIE'
                                continue
                        except Exception:
                            p['test_channel_result'] = 'NIE'
                            continue

                    # DZIAŁA
                    p['test_channel_result'] = 'OK'
                    p['test_channel_url'] = clean_url
                    p['test_ts'] = int(time.time())
                    p['test_http'] = 'OK'

                    if is_hls or is_https:
                        p['test_hls'] = 'OK'

                    found.append(p)
                    _add_favorite_proxy(p)

            except Exception:
                p['test_channel_result'] = 'NIE'
                continue

        _save_proxy_list_cache(proxies)

    except Exception as e:
        xbmc.log(f'[Iskierek Proxy] test_proxies_for_channel error: {e}', xbmc.LOGERROR)
    finally:
        try:
            pd.close()
        except Exception:
            pass

    # podsumowanie
    if found:
        items = []
        for p in found:
            h = p.get('host', '')
            po = p.get('port', '')
            pt = p.get('type', 'http').upper()
            c = p.get('country_name', '') or COUNTRY_NAMES.get(p.get('country_code', ''), '')
            items.append(f'[COLOR lime]{pt} | {h}:{po} | {c}[/COLOR]')

        items.append('[COLOR yellow]Zamknij[/COLOR]')

        sel = xbmcgui.Dialog().select(
            f'Działające proxy ({len(found)}/{tested} testowanych) dla: {title}',
            items
        )

        if sel >= 0 and sel < len(found):
            chosen = found[sel]
            cfg = get_proxy_config()
            cfg['host'] = chosen.get('host', '')
            cfg['port'] = str(chosen.get('port', ''))
            cfg['type'] = chosen.get('type', 'http')
            cfg['username'] = ''
            cfg['password'] = ''
            cfg['enabled'] = True
            save_proxy_config(cfg)

            xbmcgui.Dialog().notification(
                common.addonname,
                f'Proxy włączone: {chosen.get("host")}:{chosen.get("port")}',
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
    else:
        xbmcgui.Dialog().ok(
            common.addonname,
            f'Kanał: {title}\n\n'
            f'Żadne z {tested} proxy nie przeszło testu.\n\n'
            f'Typ: {type_info}\n\n'
            f'Spróbuj pobrać nową listę proxy\n'
            f'lub użyj płatnego proxy/VPN.'
        )

# ── SZYBKIE ULUBIONE PROXY DLA KONKRETNEGO KANAŁU ─────────────────

def _current_proxy_key():
    cfg = get_proxy_config()
    return f"{cfg.get('type', 'http')}|{cfg.get('host', '')}|{cfg.get('port', '')}"


def _proxy_item_key(item):
    return f"{item.get('type', 'http')}|{item.get('host', '')}|{item.get('port', '')}"


def _apply_proxy_item(item, enable=True):
    cfg = get_proxy_config()
    cfg['host'] = item.get('host', '')
    cfg['port'] = str(item.get('port', ''))
    cfg['type'] = item.get('type', 'http')
    cfg['username'] = item.get('username', '')
    cfg['password'] = item.get('password', '')
    cfg['enabled'] = bool(enable)
    save_proxy_config(cfg)
    return cfg


def _update_proxy_in_cache(item):
    try:
        data = common.read_json_safe(common.proxy_list_cache_file)
        if not isinstance(data, dict):
            return

        proxies = data.get('proxies', [])
        if not isinstance(proxies, list):
            return

        key = _proxy_item_key(item)
        changed = False

        for i, p in enumerate(proxies):
            if _proxy_item_key(p) == key:
                proxies[i].update(item)
                changed = True

        if changed:
            data['proxies'] = proxies
            common.write_json_safe(common.proxy_list_cache_file, data)
    except Exception as e:
        xbmc.log(f'[Iskierek Proxy] _update_proxy_in_cache error: {e}', xbmc.LOGERROR)


def _persist_proxy_item_updates(item):
    # cache listy
    _update_proxy_in_cache(item)

    # ulubione
    favs = _get_favorite_proxies()
    key = _proxy_item_key(item)
    changed = False

    for i, f in enumerate(favs):
        if _proxy_item_key(f) == key:
            favs[i].update(item)
            changed = True

    if changed:
        _save_favorite_proxies(favs)


def _test_single_proxy_on_channel(proxy_item, stream_url, title='', silent=False):
    clean_url = str(stream_url).split('|', 1)[0].strip()
    is_hls = '.m3u8' in clean_url.lower()
    is_https = clean_url.lower().startswith('https')

    cfg = _proxy_cfg_from_item(proxy_item)

    proxy_type = str(proxy_item.get('type', 'http')).lower()
    if proxy_type in ('socks4', 'socks5') and (is_https or is_hls):
        proxy_item['test_channel_result'] = 'N/D'
        proxy_item['test_hls'] = 'N/D'
        proxy_item['test_hls_msg'] = 'SOCKS nie jest używany przez relay dla HLS'
        proxy_item['test_ts'] = int(time.time())
        _persist_proxy_item_updates(proxy_item)

        if not silent:
            xbmcgui.Dialog().ok(
                common.addonname,
                f'Kanał: {title}\n\n'
                f'Proxy: {proxy_item.get("host")}:{proxy_item.get("port")} ({proxy_item.get("type", "").upper()})\n\n'
                f'Wynik: N/D\n'
                f'SOCKS nie jest używany przez relay dla HLS/HTTPS.'
            )
        return False

    ok, data, ctype, err = _fetch_url_via_proxy_cfg(
        cfg,
        clean_url,
        timeout=20,
        read_bytes=8192
    )

    result_ok = False
    result_msg = ''

    if ok and data and len(data) > 0:
        if is_hls:
            try:
                txt = data.decode('utf-8', errors='ignore')
                if '#EXTM3U' in txt or '#EXT-X-' in txt or '#EXTINF' in txt:
                    result_ok = True
                    result_msg = 'Kanał HLS odpowiedział poprawnie'
                else:
                    result_ok = False
                    result_msg = 'Brak poprawnej playlisty HLS'
            except Exception as e:
                result_ok = False
                result_msg = f'Błąd dekodowania HLS: {e}'
        else:
            result_ok = True
            result_msg = f'Strumień zwrócił dane ({len(data)} bajtów)'
    else:
        result_ok = False
        result_msg = err or 'Brak odpowiedzi'

    proxy_item['test_channel_result'] = 'OK' if result_ok else 'NIE'
    proxy_item['test_channel_url'] = clean_url
    proxy_item['test_ts'] = int(time.time())

    if result_ok:
        proxy_item['test_http'] = 'OK'
        if is_hls or is_https:
            proxy_item['test_hls'] = 'OK'
            proxy_item['test_hls_msg'] = result_msg
        else:
            if proxy_item.get('test_hls', '?') == '?':
                proxy_item['test_hls'] = '?'
        proxy_item['test_http_msg'] = result_msg
    else:
        if is_hls or is_https:
            proxy_item['test_hls'] = 'NIE'
            proxy_item['test_hls_msg'] = result_msg
        else:
            proxy_item['test_http'] = 'NIE'
            proxy_item['test_http_msg'] = result_msg

    _persist_proxy_item_updates(proxy_item)

    if not silent:
        xbmcgui.Dialog().ok(
            common.addonname,
            f'Kanał: {title}\n'
            f'URL: {clean_url[:120]}\n\n'
            f'Proxy: {proxy_item.get("host")}:{proxy_item.get("port")} ({proxy_item.get("type", "").upper()})\n\n'
            f'Wynik: {"OK" if result_ok else "NIE"}\n'
            f'Szczegóły: {result_msg}'
        )

    return result_ok


def favorite_proxy_picker_for_channel(stream_url, title='', play_url=''):
    favs = _get_favorite_proxies()
    if not favs:
        xbmcgui.Dialog().ok(
            common.addonname,
            'Brak ulubionych proxy.\n\n'
            'Najpierw dodaj działające proxy do ulubionych.'
        )
        return

    current_key = _current_proxy_key()

    items = []
    current_idx = -1

    for idx, p in enumerate(favs):
        host = p.get('host', '')
        port = p.get('port', '')
        ptype = p.get('type', 'http').upper()
        country = p.get('country_name', '') or COUNTRY_NAMES.get(p.get('country_code', ''), p.get('country_code', ''))
        status = _proxy_status_text(p)

        prefix = ''
        if _proxy_item_key(p) == current_key and get_proxy_config().get('enabled'):
            prefix = '[COLOR gold]> [/COLOR]'
            current_idx = idx

        label = f'{prefix}{ptype} | {host}:{port} | {country or "?"} | {status}'

        if p.get('test_hls') == 'OK':
            label = f'[COLOR lime]{label}[/COLOR]'
        elif p.get('test_http') == 'OK':
            label = f'[COLOR yellow]{label}[/COLOR]'
        elif p.get('test_http') == 'NIE':
            label = f'[COLOR red]{label}[/COLOR]'

        items.append(label)

    choice = xbmcgui.Dialog().select(
        f'Ulubione proxy dla: {title}',
        items,
        preselect=current_idx
    )

    if choice < 0:
        return

    selected = favs[choice]
    host = selected.get('host', '')
    port = selected.get('port', '')
    ptype = selected.get('type', 'http').upper()

    action = xbmcgui.Dialog().select(
        f'{host}:{port} ({ptype})',
        [
            'Włącz to proxy',
            'Włącz i testuj ten kanał',
            'Włącz i odtwórz kanał',
            'Włącz, testuj i odtwórz kanał'
        ]
    )

    if action < 0:
        return

    _apply_proxy_item(selected, enable=True)

    if action == 0:
        xbmcgui.Dialog().notification(
            common.addonname,
            f'Włączono proxy: {host}:{port}',
            xbmcgui.NOTIFICATION_INFO,
            2500
        )
        return

    if action == 1:
        _test_single_proxy_on_channel(selected, stream_url, title, silent=False)
        return

    if action == 2:
        xbmcgui.Dialog().notification(
            common.addonname,
            f'Włączono proxy i odtwarzam: {host}:{port}',
            xbmcgui.NOTIFICATION_INFO,
            2500
        )
        if play_url:
            xbmc.sleep(150)
            xbmc.executebuiltin(f'PlayMedia({play_url})')
        return

    if action == 3:
        ok = _test_single_proxy_on_channel(selected, stream_url, title, silent=False)
        if ok and play_url:
            xbmc.sleep(150)
            xbmc.executebuiltin(f'PlayMedia({play_url})')
        return


def favorite_proxy_cycle_for_channel(stream_url, title='', play_url=''):
    favs = _get_favorite_proxies()
    if not favs:
        xbmcgui.Dialog().ok(
            common.addonname,
            'Brak ulubionych proxy.\n\n'
            'Najpierw dodaj działające proxy do ulubionych.'
        )
        return

    current_key = _current_proxy_key()
    current_idx = -1

    for idx, p in enumerate(favs):
        if _proxy_item_key(p) == current_key and get_proxy_config().get('enabled'):
            current_idx = idx
            break

    next_idx = 0 if current_idx < 0 else (current_idx + 1) % len(favs)
    selected = favs[next_idx]

    _apply_proxy_item(selected, enable=True)

    host = selected.get('host', '')
    port = selected.get('port', '')
    ptype = selected.get('type', 'http').upper()
    country = selected.get('country_name', '') or COUNTRY_NAMES.get(selected.get('country_code', ''), selected.get('country_code', ''))

    xbmcgui.Dialog().notification(
        common.addonname,
        f'Proxy {next_idx + 1}/{len(favs)}: {host}:{port} ({ptype}) {country}',
        xbmcgui.NOTIFICATION_INFO,
        3500
    )

    if play_url:
        xbmc.sleep(150)
        xbmc.executebuiltin(f'PlayMedia({play_url})')