# -*- coding: utf-8 -*-
import threading
import urllib.request
import urllib.parse
import ssl
import re
import socket
import hashlib
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import xbmc

from resources.lib import common
from resources.lib.tools import proxy_tools


RELAY_VERSION = '4'
_relay_server = None
_relay_thread = None
_relay_port = None
_relay_lock = threading.Lock()


class RelayHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def _find_free_port():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    port = s.getsockname()[1]
    s.close()
    return port


def _save_relay_state(port):
    try:
        common.write_json_safe(common.relay_state_file, {
            'port': int(port),
            'version': RELAY_VERSION
        })
    except Exception as e:
        xbmc.log(f'[Relay] save state error: {e}', xbmc.LOGERROR)


def _load_relay_state():
    try:
        data = common.read_json_safe(common.relay_state_file)
        if isinstance(data, dict):
            return data
        return {}
    except Exception:
        return {}


def _clear_relay_state():
    try:
        common.write_json_safe(common.relay_state_file, {})
    except Exception:
        pass


def _load_relay_map():
    try:
        data = common.read_json_safe(common.relay_map_file)
        if isinstance(data, dict):
            return data
        return {}
    except Exception:
        return {}


def _save_relay_map(data):
    try:
        common.write_json_safe(common.relay_map_file, data)
    except Exception as e:
        xbmc.log(f'[Relay] save map error: {e}', xbmc.LOGERROR)


def _clear_relay_map():
    try:
        common.write_json_safe(common.relay_map_file, {})
    except Exception:
        pass


def _cleanup_relay_map(data, max_items=4000):
    try:
        if not isinstance(data, dict):
            return {}

        items = list(data.items())
        if len(items) <= max_items:
            return data

        items.sort(key=lambda kv: kv[1].get('ts', 0), reverse=True)
        trimmed = dict(items[:max_items])
        return trimmed
    except Exception:
        return data


def _register_entry(original_url, headers_text=''):
    with _relay_lock:
        data = _load_relay_map()

        raw = f'{original_url}|{headers_text}|{time.time()}'
        token = hashlib.md5(raw.encode('utf-8')).hexdigest()[:16]

        data[token] = {
            'url': original_url,
            'headers': headers_text or '',
            'ts': int(time.time())
        }

        data = _cleanup_relay_map(data)
        _save_relay_map(data)
        return token


def _get_entry(token):
    try:
        data = _load_relay_map()
        item = data.get(token)
        if isinstance(item, dict):
            return item
        return None
    except Exception:
        return None


def _guess_ext(url):
    try:
        parsed = urllib.parse.urlparse(url)
        path = (parsed.path or '').lower()

        if path.endswith('.m3u8'):
            return '.m3u8'
        if path.endswith('.ts'):
            return '.ts'
        if path.endswith('.mp4'):
            return '.mp4'
        if path.endswith('.m4s'):
            return '.m4s'
        if path.endswith('.aac'):
            return '.aac'
        if path.endswith('.key'):
            return '.key'
        if path.endswith('.mpd'):
            return '.mpd'
    except Exception:
        pass

    if '.m3u8' in str(url).lower():
        return '.m3u8'
    return '.bin'

def _is_local_url(url):
    u = str(url or '').split('|', 1)[0].strip().lower()
    return (
        '127.0.0.1' in u or
        'localhost' in u or
        '[::1]' in u or
        '::1' in u
    )

def get_relay_port():
    global _relay_port

    if _relay_port:
        return _relay_port

    state = _load_relay_state()
    port = int(state.get('port', 0) or 0)
    if port > 0:
        _relay_port = port
        return port

    return None


def build_relay_url(original_url, headers_text=''):
    port = get_relay_port()
    if not port:
        return ''

    token = _register_entry(original_url, headers_text)
    ext = _guess_ext(original_url)
    return f'http://127.0.0.1:{port}/r/{token}{ext}'


def _is_port_open(host, port, timeout=1.0):
    try:
        s = socket.create_connection((host, port), timeout=timeout)
        s.close()
        return True
    except Exception:
        return False


def start_relay_service():
    global _relay_server, _relay_thread, _relay_port

    if _relay_server and _relay_port:
        xbmc.log(f'[Relay] Serwer już działa na 127.0.0.1:{_relay_port}', xbmc.LOGINFO)
        return _relay_port

    port = _find_free_port()
    _relay_port = port
    _save_relay_state(port)
    _clear_relay_map()

    def _run():
        global _relay_server
        try:
            _relay_server = RelayHTTPServer(('127.0.0.1', port), StreamRelayHandler)
            xbmc.log(f'[Relay] Serwer uruchomiony na 127.0.0.1:{port}', xbmc.LOGINFO)
            _relay_server.serve_forever()
        except Exception as e:
            xbmc.log(f'[Relay] Błąd startu serwera: {e}', xbmc.LOGERROR)

    _relay_thread = threading.Thread(target=_run, daemon=True)
    _relay_thread.start()
    return port


def stop_relay_service():
    global _relay_server, _relay_thread, _relay_port
    try:
        if _relay_server:
            xbmc.log('[Relay] Zatrzymuję serwer relay', xbmc.LOGINFO)
            _relay_server.shutdown()
            _relay_server.server_close()
    except Exception as e:
        xbmc.log(f'[Relay] Błąd zatrzymywania serwera: {e}', xbmc.LOGERROR)

    _relay_server = None
    _relay_thread = None
    _relay_port = None
    _clear_relay_state()
    _clear_relay_map()


def check_relay_health(timeout=2.0):
    try:
        port = get_relay_port()
        if not port:
            xbmc.log('[Relay] Health-check: brak portu relay', xbmc.LOGERROR)
            return False

        url = f'http://127.0.0.1:{port}/health'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})

        # BEZ proxy
        no_proxy_handler = urllib.request.ProxyHandler({})
        opener = urllib.request.build_opener(no_proxy_handler)

        with opener.open(req, timeout=timeout) as response:
            data = response.read().decode('utf-8', errors='ignore').strip()

        expected = f'OK|{RELAY_VERSION}'
        if data == expected:
            xbmc.log(f'[Relay] Health-check OK: {data} on port {port}', xbmc.LOGINFO)
            return True

        xbmc.log(f'[Relay] Health-check FAILED: got={data}, expected={expected}, port={port}', xbmc.LOGERROR)
        return False

    except Exception as e:
        xbmc.log(f'[Relay] Health-check error: {e}', xbmc.LOGERROR)
        return False


def _parse_headers_text(headers_text):
    result = {}
    if not headers_text:
        return result

    for part in headers_text.split('&'):
        if '=' in part:
            k, v = part.split('=', 1)
            try:
                key = urllib.parse.unquote_plus(k)
                val = urllib.parse.unquote_plus(v)
            except Exception:
                key = k
                val = v
            result[key] = val

    return result


def _build_opener_with_current_proxy():
    proxy_url = proxy_tools.get_stream_proxy_url()
    if not proxy_url:
        return None, ''

    proxy_handler = urllib.request.ProxyHandler({
        'http': proxy_url,
        'https': proxy_url
    })

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    https_handler = urllib.request.HTTPSHandler(context=ctx)
    opener = urllib.request.build_opener(proxy_handler, https_handler)
    opener.addheaders = [('User-Agent', 'Mozilla/5.0')]

    return opener, proxy_url


def _is_m3u8(url, content_type=''):
    url_l = (url or '').lower()
    ct_l = (content_type or '').lower()

    if '.m3u8' in url_l:
        return True

    if 'mpegurl' in ct_l or 'vnd.apple.mpegurl' in ct_l:
        return True

    return False


def _rewrite_uri_match(base_url, headers_text, value):
    abs_url = urllib.parse.urljoin(base_url, value)
    return build_relay_url(abs_url, headers_text)


def _rewrite_hls_tags(line, base_url, headers_text):
    def _replace_double(match):
        old_val = match.group(1)
        new_val = _rewrite_uri_match(base_url, headers_text, old_val)
        return f'URI="{new_val}"'

    def _replace_single(match):
        old_val = match.group(1)
        new_val = _rewrite_uri_match(base_url, headers_text, old_val)
        return f"URI='{new_val}'"

    line = re.sub(r'URI="([^"]+)"', _replace_double, line)
    line = re.sub(r"URI='([^']+)'", _replace_single, line)
    return line


def _rewrite_m3u8_playlist(text, base_url, headers_text):
    out_lines = []

    for raw_line in text.splitlines():
        line = raw_line.strip()

        if not line:
            out_lines.append(raw_line)
            continue

        if line.startswith('#'):
            rewritten = _rewrite_hls_tags(raw_line, base_url, headers_text)
            out_lines.append(rewritten)
            continue

        absolute_url = urllib.parse.urljoin(base_url, line)
        relay_url = build_relay_url(absolute_url, headers_text)
        out_lines.append(relay_url)

    rewritten_text = '\n'.join(out_lines)

    try:
        xbmc.log(f'[Relay] Rewritten playlist sample:\n{rewritten_text[:1200]}', xbmc.LOGINFO)
    except Exception:
        pass

    return rewritten_text


class StreamRelayHandler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, fmt, *args):
        return

    def do_HEAD(self):
        self._handle_request(send_body=False)

    def do_GET(self):
        self._handle_request(send_body=True)

    def _extract_token(self, path):
        try:
            # /r/abcd1234.m3u8 -> abcd1234
            value = path.split('/r/', 1)[1]
            value = value.split('?', 1)[0]
            token = value.split('.', 1)[0]
            return token
        except Exception:
            return ''

    def _handle_request(self, send_body=True):
        try:
            parsed = urllib.parse.urlparse(self.path)

            if parsed.path == '/health':
                payload = f'OK|{RELAY_VERSION}'.encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'text/plain; charset=utf-8')
                self.send_header('Content-Length', str(len(payload)))
                self.send_header('Connection', 'close')
                self.end_headers()
                if send_body:
                    self.wfile.write(payload)
                return

            if not parsed.path.startswith('/r/'):
                self.send_error(404, 'Not found')
                return

            token = self._extract_token(parsed.path)
            if not token:
                self.send_error(400, 'Brak tokena relay')
                return

            entry = _get_entry(token)
            if not entry:
                xbmc.log(f'[Relay] Nie znaleziono tokena relay: {token}', xbmc.LOGERROR)
                self.send_error(404, 'Relay token not found')
                return

            target_url = entry.get('url', '')
            headers_text = entry.get('headers', '')

            if not target_url:
                self.send_error(400, 'Brak URL')
                return

            extra_headers = _parse_headers_text(headers_text)

            req_headers = {
                'User-Agent': extra_headers.get('User-Agent', 'Mozilla/5.0'),
                'Accept': '*/*',
                'Connection': 'close'
            }

            for k, v in extra_headers.items():
                req_headers[k] = v

            if 'Range' in self.headers:
                req_headers['Range'] = self.headers['Range']

            if 'Icy-MetaData' in self.headers:
                req_headers['Icy-MetaData'] = self.headers['Icy-MetaData']

            if _is_local_url(target_url):
                opener = None
                proxy_url = ''
                xbmc.log(f'[Relay] Lokalny target - proxy pominięte: {target_url}', xbmc.LOGINFO)
            else:
                opener, proxy_url = _build_opener_with_current_proxy()

            xbmc.log(f'[Relay] GET target={target_url}', xbmc.LOGINFO)
            xbmc.log(f'[Relay] GET proxy={proxy_url or "BRAK"}', xbmc.LOGINFO)

            req = urllib.request.Request(target_url, headers=req_headers)

            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

            if opener:
                response = opener.open(req, timeout=20)
            else:
                response = urllib.request.urlopen(req, timeout=20, context=ctx)

            with response:
                final_url = response.geturl()
                status_code = getattr(response, 'status', 200) or 200
                content_type = response.headers.get('Content-Type', '')
                content_length = response.headers.get('Content-Length', '')
                accept_ranges = response.headers.get('Accept-Ranges', '')
                content_range = response.headers.get('Content-Range', '')

                if _is_m3u8(final_url, content_type):
                    raw = response.read().decode('utf-8', errors='ignore')
                    xbmc.log(f'[Relay] Wykryto playlistę HLS: {final_url}', xbmc.LOGINFO)

                    rewritten = _rewrite_m3u8_playlist(raw, final_url, headers_text)
                    payload = rewritten.encode('utf-8')

                    self.send_response(200)
                    self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                    self.send_header('Content-Length', str(len(payload)))
                    self.send_header('Cache-Control', 'no-cache')
                    self.send_header('Connection', 'close')
                    self.end_headers()

                    if send_body:
                        self.wfile.write(payload)
                    return

                self.send_response(status_code)

                if content_type:
                    self.send_header('Content-Type', content_type)
                if content_length:
                    self.send_header('Content-Length', content_length)
                if accept_ranges:
                    self.send_header('Accept-Ranges', accept_ranges)
                if content_range:
                    self.send_header('Content-Range', content_range)

                self.send_header('Cache-Control', 'no-cache')
                self.send_header('Connection', 'close')
                self.end_headers()

                if not send_body:
                    return

                while True:
                    chunk = response.read(1024 * 128)
                    if not chunk:
                        break
                    self.wfile.write(chunk)

        except Exception as e:
            xbmc.log(f'[Relay] Błąd relay: {e}', xbmc.LOGERROR)
            try:
                self.send_error(502, f'Relay error: {e}')
            except Exception:
                pass