# -*- coding: utf-8 -*-
import os
import json
import hashlib
import urllib.parse
import re
import xbmc
from resources.lib import common
from resources.lib.core import channels


def load_user_config():
    user_file = common.user_sorting_file

    if not os.path.exists(user_file):
        common.check_folders()
        try:
            with open(user_file, 'w', encoding='utf-8') as f:
                json.dump(channels.DEFAULT_CONFIG_DATA, f, indent=4, ensure_ascii=False)
        except:
            pass
        return channels.DEFAULT_CONFIG_DATA

    try:
        with open(user_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            updated = False

            for key, val in channels.DEFAULT_CONFIG_DATA.items():
                if key not in data:
                    data[key] = val
                    updated = True

            if updated:
                try:
                    with open(user_file, 'w', encoding='utf-8') as fw:
                        json.dump(data, fw, indent=4, ensure_ascii=False)
                except:
                    pass

            return data
    except:
        return channels.DEFAULT_CONFIG_DATA


USER_CONFIG = load_user_config()
ORDERED_GROUPS = [tuple(g) for g in USER_CONFIG.get('ordered_groups', channels.DEFAULT_GROUPS)]
NAME_FIXES = USER_CONFIG.get('name_fixes', channels.DEFAULT_FIXES)


def clean_name_dynamic(name):
    if not name:
        return ""

    n = name.strip()
    n = re.sub(r'(?i)^[\W_]*pl[\W_]*', '', n).strip()

    changed = True
    while changed:
        changed = False
        for prefix in USER_CONFIG.get('ignored_prefixes', []):
            p = prefix.lower()
            if re.match(r'(?i)^[\W_]*' + re.escape(p) + r'[\W_]*', n):
                n = re.sub(r'(?i)^[\W_]*' + re.escape(p) + r'[\W_]*', '', n).strip()
                changed = True
                break

    changed = True
    while changed:
        changed = False
        lower_n = n.lower()
        for suffix in USER_CONFIG.get('ignored_suffixes', []):
            s = suffix.lower()
            if lower_n.endswith(s):
                n = n[:-len(s)].strip()
                changed = True
                break

    return n


def normalize_simple(name):
    if not name:
        return ""

    n = name.lower()
    replacements = [
        ("ą", "a"), ("ć", "c"), ("ę", "e"), ("ł", "l"), ("ń", "n"),
        ("ó", "o"), ("ś", "s"), ("ź", "z"), ("ż", "z"), ("é", "e")
    ]
    for old, new in replacements:
        n = n.replace(old, new)

    return re.sub(r'[^a-z0-9]', '', n)


def build_sort_map():
    mapping = {}
    for group_idx, (group_name, channels_list) in enumerate(ORDERED_GROUPS):
        for chan_idx, chan_name in enumerate(channels_list):
            norm = normalize_simple(chan_name)
            if norm:
                mapping[norm] = (group_idx, chan_idx, chan_name)
    return mapping


SORT_MAP = build_sort_map()

def reload_config():
    global USER_CONFIG,ORDERED_GROUPS,NAME_FIXES,SORT_MAP
    USER_CONFIG=load_user_config()
    ORDERED_GROUPS=[tuple(g) for g in USER_CONFIG.get('ordered_groups',channels.DEFAULT_GROUPS)]
    NAME_FIXES=USER_CONFIG.get('name_fixes',channels.DEFAULT_FIXES)
    SORT_MAP=build_sort_map()


def _extract_portal_data(portal_or_mac, url=None, serial=None):
    if isinstance(portal_or_mac, dict):
        portal = portal_or_mac
        ptype = portal.get('type', 'stalker')

        if ptype == 'xtream':
            unique_a = portal.get('url', '')
            unique_b = portal.get('username', '')
        else:
            unique_a = portal.get('url', '')
            unique_b = portal.get('mac', '')

        return portal, unique_a, unique_b

    return None, url or '', portal_or_mac or ''


def get_smart_sorted_list(load_module, portal_or_mac, url=None, serial=None, path=None):
    if path and not os.path.exists(path):
        os.makedirs(path)

    portal, unique_a, unique_b = _extract_portal_data(portal_or_mac, url, serial)

    try:
        parsed = urllib.parse.urlparse(unique_a)
        clean_host = parsed.netloc + parsed.path
        unique_str = f"{clean_host}_{unique_b}"
        file_hash = hashlib.md5(unique_str.encode('utf-8')).hexdigest()
    except:
        file_hash = hashlib.md5(str(unique_b).encode('utf-8')).hexdigest()

    cache_file = os.path.join(common.cachedir, f'pl_cache_groups_{file_hash}.json')

    try:
        if portal:
            raw_data = load_module.getAllChannels(portal, path)
            genres_data = load_module.getGenres(portal, path)
        else:
            raw_data = load_module.getAllChannels(portal_or_mac, url, serial, path)
            genres_data = load_module.getGenres(portal_or_mac, url, serial, path)
    except:
        return []

    if not raw_data or 'channels' not in raw_data:
        return []

    genres_map = genres_data.get('genres', {})
    keywords = USER_CONFIG.get('group_keywords', [])

    allowed_ids = []

    # ✅ wykrywanie typu dostawcy
    provider_type = None
    if portal and isinstance(portal, dict):
        provider_type = portal.get('type', '').lower()

    # ✅ wyjątek dla M3U i Plugin – brak filtrowania po grupach
    if provider_type in ['m3u', 'plugin']:
        allowed_ids = None

    else:
        if keywords:
            for gid, gdata in genres_map.items():
                g_title = str(gdata.get('title', '')).lower()

                if _group_title_matches_keywords(g_title, keywords):
                    if 'xxx' not in g_title and 'porn' not in g_title:
                        allowed_ids.append(str(gid))

            # jeśli zdefiniowano keywords, ale nic nie znaleziono
            if not allowed_ids:
                xbmc.log("SmartSort: No matching genre IDs found", xbmc.LOGWARNING)
                return []
        else:
            allowed_ids = None

    sorted_list = _sort_channels_by_group(raw_data['channels'], allowed_ids)

    common.write_json_safe(cache_file, {'channels': sorted_list})
    return sorted_list

def _sort_channels_by_group(raw_channels_list, allowed_genre_ids):
    unique_channels = {}

    fixes_map = {}
    for bad, good in NAME_FIXES.items():
        fixes_map[normalize_simple(bad)] = good

    for ch in raw_channels_list:

        # ✅ POPRAWIONE filtrowanie genre (spójne typy)
        if allowed_genre_ids is not None:
            genre_id = str(ch.get('genre_id', ''))
            if genre_id not in allowed_genre_ids:
                continue

        raw_name = str(ch.get('name', ''))
        cleaned_name = clean_name_dynamic(raw_name)
        norm_cleaned = normalize_simple(cleaned_name)
        fixed_name = cleaned_name

        if norm_cleaned in fixes_map:
            fixed_name = fixes_map[norm_cleaned]

        norm_final = normalize_simple(fixed_name)

        sort_idx = 9999
        bucket_idx = len(ORDERED_GROUPS)
        official_name = fixed_name

        if norm_final in SORT_MAP:
            group_idx, chan_idx, map_name = SORT_MAP[norm_final]
            bucket_idx = group_idx
            sort_idx = chan_idx
            official_name = map_name
            ch['name'] = official_name
            ch['display_name'] = official_name
        else:
            ch['name'] = fixed_name
            ch['display_name'] = fixed_name

        ch['_sort_idx'] = sort_idx
        ch['_bucket_idx'] = bucket_idx
        ch['_my_group_name'] = (
            ORDERED_GROUPS[bucket_idx][0]
            if bucket_idx < len(ORDERED_GROUPS)
            else 'POZOSTAŁE'
        )

        quality = 0
        l_raw = raw_name.lower()
        if '4k' in l_raw or 'uhd' in l_raw:
            quality = 3
        elif 'fhd' in l_raw:
            quality = 2
        elif 'hd' in l_raw:
            quality = 1
        ch['quality'] = quality

        unique_key = normalize_simple(official_name)
        if not unique_key:
            unique_key = normalize_simple(raw_name)

        if unique_key in unique_channels:
            if quality > unique_channels[unique_key]['quality']:
                unique_channels[unique_key] = ch
        else:
            unique_channels[unique_key] = ch

    final_list = []

    # ✅ Twoje zdefiniowane grupy
    for group_idx, (group_name, _) in enumerate(ORDERED_GROUPS):
        valid_chans = [
            c for c in unique_channels.values()
            if c.get('_bucket_idx') == group_idx
        ]

        if valid_chans:
            valid_chans.sort(key=lambda x: x['_sort_idx'])

            header = {
                'display_name': f" {group_name} ",
                'is_header': True,
                'logo': '',
                '_my_group_name': group_name
            }

            final_list.append(header)
            final_list.extend(valid_chans)

    # ✅ POZOSTAŁE tylko z przefiltrowanych kanałów
    others = [
        c for c in unique_channels.values()
        if c.get('_bucket_idx') == len(ORDERED_GROUPS)
    ]

    if others:
        others.sort(key=lambda x: x['name'])

        header = {
            'display_name': " POZOSTAŁE ",
            'is_header': True,
            'logo': '',
            '_my_group_name': 'POZOSTAŁE'
        }

        final_list.append(header)
        final_list.extend(others)

    return final_list

def _group_title_matches_keywords(group_title, keywords):
    try:
        title = str(group_title or '').lower().strip()
        if not title:
            return False

        # ✅ usuń znaki box-drawing i inne "ozdobne"
        title = re.sub(r'[\u2500-\u257F]', ' ', title)

        # ✅ usuń popularne separatory
        title_norm = re.sub(r'[\[\]\(\)\|\-_./]+', ' ', title)
        title_norm = re.sub(r'\s+', ' ', title_norm).strip()

        title_tokens = set(title_norm.split())

        for kw in keywords:
            kw = str(kw or '').lower().strip()
            if not kw:
                continue

            kw_norm = re.sub(r'[\u2500-\u257F]', ' ', kw)
            kw_norm = re.sub(r'[\[\]\(\)\|\-_./]+', ' ', kw_norm)
            kw_norm = re.sub(r'\s+', ' ', kw_norm).strip()

            if not kw_norm:
                continue

            if ' ' in kw_norm:
                if kw_norm in title_norm:
                    return True
            else:
                if kw_norm in title_tokens:
                    return True

        return False

    except Exception:
        return False
