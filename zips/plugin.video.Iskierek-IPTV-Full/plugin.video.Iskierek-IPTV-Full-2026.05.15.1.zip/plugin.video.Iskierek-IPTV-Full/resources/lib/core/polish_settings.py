# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcplugin
import json
import os
import shutil

from resources.lib import common
from resources.lib.core import channels
from resources.lib.core import sorting


def _load_cfg():
    data = common.read_json_safe(common.user_sorting_file)
    if not data or not isinstance(data, dict):
        return channels.DEFAULT_CONFIG_DATA.copy()
    return data


def _save_cfg(data):
    common.write_json_safe(common.user_sorting_file, data)


def _get_ordered_groups(cfg=None):
    if cfg is None:
        cfg = _load_cfg()
    groups = cfg.get('ordered_groups', channels.DEFAULT_GROUPS)
    return [list(g) for g in groups]


def _set_ordered_groups(groups, cfg=None):
    if cfg is None:
        cfg = _load_cfg()
    cfg['ordered_groups'] = groups
    _save_cfg(cfg)
    sorting.reload_config()


def PolishSettingsLevel():
    xbmcplugin.setContent(common.addon_handle, 'files')

    prefixes_url = common.build_url({'mode': 'polish_settings_prefixes'})
    li_prefixes = xbmcgui.ListItem('Ignorowane prefixy')
    li_prefixes.setArt({'icon': common.icon37, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=prefixes_url, listitem=li_prefixes, isFolder=True)

    suffixes_url = common.build_url({'mode': 'polish_settings_suffixes'})
    li_suffixes = xbmcgui.ListItem('Ignorowane sufiksy')
    li_suffixes.setArt({'icon': common.icon38, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=suffixes_url, listitem=li_suffixes, isFolder=True)

    fixes_url = common.build_url({'mode': 'polish_settings_fixes'})
    li_fixes = xbmcgui.ListItem('Wyjątki nazw')
    li_fixes.setArt({'icon': common.icon39, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=fixes_url, listitem=li_fixes, isFolder=True)

    group_keywords_url = common.build_url({'mode': 'polish_settings_group_keywords'})
    li_group_keywords = xbmcgui.ListItem('Słowa kluczowe grup polskich')
    li_group_keywords.setArt({'icon': common.icon3, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=group_keywords_url, listitem=li_group_keywords, isFolder=True)

    groups_manage_url = common.build_url({'mode': 'polish_settings_groups_manage'})
    li_groups_manage = xbmcgui.ListItem('Grupy polskie')
    li_groups_manage.setArt({'icon': common.icon3, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=groups_manage_url, listitem=li_groups_manage, isFolder=True)

    sorting_export_url = common.build_url({'mode': 'providers_sorting_export'})
    li_sorting_export = xbmcgui.ListItem('Zapisz układ polskich grup')
    li_sorting_export.setArt({'icon': common.icon20, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=sorting_export_url, listitem=li_sorting_export, isFolder=False)

    sorting_import_url = common.build_url({'mode': 'providers_sorting_import'})
    li_sorting_import = xbmcgui.ListItem('Wczytaj układ polskich grup')
    li_sorting_import.setArt({'icon': common.icon19, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=sorting_import_url, listitem=li_sorting_import, isFolder=False)

    reset_url = common.build_url({'mode': 'polish_settings_reset'})
    li_reset = xbmcgui.ListItem('Przywróć domyślne ustawienia polskiej TV')
    li_reset.setArt({'icon': common.icon12, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=reset_url, listitem=li_reset, isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)


def export_settings():
    if not os.path.exists(common.user_sorting_file):
        xbmcgui.Dialog().ok(common.addonname, 'Brak pliku ustawień do eksportu.')
        return
    dest = xbmcgui.Dialog().browseSingle(0, 'Wybierz folder eksportu', 'files')
    if not dest:
        return
    out_file = os.path.join(dest, 'user_sorting_backup.json')
    try:
        shutil.copy2(common.user_sorting_file, out_file)
        xbmcgui.Dialog().ok(common.addonname, f'Wyeksportowano ustawienia:\n{out_file}')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, f'Błąd eksportu:\n{str(e)}')


def import_settings():
    file_path = xbmcgui.Dialog().browseSingle(1, 'Wybierz plik ustawień Polskiej TV', 'files', '.json')
    if not file_path or not os.path.exists(file_path):
        return
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            xbmcgui.Dialog().ok(common.addonname, 'Nieprawidłowy format pliku.')
            return
        confirm = xbmcgui.Dialog().yesno(common.addonname, 'Czy nadpisać obecne ustawienia Polskiej TV?')
        if not confirm:
            return
        shutil.copy2(file_path, common.user_sorting_file)
        sorting.reload_config()
        xbmcgui.Dialog().ok(common.addonname, 'Zaimportowano ustawienia Polskiej TV.')
        xbmc.executebuiltin('Container.Refresh')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, f'Błąd importu:\n{str(e)}')


def reset_settings():
    confirm = xbmcgui.Dialog().yesno(common.addonname, 'Czy przywrócić domyślne ustawienia Polskiej TV?')
    if not confirm:
        return
    common.write_json_safe(common.user_sorting_file, channels.DEFAULT_CONFIG_DATA)
    sorting.reload_config()
    xbmcgui.Dialog().ok(common.addonname, 'Przywrócono ustawienia domyślne.')
    xbmc.executebuiltin('Container.Refresh')


def _list_editor(title, key, mode_add, mode_del):
    xbmcplugin.setContent(common.addon_handle, 'files')
    cfg = _load_cfg()
    items = cfg.get(key, [])

    add_url = common.build_url({'mode': mode_add})
    li_add = xbmcgui.ListItem('[COLOR lime]+ DODAJ[/COLOR]')
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=add_url, listitem=li_add, isFolder=False)

    for idx, val in enumerate(items):
        del_url = common.build_url({'mode': mode_del, 'idx': idx})
        li = xbmcgui.ListItem(val)
        li.addContextMenuItems([
            ('[COLOR red]Usuń[/COLOR]', f'RunPlugin({del_url})')
        ])
        xbmcplugin.addDirectoryItem(handle=common.addon_handle, url='', listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)


def PrefixesLevel():
    _list_editor('Prefixy', 'ignored_prefixes', 'polish_settings_prefix_add', 'polish_settings_prefix_del')


def SuffixesLevel():
    _list_editor('Suffixy', 'ignored_suffixes', 'polish_settings_suffix_add', 'polish_settings_suffix_del')


def _add_to_list(key):
    cfg = _load_cfg()
    kb = xbmc.Keyboard('', 'Dodaj wpis')
    kb.doModal()
    if not kb.isConfirmed():
        return
    val = kb.getText().strip()
    if not val:
        return
    items = cfg.get(key, [])
    if val not in items:
        items.append(val)
    cfg[key] = items
    _save_cfg(cfg)
    sorting.reload_config()
    xbmc.executebuiltin('Container.Refresh')


def _del_from_list(key):
    cfg = _load_cfg()
    idx = common.args.get('idx', [''])[0]
    if not str(idx).isdigit():
        return
    idx = int(idx)
    items = cfg.get(key, [])
    if 0 <= idx < len(items):
        items.pop(idx)
    cfg[key] = items
    _save_cfg(cfg)
    sorting.reload_config()
    xbmc.executebuiltin('Container.Refresh')


def AddPrefix():
    _add_to_list('ignored_prefixes')


def DeletePrefix():
    _del_from_list('ignored_prefixes')


def AddSuffix():
    _add_to_list('ignored_suffixes')


def DeleteSuffix():
    _del_from_list('ignored_suffixes')


def FixesLevel():
    xbmcplugin.setContent(common.addon_handle, 'files')
    cfg = _load_cfg()
    fixes = cfg.get('name_fixes', {})

    add_url = common.build_url({'mode': 'polish_settings_fix_add'})
    li_add = xbmcgui.ListItem('[COLOR lime]+ DODAJ WYJĄTEK[/COLOR]')
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=add_url, listitem=li_add, isFolder=False)

    for bad, good in sorted(fixes.items(), key=lambda x: x[0].lower()):
        li = xbmcgui.ListItem(f'{bad}  ->  {good}')
        del_url = common.build_url({'mode': 'polish_settings_fix_del', 'bad': bad})
        li.addContextMenuItems([
            ('[COLOR red]Usuń[/COLOR]', f'RunPlugin({del_url})')
        ])
        xbmcplugin.addDirectoryItem(handle=common.addon_handle, url='', listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)


def AddFix():
    cfg = _load_cfg()
    fixes = cfg.get('name_fixes', {})

    kb = xbmc.Keyboard('', 'Nazwa błędna')
    kb.doModal()
    if not kb.isConfirmed():
        return
    bad = kb.getText().strip()
    if not bad:
        return

    kb = xbmc.Keyboard('', 'Nazwa poprawna')
    kb.doModal()
    if not kb.isConfirmed():
        return
    good = kb.getText().strip()
    if not good:
        return

    fixes[bad] = good
    cfg['name_fixes'] = fixes
    _save_cfg(cfg)
    sorting.reload_config()
    xbmc.executebuiltin('Container.Refresh')


def DeleteFix():
    cfg = _load_cfg()
    fixes = cfg.get('name_fixes', {})
    bad = common.args.get('bad', [''])[0]
    if bad in fixes:
        del fixes[bad]
    cfg['name_fixes'] = fixes
    _save_cfg(cfg)
    sorting.reload_config()
    xbmc.executebuiltin('Container.Refresh')


def GroupKeywordsLevel():
    _list_editor('Grupy polskie', 'group_keywords', 'polish_settings_group_keyword_add', 'polish_settings_group_keyword_del')


def AddGroupKeyword():
    _add_to_list('group_keywords')


def DeleteGroupKeyword():
    _del_from_list('group_keywords')


def PolishGroupsManageLevel():
    xbmcplugin.setContent(common.addon_handle, 'files')
    cfg = _load_cfg()
    groups = _get_ordered_groups(cfg)

    for idx, grp in enumerate(groups):
        g_name = grp[0]
        g_channels = grp[1] if len(grp) > 1 else []

        url = common.build_url({'mode': 'polish_settings_group_channels', 'group_idx': idx})
        li = xbmcgui.ListItem(f'{idx+1}. {g_name}  [COLOR grey]({len(g_channels)})[/COLOR]')

        up_url = common.build_url({'mode': 'polish_settings_group_move_up', 'group_idx': idx})
        down_url = common.build_url({'mode': 'polish_settings_group_move_down', 'group_idx': idx})

        li.addContextMenuItems([
            ('[COLOR yellow]Przesuń grupę wyżej[/COLOR]', f'RunPlugin({up_url})'),
            ('[COLOR yellow]Przesuń grupę niżej[/COLOR]', f'RunPlugin({down_url})')
        ])

        xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)


def PolishGroupChannelsLevel():
    xbmcplugin.setContent(common.addon_handle, 'files')
    cfg = _load_cfg()
    groups = _get_ordered_groups(cfg)

    group_idx = common.args.get('group_idx', [''])[0]
    if not str(group_idx).isdigit():
        xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)
        return

    group_idx = int(group_idx)
    if group_idx < 0 or group_idx >= len(groups):
        xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)
        return

    group_name = groups[group_idx][0]
    group_channels = groups[group_idx][1]

    add_url = common.build_url({'mode': 'polish_settings_group_channel_add', 'group_idx': group_idx})
    li_add = xbmcgui.ListItem(f'[COLOR lime]+ DODAJ KANAŁ DO: {group_name}[/COLOR]')
    xbmcplugin.addDirectoryItem(handle=common.addon_handle, url=add_url, listitem=li_add, isFolder=False)

    for idx, ch_name in enumerate(group_channels):
        li = xbmcgui.ListItem(f'{idx+1}. {ch_name}')

        rename_url = common.build_url({
            'mode': 'polish_settings_group_channel_rename',
            'group_idx': group_idx,
            'channel_idx': idx
        })
        del_url = common.build_url({
            'mode': 'polish_settings_group_channel_delete',
            'group_idx': group_idx,
            'channel_idx': idx
        })
        up_url = common.build_url({
            'mode': 'polish_settings_group_channel_move_up',
            'group_idx': group_idx,
            'channel_idx': idx
        })
        down_url = common.build_url({
            'mode': 'polish_settings_group_channel_move_down',
            'group_idx': group_idx,
            'channel_idx': idx
        })

        li.addContextMenuItems([
            ('[COLOR yellow]Zmień nazwę wpisu[/COLOR]', f'RunPlugin({rename_url})'),
            ('[COLOR yellow]Przesuń wyżej[/COLOR]', f'RunPlugin({up_url})'),
            ('[COLOR yellow]Przesuń niżej[/COLOR]', f'RunPlugin({down_url})'),
            ('[COLOR red]Usuń z grupy[/COLOR]', f'RunPlugin({del_url})')
        ])

        xbmcplugin.addDirectoryItem(handle=common.addon_handle, url='', listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)


def PolishGroupMoveUp():
    cfg = _load_cfg()
    groups = _get_ordered_groups(cfg)

    group_idx = common.args.get('group_idx', [''])[0]
    if not str(group_idx).isdigit():
        return
    group_idx = int(group_idx)

    if 0 < group_idx < len(groups):
        groups[group_idx - 1], groups[group_idx] = groups[group_idx], groups[group_idx - 1]
        _set_ordered_groups(groups, cfg)

    xbmc.executebuiltin('Container.Refresh')


def PolishGroupMoveDown():
    cfg = _load_cfg()
    groups = _get_ordered_groups(cfg)

    group_idx = common.args.get('group_idx', [''])[0]
    if not str(group_idx).isdigit():
        return
    group_idx = int(group_idx)

    if 0 <= group_idx < len(groups) - 1:
        groups[group_idx + 1], groups[group_idx] = groups[group_idx], groups[group_idx + 1]
        _set_ordered_groups(groups, cfg)

    xbmc.executebuiltin('Container.Refresh')


def PolishGroupChannelAdd():
    cfg = _load_cfg()
    groups = _get_ordered_groups(cfg)

    group_idx = common.args.get('group_idx', [''])[0]
    if not str(group_idx).isdigit():
        return
    group_idx = int(group_idx)

    if group_idx < 0 or group_idx >= len(groups):
        return

    kb = xbmc.Keyboard('', 'Dodaj nazwę kanału do grupy')
    kb.doModal()
    if not kb.isConfirmed():
        return

    val = kb.getText().strip()
    if not val:
        return

    channels_list = groups[group_idx][1]
    if val not in channels_list:
        channels_list.append(val)
        groups[group_idx][1] = channels_list
        _set_ordered_groups(groups, cfg)

    xbmc.executebuiltin('Container.Refresh')


def PolishGroupChannelRename():
    cfg = _load_cfg()
    groups = _get_ordered_groups(cfg)

    group_idx = common.args.get('group_idx', [''])[0]
    channel_idx = common.args.get('channel_idx', [''])[0]

    if not str(group_idx).isdigit() or not str(channel_idx).isdigit():
        return

    group_idx = int(group_idx)
    channel_idx = int(channel_idx)

    if group_idx < 0 or group_idx >= len(groups):
        return

    channels_list = groups[group_idx][1]
    if channel_idx < 0 or channel_idx >= len(channels_list):
        return

    current_name = channels_list[channel_idx]
    kb = xbmc.Keyboard(current_name, 'Zmień nazwę wpisu kanału')
    kb.doModal()
    if not kb.isConfirmed():
        return

    new_name = kb.getText().strip()
    if not new_name:
        return

    channels_list[channel_idx] = new_name
    groups[group_idx][1] = channels_list
    _set_ordered_groups(groups, cfg)

    xbmc.executebuiltin('Container.Refresh')


def PolishGroupChannelDelete():
    cfg = _load_cfg()
    groups = _get_ordered_groups(cfg)

    group_idx = common.args.get('group_idx', [''])[0]
    channel_idx = common.args.get('channel_idx', [''])[0]

    if not str(group_idx).isdigit() or not str(channel_idx).isdigit():
        return

    group_idx = int(group_idx)
    channel_idx = int(channel_idx)

    if group_idx < 0 or group_idx >= len(groups):
        return

    channels_list = groups[group_idx][1]
    if channel_idx < 0 or channel_idx >= len(channels_list):
        return

    del channels_list[channel_idx]
    groups[group_idx][1] = channels_list
    _set_ordered_groups(groups, cfg)

    xbmc.executebuiltin('Container.Refresh')


def PolishGroupChannelMoveUp():
    cfg = _load_cfg()
    groups = _get_ordered_groups(cfg)

    group_idx = common.args.get('group_idx', [''])[0]
    channel_idx = common.args.get('channel_idx', [''])[0]

    if not str(group_idx).isdigit() or not str(channel_idx).isdigit():
        return

    group_idx = int(group_idx)
    channel_idx = int(channel_idx)

    if group_idx < 0 or group_idx >= len(groups):
        return

    channels_list = groups[group_idx][1]
    if 0 < channel_idx < len(channels_list):
        channels_list[channel_idx - 1], channels_list[channel_idx] = channels_list[channel_idx], channels_list[channel_idx - 1]
        groups[group_idx][1] = channels_list
        _set_ordered_groups(groups, cfg)

    xbmc.executebuiltin('Container.Refresh')


def PolishGroupChannelMoveDown():
    cfg = _load_cfg()
    groups = _get_ordered_groups(cfg)

    group_idx = common.args.get('group_idx', [''])[0]
    channel_idx = common.args.get('channel_idx', [''])[0]

    if not str(group_idx).isdigit() or not str(channel_idx).isdigit():
        return

    group_idx = int(group_idx)
    channel_idx = int(channel_idx)

    if group_idx < 0 or group_idx >= len(groups):
        return

    channels_list = groups[group_idx][1]
    if 0 <= channel_idx < len(channels_list) - 1:
        channels_list[channel_idx + 1], channels_list[channel_idx] = channels_list[channel_idx], channels_list[channel_idx + 1]
        groups[group_idx][1] = channels_list
        _set_ordered_groups(groups, cfg)

    xbmc.executebuiltin('Container.Refresh')