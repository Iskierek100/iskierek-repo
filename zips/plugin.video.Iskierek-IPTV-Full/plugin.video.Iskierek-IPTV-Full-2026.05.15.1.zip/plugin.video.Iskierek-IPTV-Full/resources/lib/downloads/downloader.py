# -*- coding: utf-8 -*-
# downloader.py
import os
import re
import time
import threading
import urllib.request
import ssl
import xbmc
import xbmcgui
from resources.lib import common
from resources.lib.providers import provider_api


_download_thread = None
_download_cancel = False

_progress_bg = None
_progress_lock = threading.Lock()


def safe_filename(name):
    if not name:
        return "plik"
    name = re.sub(r'[\\/:*?"<>|]+', '_', str(name))
    name = name.strip().strip('.')
    return name or "plik"


def choose_download_dir():
    default_dir = common.addon.getSetting('recordings_dir').strip()
    if default_dir and os.path.exists(default_dir):
        return default_dir

    path = xbmcgui.Dialog().browseSingle(
        0,
        'Wybierz folder docelowy',
        'files'
    )
    return path


def _open_url(url, start_byte=0):
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    headers = {'User-Agent': 'Mozilla/5.0'}
    if start_byte > 0:
        headers['Range'] = f'bytes={start_byte}-'

    req = urllib.request.Request(url, headers=headers)
    return urllib.request.urlopen(req, context=ctx, timeout=60)


# ── PASEK POSTĘPU NA DOLE KODI ───────────────────────────────

def _progress_open(title):
    global _progress_bg
    with _progress_lock:
        try:
            if _progress_bg:
                _progress_bg.close()
        except Exception:
            pass

        try:
            _progress_bg = xbmcgui.DialogProgressBG()
            _progress_bg.create(common.addonname, f'Pobieranie: {title}')
        except Exception:
            _progress_bg = None


def _progress_update(percent, title, text):
    global _progress_bg
    with _progress_lock:
        if not _progress_bg:
            return
        try:
            percent = max(0, min(100, int(percent)))
            _progress_bg.update(percent, common.addonname, f'{title} - {text}')
        except Exception:
            pass


def _progress_close():
    global _progress_bg
    with _progress_lock:
        try:
            if _progress_bg:
                _progress_bg.close()
        except Exception:
            pass
        _progress_bg = None


def _state_label(state):
    if state == 'downloading':
        return '[COLOR gold]POBIERANIE[/COLOR]'
    if state == 'completed':
        return '[COLOR lime]ZAKOŃCZONE[/COLOR]'
    if state == 'cancelled':
        return '[COLOR red]ANULOWANE[/COLOR]'
    if state == 'error':
        return '[COLOR red]BŁĄD[/COLOR]'
    if state == 'queued':
        return '[COLOR orange]W KOLEJCE[/COLOR]'
    return '[COLOR gray]BRAK[/COLR]'


# ── STATUS POBIERANIA ────────────────────────────────────────

def get_download_status():
    try:
        return common.read_json_safe(common.download_status_file)
    except Exception:
        return {}


def _save_download_status(status):
    try:
        common.write_json_safe(common.download_status_file, status)
    except Exception:
        pass


def _clear_download_status():
    try:
        if os.path.exists(common.download_status_file):
            os.remove(common.download_status_file)
    except Exception:
        pass


def is_downloading():
    status = get_download_status()
    return status.get('active', False)


def _is_cancel_requested():
    """Sprawdza plik statusu czy ktoś zażądał przerwania."""
    global _download_cancel
    if _download_cancel:
        return True
    try:
        status = get_download_status()
        if status.get('cancel_requested', False):
            _download_cancel = True
            return True
    except Exception:
        pass
    return False


# ── HISTORIA POBIERANIA ─────────────────────────────────────

def _get_history():
    try:
        data = common.read_json_safe(common.download_history_file)
        if isinstance(data, list):
            return data
        return []
    except Exception:
        return []


def _save_history(history):
    try:
        common.write_json_safe(common.download_history_file, history[-50:])
    except Exception:
        pass


def _add_to_history(entry):
    history = _get_history()
    history.append(entry)
    _save_history(history)


def clear_history():
    _save_history([])
    xbmcgui.Dialog().notification(
        common.addonname,
        'Historia pobierania wyczyszczona',
        xbmcgui.NOTIFICATION_INFO,
        2000
    )


# ── KOLEJKA POBIERANIA ──────────────────────────────────────

def _get_queue():
    try:
        data = common.read_json_safe(common.download_queue_file)
        if isinstance(data, list):
            return data
        return []
    except Exception:
        return []


def _save_queue(queue):
    try:
        common.write_json_safe(common.download_queue_file, queue)
    except Exception:
        pass


def _add_to_queue(entry):
    queue = _get_queue()
    # sprawdź czy już nie ma takiego samego w kolejce
    for item in queue:
        if item.get('output_path') == entry.get('output_path'):
            return False
    queue.append(entry)
    _save_queue(queue)
    return True


def _remove_from_queue(index):
    queue = _get_queue()
    if 0 <= index < len(queue):
        queue.pop(index)
        _save_queue(queue)


def _clear_queue():
    _save_queue([])


def _pop_next_from_queue():
    queue = _get_queue()
    if not queue:
        return None
    item = queue.pop(0)
    _save_queue(queue)
    return item


def _process_queue():
    """Sprawdza kolejkę i rozpoczyna następne pobieranie jeśli jest coś w kolejce."""
    next_item = _pop_next_from_queue()
    if not next_item:
        return

    url = next_item.get('url', '')
    output_path = next_item.get('output_path', '')
    title = next_item.get('title', '')

    if not url or not output_path or not title:
        _process_queue()
        return

    xbmcgui.Dialog().notification(
        common.addonname,
        f'Kolejka: rozpoczynam pobieranie: {title}',
        xbmcgui.NOTIFICATION_INFO,
        3000
    )

    xbmc.sleep(1000)
    _start_background_download_internal(url, output_path, title)


# ── KONTROLA POBIERANIA ─────────────────────────────────────

def stop_download():
    global _download_cancel
    _download_cancel = True

    status = get_download_status()
    if status.get('active'):
        status['active'] = False
        status['state'] = 'cancelled'
        status['cancel_requested'] = True
        _save_download_status(status)

    _progress_close()

    xbmcgui.Dialog().notification(
        common.addonname,
        'Pobieranie zatrzymane',
        xbmcgui.NOTIFICATION_INFO,
        2000
    )


def stop_download_and_queue():
    """Zatrzymuje pobieranie i czyści całą kolejkę."""
    global _download_cancel
    _download_cancel = True

    status = get_download_status()
    if status.get('active'):
        status['active'] = False
        status['state'] = 'cancelled'
        status['cancel_requested'] = True
        status['skip_queue'] = True
        _save_download_status(status)

    _clear_queue()
    _progress_close()

    xbmcgui.Dialog().notification(
        common.addonname,
        'Pobieranie i kolejka zatrzymane',
        xbmcgui.NOTIFICATION_INFO,
        2000
    )


# ── PODGLĄD NA ŻYWO ─────────────────────────────────────────

def download_info():
    status = get_download_status()

    if not status or not status.get('title'):
        xbmcgui.Dialog().ok(common.addonname, 'Brak danych o pobieraniu.')
        return

    if not status.get('active'):
        title = status.get('title', 'Nieznany')
        state = _state_label(status.get('state', ''))
        percent = int(status.get('percent', 0) or 0)
        mb_read = float(status.get('mb_read', 0) or 0)
        mb_total = float(status.get('mb_total', 0) or 0)
        elapsed = status.get('elapsed', '')
        error = status.get('error', '')

        lines = [
            f'Tytuł: {title}',
            f'Status: {state}',
            f'Postęp: {percent}%',
        ]

        if mb_total > 0:
            lines.append(f'Pobrano: {mb_read:.1f} / {mb_total:.1f} MB')
        elif mb_read > 0:
            lines.append(f'Pobrano: {mb_read:.1f} MB')

        if elapsed:
            lines.append(f'Czas: {elapsed}')

        if error:
            lines.append(f'Błąd: {error}')

        queue = _get_queue()
        if queue:
            lines.append(f'\nW kolejce: {len(queue)} pozycji')

        xbmcgui.Dialog().ok(common.addonname, '\n'.join(lines))
        return

    _download_info_live()


def _download_info_live():
    while True:
        status = get_download_status()

        if not status or not status.get('active'):
            download_info()
            return

        title = status.get('title', 'Nieznany')
        state = _state_label(status.get('state', ''))
        percent = int(status.get('percent', 0) or 0)
        mb_read = float(status.get('mb_read', 0) or 0)
        mb_total = float(status.get('mb_total', 0) or 0)
        speed = status.get('speed', '')
        elapsed = status.get('elapsed', '')

        queue = _get_queue()
        queue_info = f'  |  W kolejce: {len(queue)}' if queue else ''

        line1 = f'Tytuł: {title}'
        line2 = f'Status: {state}  |  Postęp: {percent}%{queue_info}'

        if mb_total > 0:
            line3 = f'{mb_read:.1f} / {mb_total:.1f} MB'
        else:
            line3 = f'{mb_read:.1f} MB'

        if speed:
            line3 += f'  |  {speed}'
        if elapsed:
            line3 += f'  |  {elapsed}'

        choice = xbmcgui.Dialog().yesno(
            common.addonname,
            f'{line1}\n{line2}\n{line3}',
            nolabel='Wyjdź',
            yeslabel='Przerwij'
        )

        if choice:
            stop_download()
            return

        return


# ── WZNAWIANIE POBIERANIA ───────────────────────────────────

def _resume_download():
    status = get_download_status()

    if status.get('active'):
        xbmcgui.Dialog().notification(
            common.addonname,
            'Już trwa pobieranie',
            xbmcgui.NOTIFICATION_INFO,
            2000
        )
        return

    state = status.get('state', '')
    if state not in ('cancelled', 'error'):
        xbmcgui.Dialog().notification(
            common.addonname,
            'Brak przerwanego pobierania do wznowienia',
            xbmcgui.NOTIFICATION_INFO,
            2000
        )
        return

    output_path = status.get('output_path', '')
    title = status.get('title', '')
    url = status.get('url', '')

    if not output_path or not title:
        xbmcgui.Dialog().notification(
            common.addonname,
            'Brak danych do wznowienia',
            xbmcgui.NOTIFICATION_ERROR,
            2000
        )
        return

    if not url:
        xbmcgui.Dialog().ok(
            common.addonname,
            'Nie można wznowić pobierania.\n'
            'Link do pliku nie został zapisany.\n\n'
            'Rozpocznij pobieranie ponownie z listy.'
        )
        return

    temp_path = output_path + '.part'
    if not os.path.exists(temp_path):
        xbmcgui.Dialog().ok(
            common.addonname,
            'Plik częściowy (.part) nie istnieje.\n'
            'Nie można wznowić - rozpocznij pobieranie od nowa.'
        )
        return

    part_size = os.path.getsize(temp_path)
    part_mb = part_size / (1024 * 1024)

    if not xbmcgui.Dialog().yesno(
        common.addonname,
        f'Wznowić pobieranie?\n\n'
        f'Tytuł: {title}\n'
        f'Pobrano: {part_mb:.1f} MB'
    ):
        return

    _start_background_download(url, output_path, title)


# ── MENEDŻER POBIERANIA ─────────────────────────────────────

def download_manager():
    import xbmcplugin

    xbmcplugin.setContent(common.addon_handle, 'files')
    xbmcplugin.setPluginCategory(common.addon_handle, 'Menedżer pobierania')

    status = get_download_status()

    # status na górze
    if status.get('active'):
        title = status.get('title', '')
        percent = int(status.get('percent', 0) or 0)
        speed = status.get('speed', '')
        mb_read = float(status.get('mb_read', 0) or 0)
        mb_total = float(status.get('mb_total', 0) or 0)

        if mb_total > 0:
            top_label = f'POBIERANIE: {title} | {percent}% | {mb_read:.1f}/{mb_total:.1f} MB | {speed}'
        else:
            top_label = f'POBIERANIE: {title} | {mb_read:.1f} MB | {speed}'

        top_icon = common.icon25
    else:
        state = _state_label(status.get('state', ''))
        title = status.get('title', '')
        if title:
            top_label = f'Status: {state} | {title}'
        else:
            top_label = 'Status: Brak aktywnego pobierania'
        top_icon = common.icon26

    url_info = common.build_url({'mode': 'download_info'})
    li = xbmcgui.ListItem(top_label)
    li.setArt({'icon': top_icon, 'thumb': top_icon, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, url_info, li, False)

    # wznów
    can_resume = False
    if not status.get('active') and status.get('state') in ('cancelled', 'error'):
        part_path = status.get('output_path', '') + '.part'
        if status.get('url') and part_path and os.path.exists(part_path):
            can_resume = True

    if can_resume:
        url_resume = common.build_url({'mode': 'download_resume'})
        li = xbmcgui.ListItem('Wznów przerwane pobieranie')
        li.setArt({'icon': common.icon12, 'fanart': common.fanart})
        xbmcplugin.addDirectoryItem(common.addon_handle, url_resume, li, False)

    # zatrzymaj
    stop_icon = common.icon25 if status.get('active') else common.icon26
    url_stop = common.build_url({'mode': 'download_stop'})
    li = xbmcgui.ListItem('Zatrzymaj pobieranie')
    li.setArt({'icon': stop_icon, 'thumb': stop_icon, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, url_stop, li, False)

    # zatrzymaj i wyczyść kolejkę
    url_stop_all = common.build_url({'mode': 'download_stop_all'})
    li = xbmcgui.ListItem('Zatrzymaj pobieranie i wyczyść kolejkę')
    li.setArt({'icon': common.icon40, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, url_stop_all, li, False)

    # kolejka
    queue = _get_queue()
    queue_label = f'Kolejka pobierania ({len(queue)} pozycji)' if queue else 'Kolejka pobierania (pusta)'
    url_queue = common.build_url({'mode': 'download_queue'})
    li = xbmcgui.ListItem(queue_label)
    li.setArt({'icon': common.icon13, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, url_queue, li, False)

    # historia
    history = _get_history()
    history_label = f'Historia pobierania ({len(history)} pozycji)' if history else 'Historia pobierania (pusta)'
    url_history = common.build_url({'mode': 'download_history'})
    li = xbmcgui.ListItem(history_label)
    li.setArt({'icon': common.icon13, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, url_history, li, False)

    # wyczyść historię
    url_clear = common.build_url({'mode': 'download_clear_history'})
    li = xbmcgui.ListItem('Wyczyść historię pobierania')
    li.setArt({'icon': common.icon29, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, url_clear, li, False)

    # otwórz folder
    url_folder = common.build_url({'mode': 'download_open_folder'})
    li = xbmcgui.ListItem('Otwórz folder pobranych')
    li.setArt({'icon': common.icon11, 'fanart': common.fanart})
    xbmcplugin.addDirectoryItem(common.addon_handle, url_folder, li, False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=False)


def download_queue_menu():
    import xbmcplugin

    queue = _get_queue()

    xbmcplugin.setContent(common.addon_handle, 'files')
    xbmcplugin.setPluginCategory(common.addon_handle, 'Kolejka pobierania')

    if not queue:
        li = xbmcgui.ListItem('Kolejka jest pusta')
        li.setArt({'icon': common.icon17, 'fanart': common.fanart})
        xbmcplugin.addDirectoryItem(common.addon_handle, '', li, False)
    else:
        for idx, entry in enumerate(queue):
            title = entry.get('title', 'Nieznany')
            url_remove = common.build_url({'mode': 'download_queue_remove', 'queue_index': str(idx)})
            li = xbmcgui.ListItem(f'{idx + 1}. {title}')
            li.setArt({'icon': common.icon4, 'fanart': common.fanart})
            xbmcplugin.addDirectoryItem(common.addon_handle, url_remove, li, False)

    # wyczyść kolejkę
    if queue:
        url_clear = common.build_url({'mode': 'download_queue_clear'})
        li = xbmcgui.ListItem('Wyczyść całą kolejkę')
        li.setArt({'icon': common.icon29, 'fanart': common.fanart})
        xbmcplugin.addDirectoryItem(common.addon_handle, url_clear, li, False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=False)


def download_queue_remove_item():
    idx = common.args.get('queue_index', [''])[0]
    try:
        idx = int(idx)
        queue = _get_queue()
        if 0 <= idx < len(queue):
            title = queue[idx].get('title', '')
            _remove_from_queue(idx)
            xbmcgui.Dialog().notification(common.addonname, f'Usunięto: {title}', xbmcgui.NOTIFICATION_INFO, 2000)
    except Exception:
        pass
    xbmc.executebuiltin('Container.Refresh')


def download_queue_clear_all():
    if xbmcgui.Dialog().yesno(common.addonname, 'Wyczyścić całą kolejkę pobierania?'):
        _clear_queue()
        xbmcgui.Dialog().notification(common.addonname, 'Kolejka wyczyszczona', xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def download_history_menu():
    import xbmcplugin

    history = _get_history()

    xbmcplugin.setContent(common.addon_handle, 'files')
    xbmcplugin.setPluginCategory(common.addon_handle, 'Historia pobierania')

    if not history:
        li = xbmcgui.ListItem('Historia jest pusta')
        li.setArt({'icon': common.icon17, 'fanart': common.fanart})
        xbmcplugin.addDirectoryItem(common.addon_handle, '', li, False)
    else:
        for entry in reversed(history):
            title = entry.get('title', 'Nieznany')
            state = _state_label(entry.get('state', ''))
            date = entry.get('date', '')
            mb = float(entry.get('mb_total', 0) or 0)
            elapsed = entry.get('elapsed', '')

            size_str = f'{mb:.1f} MB' if mb > 0 else '0 MB'

            parts = [state, title, size_str]
            if elapsed:
                parts.append(elapsed)
            parts.append(date)

            label = ' | '.join(parts)

            if entry.get('state') == 'completed':
                icon = common.icon25
            else:
                icon = common.icon26

            li = xbmcgui.ListItem(label)
            li.setArt({'icon': icon, 'thumb': icon, 'fanart': common.fanart})
            xbmcplugin.addDirectoryItem(common.addon_handle, '', li, False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=False)


def download_stop_action():
    if is_downloading():
        if xbmcgui.Dialog().yesno(common.addonname, 'Zatrzymać pobieranie?\nKolejka będzie kontynuowana.'):
            stop_download()
    else:
        xbmcgui.Dialog().notification(common.addonname, 'Nie trwa żadne pobieranie', xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def download_stop_all_action():
    if is_downloading() or _get_queue():
        if xbmcgui.Dialog().yesno(common.addonname, 'Zatrzymać pobieranie i wyczyścić całą kolejkę?'):
            stop_download_and_queue()
    else:
        xbmcgui.Dialog().notification(common.addonname, 'Nie trwa żadne pobieranie i kolejka jest pusta', xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def download_open_folder_action():
    rec_dir = common.addon.getSetting('recordings_dir').strip()
    if rec_dir and os.path.exists(rec_dir):
        xbmc.executebuiltin(f'ActivateWindow(Videos,{rec_dir},return)')
    else:
        xbmcgui.Dialog().notification(common.addonname, 'Folder pobranych nie jest ustawiony', xbmcgui.NOTIFICATION_ERROR, 2000)


def download_clear_history_action():
    if xbmcgui.Dialog().yesno(common.addonname, 'Wyczyścić historię pobierania?'):
        clear_history()
    xbmc.executebuiltin('Container.Refresh')


def download_resume_action():
    _resume_download()
    xbmc.executebuiltin('Container.Refresh')

def _show_queue_dialog():
    while True:
        queue = _get_queue()

        if not queue:
            xbmcgui.Dialog().ok(common.addonname, 'Kolejka pobierania jest pusta.')
            return

        items = []
        for idx, entry in enumerate(queue):
            title = entry.get('title', 'Nieznany')
            items.append(f'{idx + 1}. {title}')

        items.append('Wyczyść całą kolejkę')

        choice = xbmcgui.Dialog().select(f'Kolejka pobierania ({len(queue)} pozycji)', items)

        if choice < 0:
            return

        if choice == len(items) - 1:
            if xbmcgui.Dialog().yesno(common.addonname, 'Wyczyścić całą kolejkę pobierania?'):
                _clear_queue()
                xbmcgui.Dialog().notification(
                    common.addonname,
                    'Kolejka wyczyszczona',
                    xbmcgui.NOTIFICATION_INFO,
                    2000
                )
            continue

        if choice < len(queue):
            entry = queue[choice]
            title = entry.get('title', 'Nieznany')

            action = xbmcgui.Dialog().select(
                title,
                ['Usuń z kolejki', 'Przenieś na początek kolejki']
            )

            if action == 0:
                _remove_from_queue(choice)
                xbmcgui.Dialog().notification(
                    common.addonname,
                    f'Usunięto z kolejki: {title}',
                    xbmcgui.NOTIFICATION_INFO,
                    2000
                )

            elif action == 1:
                queue = _get_queue()
                if 0 <= choice < len(queue):
                    item = queue.pop(choice)
                    queue.insert(0, item)
                    _save_queue(queue)
                    xbmcgui.Dialog().notification(
                        common.addonname,
                        f'Przeniesiono na początek: {title}',
                        xbmcgui.NOTIFICATION_INFO,
                        2000
                    )


def _show_history_dialog():
    history = _get_history()

    if not history:
        xbmcgui.Dialog().ok(common.addonname, 'Historia pobierania jest pusta.')
        return

    items = []

    for entry in reversed(history):
        title = entry.get('title', 'Nieznany')
        state = _state_label(entry.get('state', ''))
        date = entry.get('date', '')
        mb = float(entry.get('mb_total', 0) or 0)
        elapsed = entry.get('elapsed', '')

        size_str = f'{mb:.1f} MB' if mb > 0 else '0 MB'
        time_str = elapsed if elapsed else ''

        if time_str:
            items.append(f'{state} | {title} | {size_str} | {time_str} | {date}')
        else:
            items.append(f'{state} | {title} | {size_str} | {date}')

    xbmcgui.Dialog().select('Historia pobierania', items)


# ── FORMATOWANIE ────────────────────────────────────────────

def _format_elapsed(seconds):
    try:
        s = int(seconds)
        h = s // 3600
        m = (s % 3600) // 60
        sec = s % 60
        if h > 0:
            return f'{h}h {m}m {sec}s'
        elif m > 0:
            return f'{m}m {sec}s'
        else:
            return f'{sec}s'
    except:
        return ''


def _format_speed(bytes_per_sec):
    try:
        if bytes_per_sec >= 1024 * 1024:
            return f'{bytes_per_sec / (1024 * 1024):.1f} MB/s'
        elif bytes_per_sec >= 1024:
            return f'{bytes_per_sec / 1024:.0f} KB/s'
        else:
            return f'{bytes_per_sec:.0f} B/s'
    except:
        return ''


# ── POBIERANIE W TLE ────────────────────────────────────────

def _download_file_background(url, output_path, title):
    global _download_cancel, _download_thread

    _download_cancel = False
    temp_path = output_path + '.part'
    existing_size = 0

    if os.path.exists(temp_path):
        try:
            existing_size = os.path.getsize(temp_path)
        except:
            existing_size = 0

    start_time = time.time()
    bytes_read = existing_size

    _save_download_status({
        'active': True,
        'state': 'downloading',
        'title': title,
        'output_path': output_path,
        'url': url,
        'percent': 0,
        'mb_read': 0,
        'mb_total': 0,
        'speed': '',
        'start_time': time.strftime('%H:%M:%S'),
        'elapsed': ''
    })

    try:
        response = _open_url(url, existing_size)

        total_size = response.headers.get('Content-Length')
        try:
            total_size = int(total_size)
        except:
            total_size = 0

        content_range = response.headers.get('Content-Range')
        supports_resume = bool(content_range) or existing_size == 0

        if existing_size > 0 and not supports_resume:
            try:
                os.remove(temp_path)
            except:
                pass
            existing_size = 0
            bytes_read = 0
            response = _open_url(url, 0)
            total_size = response.headers.get('Content-Length')
            try:
                total_size = int(total_size)
            except:
                total_size = 0

        mode = 'ab' if existing_size > 0 else 'wb'
        full_size = (existing_size + total_size) if total_size > 0 else 0
        chunk_size = 1024 * 512
        last_status_update = 0
        last_speed_bytes = existing_size
        last_speed_time = start_time

        with open(temp_path, mode) as f:
            while True:
                if _is_cancel_requested():
                    xbmc.log('[Iskierek Download] Pobieranie anulowane', xbmc.LOGINFO)

                    try:
                        response.close()
                    except Exception:
                        pass

                    _save_download_status({
                        'active': False,
                        'state': 'cancelled',
                        'title': title,
                        'output_path': output_path,
                        'url': url,
                        'percent': int((bytes_read * 100) / full_size) if full_size > 0 else 0,
                        'mb_read': bytes_read / (1024 * 1024),
                        'mb_total': full_size / (1024 * 1024) if full_size > 0 else 0,
                        'speed': '',
                        'start_time': time.strftime('%H:%M:%S', time.localtime(start_time)),
                        'elapsed': _format_elapsed(time.time() - start_time)
                    })

                    _add_to_history({
                        'title': title,
                        'state': 'cancelled',
                        'date': time.strftime('%Y-%m-%d %H:%M'),
                        'mb_total': bytes_read / (1024 * 1024),
                        'elapsed': _format_elapsed(time.time() - start_time),
                        'output_path': output_path
                    })

                    _progress_close()

                    # sprawdź czy kontynuować kolejkę
                    status = get_download_status()
                    if not status.get('skip_queue'):
                        _process_queue()

                    return

                chunk = response.read(chunk_size)
                if not chunk:
                    break

                f.write(chunk)
                bytes_read += len(chunk)

                now = time.time()
                if now - last_status_update >= 1.0:
                    last_status_update = now
                    percent = int((bytes_read * 100) / full_size) if full_size > 0 else 0
                    mb_read = bytes_read / (1024 * 1024)
                    mb_total = full_size / (1024 * 1024) if full_size > 0 else 0
                    elapsed = _format_elapsed(now - start_time)

                    time_diff = now - last_speed_time
                    if time_diff > 0:
                        speed_bps = (bytes_read - last_speed_bytes) / time_diff
                        speed_str = _format_speed(speed_bps)
                    else:
                        speed_str = ''
                    last_speed_bytes = bytes_read
                    last_speed_time = now

                    queue = _get_queue()
                    queue_info = f' | Kolejka: {len(queue)}' if queue else ''

                    _save_download_status({
                        'active': True,
                        'state': 'downloading',
                        'title': title,
                        'output_path': output_path,
                        'url': url,
                        'percent': percent,
                        'mb_read': mb_read,
                        'mb_total': mb_total,
                        'speed': speed_str,
                        'start_time': time.strftime('%H:%M:%S', time.localtime(start_time)),
                        'elapsed': elapsed
                    })

                    if mb_total > 0:
                        bar_msg = f'{percent}% | {mb_read:.1f}/{mb_total:.1f} MB | {speed_str} | {elapsed}{queue_info}'
                    else:
                        bar_msg = f'{mb_read:.1f} MB | {speed_str} | {elapsed}{queue_info}'

                    _progress_update(percent, title, bar_msg)

        if os.path.exists(output_path):
            os.remove(output_path)
        os.rename(temp_path, output_path)

        elapsed = _format_elapsed(time.time() - start_time)
        mb_final = os.path.getsize(output_path) / (1024 * 1024)

        _save_download_status({
            'active': False,
            'state': 'completed',
            'title': title,
            'output_path': output_path,
            'url': url,
            'percent': 100,
            'mb_read': mb_final,
            'mb_total': mb_final,
            'speed': '',
            'start_time': time.strftime('%H:%M:%S', time.localtime(start_time)),
            'elapsed': elapsed
        })

        _add_to_history({
            'title': title,
            'state': 'completed',
            'date': time.strftime('%Y-%m-%d %H:%M'),
            'mb_total': mb_final,
            'elapsed': elapsed,
            'output_path': output_path
        })

        _progress_close()

        xbmcgui.Dialog().notification(
            common.addonname,
            f'Pobrano: {title} ({mb_final:.1f} MB)',
            xbmcgui.NOTIFICATION_INFO,
            5000
        )

        # następny z kolejki
        _process_queue()

    except Exception as e:
        xbmc.log(f'[Iskierek Download] Błąd: {e}', xbmc.LOGERROR)
        elapsed = _format_elapsed(time.time() - start_time)

        _save_download_status({
            'active': False,
            'state': 'error',
            'title': title,
            'output_path': output_path,
            'url': url,
            'percent': 0,
            'mb_read': bytes_read / (1024 * 1024),
            'mb_total': 0,
            'speed': '',
            'error': str(e),
            'start_time': time.strftime('%H:%M:%S', time.localtime(start_time)),
            'elapsed': elapsed
        })

        _add_to_history({
            'title': title,
            'state': 'error',
            'date': time.strftime('%Y-%m-%d %H:%M'),
            'mb_total': 0,
            'elapsed': elapsed,
            'error': str(e),
            'output_path': output_path
        })

        _progress_close()

        xbmcgui.Dialog().notification(
            common.addonname,
            f'Błąd pobierania: {title}',
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )

        # przy błędzie też kontynuuj kolejkę
        _process_queue()

    finally:
        _download_thread = None


def _start_background_download_internal(url, output_path, title):
    """Wewnętrzne uruchamianie pobierania - bez pytań, używane przez kolejkę."""
    global _download_thread

    if _download_thread and _download_thread.is_alive():
        return False

    _progress_open(title)

    _download_thread = threading.Thread(
        target=_download_file_background,
        args=(url, output_path, title),
        daemon=True
    )
    _download_thread.start()
    return True


def _start_background_download(url, output_path, title):
    """Publiczne uruchamianie pobierania - jeśli trwa inne, dodaje do kolejki."""
    global _download_thread

    # sprawdź plik statusu czy coś się pobiera (może w innym procesie)
    status = get_download_status()
    currently_downloading = status.get('active', False)

    # sprawdź też lokalny wątek
    local_thread_alive = _download_thread and _download_thread.is_alive()

    if currently_downloading or local_thread_alive:
        # dodaj do kolejki
        added = _add_to_queue({
            'url': url,
            'output_path': output_path,
            'title': title
        })

        if added:
            queue = _get_queue()
            xbmcgui.Dialog().notification(
                common.addonname,
                f'Dodano do kolejki ({len(queue)}): {title}',
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
        else:
            xbmcgui.Dialog().notification(
                common.addonname,
                f'Już jest w kolejce: {title}',
                xbmcgui.NOTIFICATION_INFO,
                2000
            )
        return

    _start_background_download_internal(url, output_path, title)


# ── PUBLICZNE FUNKCJE POBIERANIA ─────────────────────────────

def download_vod(portal):
    provider = provider_api.get_provider(portal)

    title = common.args.get('title', ['Film'])[0]
    cmd = common.args.get('cmd', [''])[0]
    ext = common.args.get('ext', ['mp4'])[0]

    download_dir = choose_download_dir()
    if not download_dir:
        return

    filename = safe_filename(title) + '.' + ext.lstrip('.')
    output_path = os.path.join(download_dir, filename)

    if os.path.exists(output_path):
        if not xbmcgui.Dialog().yesno(
            common.addonname,
            f'Plik już istnieje:\n{filename}\n\nNadpisać?'
        ):
            return

    try:
        if portal.get('type') == 'xtream':
            stream_url = provider.getLinkVoD(portal, cmd, ext)
        elif portal.get('type') == 'm3u':
            stream_url = cmd
        else:
            stream_url = provider.getLinkVoD(portal['mac'], portal['url'], portal['serial'], cmd)

        if not stream_url:
            xbmcgui.Dialog().notification(common.addonname, "Nie udało się pobrać linku", xbmcgui.NOTIFICATION_ERROR)
            return

        _start_background_download(stream_url, output_path, title)

    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, f"Błąd pobierania filmu:\n{str(e)}")


def download_series(portal):
    provider = provider_api.get_provider(portal)

    title = common.args.get('title', ['Odcinek'])[0]
    cmd = common.args.get('cmd', [''])[0]
    ext = common.args.get('ext', ['mp4'])[0]
    episode = common.args.get('episode', ['1'])[0]

    download_dir = choose_download_dir()
    if not download_dir:
        return

    filename = safe_filename(title) + '.' + ext.lstrip('.')
    output_path = os.path.join(download_dir, filename)

    if os.path.exists(output_path):
        if not xbmcgui.Dialog().yesno(
            common.addonname,
            f'Plik już istnieje:\n{filename}\n\nNadpisać?'
        ):
            return

    try:
        if portal.get('type') == 'xtream':
            stream_url = provider.getLinkSeries(portal, cmd, ext)
        elif portal.get('type') == 'm3u':
            stream_url = cmd
        else:
            stream_url = provider.getLinkSeries(portal['mac'], portal['url'], portal['serial'], cmd, episode)

        if not stream_url:
            xbmcgui.Dialog().notification(common.addonname, "Nie udało się pobrać linku", xbmcgui.NOTIFICATION_ERROR)
            return

        _start_background_download(stream_url, output_path, title)

    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, f"Błąd pobierania odcinka:\n{str(e)}")