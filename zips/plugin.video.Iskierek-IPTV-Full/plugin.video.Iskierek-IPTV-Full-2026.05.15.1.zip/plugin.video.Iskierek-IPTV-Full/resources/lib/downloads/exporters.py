# -*- coding: utf-8 -*-
import os
import json
import xbmc
import xbmcgui
from resources.lib import common
from resources.lib import common
from resources.lib.providers import provider_api
import resources.lib.core.sorting as sorting


def _get_polish_sorted_channels(portal):
    provider = provider_api.get_provider(portal)

    if portal.get('type') == 'xtream':
        sorted_all = sorting.get_smart_sorted_list(provider, portal, None, None, common.addondir)
    else:
        sorted_all = sorting.get_smart_sorted_list(provider, portal['mac'], portal['url'], portal['serial'], common.addondir)

    if not sorted_all:
        return []

    saved_data = common.read_json_safe(common.selected_groups_file)
    default_groups = [g[0] for g in sorting.ORDERED_GROUPS]
    allowed_groups = saved_data.get('pl_supergroup', default_groups)

    final_channels = [
        ch for ch in sorted_all
        if not ch.get('is_header')
        and ch.get('_my_group_name') in allowed_groups
    ]

    return final_channels


def export_polish_m3u(portal):
    provider = provider_api.get_provider(portal)

    pd = xbmcgui.DialogProgressBG()
    pd.create(common.addonname, "Eksport listy M3U...")

    try:
        xbmc.log(f"[Iskierek Export] Start exportu dla: {portal.get('name')} ({portal.get('type')})", xbmc.LOGINFO)

        final_channels = _get_polish_sorted_channels(portal)

        if not final_channels:
            pd.close()
            xbmcgui.Dialog().notification(common.addonname, "Brak kanałów polskich do eksportu", xbmcgui.NOTIFICATION_ERROR)
            return

        export_dir = os.path.join(common.addondir, 'exports')
        if not os.path.exists(export_dir):
            os.makedirs(export_dir)

        safe_name = portal.get('name', 'provider').replace('/', '_').replace('\\', '_').strip()
        out_file = os.path.join(export_dir, f"{safe_name}_polska_tv.m3u")

        lines = ['#EXTM3U']
        failed_count = 0
        success_count = 0
        total_count = len(final_channels)

        for idx, ch in enumerate(final_channels, start=1):
            try:
                title = ch.get('display_name', ch.get('name', 'Kanał'))
                logo = ch.get('logo', '')
                group_title = ch.get('_my_group_name', 'Polska TV')
                cmd = ch.get('cmd', '')

                pd.update(int((idx / total_count) * 100), common.addonname, f"Eksport: {title}")

                if portal.get('type') == 'xtream':
                    stream_url = provider.getLinkTV(portal, cmd)
                else:
                    stream_url = common.build_url({
                        'mode': 'play_tv',
                        'cmd': cmd,
                        'title': title,
                        'logo_url': logo,
                        'portal': json.dumps(portal),
                        'plot': '',
                        'program': ''
                    })

                if not stream_url:
                    failed_count += 1
                    xbmc.log(f"[Iskierek Export] Brak linku dla kanału: {title}", xbmc.LOGWARNING)
                    continue

                extinf = f'#EXTINF:-1 tvg-name="{title}" group-title="{group_title}" tvg-logo="{logo}",{title}'
                lines.append(extinf)
                lines.append(stream_url)
                success_count += 1

            except Exception as ch_err:
                failed_count += 1
                xbmc.log(f"[Iskierek Export] Błąd kanału {ch.get('name', '???')}: {str(ch_err)}", xbmc.LOGERROR)
                continue

        if success_count == 0:
            pd.close()
            xbmcgui.Dialog().ok(common.addonname, "Nie udało się wyeksportować żadnego kanału.")
            return

        with open(out_file, 'w', encoding='utf-8', errors='ignore') as f:
            f.write('\n'.join(lines))

        pd.close()

        msg = f'Lista została zapisana:\n{out_file}\n\nKanały: {success_count}'
        if failed_count:
            msg += f'\nPominięte: {failed_count}'
        if portal.get('type') == 'stalker':
            msg += '\n\nDla Stalkera zapisano linki plugin:// do odtwarzania w Kodi.'

        xbmcgui.Dialog().ok(common.addonname, msg)

    except Exception as e:
        try:
            pd.close()
        except:
            pass
        xbmc.log(f"[Iskierek Export] Błąd eksportu głównego: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(common.addonname, f"Błąd eksportu M3U:\n{str(e)}")

def _get_group_sorted_channels(portal, target_group):
    provider = provider_api.get_provider(portal)

    if portal.get('type') == 'xtream':
        sorted_all = sorting.get_smart_sorted_list(provider, portal, None, None, common.addondir)
    else:
        sorted_all = sorting.get_smart_sorted_list(provider, portal['mac'], portal['url'], portal['serial'], common.addondir)

    if not sorted_all:
        return []

    final_channels = [
        ch for ch in sorted_all
        if not ch.get('is_header')
        and ch.get('_my_group_name') == target_group
    ]

    return final_channels


def export_group_m3u(portal):
    import json

    provider = provider_api.get_provider(portal)
    group_name = common.args.get('group_name', [''])[0]

    if not group_name:
        xbmcgui.Dialog().notification(common.addonname, "Brak nazwy grupy", xbmcgui.NOTIFICATION_ERROR)
        return

    pd = xbmcgui.DialogProgressBG()
    pd.create(common.addonname, f"Eksport grupy: {group_name}")

    try:
        xbmc.log(f"[Iskierek Export] Start exportu grupy: {group_name} dla {portal.get('name')} ({portal.get('type')})", xbmc.LOGINFO)

        final_channels = _get_group_sorted_channels(portal, group_name)

        if not final_channels:
            pd.close()
            xbmcgui.Dialog().notification(common.addonname, "Brak kanałów w tej grupie", xbmcgui.NOTIFICATION_ERROR)
            return

        export_dir = os.path.join(common.addondir, 'exports')
        if not os.path.exists(export_dir):
            os.makedirs(export_dir)

        safe_provider = portal.get('name', 'provider').replace('/', '_').replace('\\', '_').strip()
        safe_group = group_name.replace('/', '_').replace('\\', '_').strip()
        out_file = os.path.join(export_dir, f"{safe_provider}_{safe_group}.m3u")

        lines = ['#EXTM3U']
        failed_count = 0
        success_count = 0
        total_count = len(final_channels)

        for idx, ch in enumerate(final_channels, start=1):
            try:
                title = ch.get('display_name', ch.get('name', 'Kanał'))
                logo = ch.get('logo', '')
                cmd = ch.get('cmd', '')

                pd.update(int((idx / total_count) * 100), common.addonname, f"Eksport: {title}")

                if portal.get('type') == 'xtream':
                    stream_url = provider.getLinkTV(portal, cmd)
                else:
                    stream_url = provider.getLinkTV(portal['mac'], portal['url'], portal['serial'], cmd)

                if not stream_url:
                    failed_count += 1
                    xbmc.log(f"[Iskierek Export] Brak linku dla kanału: {title}", xbmc.LOGWARNING)
                    continue

                extinf = f'#EXTINF:-1 tvg-name="{title}" group-title="{group_name}" tvg-logo="{logo}",{title}'
                lines.append(extinf)
                lines.append(stream_url)
                success_count += 1

            except Exception as ch_err:
                failed_count += 1
                xbmc.log(f"[Iskierek Export] Błąd kanału {ch.get('name', '???')}: {str(ch_err)}", xbmc.LOGERROR)
                continue

        if success_count == 0:
            pd.close()
            xbmcgui.Dialog().ok(common.addonname, "Nie udało się wyeksportować żadnego kanału.")
            return

        with open(out_file, 'w', encoding='utf-8', errors='ignore') as f:
            f.write('\n'.join(lines))

        pd.close()

        msg = f'Grupa została zapisana:\n{out_file}\n\nKanały: {success_count}'
        if failed_count:
            msg += f'\nPominięte: {failed_count}'
        if portal.get('type') == 'stalker':
            msg += '\n\nUwaga: linki Stalker mogą być czasowe.'

        xbmcgui.Dialog().ok(common.addonname, msg)

    except Exception as e:
        try:
            pd.close()
        except:
            pass
        xbmc.log(f"[Iskierek Export] Błąd eksportu grupy: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(common.addonname, f"Błąd eksportu grupy:\n{str(e)}")
