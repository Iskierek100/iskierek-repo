# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import urllib.parse
import threading

from resources.lib import common,navigation,actions
from resources.lib.providers import provider_api
from resources.lib.menu import home_menu,provider_menu,settings_menu
from resources.lib.tv import groups as tv_groups,live as tv_live,epg as tv_epg
from resources.lib.vod import movies as vod_movies,series as vod_series
from resources.lib.tools import cache_tools,provider_manager,media_tools,providers_backup,keymap_tools,search
from resources.lib.downloads import exporters,downloader
from resources.lib.recording import recorder
from resources.lib.core import polish_settings
from resources.lib.tv import channel_switch
from resources.lib.tv import channel_overlay
from resources.lib.vod import vod_overlay, vod_switch
from resources.lib.tv import guide as tv_guide
from resources.lib.tv import guide_overlay
from resources.lib.pvr import pvr_bridge
from resources.lib.menu import pvr_menu
from resources.lib.tools import keymap_tools
from resources.lib.tv import live_window
from resources.lib import timeshift
from resources.lib.tv import zapper
from resources.lib.tools import proxy_tools

portal = common.get_current_portal()
mode = common.args.get('mode', None)

if portal:
    xbmcplugin.setPluginFanart(common.addon_handle, common.fanart)


def get_portal_from_args_or_current():
    current_portal = portal
    portal_arg = common.args.get('portal', [None])[0]
    if portal_arg:
        try:
            current_portal = json.loads(portal_arg)
        except:
            pass
    return current_portal

def recordTVProgram():
    current_portal = get_portal_from_args_or_current()
    recorder.start_recording_tv_program(current_portal)

def recordTVSchedule():
    current_portal = get_portal_from_args_or_current()
    recorder.add_scheduled_recording(current_portal)

def recordTVScheduleDelete():
    cmd = common.args.get('cmd', [''])[0]
    start_ts = common.args.get('start_ts', ['0'])[0]
    stop_ts = common.args.get('stop_ts', ['0'])[0]

    removed = recorder.delete_scheduled_recording_by_data(cmd, start_ts, stop_ts)
    if removed:
        xbmcgui.Dialog().notification(common.addonname, 'Usunięto nagranie z programatora', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification(common.addonname, 'Nie znaleziono wpisu w programatorze', xbmcgui.NOTIFICATION_ERROR)

def get_provider():
    return provider_api.get_provider(portal)

def open_live_window_route():
    live_window.open_live_window()
    try:
        xbmcplugin.endOfDirectory(common.addon_handle, succeeded=False, cacheToDisc=False)
    except Exception:
        pass

def start_playback_timeout(title, timeout=12):
    def _watch():
        player = xbmc.Player()
        waited = 0

        while waited < timeout * 10:
            xbmc.sleep(100)

            try:
                if player.isPlaying():
                    return
            except:
                return

            waited += 1

        try:
            if not player.isPlaying():
                player.stop()
                xbmcgui.Dialog().notification(
                    common.addonname,
                    f"Nie udało się uruchomić kanału: {title}",
                    xbmcgui.NOTIFICATION_ERROR,
                    4000
                )
        except:
            pass

    import threading
    t = threading.Thread(target=_watch)
    t.daemon = True
    t.start()

def _clear_stream_proxy_window_props():
    try:
        win = xbmcgui.Window(10000)
        win.clearProperty('IskierekCurrentStreamProxyEnabled')
        win.clearProperty('IskierekCurrentStreamProxyValue')
        win.clearProperty('IskierekCurrentStreamProxyNote')
    except Exception:
        pass


def _set_stream_proxy_window_props(enabled=False, value='', note=''):
    try:
        win = xbmcgui.Window(10000)
        win.setProperty('IskierekCurrentStreamProxyEnabled', '1' if enabled else '0')
        win.setProperty('IskierekCurrentStreamProxyValue', value or '')
        win.setProperty('IskierekCurrentStreamProxyNote', note or '')
    except Exception:
        pass


def _fail_tv_playback(title, message, timeout=4000):
    xbmcgui.Dialog().notification(
        common.addonname,
        message,
        xbmcgui.NOTIFICATION_ERROR,
        timeout
    )
    li = xbmcgui.ListItem(title)
    xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=False, listitem=li)


def _build_tv_display_title(title, program_name):
    if program_name:
        return f"{title} : [COLOR yellow]{program_name}[/COLOR]"
    return title


def _resolve_tv_stream_and_headers(current_portal, provider, cmd):
    if current_portal.get('type') == 'm3u':
        stream_url = cmd
        headers = f"User-Agent={provider.USER_AGENT}"

    elif current_portal.get('type') == 'xtream':
        stream_url = provider.getLinkTV(current_portal, cmd)
        headers = f"User-Agent={provider.USER_AGENT}"

    else:
        stream_url = provider.getLinkTV(
            current_portal['mac'],
            current_portal['url'],
            current_portal['serial'],
            cmd
        )
        headers = (
            f"User-Agent={provider.USER_AGENT}"
            f"&Referer={current_portal['url']}"
            f"&Cookie=mac={current_portal['mac']}; stb_lang=en; timezone=Europe%2FWarsaw;"
        )

    return stream_url, headers

def _playTV_legacy(current_portal, provider, title, cmd, logo, plot_desc, program_name):
    pd = xbmcgui.DialogProgressBG()
    pd.create(common.addonname, "Pobieranie TV...")

    try:
        stream_url, headers = _resolve_tv_stream_and_headers(current_portal, provider, cmd)
        pd.close()

    except Exception as e:
        pd.close()
        _fail_tv_playback(title, "Błąd TV: " + str(e), 4000)
        return

    if not stream_url:
        _fail_tv_playback(title, 'Nie udało się pobrać linku do strumienia', 3000)
        return

    display_title_osd = _build_tv_display_title(title, program_name)

    # zachowujemy logikę starego, działającego kodu 2
    if current_portal.get('type') == 'm3u' and str(stream_url).startswith('plugin://'):
        dummy = xbmcgui.ListItem(display_title_osd)
        xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=True, listitem=dummy)
        xbmc.sleep(150)
        xbmc.executebuiltin(f'PlayMedia({stream_url})')
        return

    li = xbmcgui.ListItem(display_title_osd)
    li.setPath(stream_url)
    li.setArt({'icon': logo, 'thumb': logo})
    li.setInfo('video', {
        'Title': display_title_osd,
        'Plot': plot_desc,
        'PlotOutline': program_name,
        'tvshowtitle': program_name,
        'mediatype': 'channel'
    })

    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)

    if current_portal.get('type') != 'm3u':
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        li.setProperty('inputstream.ffmpegdirect.stream_headers', headers)
        li.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        li.setProperty('inputstream.ffmpegdirect.infinite_buffer', 'false')
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')

    xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=True, listitem=li)
    start_playback_timeout(title, timeout=12)

def _playTV_with_proxy(current_portal, provider, title, cmd, logo, plot_desc, program_name):
    from resources.lib.tools import proxy_tools

    pd = xbmcgui.DialogProgressBG()
    pd.create(common.addonname, "Przygotowanie TV przez proxy...")

    stream_url = ''
    headers = ''
    relay_used = False
    final_stream_url = ''
    original_stream_url = ''

    try:
        ok, applied, api_msg = proxy_tools.begin_temporary_api_proxy()
        if not ok:
            pd.close()
            _fail_tv_playback(
                title,
                f'Proxy dla API jest włączone, ale nie działa.\n{api_msg}',
                4500
            )
            return

        try:
            stream_url, headers = _resolve_tv_stream_and_headers(current_portal, provider, cmd)
        finally:
            proxy_tools.end_temporary_api_proxy()

        if not stream_url:
            pd.close()
            _fail_tv_playback(title, 'Nie udało się pobrać linku do strumienia', 3000)
            return

        original_stream_url = stream_url
        final_stream_url = stream_url
        display_title_osd = _build_tv_display_title(title, program_name)

        # plugin:// odtwarzamy bezpośrednio
        if str(stream_url).startswith('plugin://'):
            pd.close()
            _set_stream_proxy_window_props(
                False,
                '',
                'Strumień plugin:// - relay proxy pominięto celowo.'
            )
            dummy = xbmcgui.ListItem(display_title_osd)
            xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=True, listitem=dummy)
            xbmc.sleep(150)
            xbmc.executebuiltin(f'PlayMedia({stream_url})')
            return

        # relay tylko dla prawdziwych zdalnych URL-i HTTP/HTTPS
        if proxy_tools.should_use_stream_proxy_for_url(stream_url):
            ready_ok, ready_msg = proxy_tools.verify_stream_proxy_ready(stream_url, headers)
            if not ready_ok:
                pd.close()
                _fail_tv_playback(
                    title,
                    f'Proxy dla strumienia nie działa poprawnie.\n{ready_msg}',
                    5000
                )
                return

            from resources.lib.tools import stream_relay

            relay_ok = False
            for _ in range(16):
                if stream_relay.check_relay_health():
                    relay_ok = True
                    break
                xbmc.sleep(250)

            if not relay_ok:
                pd.close()
                _fail_tv_playback(
                    title,
                    'Relay proxy nie działa.\nPoczekaj chwilę po włączeniu proxy albo zrestartuj Kodi.',
                    5000
                )
                return

            final_stream_url = stream_relay.build_relay_url(stream_url, headers)
            if not final_stream_url:
                pd.close()
                _fail_tv_playback(
                    title,
                    'Nie udało się zbudować lokalnego URL relay.',
                    4000
                )
                return

            relay_used = True

            xbmc.log(f'[Relay] Oryginalny URL: {original_stream_url}', xbmc.LOGINFO)
            xbmc.log(f'[Relay] Lokalny URL: {final_stream_url}', xbmc.LOGINFO)

            _set_stream_proxy_window_props(
                True,
                proxy_tools.get_stream_proxy_url(),
                'Strumień przechodzi przez lokalny relay i wybrane proxy.'
            )
        else:
            if proxy_tools.is_local_or_plugin_url(stream_url):
                note = 'Stream lokalny / Ace / plugin - relay pominięto celowo.'
            elif not proxy_tools.stream_proxy_is_required():
                note = 'Proxy dla strumieni jest wyłączone albo niewspierane dla tego typu proxy.'
            else:
                note = 'Ten URL nie kwalifikuje się do relay proxy.'

            _set_stream_proxy_window_props(False, '', note)

        pd.close()

    except Exception as e:
        try:
            proxy_tools.end_temporary_api_proxy()
        except Exception:
            pass

        pd.close()
        _fail_tv_playback(title, "Błąd TV: " + str(e), 4000)
        return

    display_title_osd = _build_tv_display_title(title, program_name)

    li = xbmcgui.ListItem(display_title_osd)
    li.setPath(final_stream_url)
    li.setArt({'icon': logo, 'thumb': logo})
    li.setInfo('video', {
        'Title': display_title_osd,
        'Plot': plot_desc,
        'PlotOutline': program_name,
        'tvshowtitle': program_name,
        'mediatype': 'channel'
    })

    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)

    # ffmpegdirect tylko tam, gdzie nie psuje Ace/local
    use_ffmpegdirect = (
        current_portal.get('type') != 'm3u'
        and not proxy_tools.is_local_or_plugin_url(original_stream_url)
    )

    if use_ffmpegdirect:
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        li.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        li.setProperty('inputstream.ffmpegdirect.infinite_buffer', 'false')
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')

        if headers and not relay_used:
            li.setProperty('inputstream.ffmpegdirect.stream_headers', headers)

    xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=True, listitem=li)
    start_playback_timeout(title, timeout=12)

def _fail_media_playback(title, message, timeout=4000):
    xbmcgui.Dialog().notification(
        common.addonname,
        message,
        xbmcgui.NOTIFICATION_ERROR,
        timeout
    )
    li = xbmcgui.ListItem(title)
    xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=False, listitem=li)


def _resolve_vod_stream_and_final_url(current_portal, provider, cmd, ext):
    if current_portal.get('type') == 'xtream':
        stream_url = provider.getLinkVoD(current_portal, cmd, ext)
        final_url = stream_url + "|User-Agent=vlc&verifypeer=false" if stream_url else ''
    else:
        stream_url = provider.getLinkVoD(
            current_portal['mac'],
            current_portal['url'],
            current_portal['serial'],
            cmd
        )
        final_url = stream_url

    return stream_url, final_url


def _resolve_series_stream_and_final_url(current_portal, provider, cmd, episode, ext):
    if current_portal.get('type') == 'xtream':
        stream_url = provider.getLinkSeries(current_portal, cmd, ext)
        final_url = stream_url + "|User-Agent=vlc&verifypeer=false" if stream_url else ''
    else:
        stream_url = provider.getLinkSeries(
            current_portal['mac'],
            current_portal['url'],
            current_portal['serial'],
            cmd,
            episode
        )
        final_url = stream_url

    return stream_url, final_url


def _build_vod_series_stream_headers(current_portal, provider):
    if current_portal.get('type') == 'stalker':
        return (
            f"User-Agent={provider.USER_AGENT}"
            f"&Referer={current_portal['url']}"
            f"&Cookie=mac={current_portal['mac']}; stb_lang=en; timezone=Europe%2FWarsaw;"
        )
    elif current_portal.get('type') == 'xtream':
        return "User-Agent=vlc"
    else:
        return f"User-Agent={provider.USER_AGENT}"


def _playVoD_legacy(current_portal, provider, title, cmd, logo, ext):
    pd = xbmcgui.DialogProgressBG()
    pd.create(common.addonname, "Pobieranie Filmu...")

    try:
        stream_url, final_url = _resolve_vod_stream_and_final_url(current_portal, provider, cmd, ext)
        pd.close()

    except Exception as e:
        pd.close()
        _fail_media_playback(title, "Błąd VOD: " + str(e), 4000)
        return

    if not stream_url:
        _fail_media_playback(title, 'Nie udało się pobrać linku VOD', 3000)
        return

    li = xbmcgui.ListItem(title)
    li.setPath(final_url)
    li.setArt({'icon': logo, 'thumb': logo})
    li.setInfo('video', {'Title': title})
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)

    if current_portal.get('type') == 'stalker':
        stalker_headers = (
            f"User-Agent={provider.USER_AGENT}"
            f"&Referer={current_portal['url']}"
            f"&Cookie=mac={current_portal['mac']}; stb_lang=en; timezone=Europe%2FWarsaw;"
        )
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'false')
        li.setProperty('inputstream.ffmpegdirect.stream_headers', stalker_headers)
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        li.setProperty('ResumeTime', '1')
        li.setProperty('TotalTime', '1')

    xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=True, listitem=li)


def _playVoD_with_proxy(current_portal, provider, title, cmd, logo, ext):
    from resources.lib.tools import proxy_tools

    pd = xbmcgui.DialogProgressBG()
    pd.create(common.addonname, "Przygotowanie Filmu przez proxy...")

    stream_url = ''
    final_url = ''
    original_stream_url = ''
    relay_used = False

    try:
        ok, applied, api_msg = proxy_tools.begin_temporary_api_proxy()
        if not ok:
            pd.close()
            _fail_media_playback(
                title,
                f'Proxy dla API jest włączone, ale nie działa.\n{api_msg}',
                4500
            )
            return

        try:
            stream_url, final_url = _resolve_vod_stream_and_final_url(current_portal, provider, cmd, ext)
        finally:
            proxy_tools.end_temporary_api_proxy()

        if not stream_url:
            pd.close()
            _fail_media_playback(title, 'Nie udało się pobrać linku VOD', 3000)
            return

        original_stream_url = stream_url
        headers = _build_vod_series_stream_headers(current_portal, provider)

        if proxy_tools.should_use_stream_proxy_for_url(stream_url):
            ready_ok, ready_msg = proxy_tools.verify_stream_proxy_ready(stream_url, headers)
            if not ready_ok:
                pd.close()
                _fail_media_playback(
                    title,
                    f'Proxy dla strumienia VOD nie działa poprawnie.\n{ready_msg}',
                    5000
                )
                return

            from resources.lib.tools import stream_relay

            relay_ok = False
            for _ in range(16):
                if stream_relay.check_relay_health():
                    relay_ok = True
                    break
                xbmc.sleep(250)

            if not relay_ok:
                pd.close()
                _fail_media_playback(
                    title,
                    'Relay proxy nie działa.\nPoczekaj chwilę po włączeniu proxy albo zrestartuj Kodi.',
                    5000
                )
                return

            final_url = stream_relay.build_relay_url(stream_url, headers)
            if not final_url:
                pd.close()
                _fail_media_playback(title, 'Nie udało się zbudować URL relay.', 4000)
                return

            relay_used = True

            xbmc.log(f'[Relay VOD] Oryginalny URL: {original_stream_url}', xbmc.LOGINFO)
            xbmc.log(f'[Relay VOD] Lokalny URL: {final_url}', xbmc.LOGINFO)

            _set_stream_proxy_window_props(
                True,
                proxy_tools.get_stream_proxy_url(),
                'VOD przechodzi przez lokalny relay i proxy.'
            )
        else:
            if proxy_tools.is_local_or_plugin_url(stream_url):
                note = 'VOD lokalny / Ace / plugin - relay pominięto celowo.'
            elif not proxy_tools.stream_proxy_is_required():
                note = 'Proxy dla strumieni jest wyłączone albo niewspierane dla tego typu proxy.'
            else:
                note = 'Ten URL VOD nie kwalifikuje się do relay proxy.'

            _set_stream_proxy_window_props(False, '', note)

        pd.close()

    except Exception as e:
        try:
            proxy_tools.end_temporary_api_proxy()
        except Exception:
            pass

        pd.close()
        _fail_media_playback(title, "Błąd VOD: " + str(e), 4000)
        return

    li = xbmcgui.ListItem(title)
    li.setPath(final_url)
    li.setArt({'icon': logo, 'thumb': logo})
    li.setInfo('video', {'Title': title})
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)

    if current_portal.get('type') == 'stalker' and not relay_used:
        stalker_headers = (
            f"User-Agent={provider.USER_AGENT}"
            f"&Referer={current_portal['url']}"
            f"&Cookie=mac={current_portal['mac']}; stb_lang=en; timezone=Europe%2FWarsaw;"
        )
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'false')
        li.setProperty('inputstream.ffmpegdirect.stream_headers', stalker_headers)
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        li.setProperty('ResumeTime', '1')
        li.setProperty('TotalTime', '1')

    elif relay_used:
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'false')
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')

        if '.m3u8' in str(original_stream_url).lower():
            li.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')

    xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=True, listitem=li)


def _playSeries_legacy(current_portal, provider, title, cmd, episode, logo, ext):
    pd = xbmcgui.DialogProgressBG()
    pd.create(common.addonname, f"Pobieranie Odc. {episode}...")

    try:
        stream_url, final_url = _resolve_series_stream_and_final_url(
            current_portal, provider, cmd, episode, ext
        )
        pd.close()

    except Exception as e:
        pd.close()
        _fail_media_playback(title, "Błąd Serialu: " + str(e), 4000)
        return

    if not stream_url:
        _fail_media_playback(title, 'Nie udało się pobrać linku serialu', 3000)
        return

    li = xbmcgui.ListItem(title)
    li.setPath(final_url)
    li.setArt({'icon': logo, 'thumb': logo})
    li.setInfo('video', {'Title': title})
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)

    if current_portal.get('type') == 'stalker':
        stalker_headers = (
            f"User-Agent={provider.USER_AGENT}"
            f"&Referer={current_portal['url']}"
            f"&Cookie=mac={current_portal['mac']}; stb_lang=en; timezone=Europe%2FWarsaw;"
        )
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'false')
        li.setProperty('inputstream.ffmpegdirect.stream_headers', stalker_headers)
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        li.setProperty('ResumeTime', '1')
        li.setProperty('TotalTime', '1')

    xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=True, listitem=li)


def _playSeries_with_proxy(current_portal, provider, title, cmd, episode, logo, ext):
    from resources.lib.tools import proxy_tools

    pd = xbmcgui.DialogProgressBG()
    pd.create(common.addonname, f"Przygotowanie Odc. {episode} przez proxy...")

    stream_url = ''
    final_url = ''
    original_stream_url = ''
    relay_used = False

    try:
        ok, applied, api_msg = proxy_tools.begin_temporary_api_proxy()
        if not ok:
            pd.close()
            _fail_media_playback(
                title,
                f'Proxy dla API jest włączone, ale nie działa.\n{api_msg}',
                4500
            )
            return

        try:
            stream_url, final_url = _resolve_series_stream_and_final_url(
                current_portal, provider, cmd, episode, ext
            )
        finally:
            proxy_tools.end_temporary_api_proxy()

        if not stream_url:
            pd.close()
            _fail_media_playback(title, 'Nie udało się pobrać linku serialu', 3000)
            return

        original_stream_url = stream_url
        headers = _build_vod_series_stream_headers(current_portal, provider)

        if proxy_tools.should_use_stream_proxy_for_url(stream_url):
            ready_ok, ready_msg = proxy_tools.verify_stream_proxy_ready(stream_url, headers)
            if not ready_ok:
                pd.close()
                _fail_media_playback(
                    title,
                    f'Proxy dla strumienia serialu nie działa poprawnie.\n{ready_msg}',
                    5000
                )
                return

            from resources.lib.tools import stream_relay

            relay_ok = False
            for _ in range(16):
                if stream_relay.check_relay_health():
                    relay_ok = True
                    break
                xbmc.sleep(250)

            if not relay_ok:
                pd.close()
                _fail_media_playback(
                    title,
                    'Relay proxy nie działa.\nPoczekaj chwilę po włączeniu proxy albo zrestartuj Kodi.',
                    5000
                )
                return

            final_url = stream_relay.build_relay_url(stream_url, headers)
            if not final_url:
                pd.close()
                _fail_media_playback(title, 'Nie udało się zbudować URL relay.', 4000)
                return

            relay_used = True

            xbmc.log(f'[Relay Series] Oryginalny URL: {original_stream_url}', xbmc.LOGINFO)
            xbmc.log(f'[Relay Series] Lokalny URL: {final_url}', xbmc.LOGINFO)

            _set_stream_proxy_window_props(
                True,
                proxy_tools.get_stream_proxy_url(),
                'Serial przechodzi przez lokalny relay i proxy.'
            )
        else:
            if proxy_tools.is_local_or_plugin_url(stream_url):
                note = 'Serial lokalny / Ace / plugin - relay pominięto celowo.'
            elif not proxy_tools.stream_proxy_is_required():
                note = 'Proxy dla strumieni jest wyłączone albo niewspierane dla tego typu proxy.'
            else:
                note = 'Ten URL serialu nie kwalifikuje się do relay proxy.'

            _set_stream_proxy_window_props(False, '', note)

        pd.close()

    except Exception as e:
        try:
            proxy_tools.end_temporary_api_proxy()
        except Exception:
            pass

        pd.close()
        _fail_media_playback(title, "Błąd Serialu: " + str(e), 4000)
        return

    li = xbmcgui.ListItem(title)
    li.setPath(final_url)
    li.setArt({'icon': logo, 'thumb': logo})
    li.setInfo('video', {'Title': title})
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)

    if current_portal.get('type') == 'stalker' and not relay_used:
        stalker_headers = (
            f"User-Agent={provider.USER_AGENT}"
            f"&Referer={current_portal['url']}"
            f"&Cookie=mac={current_portal['mac']}; stb_lang=en; timezone=Europe%2FWarsaw;"
        )
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'false')
        li.setProperty('inputstream.ffmpegdirect.stream_headers', stalker_headers)
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        li.setProperty('ResumeTime', '1')
        li.setProperty('TotalTime', '1')

    elif relay_used:
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'false')
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')

        if '.m3u8' in str(original_stream_url).lower():
            li.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')

    xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=True, listitem=li)

def playTV():
    current_portal = get_portal_from_args_or_current()
    provider = provider_api.get_provider(current_portal)

    title = common.args.get('title', ['TV'])[0]
    cmd = common.args.get('cmd', [''])[0]
    logo = common.args.get('logo_url', [''])[0]
    plot_desc = common.args.get('plot', [''])[0]
    program_name = common.args.get('program', [''])[0]

    common.write_json_safe(common.playback_state_file, {'type': 'tv'})
    set_plugin_playback_identity('plugin.video.Iskierek-IPTV-Full', True)
    _clear_stream_proxy_window_props()

    try:
        idx = common.args.get('channel_index', [''])[0]
        if str(idx).isdigit():
            state = common.read_json_safe(common.channel_state_file)
            channels = state.get('channels', [])
            state_portal = state.get('portal', current_portal)
            channel_switch.save_channel_state(channels, int(idx), state_portal)
    except Exception:
        pass

    if current_portal.get('use_f4m', False):
        xbmc.log(f"[Iskierek IPTV Full] Wymuszono f4mTester dla: {title}", xbmc.LOGINFO)
        play_f4m()
        return

    try:
        proxy_enabled = proxy_tools.is_proxy_enabled()
    except Exception:
        proxy_enabled = False

    # proxy OFF = dokładnie stara, sprawdzona logika
    if not proxy_enabled:
        _playTV_legacy(current_portal, provider, title, cmd, logo, plot_desc, program_name)
        return

    # proxy ON = nowa logika z API proxy + relay + bypass dla Ace/local
    _playTV_with_proxy(current_portal, provider, title, cmd, logo, plot_desc, program_name)



def set_plugin_playback_identity(plugin_id, is_tv=False):
    try:
        win = xbmcgui.Window(10000)
        if plugin_id:
            win.setProperty('IskierekPlaybackPlugin', plugin_id)
        else:
            win.clearProperty('IskierekPlaybackPlugin')

        if is_tv:
            win.setProperty('IskierekTvPlaybackActive', '1')
        else:
            win.clearProperty('IskierekTvPlaybackActive')
    except Exception:
        pass

def playTVIndexed():
    current_portal = get_portal_from_args_or_current()
    idx = common.args.get('channel_index', [''])[0]

    try:
        if str(idx).isdigit():
            state = common.read_json_safe(common.channel_state_file)
            channels = state.get('channels', [])
            state_portal = state.get('portal', current_portal)
            channel_switch.save_channel_state(channels, int(idx), state_portal)
    except:
        pass

    playTV()


def play_f4m():
    provider = get_provider()

    f4m_id = None
    possible_ids = ["plugin.video.f4mTester", "plugin.video.f4mtester", "plugin.video.shani"]

    for aid in possible_ids:
        if xbmc.getCondVisibility(f'System.HasAddon("{aid}")'):
            f4m_id = aid
            break
        try:
            xbmcaddon.Addon(id=aid)
            f4m_id = aid
            break
        except:
            pass

    if not f4m_id:
        xbmcgui.Dialog().notification(common.addonname, "Brak wtyczki f4mTester! Zainstaluj ją.", xbmcgui.NOTIFICATION_ERROR)
        return

    title = common.args.get('title', ['TV'])[0]
    cmd = common.args.get('cmd', [''])[0]
    logo = common.args.get('logo_url', [''])[0]

    try:
        if portal.get('type') == 'xtream':
            stream_url = provider.getLinkTV(portal, cmd)
        else:
            stream_url = provider.getLinkTV(portal['mac'], portal['url'], portal['serial'], cmd)
    except Exception as e:
        xbmcgui.Dialog().notification(common.addonname, "Błąd f4mTester: " + str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    if ".ts" in stream_url:
        stream_url = stream_url.replace(".ts", ".m3u8")
    elif ".mp4" in stream_url:
        stream_url = stream_url.replace(".mp4", ".m3u8")
    elif ".mkv" in stream_url:
        stream_url = stream_url.replace(".mkv", ".m3u8")
    elif not stream_url.endswith(".m3u8"):
        if "?" in stream_url:
            stream_url = stream_url.replace("?", ".m3u8?")
        else:
            stream_url = stream_url + ".m3u8"

    default_ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36"
    stream_url_with_headers = stream_url + "|User-Agent=" + urllib.parse.quote(default_ua)

    u_url = urllib.parse.quote_plus(stream_url_with_headers)
    u_name = urllib.parse.quote_plus(title)
    u_icon = urllib.parse.quote_plus(logo)

    def close_error_dialogs(delay=5.0, interval=0.2):
        import time
        loops = int(delay / interval)
        for _ in range(loops):
            time.sleep(interval)
            xbmc.executebuiltin("Dialog.Close(error,true)")
            xbmc.executebuiltin("Dialog.Close(ok,true)")

    t = threading.Thread(target=close_error_dialogs, args=(5.0, 0.2))
    t.daemon = True
    t.start()

    dummy_item = xbmcgui.ListItem(label="Start f4mTester...")
    dummy_item.setPath(common.icon0)
    dummy_item.setContentLookup(False)
    dummy_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=True, listitem=dummy_item)

    f4m_path = f"plugin://{f4m_id}/?streamtype=HLSRETRY&name={u_name}&iconImage={u_icon}&url={u_url}"
    xbmc.log(f"[Iskierek IPTV Full] Uruchamiam f4mTester ({f4m_id}): {f4m_path}", xbmc.LOGINFO)
    xbmc.sleep(300)
    xbmc.executebuiltin(f"RunPlugin({f4m_path})")


def playVoD():
    current_portal = get_portal_from_args_or_current()
    provider = provider_api.get_provider(current_portal)

    title = common.args.get('title', ['Film'])[0]
    cmd = common.args.get('cmd', [''])[0]
    logo = common.args.get('logo_url', [''])[0]
    ext = common.args.get('ext', ['mp4'])[0]

    common.write_json_safe(common.playback_state_file, {'type': 'vod'})
    set_plugin_playback_identity(None, False)
    _clear_stream_proxy_window_props()

    try:
        proxy_enabled = proxy_tools.is_proxy_enabled()
    except Exception:
        proxy_enabled = False

    if not proxy_enabled:
        _playVoD_legacy(current_portal, provider, title, cmd, logo, ext)
        return

    _playVoD_with_proxy(current_portal, provider, title, cmd, logo, ext)


def playVoDIndexed():
    idx=common.args.get('vod_index',[''])[0]
    try:
        if str(idx).isdigit():
            state=common.read_json_safe(common.vod_state_file)
            items=state.get('items',[])
            state_portal=state.get('portal',portal)
            content_type=state.get('content_type','vod')
            vod_switch.save_vod_state(items,int(idx),state_portal,content_type)
    except:
        pass
    playVoD()

def playSeriesIndexed():
    idx=common.args.get('vod_index',[''])[0]
    try:
        if str(idx).isdigit():
            state=common.read_json_safe(common.vod_state_file)
            items=state.get('items',[])
            state_portal=state.get('portal',portal)
            content_type=state.get('content_type','series')
            vod_switch.save_vod_state(items,int(idx),state_portal,content_type)
    except:
        pass
    playSeries()

def open_any_overlay():
    playback_state = common.read_json_safe(common.playback_state_file)
    ptype = playback_state.get('type', '')

    try:
        if timeshift.is_timeshift_active():
            channel_overlay.open_overlay()
            return
    except Exception:
        pass

    if ptype == 'tv':
        channel_overlay.open_overlay()
        return

    if ptype in ['vod', 'series']:
        vod_overlay.open_overlay()
        return

    tv_state = common.read_json_safe(common.channel_state_file)
    vod_state = common.read_json_safe(common.vod_state_file)

    if vod_state.get('items'):
        vod_overlay.open_overlay()
        return
    if tv_state.get('channels'):
        channel_overlay.open_overlay()
        return

    xbmcgui.Dialog().notification(common.addonname, 'Brak zapisanej listy do overlay', xbmcgui.NOTIFICATION_ERROR)


def playSeries():
    current_portal = get_portal_from_args_or_current()
    provider = provider_api.get_provider(current_portal)

    title = common.args.get('title', ['Serial'])[0]
    cmd = common.args.get('cmd', [''])[0]
    episode = common.args.get('episode', ['1'])[0]
    logo = common.args.get('logo_url', [''])[0]
    ext = common.args.get('ext', ['mp4'])[0]

    common.write_json_safe(common.playback_state_file, {'type': 'series'})
    set_plugin_playback_identity(None, False)
    _clear_stream_proxy_window_props()

    try:
        proxy_enabled = proxy_tools.is_proxy_enabled()
    except Exception:
        proxy_enabled = False

    if not proxy_enabled:
        _playSeries_legacy(current_portal, provider, title, cmd, episode, logo, ext)
        return

    _playSeries_with_proxy(current_portal, provider, title, cmd, episode, logo, ext)


def pvr_bridge_start():
    if _is_pvr_busy():
        xbmcgui.Dialog().notification(
            'PVR Bridge',
            'Eksport PVR już trwa...',
            xbmcgui.NOTIFICATION_INFO,
            2500
        )
        return

    pd = xbmcgui.DialogProgressBG()
    _set_pvr_busy(True)

    try:
        current_portal = get_portal_from_args_or_current()
        if not current_portal:
            pd.close()
            xbmcgui.Dialog().ok(common.addonname, 'Brak aktywnego portalu.')
            return

        provider_info = pvr_bridge.get_provider_label(current_portal)

        pd.create('PVR Bridge', 'Przygotowanie eksportu...')
        pd.update(5, 'PVR Bridge', 'Sprawdzanie portalu...')

        xbmc.sleep(150)

        pd.update(20, 'PVR Bridge', 'Zapisywanie listy M3U...')
        pvr_bridge.refresh_exports(current_portal)

        urls = pvr_bridge.get_urls(8099)

        xbmc.sleep(150)

        pd.update(55, 'PVR Bridge', 'Odświeżanie klienta PVR...')
        refresh_pvr_soft()

        xbmc.sleep(250)

        pd.update(80, 'PVR Bridge', 'Przygotowanie otwarcia TV...')
        xbmc.sleep(300)

        pd.update(100, 'PVR Bridge', 'Gotowe')

        xbmcgui.Dialog().notification(
            'PVR Bridge',
            'Dostawca: %s | M3U zapisane' % provider_info.get('name', 'IPTV'),
            xbmcgui.NOTIFICATION_INFO,
            3500
        )

        pd.close()
        xbmc.sleep(600)


    except Exception as e:
        try:
            pd.close()
        except:
            pass
        xbmcgui.Dialog().ok(common.addonname, 'Błąd uruchamiania PVR Bridge:\n%s' % str(e))

    finally:
        _set_pvr_busy(False)
        try:
            pd.close()
        except:
            pass

def get_pvr_simple_enabled():
    try:
        query = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Addons.GetAddonDetails",
            "params": {
                "addonid": "pvr.iptvsimple",
                "properties": ["enabled", "installed"]
            }
        }

        response = xbmc.executeJSONRPC(json.dumps(query))
        data = json.loads(response)

        addon = data.get('result', {}).get('addon', {})
        installed = addon.get('installed', False)
        enabled = addon.get('enabled', False)

        if not installed:
            return None

        return bool(enabled)

    except Exception as e:
        xbmc.log(f'[Iskierek IPTV Full] get_pvr_simple_enabled error: {str(e)}', xbmc.LOGWARNING)
        return None


def set_pvr_simple_enabled(state):
    try:
        cmd = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Addons.SetAddonEnabled",
            "params": {
                "addonid": "pvr.iptvsimple",
                "enabled": bool(state)
            }
        }

        response = xbmc.executeJSONRPC(json.dumps(cmd))
        xbmc.log(f'[Iskierek IPTV Full] set_pvr_simple_enabled({state}) response: {response}', xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log(f'[Iskierek IPTV Full] set_pvr_simple_enabled error: {str(e)}', xbmc.LOGERROR)
        return False


def refresh_pvr_client_experimental():
    try:
        current_state = get_pvr_simple_enabled()

        if current_state is None:
            xbmcgui.Dialog().ok(common.addonname, 'PVR IPTV Simple nie jest zainstalowany.')
            return



        pd = xbmcgui.DialogProgressBG()
        pd.create('Odśwież Klienta PVR', 'Trwa restart klienta PVR IPTV Simple...')
        pd.update(10, 'Odśwież Klienta PVR', 'Przygotowanie...')

        xbmc.log('[Iskierek IPTV Full] experimental PVR refresh start', xbmc.LOGINFO)

        pd.update(35, 'Odśwież Klienta PVR', 'Wyłączanie PVR IPTV Simple...')
        set_pvr_simple_enabled(False)
        xbmc.sleep(2000)

        pd.update(70, 'Odśwież Klienta PVR', 'Włączanie PVR IPTV Simple...')
        set_pvr_simple_enabled(True)
        xbmc.sleep(3000)

        pd.update(90, 'Odśwież Klienta PVR', 'Odświeżanie PVR...')
        try:
            refresh_pvr_soft_strong()
        except Exception as e:
            xbmc.log(f'[Iskierek IPTV Full] refresh_pvr_soft_strong error: {str(e)}', xbmc.LOGWARNING)

        pd.update(100, 'Odśwież Klienta PVR', 'Gotowe')
        pd.close()

        xbmc.log('[Iskierek IPTV Full] experimental PVR refresh done', xbmc.LOGINFO)



    except Exception as e:
        try:
            pd.close()
        except:
            pass
        xbmc.log(f'[Iskierek IPTV Full] refresh_pvr_client_experimental error: {str(e)}', xbmc.LOGERROR)
        xbmcgui.Dialog().ok(common.addonname, 'Błąd odświeżania klienta PVR:\n%s' % str(e))



def pvr_bridge_refresh():
    current_portal = get_portal_from_args_or_current()
    try:
        pvr_bridge.refresh_exports(current_portal)
        provider_info = pvr_bridge.get_provider_label(current_portal)
        urls = pvr_bridge.get_urls(8099)

        refresh_pvr_soft()

        xbmcgui.Dialog().ok(
            'PVR Bridge',
            'Odświeżono eksport PVR.\n\n'
            'Dostawca: %s\n'
            'Typ: %s\n'
            'Fallback: %s\n\n'
            'Folder eksportu:\n%s\n\n'
            'Lokalne M3U:\n%s\n\n'
            'EPG:\n%s' % (
                provider_info.get('name', 'IPTV'),
                provider_info.get('type', 'unknown'),
                'WŁ' if urls.get('fallback_enabled') else 'WYŁ',
                urls['export_folder'],
                urls['m3u_file'],
                urls['epg_file']
            )
        )
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, 'Błąd odświeżania PVR Bridge:\n%s' % str(e))


def pvr_bridge_stop():
    try:
        pvr_bridge.stop_server()
        xbmcgui.Dialog().ok('PVR Bridge', 'Serwer zatrzymany.')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, 'Błąd zatrzymywania PVR Bridge:\n%s' % str(e))

def refresh_pvr_soft():
    commands = [
        'PVR.RefreshChannels',
        'PVR.RefreshGuide',
        'Container.Refresh'
    ]

    for cmd in commands:
        try:
            xbmc.executebuiltin(cmd)
            xbmc.log(f'[Iskierek IPTV Full] executed builtin: {cmd}', xbmc.LOGINFO)
            xbmc.sleep(250)
        except Exception as e:
            xbmc.log(f'[Iskierek IPTV Full] builtin failed: {cmd} / {str(e)}', xbmc.LOGWARNING)

def open_pvr_tv():
    commands = [
        'ActivateWindow(TVChannels)',
        'ActivateWindow(MyPVRChannels)',
        'ActivateWindow(TVGuide)',
        'ActivateWindow(TV)'
    ]

    for cmd in commands:
        try:
            xbmc.executebuiltin(cmd)
            xbmc.log(f'[Iskierek IPTV Full] opened PVR window: {cmd}', xbmc.LOGINFO)
            return
        except Exception as e:
            xbmc.log(f'[Iskierek IPTV Full] failed PVR window: {cmd} / {str(e)}', xbmc.LOGWARNING)

    xbmcgui.Dialog().ok(common.addonname, 'Nie udało się otworzyć sekcji PVR TV.')

def pvr_bridge_choose_folder():
    try:
        ok = pvr_bridge.choose_export_folder()
        if ok:
            urls = pvr_bridge.get_urls(8099)
            xbmcgui.Dialog().ok(
                'PVR Bridge',
                'Zapisano folder eksportu.\n\nFolder:\n%s\n\nM3U:\n%s\n\nEPG:\n%s' % (
                    urls['export_folder'],
                    urls['m3u_file'],
                    urls['epg_file']
                )
            )
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, 'Błąd wyboru folderu PVR:\n%s' % str(e))

def pvr_toggle_fallback():
    try:
        state = pvr_bridge.toggle_fallback_enabled()
        if not state:
            pvr_bridge.stop_server()

        xbmcgui.Dialog().notification(
            'PVR Bridge',
            'Fallback server: %s' % ('WŁ' if state else 'WYŁ'),
            xbmcgui.NOTIFICATION_INFO,
            2500
        )

        xbmc.executebuiltin('Container.Refresh')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, 'Błąd zmiany fallback server:\n%s' % str(e))

def open_pvr_client_settings():
    try:
        xbmc.executebuiltin('Addon.OpenSettings(pvr.iptvsimple)')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, 'Nie udało się otworzyć ustawień PVR IPTV Simple:\n%s' % str(e))

def _is_pvr_busy():
    try:
        return xbmcgui.Window(10000).getProperty('iskierek_pvr_busy') == 'true'
    except:
        return False

def _set_pvr_busy(val):
    try:
        win = xbmcgui.Window(10000)
        if val:
            win.setProperty('iskierek_pvr_busy', 'true')
        else:
            win.clearProperty('iskierek_pvr_busy')
    except:
        pass

def ToggleAutoTimeshift():
    enabled = common.addon.getSetting('auto_timeshift') == 'true'
    common.addon.setSetting('auto_timeshift', 'false' if enabled else 'true')
    xbmc.executebuiltin('Container.Refresh')

def ToggleTimeshift():
    timeshift.toggle_timeshift()

def StopTimeshiftOnPlay():
    timeshift.stop_timeshift_on_play()


def RefreshTimeshiftPlayback():
    try:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        ok = timeshift.refresh_timeshift_playback()
        if not ok:
            xbmcgui.Dialog().notification(
                common.addonname,
                'Nie udało się odświeżyć timeshift',
                xbmcgui.NOTIFICATION_INFO,
                2500
            )
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmc.executebuiltin('Dialog.Close(busydialog)')


def PlayTimeshiftSnapshotCopy():
    ok = timeshift.play_timeshift_snapshot_copy()
    if not ok:
        xbmcgui.Dialog().notification(
            common.addonname,
            'Nie udało się uruchomić snapshotu timeshift',
            xbmcgui.NOTIFICATION_INFO,
            2500
        )

def playTVWithTimeshiftOption():
    current_portal = get_portal_from_args_or_current()

    try:
        common.write_json_safe(common.playback_state_file, {'type': 'tv'})
        set_plugin_playback_identity('plugin.video.Iskierek-IPTV-Full', True)
    except Exception:
        pass

    # Jeśli proxy dla strumieni jest włączone,
    # omijamy timeshift i lecimy bezpośrednio przez playTV(),
    # bo playback ma iść przez relay.
    try:
        from resources.lib.tools.proxy_tools import stream_proxy_is_required
        if stream_proxy_is_required():
            xbmc.log('[Iskierek Proxy] Proxy dla strumieni włączone - pomijam timeshift i uruchamiam playTV()', xbmc.LOGINFO)
            playTV()
            return
    except Exception as e:
        xbmc.log(f'[Iskierek Proxy] playTVWithTimeshiftOption proxy check error: {e}', xbmc.LOGWARNING)

    if common.addon.getSetting('auto_timeshift') == 'true' or timeshift.is_timeshift_enabled():
        ok = timeshift.play_channel_with_timeshift(current_portal)
        if ok:
            return

    playTV()

def StopTimeshiftOnPlay():
    timeshift.stop_timeshift_on_play()

def RefreshTimeshiftToLiveEdge():
    try:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        ok = timeshift.refresh_timeshift_to_live_edge(offset_seconds=5.0)
        if not ok:
            xbmcgui.Dialog().notification(
                common.addonname,
                'Nie udało się odświeżyć do końca timeshift',
                xbmcgui.NOTIFICATION_INFO,
                2500
            )
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmc.executebuiltin('Dialog.Close(busydialog)')

def _proxy_test_for_channel_route():
    from resources.lib.tools import proxy_tools

    current_portal = get_portal_from_args_or_current()
    provider = provider_api.get_provider(current_portal)

    title = common.args.get('title', [''])[0]
    cmd = common.args.get('cmd', [''])[0]

    try:
        if current_portal.get('type') == 'm3u':
            stream_url = cmd
        elif current_portal.get('type') == 'xtream':
            stream_url = provider.getLinkTV(current_portal, cmd)
        else:
            stream_url = provider.getLinkTV(
                current_portal['mac'],
                current_portal['url'],
                current_portal['serial'],
                cmd
            )
    except Exception as e:
        xbmcgui.Dialog().notification(
            common.addonname,
            f'Błąd pobierania linku: {e}',
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )
        return

    if not stream_url:
        xbmcgui.Dialog().notification(
            common.addonname,
            'Brak linku do strumienia',
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )
        return

    proxy_tools.test_proxies_for_channel(stream_url, title)

def _resolve_stream_url_for_channel_proxy():
    current_portal = get_portal_from_args_or_current()
    provider = provider_api.get_provider(current_portal)

    cmd = common.args.get('cmd', [''])[0]

    if current_portal.get('type') == 'm3u':
        return cmd

    if current_portal.get('type') == 'xtream':
        return provider.getLinkTV(current_portal, cmd)

    return provider.getLinkTV(
        current_portal['mac'],
        current_portal['url'],
        current_portal['serial'],
        cmd
    )


def _build_channel_play_url():
    current_portal = get_portal_from_args_or_current()

    return common.build_url({
        'mode': 'play_tv_ts',
        'cmd': common.args.get('cmd', [''])[0],
        'title': common.args.get('title', ['TV'])[0],
        'logo_url': common.args.get('logo_url', [''])[0],
        'portal': json.dumps(current_portal),
        'plot': common.args.get('plot', [''])[0],
        'program': common.args.get('program', [''])[0],
        'stop_ts': common.args.get('stop_ts', ['0'])[0],
        'channel_index': common.args.get('channel_index', [''])[0]
    })


def _proxy_pick_favorite_for_channel_route():
    from resources.lib.tools import proxy_tools

    try:
        stream_url = _resolve_stream_url_for_channel_proxy()
    except Exception as e:
        xbmcgui.Dialog().notification(
            common.addonname,
            f'Błąd pobierania linku kanału: {e}',
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )
        return

    title = common.args.get('title', [''])[0]
    play_url = _build_channel_play_url()
    proxy_tools.favorite_proxy_picker_for_channel(stream_url, title, play_url)


def _proxy_cycle_favorite_for_channel_route():
    from resources.lib.tools import proxy_tools

    try:
        stream_url = _resolve_stream_url_for_channel_proxy()
    except Exception as e:
        xbmcgui.Dialog().notification(
            common.addonname,
            f'Błąd pobierania linku kanału: {e}',
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )
        return

    title = common.args.get('title', [''])[0]
    play_url = _build_channel_play_url()
    proxy_tools.favorite_proxy_cycle_for_channel(stream_url, title, play_url)

def OpenM3UFolder():
    folder = bridge.get_export_folder()
    if not folder:
        xbmcgui.Dialog().ok(common.addonname, 'Nie ustawiono folderu eksportu M3U')
        return

    xbmc.executebuiltin(f'ActivateWindow(Videos,{folder},return)')

if mode is None:
    home_menu.homeLevel()

else:
    mode_key = mode[0]

    routes={
        'account_info':lambda:tv_epg.AccountInfoLevel(portal),
        'apply_keymap': lambda: keymap_tools.apply_keymap(),
        'cache':cache_tools.ClearLevel,
        'channels':lambda:tv_live.channelLevel(portal),
        'choose_recordings_dir': recorder.ChooseRecordingsDir,
        'delete_local_file':media_tools.DeleteLocalFile,
        'download_series':lambda:downloader.download_series(portal),
        'download_vod':lambda:downloader.download_vod(portal),
        'download_manager': lambda: downloader.download_manager(),
        'download_info': downloader.download_info,
        'download_stop': downloader.download_stop_action,
        'download_stop_all': downloader.download_stop_all_action,
        'download_resume': downloader.download_resume_action,
        'download_queue': downloader.download_queue_menu,
        'download_queue_remove': downloader.download_queue_remove_item,
        'download_queue_clear': downloader.download_queue_clear_all,
        'download_history': downloader.download_history_menu,
        'download_clear_history': downloader.download_clear_history_action,
        'download_open_folder': downloader.download_open_folder_action,
        'edit_pl_supergroup':lambda:actions.OpenPolishGroupSelectDialog(portal),
        'episode':lambda:vod_series.EpisodeLevel(portal),
        'export_group_m3u':lambda:exporters.export_group_m3u(portal),
        'export_polish_m3u':lambda:exporters.export_polish_m3u(portal),
        'global_search':search.GlobalSearchMenu,
        'global_search_results':search.GlobalSearchResults,
        'hidden_manager':lambda:actions.HiddenManagerLevel(portal),
        'hide_channel':lambda:actions.hideChannel(portal),
        'install_keymap':keymap_tools.install_keymap,
        'live_window': open_live_window_route,
        'lock_adult':lambda:(navigation.lock_adult(portal),xbmc.executebuiltin('Container.Refresh')),
        'm3u_lists_menu': lambda: settings_menu.M3UListsLevel(portal),
        'manage_groups_list':lambda:actions.OpenGroupSelectDialog(portal),
        'manage_groups_menu':lambda:actions.ManageGroupsMenu(portal),
        'media_manager':media_tools.MediaManagerLevel,
        'my_groups_view':lambda:actions.MyGroupsLevel(portal),
        'open_channel_overlay':open_any_overlay,
        'open_exports_dir': media_tools.OpenExportsDir,
        'open_group_select':lambda:actions.OpenGroupSelectDialog(portal),
        'open_live_window': live_window.open_live_window,
        'open_pvr_client_settings': open_pvr_client_settings,
        'open_pvr_tv': open_pvr_tv,
        'open_vod_overlay':vod_overlay.open_overlay,
        'parental_change_pin':navigation.change_parental_pin,
        'parental_manager':provider_manager.ParentalManagerLevel,
        'parental_toggle_global':provider_manager.ToggleGlobalParental,
        'play_local_file':media_tools.PlayLocalFile,
        'play_next_channel':channel_switch.play_next_channel,
        'play_next_vod':vod_switch.play_next,
        'play_prev_channel':channel_switch.play_prev_channel,
        'play_prev_vod':vod_switch.play_prev,
        'play_series':playSeries,
        'play_series_indexed':playSeriesIndexed,
        'play_timeshift_snapshot_copy': PlayTimeshiftSnapshotCopy,
        'play_tv':playTV,
        'play_tv_indexed':playTVIndexed,
        'play_tv_ts': playTVWithTimeshiftOption,
        'play_vod':playVoD,
        'play_vod_indexed':playVoDIndexed,
        'polish_groups_menu':lambda:tv_groups.PolishGroupsLevel(portal),
        'polish_settings':polish_settings.PolishSettingsLevel,
        'polish_settings_export':polish_settings.export_settings,
        'polish_settings_fix_add':polish_settings.AddFix,
        'polish_settings_fix_del':polish_settings.DeleteFix,
        'polish_settings_fixes':polish_settings.FixesLevel,
        'polish_settings_group_channel_add': polish_settings.PolishGroupChannelAdd,
        'polish_settings_group_channel_delete': polish_settings.PolishGroupChannelDelete,
        'polish_settings_group_channel_move_down': polish_settings.PolishGroupChannelMoveDown,
        'polish_settings_group_channel_move_up': polish_settings.PolishGroupChannelMoveUp,
        'polish_settings_group_channel_rename': polish_settings.PolishGroupChannelRename,
        'polish_settings_group_channels': polish_settings.PolishGroupChannelsLevel,
        'polish_settings_group_keyword_add':polish_settings.AddGroupKeyword,
        'polish_settings_group_keyword_del':polish_settings.DeleteGroupKeyword,
        'polish_settings_group_keywords':polish_settings.GroupKeywordsLevel,
        'polish_settings_group_move_down': polish_settings.PolishGroupMoveDown,
        'polish_settings_group_move_up': polish_settings.PolishGroupMoveUp,
        'polish_settings_groups_manage': polish_settings.PolishGroupsManageLevel,
        'polish_settings_import':polish_settings.import_settings,
        'polish_settings_prefix_add':polish_settings.AddPrefix,
        'polish_settings_prefix_del':polish_settings.DeletePrefix,
        'polish_settings_prefixes':polish_settings.PrefixesLevel,
        'polish_settings_reset':polish_settings.reset_settings,
        'polish_settings_suffix_add':polish_settings.AddSuffix,
        'polish_settings_suffix_del':polish_settings.DeleteSuffix,
        'polish_settings_suffixes':polish_settings.SuffixesLevel,
        'provider_add':provider_manager.AddProvider,
        'provider_delete':provider_manager.DeleteProvider,
        'provider_edit_f4m':provider_manager.EditProviderF4M,
        'provider_edit_m3u_path':provider_manager.EditProviderM3UPath,
        'provider_edit_m3u_source_type':provider_manager.EditProviderM3USourceType,
        'provider_edit_mac':provider_manager.EditProviderMac,
        'provider_edit_menu':provider_manager.ProviderEditMenu,
        'provider_edit_name':provider_manager.EditProviderName,
        'provider_edit_password':provider_manager.EditProviderPassword,
        'provider_edit_serial':provider_manager.EditProviderSerial,
        'provider_edit_url':provider_manager.EditProviderUrl,
        'provider_edit_username':provider_manager.EditProviderUsername,
        'provider_settings':lambda:settings_menu.ProviderSettingsLevel(portal),
        'provider_settings_groups':lambda:settings_menu.GroupsSettingsLevel(portal),
        'provider_settings_provider':lambda:settings_menu.ProviderEditSettingsLevel(portal),
        'provider_settings_recording':lambda:settings_menu.RecordingSettingsLevel(portal),
        'provider_settings_tools':lambda:settings_menu.ToolsSettingsLevel(portal),
        'provider_toggle_enabled':provider_manager.ToggleProviderEnabled,
        'providers_export':providers_backup.export_providers,
        'providers_import':providers_backup.import_providers,
        'providers_manager':provider_manager.ProvidersManagerLevel,
        'providers_sorting_export':providers_backup.export_sorting,
        'providers_sorting_import':providers_backup.import_sorting,
        'proxy_add_current_to_favorites': proxy_tools.proxy_add_current_to_favorites,
        'proxy_check_ip': proxy_tools.check_current_ip,
        'proxy_cycle_favorite_for_channel': _proxy_cycle_favorite_for_channel_route,
        'proxy_pick_favorite_for_channel': _proxy_pick_favorite_for_channel_route,
        'proxy_reset': proxy_tools.proxy_reset,
        'proxy_favorites': proxy_tools.favorite_proxies_menu,
        'proxy_settings': proxy_tools.proxy_settings_menu,
        'proxy_set_type': proxy_tools.proxy_set_type,
        'proxy_set_address': proxy_tools.proxy_set_address,
        'proxy_set_username': proxy_tools.proxy_set_username,
        'proxy_set_password': proxy_tools.proxy_set_password,
        'proxy_smart_scan': proxy_tools.smart_proxy_scan,
        'proxy_test': proxy_tools.test_proxy,
        'proxy_test_for_channel': _proxy_test_for_channel_route,
        'proxy_toggle_enabled': proxy_tools.proxy_toggle_enabled,
        'pvr_bridge_choose_folder': lambda: pvr_bridge_choose_folder(),
        'pvr_bridge_info': lambda: pvr_bridge.dialog_info(),
        'pvr_bridge_refresh': lambda: pvr_bridge_refresh(),
        'pvr_bridge_start': lambda: pvr_bridge_start(),
        'pvr_bridge_stop': lambda: pvr_bridge_stop(),
        'pvr_menu': lambda: pvr_menu.PVRMenuLevel(portal),
        'pvr_settings': lambda: pvr_menu.PVRSettingsLevel(portal),
        'pvr_toggle_fallback': lambda: pvr_toggle_fallback(),
        'record_schedule_delete':recorder.DeleteScheduledRecording,
        'record_schedule_info': recorder.ScheduledRecordingInfo,
        'record_schedule_manager':recorder.ScheduledRecordingsLevel,
        'record_tv_program':recordTVProgram,
        'record_tv_schedule':recordTVSchedule,
        'record_tv_schedule_delete':recordTVScheduleDelete,
        'record_tv_start':lambda:recorder.start_recording_tv(portal),
        'record_tv_stop':recorder.stop_recording_tv,
        'recording_info':recorder.show_recording_info,
        'refresh_list':lambda:xbmc.executebuiltin('Container.Refresh'),
        'refresh_pvr_client_experimental': refresh_pvr_client_experimental,
        'refresh_timeshift_playback': RefreshTimeshiftPlayback,
        'refresh_timeshift_to_live_edge': RefreshTimeshiftToLiveEdge,
        'remove_keymap': lambda: keymap_tools.remove_keymap(),
        'rename_channel':lambda:actions.renameChannel(portal),
        'restore_channel':lambda:actions.restoreChannel(portal),
        'restore_live_window': open_live_window_route,
        'season':lambda:vod_series.SeasonLevel(portal),
        'sel':lambda:provider_menu.SelectLevel(portal),
        'sergen':lambda:vod_series.SeriesGenre(portal),
        'seriescat':lambda:vod_series.SeriesLevel(portal),
        'set_keymap_mouselock': lambda: keymap_tools.set_keymap_mouselock(),
        'set_keymap_overlay': lambda: keymap_tools.set_keymap_overlay(),
        'set_keymap_switches': lambda: keymap_tools.set_keymap_switches(),
        'show_epg':tv_epg.ShowEPG,
        'stop_timeshift_on_play': StopTimeshiftOnPlay,
        'toggle_auto_timeshift': ToggleAutoTimeshift,
        'toggle_group':lambda:actions.OpenGroupSelectDialog(portal),
        'toggle_timeshift': ToggleTimeshift,
        'tv_guide':tv_guide.open_guide,
        'unlock_adult':lambda:navigation.unlock_adult(portal) and xbmc.executebuiltin('Container.Refresh'),
        'vod':lambda:vod_movies.vodLevel(portal),
        'vodgen':lambda:vod_movies.vodgenreLevel(portal),
        'preview_channel_up': channel_switch.preview_channel_up,
        'preview_channel_down': channel_switch.preview_channel_down,
        'perform_delayed_switch': lambda: channel_switch.perform_delayed_switch(common.args.get('action_time', [''])[0]),
        'open_zapper': zapper.open_zapper,
    }

    action = routes.get(mode_key)
    if action:
        action()
    else:
        xbmcgui.Dialog().notification(common.addonname, f'Nieznany tryb: {mode_key}', xbmcgui.NOTIFICATION_ERROR)
