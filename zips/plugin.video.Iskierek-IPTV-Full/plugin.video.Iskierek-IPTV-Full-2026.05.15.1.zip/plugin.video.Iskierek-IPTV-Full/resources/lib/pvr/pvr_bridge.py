# -*- coding: utf-8 -*-
import os
import json
import threading
import hashlib
import xbmc
import xbmcgui
import xbmcvfs

try:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from SocketServer import ThreadingMixIn
    from urlparse import urlparse
except:
    from http.server import HTTPServer, BaseHTTPRequestHandler
    from socketserver import ThreadingMixIn
    from urllib.parse import urlparse

from resources.lib import common
from resources.lib.providers import provider_api
import resources.lib.core.sorting as sorting
from resources.lib.tv.epg import load_epg_cache_fast

_SERVER = None
_SERVER_THREAD = None
_DEFAULT_PORT = 8099
_DEFAULT_EPG_URL = 'https://epg.ovh/pl.gz'
_PVR_EXPORT_CONFIG = os.path.join(xbmcvfs.translatePath(common.addon.getAddonInfo('profile')), 'pvr_export_config.json')


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("[PVR BRIDGE] %s" % msg, level)


def _profile_dir():
    path = xbmcvfs.translatePath(common.addon.getAddonInfo('profile'))
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def _bridge_dir():
    p = os.path.join(_profile_dir(), 'pvr_bridge')
    if not xbmcvfs.exists(p):
        xbmcvfs.mkdirs(p)
    return p


def _default_local_pvr_dir():
    p = os.path.join(_profile_dir(), 'PVRm3u')
    if not xbmcvfs.exists(p):
        xbmcvfs.mkdirs(p)
    return p


def _m3u_path():
    return os.path.join(_bridge_dir(), 'playlist.m3u')


def _portal_path():
    return os.path.join(_bridge_dir(), 'portal.json')


def _local_m3u_path():
    return os.path.join(get_export_folder(), 'playlist.m3u')


def _local_epg_url():
    return _DEFAULT_EPG_URL


def _read_export_cfg():
    data = common.read_json_safe(_PVR_EXPORT_CONFIG)
    if not isinstance(data, dict):
        return {}
    return data


def _write_export_cfg(data):
    common.write_json_safe(_PVR_EXPORT_CONFIG, data)


def get_export_folder():
    cfg = _read_export_cfg()
    folder = str(cfg.get('export_folder', '')).strip()

    if folder and xbmcvfs.exists(folder):
        return folder

    return _default_local_pvr_dir()


def set_export_folder(folder):
    if not folder:
        return False

    folder = str(folder).strip()
    if not folder:
        return False

    if not xbmcvfs.exists(folder):
        try:
            xbmcvfs.mkdirs(folder)
        except:
            pass

    if not xbmcvfs.exists(folder):
        return False

    cfg = _read_export_cfg()
    cfg['export_folder'] = folder
    _write_export_cfg(cfg)
    return True


def choose_export_folder():
    current = get_export_folder()
    folder = xbmcgui.Dialog().browseSingle(0, 'Wybierz folder eksportu PVR M3U', 'files', '', False, False, current)
    if not folder:
        return False

    ok = set_export_folder(folder)
    if ok:
        xbmcgui.Dialog().notification('PVR Bridge', 'Zapisano folder eksportu PVR', xbmcgui.NOTIFICATION_INFO, 2500)
    else:
        xbmcgui.Dialog().notification('PVR Bridge', 'Nie udało się zapisać folderu eksportu', xbmcgui.NOTIFICATION_ERROR, 3000)

    return ok


def is_fallback_enabled():
    cfg = _read_export_cfg()
    return bool(cfg.get('fallback_server_enabled', False))


def set_fallback_enabled(enabled):
    cfg = _read_export_cfg()
    cfg['fallback_server_enabled'] = bool(enabled)
    _write_export_cfg(cfg)


def toggle_fallback_enabled():
    new_state = not is_fallback_enabled()
    set_fallback_enabled(new_state)
    return new_state


def _xml_escape(val):
    s = '' if val is None else str(val)
    s = s.replace('&', '&amp;')
    s = s.replace('<', '&lt;')
    s = s.replace('>', '&gt;')
    s = s.replace('"', '&quot;')
    s = s.replace("'", '&apos;')
    return s


def _safe_write_text(path, content):
    fh = xbmcvfs.File(path, 'w')
    try:
        fh.write(content)
    finally:
        fh.close()


def _save_portal(portal):
    try:
        common.write_json_safe(_portal_path(), portal)
        return True
    except Exception as e:
        _log("save portal failed: %s" % str(e), xbmc.LOGERROR)
        return False


def _load_portal():
    try:
        p = common.read_json_safe(_portal_path())
        if isinstance(p, dict) and p:
            return p
    except Exception as e:
        _log("load portal failed: %s" % str(e), xbmc.LOGERROR)
    return None


def get_provider_label(portal=None):
    if portal is None:
        portal = _load_portal()

    if not portal:
        return {
            'name': 'Brak',
            'type': 'unknown'
        }

    return {
        'name': str(portal.get('name', 'IPTV')),
        'type': str(portal.get('type', 'unknown'))
    }


def _get_allowed_polish_groups():
    sorting.reload_config()
    saved_data = common.read_json_safe(common.selected_groups_file)

    # domyślnie BEZ POZOSTAŁE
    default_groups = [g[0] for g in sorting.ORDERED_GROUPS]
    allowed_groups = saved_data.get('pl_supergroup', default_groups)

    if not isinstance(allowed_groups, list):
        allowed_groups = default_groups

    return allowed_groups


def _channel_uid(item):
    cid = str(item.get('id', '')).strip()
    if cid:
        return cid

    raw = '%s|%s' % (
        str(item.get('display_name', item.get('name', ''))),
        str(item.get('cmd', ''))
    )
    return hashlib.md5(raw.encode('utf-8')).hexdigest()


def _get_filtered_channels(portal):
    sorting.reload_config()
    provider = provider_api.get_provider(portal)
    allowed_groups = _get_allowed_polish_groups()

    portal_key = common.get_portal_key(portal)
    custom_names = common.read_json_safe(common.custom_names_file).get(portal_key, {})
    hidden_channels = common.read_json_safe(common.hidden_channels_file).get(portal_key, [])

    try:
        if portal.get('type') in ['xtream', 'm3u']:
            sorted_all = sorting.get_smart_sorted_list(provider, portal, None, None, common.addondir)
        else:
            sorted_all = sorting.get_smart_sorted_list(
                provider,
                portal['mac'],
                portal['url'],
                portal['serial'],
                common.addondir
            )
    except Exception as e:
        _log("sorting failed: %s" % str(e), xbmc.LOGERROR)
        return []

    if not sorted_all:
        return []

    result = []
    for item in sorted_all:
        if item.get('is_header'):
            continue

        if item.get('_my_group_name') not in allowed_groups:
            continue

        base_name = str(item.get('display_name', item.get('name', ''))).strip()
        if not base_name:
            continue

        if base_name in hidden_channels:
            continue

        item = dict(item)
        display_name = custom_names.get(base_name, base_name)
        item['display_name'] = display_name
        item['_original_key'] = base_name
        item['_bridge_id'] = _channel_uid(item)
        result.append(item)

    return result


def _find_channel_by_bridge_id(portal, bridge_id):
    channels = _get_filtered_channels(portal)

    for item in channels:
        if str(item.get('_bridge_id', '')) == str(bridge_id):
            return item

    return None


def _choose_logo(portal, item, epg_item=None):
    bad_hosts = ['103.176.90.95']
    default_icon = common.icon0

    if epg_item:
        epg_logo = epg_item.get('chan_logo') or epg_item.get('logo') or epg_item.get('icon')
        if epg_logo and str(epg_logo).startswith('http'):
            if not any(host in str(epg_logo) for host in bad_hosts):
                return str(epg_logo)

    portal_logo_raw = item.get("logo", "")
    if portal_logo_raw and str(portal_logo_raw).lower() != 'none':
        if str(portal_logo_raw).startswith('http'):
            if not any(host in str(portal_logo_raw) for host in bad_hosts):
                return str(portal_logo_raw)
        else:
            try:
                base = portal['url'].split('/c/')[0] if '/c/' in portal['url'] else portal['url'].rstrip('/')
                return "%s/stalker_portal/misc/logos/320/%s" % (base, portal_logo_raw)
            except:
                pass

    return default_icon


def _epg_lookup(display_name, cache):
    norm_name = common.clean_channel_name(display_name)

    if norm_name in cache:
        return cache[norm_name], norm_name
    if display_name.lower() in cache:
        return cache[display_name.lower()], norm_name

    for key in cache.keys():
        if norm_name in key or key in norm_name:
            return cache[key], norm_name

    return None, norm_name


def _channel_id(display_name):
    cid = common.clean_channel_name(display_name)
    cid = cid.replace(' ', '_')
    return cid or display_name.replace(' ', '_').lower()


def _extract_direct_url_from_cmd(cmd):
    if not cmd:
        return ''

    s = str(cmd).strip()

    if s.startswith('ffmpeg '):
        s = s[7:].strip()

    if s.startswith('http://') or s.startswith('https://'):
        return s

    if ' http://' in s or ' https://' in s:
        parts = s.split()
        for p in parts:
            p = p.strip()
            if p.startswith('http://') or p.startswith('https://'):
                return p

    return ''


def _resolve_stream_url(portal, item):
    provider = provider_api.get_provider(portal)
    cmd = str(item.get('cmd', ''))

    if not cmd:
        raise Exception('Brak cmd dla kanału')

    direct_url = _extract_direct_url_from_cmd(cmd)
    if direct_url and 'localhost' not in direct_url:
        return direct_url

    if portal.get('type') == 'm3u':
        return provider.getLinkTV(portal, cmd)

    if portal.get('type') == 'xtream':
        return provider.getLinkTV(portal, cmd)

    return provider.getLinkTV(portal['mac'], portal['url'], portal['serial'], cmd)


def _can_export_direct(portal, item):
    # jeśli provider wymaga f4m, to direct export nie jest pewny
    if portal.get('use_f4m', False):
        return False

    cmd = str(item.get('cmd', ''))
    direct_url = _extract_direct_url_from_cmd(cmd)

    if portal.get('type') == 'm3u':
        return bool(direct_url or cmd.startswith('http://') or cmd.startswith('https://') or cmd.startswith('plugin://'))

    if portal.get('type') == 'xtream':
        return True

    # stalker
    if direct_url and 'localhost' not in direct_url:
        return True

    return False


def _get_direct_export_url(portal, item):
    provider = provider_api.get_provider(portal)
    cmd = str(item.get('cmd', ''))

    if portal.get('use_f4m', False):
        return ''

    direct_url = _extract_direct_url_from_cmd(cmd)
    if direct_url and 'localhost' not in direct_url:
        return direct_url

    if portal.get('type') == 'm3u':
        return provider.getLinkTV(portal, cmd)

    if portal.get('type') == 'xtream':
        return provider.getLinkTV(portal, cmd)

    return ''


def build_m3u(portal):
    channels = _get_filtered_channels(portal)
    epg_cache = load_epg_cache_fast()
    fallback_enabled = is_fallback_enabled()

    lines = ['#EXTM3U']
    exported_count = 0
    skipped_count = 0
    fallback_count = 0

    for item in channels:
        display_name = item.get('display_name', item.get('name', 'Nieznany'))
        epg_item, _ = _epg_lookup(display_name, epg_cache)
        logo = _choose_logo(portal, item, epg_item)
        group_name = item.get('_my_group_name', 'POZOSTAŁE')
        ch_id = _channel_id(display_name)
        bridge_id = item.get('_bridge_id', _channel_uid(item))

        stream_url = ''

        if _can_export_direct(portal, item):
            stream_url = _get_direct_export_url(portal, item)

        if not stream_url and fallback_enabled:
            stream_url = 'http://127.0.0.1:%s/live/%s' % (_DEFAULT_PORT, bridge_id)
            fallback_count += 1

        if not stream_url:
            skipped_count += 1
            _log("skip channel without direct url and fallback off: %s" % display_name, xbmc.LOGWARNING)
            continue

        extinf = '#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-logo="%s" group-title="%s",%s' % (
            _xml_escape(ch_id),
            _xml_escape(display_name),
            _xml_escape(logo),
            _xml_escape(group_name),
            _xml_escape(display_name)
        )

        lines.append(extinf)
        lines.append(stream_url)
        exported_count += 1

    content = '\n'.join(lines) + '\n'

    _safe_write_text(_m3u_path(), content)
    _safe_write_text(_local_m3u_path(), content)

    _log(
        "M3U exported: local=%s exported=%d skipped=%d fallback=%d fallback_enabled=%s" % (
            _local_m3u_path(), exported_count, skipped_count, fallback_count, str(fallback_enabled)
        ),
        xbmc.LOGINFO
    )
    return content


class _ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class _Handler(BaseHTTPRequestHandler):
    def _send(self, content, content_type='text/plain; charset=utf-8', code=200):
        if isinstance(content, str):
            content = content.encode('utf-8')

        self.send_response(code)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def _redirect(self, location, code=302):
        self.send_response(code)
        self.send_header('Location', location)
        self.end_headers()

    def do_GET(self):
        try:
            parsed = urlparse(self.path)
            path = parsed.path

            if path.startswith('/playlist.m3u'):
                portal = _load_portal()
                if not portal:
                    return self._send('#EXTM3U\n', 'audio/x-mpegurl', 200)
                return self._send(build_m3u(portal), 'audio/x-mpegurl', 200)

            if path.startswith('/epg.xml'):
                return self._send('<?xml version="1.0" encoding="UTF-8"?><tv></tv>', 'application/xml', 200)

            if path.startswith('/status'):
                return self._send('OK', 'text/plain', 200)

            if path.startswith('/debug_channels'):
                portal = _load_portal()
                if not portal:
                    return self._send('Brak aktywnego portalu', 'text/plain', 500)

                channels = _get_filtered_channels(portal)
                out = []
                out.append('Provider: %s (%s)' % (portal.get('name', 'IPTV'), portal.get('type', 'unknown')))
                out.append('Channels: %d' % len(channels))
                out.append('Fallback enabled: %s' % str(is_fallback_enabled()))
                out.append('')

                for item in channels[:400]:
                    out.append('ID=%s | NAME=%s | GROUP=%s | CMD=%s' % (
                        item.get('_bridge_id', ''),
                        item.get('display_name', item.get('name', '')),
                        item.get('_my_group_name', ''),
                        item.get('cmd', '')
                    ))

                return self._send('\n'.join(out), 'text/plain; charset=utf-8', 200)

            if path.startswith('/debug_live/'):
                portal = _load_portal()
                if not portal:
                    return self._send('Brak aktywnego portalu', 'text/plain', 500)

                bridge_id = path.split('/debug_live/', 1)[1].strip().strip('/')
                out = []
                out.append('PORTAL_NAME=%s' % portal.get('name', ''))
                out.append('PORTAL_TYPE=%s' % portal.get('type', ''))

                item = _find_channel_by_bridge_id(portal, bridge_id)
                if not item:
                    out.append('FOUND=NO')
                    return self._send('\n'.join(out), 'text/plain; charset=utf-8', 404)

                out.append('FOUND=YES')
                out.append('NAME=%s' % item.get('display_name', item.get('name', '')))
                out.append('GROUP=%s' % item.get('_my_group_name', ''))
                out.append('CMD=%s' % item.get('cmd', ''))
                out.append('DIRECT_OK=%s' % str(_can_export_direct(portal, item)))
                out.append('DIRECT_URL=%s' % _get_direct_export_url(portal, item))

                try:
                    stream_url = _resolve_stream_url(portal, item)
                    out.append('RESOLVED=%s' % stream_url)
                    return self._send('\n'.join(out), 'text/plain; charset=utf-8', 200)
                except Exception as e:
                    out.append('ERROR=%s' % str(e))
                    return self._send('\n'.join(out), 'text/plain; charset=utf-8', 500)

            if path.startswith('/live/'):
                portal = _load_portal()
                if not portal:
                    return self._send('Brak aktywnego portalu', 'text/plain', 500)

                bridge_id = path.split('/live/', 1)[1].strip().strip('/')
                if not bridge_id:
                    return self._send('Brak channel id', 'text/plain', 404)

                item = _find_channel_by_bridge_id(portal, bridge_id)
                if not item:
                    return self._send('Kanał nie znaleziony', 'text/plain', 404)

                try:
                    stream_url = _resolve_stream_url(portal, item)
                    if not stream_url:
                        raise Exception('Pusty stream URL')
                    return self._redirect(stream_url, 302)
                except Exception as e:
                    _log("resolve stream failed bridge_id=%s error=%s" % (bridge_id, str(e)), xbmc.LOGERROR)
                    return self._send('Błąd resolve streamu: %s' % str(e), 'text/plain', 500)

            return self._send('Not found', 'text/plain', 404)

        except Exception as e:
            _log("HTTP error: %s" % str(e), xbmc.LOGERROR)
            return self._send('Internal error: %s' % str(e), 'text/plain', 500)

    def log_message(self, format, *args):
        return


def start_server(port=_DEFAULT_PORT):
    global _SERVER, _SERVER_THREAD

    if _SERVER is not None:
        return True

    try:
        _SERVER = _ThreadedHTTPServer(('127.0.0.1', int(port)), _Handler)
        _SERVER_THREAD = threading.Thread(target=_SERVER.serve_forever)
        _SERVER_THREAD.daemon = True
        _SERVER_THREAD.start()
        _log("server started on 127.0.0.1:%s" % port)
        return True
    except Exception as e:
        _SERVER = None
        _SERVER_THREAD = None
        _log("start_server failed: %s" % str(e), xbmc.LOGERROR)
        return False


def stop_server():
    global _SERVER, _SERVER_THREAD
    try:
        if _SERVER:
            _SERVER.shutdown()
            _SERVER.server_close()
    except Exception as e:
        _log("stop_server error: %s" % str(e), xbmc.LOGERROR)
    _SERVER = None
    _SERVER_THREAD = None


def ensure_server_if_needed():
    if is_fallback_enabled():
        return start_server(_DEFAULT_PORT)
    return True


def refresh_exports(portal):
    if not portal:
        raise Exception("Brak portalu do eksportu")
    _save_portal(portal)
    ensure_server_if_needed()
    build_m3u(portal)
    return True


def start_bridge_for_portal(portal, port=_DEFAULT_PORT):
    if not portal:
        raise Exception("Brak portalu")
    _save_portal(portal)
    if is_fallback_enabled():
        ok = start_server(port)
        if not ok:
            raise Exception("Nie udało się uruchomić serwera HTTP")
    build_m3u(portal)
    return True


def get_urls(port=_DEFAULT_PORT):
    return {
        'playlist': 'http://127.0.0.1:%s/playlist.m3u' % port,
        'epg': _local_epg_url(),
        'status': 'http://127.0.0.1:%s/status' % port,
        'm3u_file': _local_m3u_path(),
        'epg_file': _local_epg_url(),
        'portal_file': _portal_path(),
        'export_folder': get_export_folder(),
        'debug_channels': 'http://127.0.0.1:%s/debug_channels' % port,
        'fallback_enabled': is_fallback_enabled()
    }


def dialog_info(port=_DEFAULT_PORT):
    urls = get_urls(port)
    provider_info = get_provider_label()

    xbmcgui.Dialog().ok(
        'PVR Bridge',
        'Dostawca: %s\n'
        'Typ: %s\n'
        'Lokalny serwer: %s\n\n'
        'Folder eksportu:\n%s\n\n'
        'Lokalne M3U:\n%s\n\n'
        'EPG:\n%s\n\n'
        'HTTP M3U:\n%s\n\n'
        'DEBUG channels:\n%s' % (
            provider_info['name'],
            provider_info['type'],
            '[COLOR lime]WŁ[/COLOR]' if urls['fallback_enabled'] else '[COLOR red]WYŁ[/COLOR]',
            urls['export_folder'],
            urls['m3u_file'],
            urls['epg_file'],
            urls['playlist'],
            urls['debug_channels']
        )
    )


def is_server_running(port=_DEFAULT_PORT):
    try:
        import urllib.request
        with urllib.request.urlopen('http://127.0.0.1:%s/status' % port, timeout=1.5) as resp:
            data = resp.read().decode('utf-8', errors='ignore').strip()
            return data == 'OK'
    except:
        return False