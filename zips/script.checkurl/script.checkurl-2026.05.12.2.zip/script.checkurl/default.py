import xbmc
import xbmcgui
import os
import xbmcvfs
import datetime 

player = xbmc.Player()

if player.isPlaying():
    url = player.getPlayingFile()
    
    title = xbmc.getInfoLabel('Player.Title')
    if not title:
        title = "Brak tytułu / No Title"
    
    timestamp = datetime.datetime.now().strftime("- ZAPIS: %Y-%m-%d %H:%M:%S -")
    content_to_write = f"\n\n{timestamp}\n{title}\n{url}"
    
    kodi_base_path = "special://userdata/Linki URL - script.checkurl"
    
    target_dir = xbmcvfs.translatePath(kodi_base_path) 
    
    if not os.path.exists(target_dir):
        os.makedirs(target_dir, exist_ok=True) 

    filepath = os.path.join(target_dir, "kodi_url_Filmu.txt") 
    
    with open(filepath, "a", encoding="utf-8") as f:
        f.write(content_to_write) 

    message = f"--->   Link do '{title}' zapisano!   <---"
    
    xbmc.executebuiltin(f'Notification(URL zapisany, {message}, 5000)')

    xbmc.executebuiltin('ActivateWindow(Home)')

else:
    xbmc.executebuiltin('Notification(Informacja, Nic nie jest odtwarzane., 5000)')
