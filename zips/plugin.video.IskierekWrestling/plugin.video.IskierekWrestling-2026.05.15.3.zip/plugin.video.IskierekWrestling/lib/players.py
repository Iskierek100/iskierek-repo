# -*- coding: UTF-8 -*-
"""
Funkcje odtwarzania video w Kodi.
"""
import os
import time
from urllib.parse import quote_plus
import html as html_lib

import xbmc
import xbmcgui
import xbmcplugin

from lib.constants import UA, HANDLE, ICON, FANART, OKRU_START_QUALITY
from lib.helpers import log, detect_quality_from_text
from lib.resolvers import collect_okru_sources, okru_get_720_bandwidth


def play_hls(url, title, image, subtitles='', add_cachebuster=True,
             referer='https://www.dailymotion.com/'):
    chosen = html_lib.unescape(url)
    chosen = chosen.replace('\\u0026', '&').replace('\\&', '&')
    chosen = chosen.replace('\\/', '/').replace('&amp;', '&').strip()

    if add_cachebuster:
        separator = '&' if '?' in chosen else '?'
        chosen = chosen + separator + 'cb=%d' % int(time.time())

    headers = {
        'User-Agent': UA,
        'Referer': referer,
        'Origin': 'https://www.dailymotion.com'
    }

    header_string = '&'.join(
        ['%s=%s' % (k, quote_plus(v)) for k, v in headers.items()]
    )

    playback_url = chosen + '|' + header_string

    li = xbmcgui.ListItem(path=playback_url)
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setMimeType('application/vnd.apple.mpegurl')

    info_tag = li.getVideoInfoTag()
    info_tag.setTitle(title or '')

    li.setArt({'thumb': image or ICON, 'fanart': FANART})

    if subtitles and os.path.exists(subtitles):
        try:
            if hasattr(li, 'setSubtitles'):
                li.setSubtitles([subtitles])
                log('Subtitles attached: %s' % subtitles)
        except Exception as e:
            log('Attach subtitles error: %s' % str(e), xbmc.LOGWARNING)

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def play_direct(url, title, image):
    log('Playing direct: %s' % url[:100])
    li = xbmcgui.ListItem(path=url)
    info_tag = li.getVideoInfoTag()
    info_tag.setTitle(title or '')
    li.setArt({'thumb': image or ICON, 'fanart': FANART})
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def play_okru_hls(url, title, image, start_bitrate=''):
    chosen = html_lib.unescape(url)
    chosen = chosen.replace('\\u0026', '&').replace('\\&', '&')
    chosen = chosen.replace('\\/', '/').replace('&amp;', '&').strip()

    headers = {
        'User-Agent': UA,
        'Referer': 'https://ok.ru/',
        'Origin': 'https://ok.ru'
    }

    header_string = '&'.join(
        ['%s=%s' % (k, quote_plus(v)) for k, v in headers.items()]
    )

    playback_url = chosen + '|' + header_string

    li = xbmcgui.ListItem(path=playback_url)
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    li.setMimeType('application/vnd.apple.mpegurl')

    if start_bitrate:
        li.setProperty('inputstream.adaptive.initial_bitrate', str(start_bitrate))

    info_tag = li.getVideoInfoTag()
    info_tag.setTitle(title or '')
    li.setArt({'thumb': image or ICON, 'fanart': FANART})

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def play_okru_with_quality(video_id, title, image):
    sources = collect_okru_sources(video_id)

    if not sources:
        log('OK.ru: brak źródeł', xbmc.LOGWARNING)
        return False

    # 1) Preferuj HLS master
    hls_source = None
    for s in sources:
        q = (s.get('quality') or '').lower()
        u = (s.get('url') or '').lower()
        if q == 'hls' or '.m3u8' in u:
            hls_source = s
            break

    if hls_source:
        hls_url = hls_source['url']
        bw_720 = okru_get_720_bandwidth(hls_url)
        log('OK.ru HLS: %s' % hls_url[:160])
        play_okru_hls(hls_url, title, image, start_bitrate=bw_720)
        return True

    # 2) Fallback: wybór jakości
    labels = []
    for s in sources:
        q = (s.get('quality') or '').lower()
        url = s.get('url', '')

        nice = {
            'mobile': 'MOBILE', 'lowest': 'LOWEST', 'low': 'LOW',
            'sd': 'SD', 'hd': 'HD', 'full': 'FULL',
            'hls': 'HLS', 'auto': 'AUTO',
        }.get(q, q.upper())

        if '.m3u8' in url.lower():
            nice += ' [HLS]'
        else:
            nice += ' [MP4]'

        labels.append(nice)

    idx = xbmcgui.Dialog().select('OK.ru - wybierz jakość', labels)
    if idx < 0:
        return True

    chosen = sources[idx]['url']

    if '.m3u8' in chosen.lower():
        bw_720 = okru_get_720_bandwidth(chosen)
        play_okru_hls(chosen, title, image, start_bitrate=bw_720)
    else:
        play_direct(chosen, title, image)

    return True