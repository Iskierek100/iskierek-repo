# -*- coding: UTF-8 -*-
"""
Resolvery dla poszczególnych serwisów video.
"""
import re
import base64
import xbmc

from lib.constants import UA, SESSION
from lib.helpers import log, get_html, detect_quality_from_text


def resolve_with_resolveurl(test_url):
    try:
        import resolveurl
    except Exception as e:
        log('resolveurl not available: %s' % str(e), xbmc.LOGWARNING)
        return ''

    try:
        hmf = resolveurl.HostedMediaFile(test_url)
        if hmf and hmf.valid_url():
            link = hmf.resolve()
            if link:
                log('resolveurl OK: %s -> %s' % (test_url[:120], link[:120]))
                return link
    except Exception as e:
        log('resolveurl HMF error: %s -> %s' % (test_url, str(e)), xbmc.LOGWARNING)

    try:
        import resolveurl
        link = resolveurl.resolve(test_url)
        if link:
            log('resolveurl direct OK: %s -> %s' % (test_url[:120], link[:120]))
            return link
    except Exception as e:
        log('resolveurl direct error: %s -> %s' % (test_url, str(e)), xbmc.LOGWARNING)

    return ''


def resolve_dailymotion(video_id):
    log('DM resolve: %s' % video_id)

    candidate_urls = [
        'https://www.dailymotion.com/video/%s' % video_id,
        'https://www.dailymotion.com/embed/video/%s' % video_id,
    ]

    # 1) ResolveURL
    for u in candidate_urls:
        link = resolve_with_resolveurl(u)
        if link:
            return link

    # 2) Fallback: metadata API
    try:
        api = 'https://www.dailymotion.com/player/metadata/video/' + video_id
        headers = {'User-Agent': UA, 'Referer': 'https://www.dailymotion.com/'}
        r = SESSION.get(api, headers=headers, timeout=15)
        r.raise_for_status()
        data = r.json()

        if 'error' in data:
            log('DM error: %s' % data['error'], xbmc.LOGWARNING)
            return ''

        qualities = data.get('qualities', {})

        if 'auto' in qualities:
            for item in qualities['auto']:
                if item.get('type') == 'application/x-mpegURL':
                    return item['url']

        for q in ('1080', '720', '480', '380', '240'):
            if q in qualities:
                for item in qualities[q]:
                    if item.get('type') in ('application/x-mpegURL', 'video/mp4'):
                        return item['url']

    except Exception as e:
        log('DM metadata error: %s' % str(e), xbmc.LOGWARNING)

    return ''


def resolve_okru(video_id):
    import html as html_lib

    embed_url = 'https://ok.ru/videoembed/' + video_id
    html = get_html(embed_url, referer='https://ok.ru/')
    if not html:
        return ''

    text = html_lib.unescape(html)
    text = text.replace('\\/', '/').replace('\\u0026', '&')

    patterns = [
        r'"hlsManifestUrl"\s*:\s*"([^"]+?\.m3u8[^"]*)"',
        r'"hlsMasterPlaylistUrl"\s*:\s*"([^"]+?\.m3u8[^"]*)"',
        r'"masterPlaylistUrl"\s*:\s*"([^"]+?\.m3u8[^"]*)"',
        r'"videoUrl"\s*:\s*"([^"]+?\.m3u8[^"]*)"',
        r'"src"\s*:\s*"([^"]+?\.m3u8[^"]*)"',
    ]

    for pat in patterns:
        m = re.search(pat, text, re.I | re.S)
        if m:
            url = m.group(1).strip()
            url = re.split(r'["\'<\s]', url)[0]
            url = url.replace('&amp;', '&').replace('\\u0026', '&').replace('\\/', '/')
            log('OK.ru manifest: %s' % url[:160])
            return url

    m = re.search(r'https?://[^"\']+?\.m3u8[^"\']*', text, re.I)
    if m:
        url = m.group(0).strip()
        url = re.split(r'["\'<\s]', url)[0]
        url = url.replace('&amp;', '&').replace('\\u0026', '&').replace('\\/', '/')
        return url

    log('OK.ru: nie znaleziono m3u8', xbmc.LOGWARNING)
    return ''


def collect_okru_sources(video_id):
    import html as html_lib

    embed_url = 'https://ok.ru/videoembed/' + video_id
    html = get_html(embed_url, referer='https://ok.ru/')
    if not html:
        return []

    text = html_lib.unescape(html)
    text = text.replace('\\/', '/').replace('\\u0026', '&').replace('\\"', '"')

    sources = []
    seen = set()

    for m in re.finditer(
        r'"name"\s*:\s*"([^"]+)"\s*,\s*"url"\s*:\s*"([^"]+)"',
        text, re.I | re.S
    ):
        name = m.group(1).strip()
        url = m.group(2).strip()
        url = url.replace('\\u0026', '&').replace('\\&', '&').replace('\\/', '/').replace('&amp;', '&')
        if url in seen:
            continue
        seen.add(url)
        sources.append({'quality': name, 'url': url})

    m = re.search(r'"hlsManifestUrl"\s*:\s*"([^"]+?\.m3u8[^"]*)"', text, re.I | re.S)
    if m:
        url = m.group(1).strip().replace('\\u0026', '&')
        if url not in seen:
            seen.add(url)
            sources.append({'quality': 'hls', 'url': url})

    if not sources:
        for m in re.finditer(r'https?://[^"\']+\.(?:m3u8|mp4)(?:\?[^"\']*)?', text, re.I):
            url = m.group(0).strip()
            if url in seen:
                continue
            seen.add(url)
            ctx = text[max(0, m.start() - 200):m.end() + 200].lower()
            q = detect_quality_from_text(ctx, url) or 'auto'
            sources.append({'quality': q, 'url': url})

    def q_rank(q):
        q = (q or '').lower()
        order = {'mobile': 0, 'lowest': 1, 'low': 2, 'sd': 3, 'hd': 4, 'full': 5, 'hls': 6, 'auto': 7}
        return order.get(q, 99)

    sources.sort(key=lambda s: q_rank(s.get('quality')))
    return sources


def okru_get_720_bandwidth(master_url):
    try:
        manifest = get_html(master_url, referer='https://ok.ru/')
        if not manifest:
            return ''
        for m in re.finditer(r'#EXT-X-STREAM-INF:([^\n]+)\n([^\n]+)', manifest, re.I):
            attrs = m.group(1)
            if re.search(r'RESOLUTION\s*=\s*1280x720', attrs, re.I) or '720' in attrs:
                bw = re.search(r'BANDWIDTH=(\d+)', attrs, re.I)
                if bw:
                    return bw.group(1)
    except Exception as e:
        log('OK.ru 720 bandwidth error: %s' % str(e), xbmc.LOGWARNING)
    return ''


def resolve_dood(video_id, page_url=''):
    candidates = []

    if page_url:
        candidates.append(page_url)
        try:
            html = get_html(page_url)
            if html:
                html = html.replace('&amp;', '&')
                dood_matches = re.findall(
                    r'https?://[^"\']*(?:doodstream\.com|dood\.to|dood\.yt|dood\.watch|dood\.sh|dood\.so)[^"\']*',
                    html, re.I
                )
                for u in dood_matches:
                    u = u.strip()
                    if u and u not in candidates:
                        candidates.append(u)
        except Exception as e:
            log('DOOD HTML scan error: %s' % str(e), xbmc.LOGWARNING)

    if video_id:
        candidates.extend([
            'https://doodstream.com/e/%s' % video_id,
            'https://doodstream.com/d/%s' % video_id,
            'https://dood.to/e/%s' % video_id,
            'https://dood.yt/e/%s' % video_id,
            'https://dood.watch/e/%s' % video_id,
            'https://dood.sh/e/%s' % video_id,
            'https://dood.so/e/%s' % video_id,
        ])

    for u in candidates:
        link = resolve_with_resolveurl(u)
        if link:
            return link

    return ''


def resolve_voe(voe_url):
    try:
        html = get_html(voe_url)
        for pattern in [
            r"'hls'\s*:\s*'([^']+)'",
            r"'mp4'\s*:\s*'([^']+)'",
            r'source\s*[:=]\s*["\']([^"\']+\.m3u8[^"\']*)["\']',
            r'source\s*[:=]\s*["\']([^"\']+\.mp4[^"\']*)["\']',
            r'window\.location\.href\s*=\s*["\']([^"\']+)["\']',
        ]:
            m = re.search(pattern, html)
            if m:
                log('VOE resolved: %s' % m.group(1)[:80])
                return m.group(1)
    except Exception as e:
        log('VOE error: %s' % str(e), xbmc.LOGWARNING)
    return ''


def resolve_gofile(gofile_url):
    folder_id = re.search(r'/d/([^/?]+)', gofile_url)
    if not folder_id:
        return ''
    try:
        token_r = SESSION.get('https://api.gofile.io/accounts', timeout=15)
        token_data = token_r.json()
        token = token_data.get('data', {}).get('token', '')

        api = 'https://api.gofile.io/contents/%s?wt=4fd6sg89d7s6&cache=true' % folder_id.group(1)
        headers = {'Authorization': 'Bearer %s' % token, 'User-Agent': UA}
        r = SESSION.get(api, headers=headers, timeout=15)
        data = r.json()

        if data.get('status') == 'ok':
            contents = data.get('data', {}).get('contents', {})
            files = [(k, v) for k, v in contents.items()
                     if v.get('type') == 'file' and v.get('link')]
            files.sort(key=lambda x: x[1].get('size', 0), reverse=True)

            if files:
                best_file = files[0][1]
                link = best_file['link']
                log('GoFile resolved: %s' % link[:80])
                return link

    except Exception as e:
        log('GoFile error: %s' % str(e), xbmc.LOGWARNING)
    return ''