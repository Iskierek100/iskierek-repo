# -*- coding: UTF-8 -*-
"""
Parsowanie i wyświetlanie źródeł video z watchprowrestling.
"""
import re
import os
import base64
from collections import Counter, defaultdict
from urllib.parse import urlparse, parse_qs

import xbmc
import xbmcgui
import xbmcplugin

from lib.constants import (
    ADDON_NAME, HANDLE, ICON, FANART, DATAPATH,
    BROWSER_ONLY_TYPES, TYPE_NAMES
)
from lib.helpers import (
    log, get_html, clean_title, detect_quality_from_text,
    source_quality_icon
)
from lib.ui import add_directory, add_video, end_directory
from lib.browser import open_browser


def _parse_vptips(lnk):
    m_type = re.search(r'[?&]type=([^&]+)', lnk)
    m_id = re.search(r'[?&]ids?=([^&]+)', lnk)
    srv_type = m_type.group(1) if m_type else '?'
    srv_id = m_id.group(1) if m_id else ''

    extra = srv_id
    if srv_type == 'go' and srv_id:
        try:
            extra = base64.b64decode(srv_id + '==').decode('utf-8', errors='ignore')
        except Exception:
            pass

    return {
        'type': srv_type,
        'id': srv_id,
        'name': TYPE_NAMES.get(srv_type, srv_type.upper()),
        'extra': extra,
        'quality': '',
    }


def _guess_source_group(html, pos):
    chunk = html[max(0, pos - 2000):pos]

    headings = re.findall(r'<h[1-6][^>]*>(.*?)</h[1-6]>', chunk, re.I | re.S)
    for h in reversed(headings):
        txt = clean_title(re.sub(r'<[^>]+>', '', h).strip())
        if txt:
            return txt

    text = re.sub(r'<[^>]+>', '\n', chunk)
    lines = [clean_title(x) for x in text.splitlines()]
    lines = [x for x in lines if x and len(x) > 2]

    return lines[-1] if lines else ''


def _collect_vptips_sources(html):
    sources = []
    seen = set()

    for m in re.finditer(
        r'<a[^>]+href=[\'"](https://vptips\.online/ads3/temp/player\.php\?[^\'"]+)[\'"][^>]*>(.*?)</a>',
        html, re.I | re.S
    ):
        lnk = m.group(1).replace('&amp;', '&')
        if lnk in seen:
            continue
        seen.add(lnk)

        label_html = m.group(2)
        label = clean_title(re.sub(r'<[^>]+>', '', label_html).strip())
        section = _guess_source_group(html, m.start())

        info = _parse_vptips(lnk)
        info['link'] = lnk
        info['label'] = label
        info['section'] = section
        sources.append(info)

    return sources


def is_browser_only_source(info):
    return False


def show_sources(url, title, image):
    html = get_html(url)
    if not html:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Nie można pobrać strony',
                                      xbmcgui.NOTIFICATION_ERROR)
        end_directory('files')
        return

    try:
        with open(os.path.join(DATAPATH, 'debug_sources.html'), 'w', encoding='utf-8') as f:
            f.write(html)
    except Exception:
        pass

    all_sources = _collect_vptips_sources(html)
    kodi_sources = [s for s in all_sources if not is_browser_only_source(s)]
    browser_sources = [s for s in all_sources if is_browser_only_source(s)]

    log('show_sources: kodi=%d browser=%d' % (len(kodi_sources), len(browser_sources)))

    sources = []
    seen = set()

    # Szukaj w akordionach
    accordion_sections = re.findall(
        r'<div\s+class="accordion-header[^"]*"[^>]*>(.*?)</div>'
        r'\s*<div\s+class="accordion-content[^"]*"[^>]*>(.*?)</div>',
        html, re.DOTALL
    )

    if accordion_sections:
        log('Znaleziono %d accordion sekcji' % len(accordion_sections))
        for header_html, content_html in accordion_sections:
            quality = detect_quality_from_text(header_html, content_html, title)

            vptips = re.findall(
                r'https://vptips\.online/ads3/temp/player\.php\?[^"\'<>\s]+',
                content_html
            )
            for lnk in vptips:
                lnk = lnk.replace('&amp;', '&')
                if lnk in seen:
                    continue
                seen.add(lnk)

                info = _parse_vptips(lnk)
                if info['type'] in BROWSER_ONLY_TYPES:
                    continue

                info['quality'] = quality
                info['link'] = lnk
                sources.append(info)

    # Fallback: szukaj w całym HTML
    if not sources:
        for info in kodi_sources:
            if info['link'] in seen:
                continue
            seen.add(info['link'])

            idx = html.find(info['link'].replace('&', '&amp;'))
            if idx < 0:
                idx = html.find(info['link'])
            if idx > 0:
                ctx = html[max(0, idx - 500):idx].lower()
                if 'fhd' in ctx or '1080' in ctx:
                    info['quality'] = 'FHD'
                elif 'hd' in ctx or '720' in ctx:
                    info['quality'] = 'HD'
                elif 'sd' in ctx or '480' in ctx:
                    info['quality'] = 'SD'
                elif 'lq' in ctx or '360' in ctx:
                    info['quality'] = 'LQ'
            sources.append(info)

    log('show_sources: %d zrodel kodi' % len(sources))

    if sources:
        sep = '═' * 40
        add_video('[COLOR gold]%s[/COLOR]' % sep, {'mode': 'none'}, icon=image)
        add_video('[B][COLOR gold]%s[/COLOR][/B]' % title, {'mode': 'none'},
                  icon=image, plot=title)
        add_video('[COLOR gold]%s[/COLOR]' % sep, {'mode': 'none'}, icon=image)

        sources.sort(key=lambda s: s.get('type') == 'pvp')

        def get_display_name(info):
            section = (info.get('section') or '').strip()
            label_text = (info.get('label') or '').strip()
            name = TYPE_NAMES.get(info['type'], info['type'].upper())
            base = section or name
            if label_text and label_text.lower() not in base.lower():
                base = '%s - %s' % (base, label_text)
            return base

        display_names = [get_display_name(info) for info in sources]
        counts = Counter(display_names)
        seen_counts = defaultdict(int)

        for info, display_name in zip(sources, display_names):
            seen_counts[display_name] += 1
            idx = seen_counts[display_name]
            total = counts[display_name]

            if total > 1:
                final_name = '%s [#%d]' % (display_name, idx)
            else:
                final_name = display_name

            quality = (info.get('quality') or '').upper()

            item_icon = image
            q_icon = source_quality_icon(info['type'], quality, info.get('label', ''))
            if q_icon:
                item_icon = q_icon

            label = '[B]%s[/B]' % final_name

            add_video(
                title=label,
                params={
                    'mode': 'play',
                    'url': info['link'],
                    'title': title,
                    'image': image,
                    'referer': url,
                    'label': info.get('label', '')
                },
                icon=item_icon,
                plot='%s - %s' % (title, final_name)
            )

        if browser_sources:
            add_directory(
                '[COLOR cyan][B]>Źródła wymagające przeglądarki< (%d)[/B][/COLOR]' % len(browser_sources),
                {'mode': 'browser_sources', 'url': url, 'title': title, 'image': image},
                icon=item_icon
            )
    else:
        add_directory('[COLOR red]Brak wyników[/COLOR]', {'mode': 'home'})

    end_directory('files')


def show_browser_sources(url, title, image):
    html = get_html(url)
    if not html:
        end_directory('files')
        return

    all_sources = _collect_vptips_sources(html)
    browser_sources = [s for s in all_sources if is_browser_only_source(s)]

    if not browser_sources:
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            'Brak źródeł wymagających przeglądarki',
            xbmcgui.NOTIFICATION_WARNING
        )
        end_directory('files')
        return

    sep = '═' * 40
    add_video('[COLOR gold]%s[/COLOR]' % sep, {'mode': 'none'}, icon=image)
    add_video('[B][COLOR gold]Źródła wymagające przeglądarki[/COLOR][/B]', {'mode': 'none'}, icon=image)
    add_video('[COLOR gold]%s[/COLOR]' % sep, {'mode': 'none'}, icon=image)

    def get_display_name(info):
        section = (info.get('section') or '').strip()
        label_text = (info.get('label') or '').strip()
        name = TYPE_NAMES.get(info['type'], info['type'].upper())
        base = section or name
        if label_text and label_text.lower() not in base.lower():
            base = '%s - %s' % (base, label_text)
        return base

    display_names = [get_display_name(info) for info in browser_sources]
    counts = Counter(display_names)
    seen_counts = defaultdict(int)

    for info, display_name in zip(browser_sources, display_names):
        seen_counts[display_name] += 1
        idx = seen_counts[display_name]
        total = counts[display_name]

        if total > 1:
            final_name = '%s [#%d]' % (display_name, idx)
        else:
            final_name = display_name

        label_text = (info.get('label') or '').strip()

        item_icon = image
        q_icon = source_quality_icon(info['type'], info.get('quality', ''), label_text)
        if q_icon:
            item_icon = q_icon

        label = '[B]%s[/B]' % final_name

        add_video(
            title=label,
            params={
                'mode': 'play',
                'url': info['link'],
                'title': title,
                'image': image,
                'referer': url,
                'label': info.get('label', '')
            },
            icon=item_icon,
            plot='%s - %s' % (title, final_name)
        )

    add_video(
        '[COLOR cyan][B]▶ Otwórz w przeglądarce[/B][/COLOR]',
        {'mode': 'browser', 'url': url, 'title': title, 'image': image},
        icon=item_icon
    )

    end_directory('files')