# -*- coding: UTF-8 -*-
import os
import sys
import requests
import xbmcaddon
import xbmcvfs

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_NAME = ADDON.getAddonInfo('name')
DATAPATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

FANART = os.path.join(ADDON_PATH, 'fanart.jpg')
ICON = os.path.join(ADDON_PATH, 'icon.png')
QUALITY_ICON_720 = os.path.join(ADDON_PATH, '720p.png')
QUALITY_ICON_1080 = os.path.join(ADDON_PATH, '1080p.png')

HANDLE = int(sys.argv[1])
BASE_PLUGIN_URL = sys.argv[0]
BASE_URL = 'https://watchprowrestling.store'

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/120.0.0.0 Safari/537.36')

SESSION = requests.Session()
SESSION.headers.update({'User-Agent': UA})
SESSION.verify = False

PREFERRED_QUALITY = 1080
OKRU_START_QUALITY = 'hd'

BROWSER_ONLY_TYPES = {'pvp', 'dh', 'waav'}

TYPE_NAMES = {
    'dm': 'DailyMotion',
    'dh': 'DailyMotion HD',
    'ok': 'OK.ru',
    'voe': 'VOE',
    'dood': 'Dood',
    'go': 'GoFile',
    'pvp': 'PVP/TubeReplays',
    'waav': 'Waav',
    'fl': 'Flashx',
}

CATEGORIES = [
    {'title': '[B][COLOR red]Most Recent Shows[/COLOR][/B]',
     'url': BASE_URL + '/'},
    {'title': '[B][COLOR yellow]Popular[/COLOR][/B]',
     'url': BASE_URL + '/categorys/popular/'},
    {'title': '[B][COLOR lime]Tonight[/COLOR][/B]',
     'url': BASE_URL + '/categorys/tonight/'},
    {'title': '[COLOR white]WWE[/COLOR]',
     'url': BASE_URL + '/categorys/wwe/'},
    {'title': '[COLOR orange]AEW[/COLOR]',
     'url': BASE_URL + '/categorys/aew/'},
    {'title': '[COLOR gold]Pay Per View[/COLOR]',
     'url': BASE_URL + '/categorys/pay-per-view/'},
    {'title': '[COLOR cyan]Impact / TNA[/COLOR]',
     'url': BASE_URL + '/categorys/impact-wrestling/'},
    {'title': '[COLOR red]NJPW[/COLOR]',
     'url': BASE_URL + '/categorys/njpw/'},
    {'title': '[COLOR pink]Puroresu[/COLOR]',
     'url': BASE_URL + '/categorys/puroresu/'},
    {'title': '[COLOR lightyellow]NWA[/COLOR]',
     'url': BASE_URL + '/categorys/nwa/'},
    {'title': '[COLOR darkred]GCW[/COLOR]',
     'url': BASE_URL + '/categorys/gcw/'},
    {'title': '[COLOR lightgreen]Indy Shows[/COLOR]',
     'url': BASE_URL + '/categorys/indy-shows/'},
    {'title': '[COLOR salmon]MMA / UFC[/COLOR]',
     'url': BASE_URL + '/categorys/mma/'},
    {'title': '[COLOR coral]Boxing[/COLOR]',
     'url': BASE_URL + '/categorys/boxing/'},
    {'title': '[COLOR silver]Documentary[/COLOR]',
     'url': BASE_URL + '/categorys/documentary/'},
    {'title': '[COLOR gold]WrestleMania[/COLOR]',
     'url': BASE_URL + '/categorys/wrestle-mania/'},
]