# -*- coding: UTF-8 -*-
import xbmcgui
import xbmcplugin

from lib.constants import HANDLE, ICON, FANART
from lib.helpers import build_url


def add_directory(title, params, icon=ICON, fanart=FANART, plot=''):
    li = xbmcgui.ListItem(label=title)
    li.setArt({'thumb': icon, 'poster': icon, 'fanart': fanart, 'icon': icon})
    if plot:
        li.getVideoInfoTag().setPlot(plot)
    xbmcplugin.addDirectoryItem(HANDLE, build_url(params), li, True)


def add_video(title, params, icon=ICON, fanart=FANART, plot=''):
    li = xbmcgui.ListItem(label=title)
    li.setProperty('IsPlayable', 'true')
    li.setArt({'thumb': icon, 'poster': icon, 'fanart': fanart, 'icon': icon})
    if plot:
        li.getVideoInfoTag().setPlot(plot)
    xbmcplugin.addDirectoryItem(HANDLE, build_url(params), li, False)


def end_directory(content='files'):
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)