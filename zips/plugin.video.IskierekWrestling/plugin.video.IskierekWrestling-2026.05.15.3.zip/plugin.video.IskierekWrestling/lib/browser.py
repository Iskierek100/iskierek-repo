# -*- coding: UTF-8 -*-
"""
Uniwersalne otwieranie przeglądarki systemowej.
"""
import os
import sys
import subprocess
import xbmc
import xbmcgui

from lib.constants import ADDON_NAME
from lib.helpers import log


def open_browser(url):
    """
    Otwiera URL w domyślnej przeglądarce systemowej.
    Zwraca True jeśli się udało, False jeśli nie.
    """
    log('Otwieram przeglądarkę dla: %s' % url)

    if not url:
        return False

    # 1. Windows
    if xbmc.getCondVisibility('System.Platform.Windows'):
        xbmc.executebuiltin('System.Browse(%s)' % url)
        return True

    # 2. Android
    if xbmc.getCondVisibility('System.Platform.Android'):
        xbmc.executebuiltin(
            'StartAndroidActivity(android.intent.action.VIEW,,,%s)' % url
        )
        return True

    # 3. macOS
    if sys.platform == 'darwin':
        try:
            subprocess.Popen(
                ['open', url],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            return True
        except Exception as e:
            log('macOS open error: %s' % str(e))

    # 4. Linux / SteamOS / BSD
    if os.name == 'posix':
        desktop_openers = [
            ['xdg-open'],
            ['gio', 'open'],
            ['kde-open5'],
            ['kde-open'],
            ['gnome-open'],
            ['flatpak-spawn', '--host', 'xdg-open']
        ]

        for opener in desktop_openers:
            try:
                subprocess.Popen(
                    opener + [url],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                log('SUKCES: Użyto systemowego otwieracza: %s' % opener[0])
                return True
            except Exception as e:
                log('Nieudany opener %s: %s' % (opener[0], str(e)))
                continue

    # 5. Fallback Kodi
    try:
        xbmc.executebuiltin('System.Browse(%s)' % url)
        return True
    except Exception as e:
        log('System.Browse error: %s' % str(e))

    return False


def open_browser_with_confirm(url):
    """
    Otwiera przeglądarkę po potwierdzeniu przez użytkownika.
    """
    if not url:
        return

    confirm = xbmcgui.Dialog().yesno(
        ADDON_NAME,
        "Otworzyć stronę w przeglądarce?",
        yeslabel="Tak",
        nolabel="Nie"
    )

    if not confirm:
        return

    ok = open_browser(url)

    if ok:
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            "Otwarto w przeglądarce",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
    else:
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            "Nie można otworzyć przeglądarki",
            xbmcgui.NOTIFICATION_ERROR,
            4000
        )