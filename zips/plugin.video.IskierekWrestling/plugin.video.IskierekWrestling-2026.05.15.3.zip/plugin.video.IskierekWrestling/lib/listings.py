# -*- coding: UTF-8 -*-
"""
Listowanie pokazów, strona główna, wyszukiwanie.
"""
import re
import os
import requests

import xbmc
import xbmcgui

from lib.constants import ADDON_NAME, ICON, CATEGORIES, DATAPATH, BASE_URL
from lib.helpers import log, get_html, clean_title, get_home_icon
from lib.ui import add_directory, end_directory


def show_home():
    for cat in CATEGORIES:
        icon = get_home_icon(cat['url'])
        add_directory(
            cat['title'],
            {'mode': 'list_shows', 'url': cat['url'], 'page': '1'},
            icon=icon
        )

    add_directory(
        '[B][COLOR cyan]Szukaj / Search[/COLOR][/B]',
        {'mode': 'search'}
    )

    end_directory('files')


def show_search():
    kb = xbmc.Keyboard('', 'Szukaj show...')
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText().strip()
    if not query:
        return
    url = BASE_URL + '/?s=' + requests.utils.quote(query)
    list_shows(url, 1)


def list_shows(url, page):
    page = int(page)
    if page > 1:
        if '/page/' in url:
            url = re.sub(r'/page/\d+/?', '/page/%d/' % page, url)
        else:
            url = url.rstrip('/') + '/page/%d/' % page

    html = get_html(url)
    if not html:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Nie można pobrać strony',
                                      xbmcgui.NOTIFICATION_ERROR)
        end_directory('files')
        return

    try:
        os.makedirs(DATAPATH, exist_ok=True)
        with open(os.path.join(DATAPATH, 'debug_list.html'), 'w', encoding='utf-8') as f:
            f.write(html)
    except Exception:
        pass

    post_images = re.findall(
        r'<img[^>]+class="post-image"[^>]+src="([^"]+)"[^>]+alt="([^"]*)"',
        html
    )

    show_pattern = re.compile(
        r'<a[^>]+href="(https://watchprowrestling\.store/watch-[^"]+)"'
        r'[^>]*class="post-image-container"[^>]*>'
        r'(.*?)'
        r'</a>',
        re.DOTALL
    )

    found = 0
    seen_urls = set()
    items = []

    for match in show_pattern.finditer(html):
        href = match.group(1).split('#')[0].split('?')[0].rstrip('/')
        inner = match.group(2)

        if href in seen_urls:
            continue
        seen_urls.add(href)

        img_m = re.search(
            r'<img[^>]+class="post-image"[^>]+src="([^"]+)"[^>]+alt="([^"]*)"',
            inner
        )

        if img_m:
            img = img_m.group(1)
            title = clean_title(img_m.group(2).strip())
        else:
            img = ICON
            title = ''
            slug = href.split('/watch-')[-1] if '/watch-' in href else ''
            title = clean_title(slug.replace('-', ' ').title()) if slug else href

        if not title or len(title) < 3:
            slug = href.split('/watch-')[-1] if '/watch-' in href else ''
            title = clean_title(slug.replace('-', ' ').title())

        items.append((href, img, title))

    # FALLBACK 1
    if not items:
        log('Fallback: szukam post-image + najblizszy link')
        for img_src, img_alt in post_images:
            idx = html.find(img_src)
            if idx < 0:
                continue
            chunk = html[max(0, idx - 500):idx]
            href_m = re.search(
                r'href="(https://watchprowrestling\.store/watch-[^"]+)"',
                chunk
            )
            if not href_m:
                continue
            href = href_m.group(1).split('#')[0].split('?')[0].rstrip('/')
            if href in seen_urls:
                continue
            seen_urls.add(href)
            title = clean_title(img_alt.strip()) if img_alt else ''
            if not title:
                slug = href.split('/watch-')[-1]
                title = clean_title(slug.replace('-', ' ').title())
            items.append((href, img_src, title))

    # FALLBACK 2
    if not items:
        log('Fallback 2: h2/h3 z linkami')
        h_links = re.findall(
            r'<h[23][^>]*>\s*<a[^>]+href="(https://watchprowrestling\.store/watch-[^"]+)"[^>]*>'
            r'([^<]+)</a>',
            html
        )
        for href, title in h_links:
            href_clean = href.split('#')[0].split('?')[0].rstrip('/')
            if href_clean in seen_urls:
                continue
            seen_urls.add(href_clean)
            items.append((href, ICON, clean_title(title.strip())))

    log('list_shows: znaleziono %d pozycji' % len(items))

    for href, img, title in items:
        add_directory(
            title=title,
            params={'mode': 'show_sources', 'url': href,
                    'title': title, 'image': img},
            icon=img,
            plot=title
        )
        found += 1

    if found == 0:
        add_directory('[COLOR red]Brak wyników[/COLOR]', {'mode': 'home'})

    has_next = ('rel="next"' in html or
                bool(re.search(r'class="[^"]*next[^"]*"', html)))
    if has_next:
        add_directory(
            '[B][COLOR cyan]>> Następna strona (%d) >>[/COLOR][/B]' % (page + 1),
            {'mode': 'list_shows', 'url': url, 'page': str(page + 1)}
        )

    end_directory('files')