# -*- coding: UTF-8 -*-
import re
import os
import xbmc
from urllib.parse import urlencode, urljoin, quote_plus

from lib.constants import (
    ADDON_ID, BASE_PLUGIN_URL, SESSION, ICON,
    QUALITY_ICON_720, QUALITY_ICON_1080
)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def build_url(params):
    return BASE_PLUGIN_URL + '?' + urlencode(params)


def get_html(url, referer=''):
    headers = {'Referer': referer} if referer else {}
    try:
        r = SESSION.get(url, headers=headers, timeout=30)
        r.raise_for_status()
        return r.text
    except Exception as e:
        log('get_html error: %s -> %s' % (url, str(e)), xbmc.LOGERROR)
        return ''


def clean_title(title):
    replacements = {
        '&#8211;': '-', '&#8217;': "'", '&#8230;': '...',
        '&#8222;': '"', '&#8221;': '"', '&#038;': '&',
        '&#039;': "'", '&quot;': '"', '&amp;': '&',
        '&nbsp;': ' ', '&rsquo;': "'", '&oacute;': 'ó',
        '&eacute;': 'é', '[&hellip;]': '...',
    }
    for old, new in replacements.items():
        title = title.replace(old, new)
    title = re.sub(r'^[Ww]atch\s+', '', title)
    title = re.sub(r'\s+', ' ', title).strip()
    return title


def _abs_url(base, u):
    if not u:
        return ''
    u = u.replace('&amp;', '&').strip()
    if u.startswith('//'):
        return 'https:' + u
    return urljoin(base, u)


def detect_quality_from_text(*parts):
    text = ' '.join([p for p in parts if p]).lower()
    if re.search(r'\b(2160|4k|uhd)\b', text):
        return '2160p'
    if re.search(r'\b(1080|fhd)\b', text):
        return '1080p'
    if re.search(r'\b(720|hd)\b', text):
        return '720p'
    if re.search(r'\b(480|sd)\b', text):
        return '480p'
    if re.search(r'\b(360|lq)\b', text):
        return '360p'
    return ''


def quality_label(quality):
    q = (quality or '').upper()
    if '2160' in q or '4K' in q or 'UHD' in q:
        return '[COLOR cyan][2160p][/COLOR] '
    if '1080' in q or 'FHD' in q:
        return '[COLOR lime][1080p][/COLOR] '
    if '720' in q or 'HD' in q:
        return '[COLOR yellow][720p][/COLOR] '
    if '480' in q or 'SD' in q:
        return '[COLOR orange][480p][/COLOR] '
    if '360' in q or 'LQ' in q:
        return '[COLOR gray][360p][/COLOR] '
    return ''


def source_quality_icon(source_type, quality, label=''):
    t = (source_type or '').lower()
    q = (quality or '').upper()
    l = (label or '').strip().lower()

    if t == 'dm':
        return QUALITY_ICON_1080
    if t == 'go':
        if '720' in q or 'HD' in q:
            return QUALITY_ICON_720
        return QUALITY_ICON_1080
    if t == 'voe' or l == 'voe':
        return QUALITY_ICON_720
    if l == 'dood':
        return QUALITY_ICON_720
    if '1080' in q or 'FHD' in q:
        return QUALITY_ICON_1080
    if '720' in q or 'HD' in q:
        return QUALITY_ICON_720
    return ''


def get_home_icon(url):
    html = get_html(url)
    if not html:
        return ICON

    candidates = []

    patterns = [
        r'<meta[^>]+property=["\']og:image(?::secure_url)?["\'][^>]+content=["\']([^"\']+)["\']',
        r'<meta[^>]+name=["\']twitter:image(?::src)?["\'][^>]+content=["\']([^"\']+)["\']',
        r'<link[^>]+rel=["\']image_src["\'][^>]+href=["\']([^"\']+)["\']',
        r'<img[^>]+class="post-image"[^>]+src="([^"]+)"',
        r'<img[^>]+src="([^"]+)"[^>]+class="post-image"',
    ]

    for pat in patterns:
        for m in re.finditer(pat, html, re.I | re.S):
            img = (m.group(1) or '').strip()
            if img:
                candidates.append(img)

    for m in re.finditer(r'<img[^>]+src=["\']([^"\']+)["\']', html, re.I | re.S):
        img = (m.group(1) or '').strip()
        if img:
            candidates.append(img)

    seen = set()
    for img in candidates:
        img = img.replace('&amp;', '&').strip()
        if not img or img in seen:
            continue
        seen.add(img)

        low = img.lower()
        if low.startswith('data:'):
            continue
        if any(x in low for x in ('placeholder', 'blank', 'default', 'avatar')):
            continue
        if 'icon.png' in low:
            continue

        return _abs_url(url, img)

    return ICON