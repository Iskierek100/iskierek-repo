# -*- coding: UTF-8 -*-
import re
import os
from urllib.parse import quote_plus

from lib.constants import UA, SESSION, DATAPATH
from lib.helpers import log

import xbmc

_TRANSLATE_CACHE = {}


def _translate_text_pl(text):
    text = (text or '').strip()
    if not text:
        return text

    if text in _TRANSLATE_CACHE:
        return _TRANSLATE_CACHE[text]

    try:
        api = (
            'https://translate.googleapis.com/translate_a/single'
            '?client=gtx&sl=auto&tl=pl&dt=t&q=' + quote_plus(text)
        )
        r = SESSION.get(api, timeout=20)
        r.raise_for_status()
        data = r.json()

        translated = ''
        if data and isinstance(data, list) and data[0]:
            translated = ''.join([x[0] for x in data[0] if x and x[0]])

        translated = translated or text
        _TRANSLATE_CACHE[text] = translated
        return translated

    except Exception as e:
        log('translate error: %s' % str(e), xbmc.LOGWARNING)
        return text


def _translate_vtt_to_pl(vtt_text):
    vtt_text = vtt_text or ''
    if not vtt_text.strip():
        return ''

    blocks = re.split(r'\n\s*\n', vtt_text.strip())
    out = []

    for block in blocks:
        lines = block.splitlines()
        if not lines:
            continue

        if lines[0].strip().upper().startswith('WEBVTT'):
            out.append(lines[0])
            out.append('')
            continue

        ts_idx = -1
        for i, line in enumerate(lines):
            if '-->' in line:
                ts_idx = i
                break

        if ts_idx < 0:
            out.extend(lines)
            out.append('')
            continue

        out.extend(lines[:ts_idx + 1])

        for line in lines[ts_idx + 1:]:
            plain = re.sub(r'<[^>]+>', '', line).strip()
            if plain:
                out.append(_translate_text_pl(plain))
            else:
                out.append(line)

        out.append('')

    return '\n'.join(out)


def get_dailymotion_subtitle_url(video_id):
    try:
        api = 'https://www.dailymotion.com/player/metadata/video/' + video_id
        headers = {'User-Agent': UA, 'Referer': 'https://www.dailymotion.com/'}
        r = SESSION.get(api, headers=headers, timeout=15)
        r.raise_for_status()
        data = r.json()

        subs = data.get('subtitles') or data.get('captions') or {}

        if isinstance(subs, dict):
            for key in ('en', 'en-us', 'en_us', 'en-gb', 'auto'):
                entry = subs.get(key) or subs.get(key.upper()) or subs.get(key.lower())
                if isinstance(entry, dict):
                    url = entry.get('url') or entry.get('href') or ''
                    if url:
                        return url
                elif isinstance(entry, str) and entry:
                    return entry

            for _, entry in subs.items():
                if isinstance(entry, dict):
                    url = entry.get('url') or entry.get('href') or ''
                    if url:
                        return url
                elif isinstance(entry, str) and entry:
                    return entry

        if isinstance(subs, list):
            for entry in subs:
                lang = (entry.get('lang') or entry.get('language') or '').lower()
                url = entry.get('url') or entry.get('href') or ''
                if url and (lang.startswith('en') or lang == 'auto' or not lang):
                    return url

    except Exception as e:
        log('DM subtitles lookup error: %s' % str(e), xbmc.LOGWARNING)

    return ''


def download_translate_dm_subtitles(video_id):
    sub_url = get_dailymotion_subtitle_url(video_id)
    if not sub_url:
        log('DM subtitles: brak URL', xbmc.LOGWARNING)
        return ''

    try:
        r = SESSION.get(sub_url, timeout=20)
        r.raise_for_status()
        vtt = r.text

        if 'WEBVTT' not in vtt[:200].upper():
            log('DM subtitles: plik nie wygląda jak VTT', xbmc.LOGWARNING)
            return ''

        translated = _translate_vtt_to_pl(vtt)
        if not translated.strip():
            return ''

        subs_dir = os.path.join(DATAPATH, 'subs')
        os.makedirs(subs_dir, exist_ok=True)

        out_path = os.path.join(subs_dir, 'dm_%s_pl.vtt' % video_id)
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(translated)

        log('DM subtitles saved: %s' % out_path)
        return out_path

    except Exception as e:
        log('DM subtitles download/translate error: %s' % str(e), xbmc.LOGWARNING)
        return ''