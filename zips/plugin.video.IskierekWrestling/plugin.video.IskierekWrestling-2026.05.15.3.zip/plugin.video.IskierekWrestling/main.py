# -*- coding: UTF-8 -*-
"""
Pro Wrestling Kodi Addon v2.3
"""
import sys
import base64
import re
from urllib.parse import parse_qsl, urlparse, parse_qs

import xbmc
import xbmcgui
import xbmcplugin

from lib.constants import ADDON_NAME, HANDLE, ICON
from lib.helpers import log
from lib.browser import open_browser, open_browser_with_confirm
from lib.listings import show_home, show_search, list_shows
from lib.sources import show_sources, show_browser_sources

try:
    import resolveurl as urlresolver
except ImportError:
    urlresolver = None


def play(url, title, image, referer, label=''):
    url = (url or '').replace('&amp;', '&')
    referer = (referer or '').replace('&amp;', '&')

    # Ekstrakcja linku
    real_url = url
    if 'vptips.online' in url:
        parsed = urlparse(url)
        qs = parse_qs(parsed.query)
        srv_type = (qs.get('type', [''])[0] or '').lower()
        srv_id = qs.get('id', qs.get('ids', ['']))[0]

        mapping = {
            'dm': 'https://www.dailymotion.com/video/%s',
            'ok': 'https://ok.ru/video/%s',
            'voe': 'https://voe.sx/%s',
            'dood': 'https://dood.to/e/%s',
            'waav': 'https://waav.tv/v/%s',
            'pvp': 'https://tubereplays.com/v/%s'
        }
        if srv_type in mapping:
            real_url = mapping[srv_type] % srv_id
        elif srv_type == 'go':
            try:
                decoded = base64.b64decode(srv_id + '==').decode('utf-8', errors='ignore')
                real_url = decoded if 'gofile.io' in decoded else 'https://gofile.io/d/%s' % srv_id
            except Exception:
                real_url = 'https://gofile.io/d/%s' % srv_id

    # ResolveURL
    if urlresolver:
        log('Próba ResolveURL: %s' % real_url)
        if urlresolver.HostedMediaFile(real_url).valid_url():
            stream_url = urlresolver.resolve(real_url)
            if stream_url:
                log('Odtwarzam przez Resolver')
                li = xbmcgui.ListItem(path=stream_url)
                li.setInfo('video', {'title': title})
                xbmcplugin.setResolvedUrl(HANDLE, True, listitem=li)
                return

    # Fallback: przeglądarka
    target = referer if 'vptips' in url else real_url
    if xbmcgui.Dialog().yesno("Błąd odtwarzania",
                               "ResolveURL nie obsłużył linku. Otworzyć w przeglądarce?"):
        ok = open_browser(target)
        if not ok:
            xbmcgui.Dialog().notification(
                ADDON_NAME,
                "Nie można otworzyć przeglądarki",
                xbmcgui.NOTIFICATION_ERROR,
                4000
            )


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    mode = params.get('mode', '')

    log('router mode=%s' % mode)

    if not mode or mode == 'home':
        show_home()
    elif mode == 'search':
        show_search()
    elif mode == 'list_shows':
        list_shows(params['url'], params.get('page', '1'))
    elif mode == 'show_sources':
        show_sources(params['url'], params.get('title', ''), params.get('image', ICON))
    elif mode == 'play':
        play(params['url'], params.get('title', ''),
             params.get('image', ''), params.get('referer', ''),
             params.get('label', ''))
    elif mode == 'browser':
        open_browser_with_confirm(params.get('url', ''))
    elif mode == 'browser_sources':
        show_browser_sources(
            params.get('url', ''),
            params.get('title', ''),
            params.get('image', '')
        )
    elif mode == 'none':
        pass


if __name__ == '__main__':
    router(sys.argv[2][1:])